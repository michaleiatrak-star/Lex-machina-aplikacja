﻿param(
  [string]$Configuration = "release",
  # The standalone offline installer reuses this thin payload; its NSIS hook
  # runs bootstrap\windows-offline-bundle-install.ps1 when the offline runtime
  # zip sits beside the installer. The online installer must not carry them.
  [switch]$IncludeOfflineHelpers
)

$ErrorActionPreference = "Stop"
$installer = Split-Path -Parent $MyInvocation.MyCommand.Path
$repo = (Resolve-Path (Join-Path $installer "..\..")).Path
$desktop = Join-Path $repo "app\lex-desktop"
$tauri = Join-Path $desktop "src-tauri"
$payload = Join-Path $tauri "runtime"

if ($env:OS -ne "Windows_NT") { throw "Windows online bootstrap payload must be built on Windows." }

Write-Host "[brand] Materialize pinned Windows icon"
& (Join-Path $installer "materialize-brand-icon.ps1")

Write-Host "[0/4] Installer state machine self-test"
& (Join-Path $installer "installer-state-machine-selftest.ps1")
if ($LASTEXITCODE -ne 0) { throw "Installer state machine self-test failed" }

Remove-Item $payload -Recurse -Force -ErrorAction SilentlyContinue
New-Item $payload -ItemType Directory | Out-Null

Write-Host "[1/4] Build runtime JS"
Push-Location (Join-Path $repo "app\lex-runtime")
try {
  npm install --no-audit --no-fund
  if ($LASTEXITCODE -ne 0) { throw "npm install runtime failed" }
  npm run build
  if ($LASTEXITCODE -ne 0) { throw "runtime build failed" }
} finally { Pop-Location }

$appStage = Join-Path $payload "app"
New-Item $appStage -ItemType Directory | Out-Null
Copy-Item (Join-Path $repo "app\lex-runtime\dist") $appStage -Recurse
Copy-Item (Join-Path $repo "app\lex-runtime\package.json") $appStage
# Strona aplikacji w przeglądarce (http://127.0.0.1:4317): ten sam interfejs co okno desktop.
Push-Location (Join-Path $repo "app\lex-web")
try {
  npm install --no-audit --no-fund
  if ($LASTEXITCODE -ne 0) { throw "npm install web failed" }
  npm run build
  if ($LASTEXITCODE -ne 0) { throw "web build failed" }
} finally { Pop-Location }
Copy-Item (Join-Path $repo "app\lex-web\dist") (Join-Path $appStage "web") -Recurse
# The publisher's Google OAuth client ("Zaloguj kontem Google" for every user, nothing to set up):
# from the repository secret LEX_GOOGLE_OAUTH_CLIENT_JSON (Google Cloud Console, "Desktop app" JSON).
$googleClient = Join-Path $appStage "config\google-oauth-client.json"
if ($env:LEX_GOOGLE_OAUTH_CLIENT_JSON) {
  New-Item (Split-Path $googleClient) -ItemType Directory -Force | Out-Null
  [System.IO.File]::WriteAllText($googleClient, $env:LEX_GOOGLE_OAUTH_CLIENT_JSON)
} elseif (Test-Path (Join-Path $repo "app\lex-runtime\config\google-oauth-client.json")) {
  New-Item (Split-Path $googleClient) -ItemType Directory -Force | Out-Null
  Copy-Item (Join-Path $repo "app\lex-runtime\config\google-oauth-client.json") $googleClient
} else {
  Write-Warning "No Google OAuth client (LEX_GOOGLE_OAUTH_CLIENT_JSON): Google sign-in stays off in this build."
}
Push-Location $appStage
try {
  npm install --omit=dev --ignore-scripts --no-audit --no-fund
  if ($LASTEXITCODE -ne 0) { throw "production runtime dependencies failed" }
  npm ls --omit=dev --all --json |
    Out-File -FilePath (Join-Path $payload "npm-dependency-tree.json") -Encoding utf8
  if ($LASTEXITCODE -ne 0) { throw "runtime production dependency provenance failed" }
} finally { Pop-Location }

Write-Host "[2/4] Copy workers, corpus, manifest and bootstrap"
Copy-Item (Join-Path $repo "app\ocr") (Join-Path $payload "ocr") -Recurse
Copy-Item (Join-Path $repo "app\privacy") (Join-Path $payload "privacy") -Recurse
Copy-Item (Join-Path $repo "app\storage") (Join-Path $payload "storage") -Recurse
Copy-Item (Join-Path $repo "Wersja rozwojowa rozpakowana") (Join-Path $payload "corpus") -Recurse
# Pakiet serwerów MCP musi mieć bajty z sumy w CHECKSUMS.sha256 skilla (bez CRLF z checkoutu).
$mcpSkill = Join-Path $payload "corpus\audyt-systemu-v4"
$mcpBundle = Join-Path $mcpSkill "mcp-servers\dist\lex-mcp.mjs"
$mcpExpected = (Get-Content (Join-Path $mcpSkill "CHECKSUMS.sha256") |
  Where-Object { $_ -match "\s\./mcp-servers/dist/lex-mcp\.mjs$" } |
  ForEach-Object { ($_ -split "\s+")[0] } | Select-Object -First 1)
$mcpActual = (Get-FileHash $mcpBundle -Algorithm SHA256).Hash.ToLowerInvariant()
if (-not $mcpExpected -or $mcpActual -ne $mcpExpected.ToLowerInvariant()) {
  throw "MCP_BUNDLE_CHECKSUM_MISMATCH: lex-mcp.mjs $mcpActual, CHECKSUMS.sha256 $mcpExpected"
}
Copy-Item (Join-Path $repo "LICENSE") (Join-Path $payload "LICENSE.txt")
Copy-Item (Join-Path $repo "POLITYKA-PRYWATNOSCI.md") (Join-Path $payload "POLITYKA-PRYWATNOSCI.md")
Copy-Item (Join-Path $installer "windows-release-source.json") (Join-Path $payload "release-source.json")
Copy-Item (Join-Path $installer "windows-release-requirements.txt") (Join-Path $payload "release-requirements.txt")

# App-local Visual C++ runtime, used by the bootstrap only when the system
# runtime is older than required and cannot be upgraded (MSI 1603 after a
# cleaned Package Cache). Source: the redistributable folder of Visual Studio on
# the build machine, the source Microsoft documents for app-local deployment.
Write-Host "[2b/4] App-local Visual C++ runtime"
# The floor the bootstrap accepts for a working runtime (read from it, not repeated here).
$vcRequired = [Version]([regex]::Match((Get-Content -Raw (Join-Path $installer "windows-online-bootstrap.ps1")), '\$script:VcRuntimeFloor = \[Version\]"([0-9.]+)"').Groups[1].Value)
$fileVersion = { param($path) $info = (Get-Item -LiteralPath $path).VersionInfo; [Version]::new($info.FileMajorPart, $info.FileMinorPart, $info.FileBuildPart, $info.FilePrivatePart) }
$vswhere = Join-Path ${env:ProgramFiles(x86)} "Microsoft Visual Studio\Installer\vswhere.exe"
$vsRoots = if (Test-Path -LiteralPath $vswhere) { @(& $vswhere -all -products * -property installationPath) } else { @() }
$crt = $vsRoots |
  ForEach-Object { Get-ChildItem -LiteralPath (Join-Path $_ "VC\Redist\MSVC") -Directory -ErrorAction SilentlyContinue } |
  ForEach-Object { Get-ChildItem -LiteralPath (Join-Path $_.FullName "x64") -Directory -Filter "Microsoft.VC*.CRT" -ErrorAction SilentlyContinue } |
  Where-Object { Test-Path -LiteralPath (Join-Path $_.FullName "vcruntime140.dll") } |
  Sort-Object { & $fileVersion (Join-Path $_.FullName "vcruntime140.dll") } -Descending |
  Select-Object -First 1
if (-not $crt) {
  Write-Warning "VC_APPLOCAL_NOT_BUNDLED: no Visual Studio redistributable CRT on the build machine"
} else {
  $crtVersion = & $fileVersion (Join-Path $crt.FullName "vcruntime140.dll")
  if ($crtVersion -lt $vcRequired) {
    Write-Warning "VC_APPLOCAL_NOT_BUNDLED: build machine CRT $crtVersion is older than the floor $vcRequired"
  } else {
    $vcAppLocal = Join-Path $payload "prerequisites\vc-applocal"
    New-Item $vcAppLocal -ItemType Directory -Force | Out-Null
    Copy-Item (Join-Path $crt.FullName "*.dll") $vcAppLocal
    $openMp = Get-ChildItem -LiteralPath $crt.Parent.FullName -Directory -Filter "Microsoft.VC*.OpenMP" -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($openMp) { Copy-Item (Join-Path $openMp.FullName "*.dll") $vcAppLocal }
    Write-Host "VC_APPLOCAL_BUNDLED: $crtVersion from $($crt.FullName) ($((Get-ChildItem $vcAppLocal -Filter *.dll).Count) DLLs)"
  }
}

$bootstrap = Join-Path $payload "bootstrap"
New-Item $bootstrap -ItemType Directory | Out-Null
foreach ($file in @(
  "windows-online-bootstrap.ps1",
  "bootstrap-run.ps1",
  "bootstrap-progress.ps1",
  "bootstrap-progress-window.ps1",
  "app-update-transaction.ps1",
  "app-update-verification.ps1",
  "install-local-llm.ps1",
  "install-local-vision.ps1",
  "configure-llama-native-web.ps1",
  "llama-web-mcp.py",
  "llama-legal-skills-mcp.py",
  "llama-local-documents-mcp.py",
  "mistral-nemo-web-grounded.jinja",
  "bielik-web-grounded.jinja",
  "get-install-state.ps1",
  "installer-state-machine-selftest.ps1",
  "prefetch-release-models.py",
  "verify-python-package-set.py",
  "generate-component-lock.ps1",
  "windows-payload-selftest.ps1",
  "windows-payload-python-selftest.py"
)) {
  Copy-Item (Join-Path $installer $file) (Join-Path $bootstrap $file)
}
$offlineHelpers = @(
  "windows-offline-bundle-install.ps1",
  "extract-offline-zip.ps1"
)
if ($IncludeOfflineHelpers) {
  foreach ($file in $offlineHelpers) {
    Copy-Item (Join-Path $installer $file) (Join-Path $bootstrap $file)
  }
}

Write-Host "[3/4] Build native runtime sidecar"
Push-Location $desktop
try {
  cargo build --release --bin lex-runtime-sidecar --manifest-path src-tauri/Cargo.toml
  if ($LASTEXITCODE -ne 0) { throw "Runtime sidecar build failed" }
} finally { Pop-Location }
$sidecar = Join-Path $tauri "target\release\lex-runtime-sidecar.exe"
if (-not (Test-Path $sidecar)) { throw "Built runtime sidecar not found" }
Copy-Item $sidecar (Join-Path $payload "lex-runtime-sidecar.exe")

Write-Host "[4/4] Thin payload contract"
foreach ($required in @(
  "app\dist\http\server.js",
  "app\web\index.html",
  "lex-runtime-sidecar.exe",
  "release-source.json",
  "release-requirements.txt",
  "bootstrap\windows-online-bootstrap.ps1",
  "bootstrap\bootstrap-run.ps1",
  "bootstrap\bootstrap-progress.ps1",
  "bootstrap\bootstrap-progress-window.ps1",
  "bootstrap\app-update-transaction.ps1",
  "bootstrap\install-local-llm.ps1",
  "bootstrap\install-local-vision.ps1",
  "bootstrap\configure-llama-native-web.ps1",
  "bootstrap\llama-web-mcp.py",
  "bootstrap\llama-legal-skills-mcp.py",
  "bootstrap\llama-local-documents-mcp.py",
  "bootstrap\mistral-nemo-web-grounded.jinja",
  "bootstrap\bielik-web-grounded.jinja",
  "bootstrap\get-install-state.ps1",
  "bootstrap\installer-state-machine-selftest.ps1",
  "bootstrap\prefetch-release-models.py",
  "bootstrap\verify-python-package-set.py",
  "bootstrap\windows-payload-selftest.ps1",
  "bootstrap\windows-payload-python-selftest.py"
)) {
  if (-not (Test-Path -LiteralPath (Join-Path $payload $required) -PathType Leaf)) {
    throw "ONLINE_PAYLOAD_REQUIRED_FILE_MISSING:$required"
  }
}

$forbiddenComponents = @(
  "app\node_modules\.bin\codex.cmd",
  "app\node_modules\.bin\claude.cmd",
  "app\node_modules\@openai\codex",
  "app\node_modules\@anthropic-ai\claude-code"
)
$offlineHelperPaths = $offlineHelpers | ForEach-Object { "bootstrap\$_" }
if ($IncludeOfflineHelpers) {
  foreach ($required in $offlineHelperPaths) {
    if (-not (Test-Path -LiteralPath (Join-Path $payload $required) -PathType Leaf)) {
      throw "OFFLINE_PAYLOAD_REQUIRED_FILE_MISSING:$required"
    }
  }
} else {
  $forbiddenComponents += $offlineHelperPaths
}
foreach ($forbidden in $forbiddenComponents) {
  if (Test-Path -LiteralPath (Join-Path $payload $forbidden)) {
    throw "ONLINE_PAYLOAD_FORBIDDEN_OPTIONAL_COMPONENT_PRESENT:$forbidden"
  }
}

Write-Host "G33_ONLINE_BOOTSTRAP_PAYLOAD_READY:$payload"
