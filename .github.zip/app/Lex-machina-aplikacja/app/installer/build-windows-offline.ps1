﻿param(
  [string]$Configuration = "release"
)

$ErrorActionPreference = "Stop"
$installer = Split-Path -Parent $MyInvocation.MyCommand.Path
$repo = (Resolve-Path (Join-Path $installer "..\..")).Path
$desktop = Join-Path $repo "app\lex-desktop"
$tauri = Join-Path $desktop "src-tauri"
$payload = Join-Path $tauri "runtime"
$sourceLock = Get-Content -Raw (Join-Path $installer "windows-release-source.json") | ConvertFrom-Json

function Assert-Sha256([string]$Path, [string]$Expected, [string]$Label) {
  if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { throw "SOURCE_FILE_MISSING:${Label}:$Path" }
  if ($Expected -notmatch '^[a-fA-F0-9]{64}$') { throw "SOURCE_HASH_INVALID:$Label" }
  $actual = (Get-FileHash -Algorithm SHA256 -LiteralPath $Path).Hash.ToLowerInvariant()
  if ($actual -ne $Expected.ToLowerInvariant()) { throw "SOURCE_HASH_MISMATCH:$Label expected=$Expected actual=$actual" }
  Write-Host "Verified $Label SHA-256: $actual"
}

if ($env:OS -ne "Windows_NT") { throw "Windows offline payload must be built on Windows." }

Write-Host "[0/10] Installer state machine self-test"
& (Join-Path $installer "installer-state-machine-selftest.ps1")
if ($LASTEXITCODE -ne 0) { throw "Installer state machine self-test failed" }

Remove-Item $payload -Recurse -Force -ErrorAction SilentlyContinue
New-Item $payload -ItemType Directory | Out-Null
$cache = Join-Path $installer ".cache"
New-Item $cache -ItemType Directory -Force | Out-Null

Write-Host "[1/10] Build runtime JS"
Push-Location (Join-Path $repo "app\lex-runtime")
try {
  npm install --no-audit --no-fund
  if ($LASTEXITCODE -ne 0) { throw "npm install runtime failed" }
  npm run build
  if ($LASTEXITCODE -ne 0) { throw "runtime build failed" }
} finally { Pop-Location }

$appStage = Join-Path $payload "app"
New-Item $appStage -ItemType Directory | Out-Null
Copy-Item (Join-Path $repo "app\lex-runtime\dist") $appStage -Recurse
Copy-Item (Join-Path $repo "app\lex-runtime\package.json") $appStage
# Strona aplikacji w przeglądarce (http://127.0.0.1:4317): ten sam interfejs co okno desktop.
Push-Location (Join-Path $repo "app\lex-web")
try {
  npm install --no-audit --no-fund
  if ($LASTEXITCODE -ne 0) { throw "npm install web failed" }
  npm run build
  if ($LASTEXITCODE -ne 0) { throw "web build failed" }
} finally { Pop-Location }
Copy-Item (Join-Path $repo "app\lex-web\dist") (Join-Path $appStage "web") -Recurse
Copy-Item (Join-Path $installer "windows-release-source.json") (Join-Path $payload "release-source.json")
Copy-Item (Join-Path $installer "windows-release-requirements.txt") (Join-Path $payload "release-requirements.txt")
Push-Location $appStage
try {
  npm install --omit=dev --ignore-scripts --no-audit --no-fund
  if ($LASTEXITCODE -ne 0) { throw "production runtime dependencies failed" }
  npm ls --omit=dev --all --json | Out-File -FilePath (Join-Path $payload "npm-dependency-tree.json") -Encoding utf8
  if ($LASTEXITCODE -ne 0) { throw "runtime production dependency provenance failed" }
} finally { Pop-Location }

Write-Host "[2/10] Copy workers, corpus and bootstrap"
Copy-Item (Join-Path $repo "app\ocr") (Join-Path $payload "ocr") -Recurse
Copy-Item (Join-Path $repo "app\privacy") (Join-Path $payload "privacy") -Recurse
Copy-Item (Join-Path $repo "app\storage") (Join-Path $payload "storage") -Recurse
Copy-Item (Join-Path $repo "Wersja rozwojowa rozpakowana") (Join-Path $payload "corpus") -Recurse
$bootstrap = Join-Path $payload "bootstrap"
New-Item $bootstrap -ItemType Directory | Out-Null
foreach ($file in @(
  "windows-online-bootstrap.ps1",
  "bootstrap-run.ps1",
  "bootstrap-progress.ps1",
  "bootstrap-progress-window.ps1",
  "windows-offline-bundle-install.ps1",
  "extract-offline-zip.ps1",
  "app-update-transaction.ps1",
  "app-update-verification.ps1",
  "install-local-llm.ps1",
  "install-local-vision.ps1",
  "configure-llama-native-web.ps1",
  "llama-web-mcp.py",
  "llama-legal-skills-mcp.py",
  "llama-local-documents-mcp.py",
  "mistral-nemo-web-grounded.jinja",
  "bielik-web-grounded.jinja",
  "get-install-state.ps1",
  "installer-state-machine-selftest.ps1",
  "prefetch-release-models.py",
  "verify-python-package-set.py",
  "generate-component-lock.ps1",
  "windows-payload-selftest.ps1",
  "windows-payload-python-selftest.py"
)) {
  Copy-Item (Join-Path $installer $file) (Join-Path $bootstrap $file)
}

Write-Host "[3/10] Private Node"
$nodeZip = Join-Path $cache "node-$($sourceLock.runtime.node.version)-win-x64.zip"
Invoke-WebRequest -UseBasicParsing -Uri $sourceLock.runtime.node.url -OutFile $nodeZip
Assert-Sha256 $nodeZip $sourceLock.runtime.node.sha256 "node-runtime-source"
$nodeExtract = Join-Path $cache "node-extract"
Remove-Item $nodeExtract -Recurse -Force -ErrorAction SilentlyContinue
Expand-Archive -Path $nodeZip -DestinationPath $nodeExtract -Force
$nodeDir = Get-ChildItem $nodeExtract -Directory | Select-Object -First 1
if (-not $nodeDir) { throw "NODE_ARCHIVE_LAYOUT_INVALID" }
Copy-Item $nodeDir.FullName (Join-Path $payload "node") -Recurse

Write-Host "[4/10] Private Python"
$pythonInstaller = Join-Path $cache "python-$($sourceLock.runtime.python.version)-amd64.exe"
Invoke-WebRequest -UseBasicParsing -Uri $sourceLock.runtime.python.url -OutFile $pythonInstaller
Assert-Sha256 $pythonInstaller $sourceLock.runtime.python.sha256 "python-runtime-source"
$pythonDir = Join-Path $payload "python"
$args = @(
  "/quiet", "InstallAllUsers=0", "TargetDir=$pythonDir", "Include_launcher=0",
  "Include_test=0", "Include_doc=0", "Include_tcltk=0", "Include_tools=0",
  "Include_pip=1", "PrependPath=0", "Shortcuts=0"
)
$install = Start-Process -FilePath $pythonInstaller -ArgumentList $args -Wait -PassThru
if ($install.ExitCode -ne 0) { throw "Private Python install failed: $($install.ExitCode)" }
$python = Join-Path $pythonDir "python.exe"
if (-not (Test-Path -LiteralPath $python -PathType Leaf)) { throw "PRIVATE_PYTHON_MISSING" }

Write-Host "[5/10] Pinned Python/ML packages"
& $python -m pip install --disable-pip-version-check --no-warn-script-location -r (Join-Path $installer "windows-release-requirements.txt")
if ($LASTEXITCODE -ne 0) { throw "Pinned Python package install failed" }
& $python -m pip freeze --all | Sort-Object | Out-File -FilePath (Join-Path $payload "python-dependency-tree.txt") -Encoding utf8
if ($LASTEXITCODE -ne 0) { throw "Python dependency provenance failed" }

Write-Host "[6/10] Prefetch OCR/NER models"
$modelRoot = Join-Path $payload "models"
New-Item $modelRoot -ItemType Directory -Force | Out-Null
& $python (Join-Path $installer "prefetch-release-models.py") $modelRoot
if ($LASTEXITCODE -ne 0) { throw "Model prefetch failed" }

Write-Host "[7/10] Bundle Visual C++ runtime prerequisite"
$prerequisites = Join-Path $payload "prerequisites"
New-Item $prerequisites -ItemType Directory -Force | Out-Null
$vcSource = $sourceLock.systemPrerequisites.visualCppRuntime
$vcRedist = Join-Path $cache "vc_redist.x64-$($vcSource.version).exe"
Invoke-WebRequest -UseBasicParsing -Uri $vcSource.url -OutFile $vcRedist
Assert-Sha256 $vcRedist $vcSource.sha256 "visual-cpp-runtime-source"
Copy-Item $vcRedist (Join-Path $prerequisites "vc_redist.x64.exe")

# App-local Visual C++ runtime, used by the offline install only when the system
# runtime is older than required and cannot be upgraded (MSI 1603 after a
# cleaned Package Cache). Source: the redistributable folder of Visual Studio on
# the build machine, the source Microsoft documents for app-local deployment.
Write-Host "[7b/10] App-local Visual C++ runtime"
# The floor the bootstrap accepts for a working runtime (read from it, not repeated here).
$vcRequired = [Version]([regex]::Match((Get-Content -Raw (Join-Path $installer "windows-offline-bundle-install.ps1")), '\$script:VcRuntimeFloor = \[Version\]"([0-9.]+)"').Groups[1].Value)
$fileVersion = { param($path) $info = (Get-Item -LiteralPath $path).VersionInfo; [Version]::new($info.FileMajorPart, $info.FileMinorPart, $info.FileBuildPart, $info.FilePrivatePart) }
$vswhere = Join-Path ${env:ProgramFiles(x86)} "Microsoft Visual Studio\Installer\vswhere.exe"
$vsRoots = if (Test-Path -LiteralPath $vswhere) { @(& $vswhere -all -products * -property installationPath) } else { @() }
$crt = $vsRoots |
  ForEach-Object { Get-ChildItem -LiteralPath (Join-Path $_ "VC\Redist\MSVC") -Directory -ErrorAction SilentlyContinue } |
  ForEach-Object { Get-ChildItem -LiteralPath (Join-Path $_.FullName "x64") -Directory -Filter "Microsoft.VC*.CRT" -ErrorAction SilentlyContinue } |
  Where-Object { Test-Path -LiteralPath (Join-Path $_.FullName "vcruntime140.dll") } |
  Sort-Object { & $fileVersion (Join-Path $_.FullName "vcruntime140.dll") } -Descending |
  Select-Object -First 1
if (-not $crt) {
  Write-Warning "VC_APPLOCAL_NOT_BUNDLED: no Visual Studio redistributable CRT on the build machine"
} else {
  $crtVersion = & $fileVersion (Join-Path $crt.FullName "vcruntime140.dll")
  if ($crtVersion -lt $vcRequired) {
    Write-Warning "VC_APPLOCAL_NOT_BUNDLED: build machine CRT $crtVersion is older than the floor $vcRequired"
  } else {
    $vcAppLocal = Join-Path $payload "prerequisites\vc-applocal"
    New-Item $vcAppLocal -ItemType Directory -Force | Out-Null
    Copy-Item (Join-Path $crt.FullName "*.dll") $vcAppLocal
    $openMp = Get-ChildItem -LiteralPath $crt.Parent.FullName -Directory -Filter "Microsoft.VC*.OpenMP" -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($openMp) { Copy-Item (Join-Path $openMp.FullName "*.dll") $vcAppLocal }
    Write-Host "VC_APPLOCAL_BUNDLED: $crtVersion from $($crt.FullName) ($((Get-ChildItem $vcAppLocal -Filter *.dll).Count) DLLs)"
  }
}

Write-Host "Install bundled Visual C++ runtime prerequisite for payload self-test"
$vcInstall = Start-Process -FilePath $vcRedist -ArgumentList @(
  "/install", "/quiet", "/norestart"
) -Wait -PassThru
if ($vcInstall.ExitCode -notin @(0, 1638, 3010)) {
  throw "Visual C++ runtime prerequisite install failed: $($vcInstall.ExitCode)"
}
Write-Host "Visual C++ runtime prerequisite exit code: $($vcInstall.ExitCode)"

Write-Host "[8/10] Build native runtime sidecar"
Push-Location $desktop
try {
  cargo build --release --bin lex-runtime-sidecar --manifest-path src-tauri/Cargo.toml
  if ($LASTEXITCODE -ne 0) { throw "Runtime sidecar build failed" }
} finally { Pop-Location }
$sidecar = Join-Path $tauri "target\release\lex-runtime-sidecar.exe"
if (-not (Test-Path $sidecar)) { throw "Built runtime sidecar not found" }
Copy-Item $sidecar (Join-Path $payload "lex-runtime-sidecar.exe")

Write-Host "[9/10] Generate immutable component lock"
$lock = Join-Path $payload "component-lock.json"
& (Join-Path $installer "generate-component-lock.ps1") -PayloadRoot $payload -Output $lock
if ($LASTEXITCODE -ne 0) { throw "Component lock failed" }

Write-Host "[10/10] Offline self-test"
& (Join-Path $installer "windows-payload-selftest.ps1") -PayloadRoot $payload
if ($LASTEXITCODE -ne 0) { throw "Offline payload self-test failed" }

Write-Host "G33_PAYLOAD_READY:LOCAL_AI_OPTIONAL:$payload"
