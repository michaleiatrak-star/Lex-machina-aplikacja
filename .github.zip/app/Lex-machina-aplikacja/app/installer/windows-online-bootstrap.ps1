﻿param(
  [Parameter(Mandatory=$true)][string]$RuntimeRoot
)

$ErrorActionPreference = "Stop"
. (Join-Path $PSScriptRoot "bootstrap-progress.ps1")

$runtime = [IO.Path]::GetFullPath($RuntimeRoot)
$manifestPath = Join-Path $runtime "release-source.json"
$requirements = Join-Path $runtime "release-requirements.txt"
$bootstrapRoot = Join-Path $runtime "bootstrap"
$manifest = Get-Content -Raw -LiteralPath $manifestPath | ConvertFrom-Json
$cache = Join-Path $env:LOCALAPPDATA "LexMachina\bootstrap-cache"
New-Item -ItemType Directory -Force -Path $cache | Out-Null

# Account-session CLIs are optional and provisioned lazily after the user
# selects ChatGPT/Claude account login. Remove stale bundled copies from
# upgrades so the online runtime remains thin.
foreach ($staleOptionalClient in @(
  (Join-Path $runtime "app\node_modules\@openai\codex"),
  (Join-Path $runtime "app\node_modules\@anthropic-ai\claude-code"),
  (Join-Path $runtime "app\node_modules\.bin\codex"),
  (Join-Path $runtime "app\node_modules\.bin\codex.cmd"),
  (Join-Path $runtime "app\node_modules\.bin\claude"),
  (Join-Path $runtime "app\node_modules\.bin\claude.cmd")
)) {
  Remove-Item -LiteralPath $staleOptionalClient -Recurse -Force -ErrorAction SilentlyContinue
}

# NSIS invokes Windows PowerShell directly. On some clean-machine/CI hosts its
# inherited module path does not expose the built-in Get-FileHash cmdlet.
# Provide a SHA-256-compatible fallback so this bootstrap and the child
# component-lock/self-test scripts remain independent of module auto-loading.
if (-not (Get-Command Get-FileHash -ErrorAction SilentlyContinue)) {
  function Get-FileHash {
    param(
      [string]$Path,
      [string]$LiteralPath,
      [string]$Algorithm = "SHA256"
    )
    if ($Algorithm.ToUpperInvariant() -ne "SHA256") {
      throw "BOOTSTRAP_HASH_ALGORITHM_UNSUPPORTED:$Algorithm"
    }
    $target = if ($LiteralPath) { $LiteralPath } else { $Path }
    if (-not $target) { throw "BOOTSTRAP_HASH_PATH_MISSING" }
    $stream = [IO.File]::OpenRead($target)
    try {
      $sha = [Security.Cryptography.SHA256]::Create()
      try {
        $bytes = $sha.ComputeHash($stream)
      } finally {
        $sha.Dispose()
      }
    } finally {
      $stream.Dispose()
    }
    [pscustomobject]@{
      Algorithm = "SHA256"
      Hash = ([BitConverter]::ToString($bytes) -replace '-','')
      Path = [IO.Path]::GetFullPath($target)
    }
  }
}

function Test-IsAdministrator {
  $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
  $principal = [Security.Principal.WindowsPrincipal]::new($identity)
  return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

# Visual C++ 2015-2022 x64 runtime: the newest version seen in the registry
# (both views) and in the System32 DLLs. A machine whose Package Cache was
# cleaned keeps a working runtime but cannot be upgraded (MSI 1603), so the
# DLLs count as well as the registry.
$script:VcRuntimeFloor = [Version]"14.40.33810" # VS 17.10 runtime: oldest that runs current llama.cpp/ONNX builds
function Get-VcRuntimeVersion {
  $found = @()
  foreach ($key in @(
    "HKLM:\SOFTWARE\Microsoft\VisualStudio\14.0\VC\Runtimes\x64",
    "HKLM:\SOFTWARE\WOW6432Node\Microsoft\VisualStudio\14.0\VC\Runtimes\x64"
  )) {
    try {
      if ((Get-ItemPropertyValue -Path $key -Name Installed -ErrorAction Stop) -eq 1) {
        $found += [Version]((Get-ItemPropertyValue -Path $key -Name Version -ErrorAction Stop).ToString().TrimStart("v"))
      }
    } catch {}
  }
  $dllVersions = @()
  foreach ($dll in @("vcruntime140.dll", "vcruntime140_1.dll", "msvcp140.dll")) {
    $path = Join-Path $env:SystemRoot "System32\$dll"
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { $dllVersions = @(); break }
    $info = (Get-Item -LiteralPath $path).VersionInfo
    $dllVersions += [Version]::new($info.FileMajorPart, $info.FileMinorPart, $info.FileBuildPart, $info.FilePrivatePart)
  }
  if ($dllVersions.Count -eq 3) {
    $found += ($dllVersions | Sort-Object | Select-Object -First 1)
  }
  if (-not $found.Count) { return $null }
  return ($found | Sort-Object -Descending | Select-Object -First 1)
}

function Test-RebootPending {
  return (
    (Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending") -or
    (Test-Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired") -or
    [bool](Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager" -Name PendingFileRenameOperations -ErrorAction SilentlyContinue)
  )
}

# App-local Visual C++ runtime (a deployment Microsoft supports for the VC++
# redistributable DLLs). When the system runtime is older than required and
# cannot be upgraded (MSI 1603 after a cleaned Package Cache), the runtime
# bundled in the installer (prerequisites\vc-applocal, taken at build time
# from the Visual Studio redistributable folder) is copied next to the
# application executables. Windows loads DLLs from the executable's folder
# first; the older system runtime is left untouched.
$script:VcAppLocalDir = $null
function Get-DllVersion([string]$path) {
  $info = (Get-Item -LiteralPath $path).VersionInfo
  return [Version]::new($info.FileMajorPart, $info.FileMinorPart, $info.FileBuildPart, $info.FilePrivatePart)
}
function Get-VcRuntimeAppLocal([string]$runtimeRoot, [Version]$required) {
  $dir = Join-Path $runtimeRoot "prerequisites\vc-applocal"
  foreach ($needed in @("vcruntime140.dll", "vcruntime140_1.dll", "msvcp140.dll")) {
    $path = Join-Path $dir $needed
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw "VC_APPLOCAL_NOT_BUNDLED:$needed" }
    $version = Get-DllVersion $path
    if ($version -lt $required) { throw "VC_APPLOCAL_TOO_OLD:${needed}:$version<$required" }
  }
  return $dir
}
function Copy-VcRuntimeAppLocal([string]$dllDir, [string[]]$targets) {
  foreach ($target in $targets) {
    if (-not $target -or -not (Test-Path -LiteralPath $target -PathType Container)) { continue }
    Get-ChildItem -LiteralPath $dllDir -File -Filter "*.dll" | ForEach-Object {
      Copy-Item -LiteralPath $_.FullName -Destination $target -Force
    }
    Write-Host "Visual C++ runtime (app-local) placed in $target"
  }
}

# Runs vc_redist with a log; on failure accepts an already working runtime
# (>= floor), then deploys the required runtime app-local, and otherwise
# explains the cause instead of a bare exit code.
function Install-VcRuntime([string]$installer, [Version]$required, [string]$logDir, [string]$errorPrefix, [int]$timeoutMs = 600000) {
  New-Item -ItemType Directory -Force -Path $logDir | Out-Null
  $log = Join-Path $logDir ("vc_redist-{0}.log" -f (Get-Date -Format "yyyyMMdd-HHmmss"))
  $startArgs = @{
    FilePath = $installer
    ArgumentList = @("/install", "/quiet", "/norestart", "/log", "`"$log`"")
    PassThru = $true
  }
  if (-not (Test-IsAdministrator)) {
    $startArgs.Verb = "RunAs"
  }
  # A declined UAC prompt (per-user install) throws instead of returning a code:
  # 1223 (ERROR_CANCELLED) takes the same fallback as a failed upgrade.
  $process = $null
  try {
    $process = Start-Process @startArgs
  } catch {
    Write-Warning "vc_redist did not start: $($_.Exception.Message)"
  }
  if ($process) {
    if (-not $process.WaitForExit($timeoutMs)) {
      Stop-Process -Id $process.Id -Force -ErrorAction SilentlyContinue
      throw "${errorPrefix}_TIMEOUT"
    }
    $process.Refresh()
    $code = $process.ExitCode
  } else {
    $code = 1223
  }
  # 0 ok, 3010 ok after restart, 1638 a newer version is already installed.
  if ($code -in @(0, 1638, 3010)) { return $code }
  $present = Get-VcRuntimeVersion
  if ($present -and $present -ge $required) {
    Write-Host "Visual C++ runtime $present present despite vc_redist exit $code; continuing"
    return $code
  }
  if ($present -and $present -ge $script:VcRuntimeFloor) {
    Write-Warning "Visual C++ runtime update to $required failed (exit $code, log $log); using installed $present (>= $($script:VcRuntimeFloor))"
    return $code
  }
  # The system runtime stays older: the required version goes next to the application instead.
  $appLocalError = $null
  try {
    $script:VcAppLocalDir = Get-VcRuntimeAppLocal $runtime $script:VcRuntimeFloor
    Write-Warning "Visual C++ runtime update to $required failed (exit $code, log $log); installed $(if ($present) { $present } else { 'none' }) stays, the required runtime is deployed next to the application"
    return $code
  } catch {
    $appLocalError = $_.Exception.Message
  }
  $logText = ""
  Get-ChildItem -LiteralPath $logDir -Filter ([IO.Path]::GetFileNameWithoutExtension($log) + "*") -ErrorAction SilentlyContinue |
    ForEach-Object { $logText += (Get-Content -Raw -LiteralPath $_.FullName -ErrorAction SilentlyContinue) }
  $hints = @()
  if (Test-RebootPending) {
    $hints += "system czeka na ponowne uruchomienie - uruchom komputer ponownie i powtorz instalacje"
  }
  if ($logText -match "(?i)1612|source (file )?(is )?not (available|found)|Package Cache") {
    $hints += "brak pakietu poprzedniej wersji Visual C++ w C:\ProgramData\Package Cache (usuniete instalatory) - odinstaluj 'Microsoft Visual C++ 2015-2022 Redistributable (x64)' w Panelu sterowania (albo narzedziem Microsoft 'Program Install and Uninstall troubleshooter'), nastepnie powtorz instalacje"
  }
  if (-not $hints.Count) {
    $hints += "napraw albo odinstaluj 'Microsoft Visual C++ 2015-2022 Redistributable (x64)' w Panelu sterowania, uruchom komputer ponownie i powtorz instalacje"
  }
  if ($appLocalError) { $hints += "wdrozenie lokalne obok aplikacji tez sie nie udalo ($appLocalError)" }
  $installedText = if ($present) { "zainstalowana $present" } else { "brak runtime" }
  throw "${errorPrefix}_FAILED:$code - Visual C++ $required nie zainstalowal sie ($installedText). Co zrobic: $($hints -join '; '). Log: $log"
}

function Get-VerifiedDownload(
  [string]$Url,
  [string]$ExpectedSha256,
  [string]$Destination,
  [string]$Label
) {
  $friendlyName = switch ($Label) {
    "node-runtime" { "narzędzia aplikacji" }
    "visual-cpp-runtime" { "składniki systemu Windows" }
    "python-embeddable-runtime" { "narzędzia analizy dokumentów" }
    default { "składniki analizy dokumentów" }
  }
  if ($ExpectedSha256 -notmatch '^[a-fA-F0-9]{64}$') {
    throw "BOOTSTRAP_HASH_INVALID:$Label"
  }
  if (Test-Path -LiteralPath $Destination -PathType Leaf) {
    $cached = (Get-FileHash -Algorithm SHA256 -LiteralPath $Destination).Hash.ToLowerInvariant()
    if ($cached -eq $ExpectedSha256.ToLowerInvariant()) {
      Set-BootstrapProgress "Gotowe pliki są już na komputerze. Przygotowanie: $friendlyName…"
      Write-Host "Using verified cache for $Label"
      return
    }
    Remove-Item -LiteralPath $Destination -Force
  }
  # A broken transfer (CI 0.1.50: node-runtime with a wrong hash after 53 min) is retried
  # like curl --retry 4 on macOS; the file is used only once its SHA-256 matches.
  $partial = "$Destination.part"
  $actual = ""
  $failure = ""
  for ($attempt = 1; $attempt -le 4; $attempt++) {
    Write-Host "Downloading $Label (attempt $attempt/4)"
    try {
      Set-BootstrapProgress "Pobieranie: $friendlyName…"
      $request = [Net.HttpWebRequest]::Create($Url)
      $offset = 0L
      if (Test-Path -LiteralPath $partial -PathType Leaf) { $offset = (Get-Item -LiteralPath $partial).Length }
      if ($offset -gt 0) { $request.AddRange($offset) }
      $request.Timeout = 60000
      $request.ReadWriteTimeout = 60000
      $response = $null; $inputStream = $null; $outputStream = $null
      try {
        $response = $request.GetResponse()
        $append = $false
        if ([int]$response.StatusCode -eq 206) {
          $range = [string]$response.Headers["Content-Range"]
          if ($range -notmatch '^bytes (\d+)-(\d+)/(\d+)$' -or [long]$Matches[1] -ne $offset) {
            Remove-Item -LiteralPath $partial -Force -ErrorAction SilentlyContinue
            throw "BOOTSTRAP_DOWNLOAD_RANGE_INVALID"
          }
          $append = $true
        } else { $offset = 0L }
        $inputStream = $response.GetResponseStream()
        $mode = if ($append) { [IO.FileMode]::Append } else { [IO.FileMode]::Create }
        $outputStream = [IO.File]::Open($partial, $mode, [IO.FileAccess]::Write, [IO.FileShare]::None)
        $buffer = New-Object byte[] 131072
        $received = $offset
        $total = if ($response.ContentLength -ge 0) { $offset + $response.ContentLength } else { 0L }
        $clock = [Diagnostics.Stopwatch]::StartNew()
        while (($count = $inputStream.Read($buffer, 0, $buffer.Length)) -gt 0) {
          $outputStream.Write($buffer, 0, $count)
          $received += $count
          if ($clock.ElapsedMilliseconds -ge 250) {
            Set-BootstrapProgress "Pobieranie: $friendlyName…" $received $total
            $clock.Restart()
          }
        }
        Set-BootstrapProgress "Sprawdzanie pobranych plików: $friendlyName…"
      } finally {
        if ($outputStream) { $outputStream.Dispose() }
        if ($inputStream) { $inputStream.Dispose() }
        if ($response) { $response.Dispose() }
      }
      $actual = (Get-FileHash -Algorithm SHA256 -LiteralPath $partial).Hash.ToLowerInvariant()
      if ($actual -eq $ExpectedSha256.ToLowerInvariant()) {
        Move-Item -LiteralPath $partial -Destination $Destination -Force
        return
      }
      $failure = "actual=$actual"
      Remove-Item -LiteralPath $partial -Force -ErrorAction SilentlyContinue
    } catch {
      $failure = $_.Exception.Message
      # An old partial file can be longer than the current remote asset.
      $errorResponse = $_.Exception.Response
      if (-not $errorResponse -and $_.Exception.InnerException) { $errorResponse = $_.Exception.InnerException.Response }
      if ($errorResponse) {
        if ([int]$errorResponse.StatusCode -eq 416) {
          Remove-Item -LiteralPath $partial -Force -ErrorAction SilentlyContinue
        }
        $errorResponse.Dispose()
      }
    }
    Write-Host "Download of $Label failed ($failure)"
    if ($attempt -lt 4) { Set-BootstrapProgress "Połączenie przerwane. Ponawianie pobierania…"; Start-Sleep -Seconds (3 * $attempt) }
  }
  # Keep interrupted transfers for the next attempt; corrupt files were removed above.
  if ($actual) {
    throw "BOOTSTRAP_HASH_MISMATCH:$Label expected=$ExpectedSha256 actual=$actual"
  }
  throw "BOOTSTRAP_DOWNLOAD_FAILED:$Label $failure"
}

function Get-CommandVersionText(
  [string]$Executable,
  [string[]]$Arguments
) {
  if (-not (Test-Path -LiteralPath $Executable -PathType Leaf)) { return $null }
  # Windows PowerShell 5.1: with "Stop" a version printed to stderr is a terminating error.
  $previousPreference = $ErrorActionPreference
  $ErrorActionPreference = "Continue"
  try {
    $line = & $Executable @Arguments 2>&1 | Select-Object -First 1
    if ($null -eq $line) { return $null }
    return $line.ToString().Trim()
  } catch {
    return $null
  } finally {
    $ErrorActionPreference = $previousPreference
  }
}

function Test-CommandVersion(
  [string]$Executable,
  [string[]]$Arguments,
  [string]$Expected
) {
  $value = Get-CommandVersionText $Executable $Arguments
  return ($null -ne $value -and $value -eq $Expected)
}

function Invoke-RedirectedNativeProcess(
  [string]$Executable,
  [string]$ArgumentLine,
  [string]$LogBase
) {
  $stdoutPath = "$LogBase.stdout.log"
  $stderrPath = "$LogBase.stderr.log"
  $logParent = Split-Path -Parent $LogBase
  if ($logParent) {
    New-Item -ItemType Directory -Force -Path $logParent | Out-Null
  }
  Remove-Item -LiteralPath $stdoutPath -Force -ErrorAction SilentlyContinue
  Remove-Item -LiteralPath $stderrPath -Force -ErrorAction SilentlyContinue

  $process = Start-Process -FilePath $Executable `
    -ArgumentList $ArgumentLine `
    -Wait `
    -PassThru `
    -NoNewWindow `
    -RedirectStandardOutput $stdoutPath `
    -RedirectStandardError $stderrPath

  [pscustomobject]@{
    ExitCode = $process.ExitCode
    StdoutPath = $stdoutPath
    StderrPath = $stderrPath
  }
}

Write-Host "[1/6] Private Node"
Set-BootstrapProgress "Sprawdzanie narzędzi aplikacji…"
$nodeDir = Join-Path $runtime "node"
$nodeExe = Join-Path $nodeDir "node.exe"
$nodeExpected = "v$($manifest.runtime.node.version)"
if (-not (Test-CommandVersion $nodeExe @("--version") $nodeExpected)) {
  $nodeZip = Join-Path $cache "node-$($manifest.runtime.node.version)-win-x64.zip"
  Get-VerifiedDownload $manifest.runtime.node.url $manifest.runtime.node.sha256 $nodeZip "node-runtime"
  $extract = Join-Path $cache "node-extract-$($manifest.runtime.node.version)"
  Remove-Item $extract -Recurse -Force -ErrorAction SilentlyContinue
  Set-BootstrapProgress "Przygotowanie pobranych narzędzi aplikacji…"
  Expand-Archive -LiteralPath $nodeZip -DestinationPath $extract -Force
  $source = Get-ChildItem $extract -Directory | Select-Object -First 1
  if (-not $source) { throw "BOOTSTRAP_NODE_ARCHIVE_LAYOUT_INVALID" }
  Remove-Item $nodeDir -Recurse -Force -ErrorAction SilentlyContinue
  New-Item -ItemType Directory -Force -Path $nodeDir | Out-Null
  Copy-Item (Join-Path $source.FullName "*") $nodeDir -Recurse -Force
}
if (-not (Test-CommandVersion $nodeExe @("--version") $nodeExpected)) {
  throw "BOOTSTRAP_NODE_VERSION_INVALID"
}

Write-Host "[2/6] System prerequisites"
Set-BootstrapProgress "Przygotowanie składników systemu Windows…"
$vc = $manifest.systemPrerequisites.visualCppRuntime
$vcPresent = Get-VcRuntimeVersion
$vcInstalled = [bool]($vcPresent -and $vcPresent -ge [Version]$vc.version)
if ($vcPresent) { Write-Host "Visual C++ runtime found: $vcPresent (required $($vc.version))" }
if (-not $vcInstalled) {
  $bundledVc = Join-Path $runtime "prerequisites\vc_redist.x64.exe"
  if (Test-Path -LiteralPath $bundledVc -PathType Leaf) {
    $bundledHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $bundledVc).Hash.ToLowerInvariant()
    if ($bundledHash -ne $vc.sha256.ToLowerInvariant()) {
      throw "BOOTSTRAP_HASH_MISMATCH:visual-cpp-runtime-bundled expected=$($vc.sha256) actual=$bundledHash"
    }
    Write-Host "Using verified bundled visual-cpp-runtime"
    $vcInstaller = $bundledVc
  } else {
    $vcInstaller = Join-Path $cache "vc_redist.x64-$($vc.version).exe"
    Get-VerifiedDownload $vc.url $vc.sha256 $vcInstaller "visual-cpp-runtime"
  }
  $null = Install-VcRuntime $vcInstaller ([Version]$vc.version) (Join-Path $cache "logs") "BOOTSTRAP_VC_RUNTIME"
}

Write-Host "[3/6] Private Python"
Set-BootstrapProgress "Sprawdzanie narzędzi analizy dokumentów…"
$pythonDir = Join-Path $runtime "python"
$pythonExe = Join-Path $pythonDir "python.exe"
$pythonExpected = "Python $($manifest.runtime.python.version)"
$pythonDelivery = $manifest.runtime.python.delivery
if (-not $pythonDelivery) {
  throw "BOOTSTRAP_PYTHON_DELIVERY_MISSING"
}
if (-not (Test-CommandVersion $pythonExe @("--version") $pythonExpected)) {

  # The registered CPython full installer cannot safely provide an app-private
  # runtime when the same Python version is already registered on the machine.
  # In maintenance mode it may return exit code 0 while retaining the previous
  # install directory. Use CPython's official embeddable distribution instead:
  # it is application-local, registry-independent and can coexist with any
  # system/user Python installation.
  if ($pythonDelivery -ne "EMBEDDABLE_APP_LOCAL") {
    throw "BOOTSTRAP_PYTHON_DELIVERY_UNSUPPORTED:$pythonDelivery"
  }

  $embedded = $manifest.runtime.python.embeddable
  if (-not $embedded -or -not $embedded.url -or -not $embedded.sha256) {
    throw "BOOTSTRAP_PYTHON_EMBEDDED_MANIFEST_INVALID"
  }
  $pythonZip = Join-Path $cache "python-$($manifest.runtime.python.version)-embeddable-amd64.zip"
  Get-VerifiedDownload $embedded.url $embedded.sha256 $pythonZip "python-embeddable-runtime"
  Set-BootstrapProgress "Przygotowanie pobranych narzędzi analizy dokumentów…"
  $pythonStage = Join-Path $cache "python-extract-$($manifest.runtime.python.version)"
  Remove-Item $pythonStage -Recurse -Force -ErrorAction SilentlyContinue
  Expand-Archive -LiteralPath $pythonZip -DestinationPath $pythonStage -Force
  if (-not (Test-Path -LiteralPath (Join-Path $pythonStage "python.exe") -PathType Leaf)) {
    throw "BOOTSTRAP_PYTHON_ARCHIVE_LAYOUT_INVALID"
  }
  Remove-Item $pythonDir -Recurse -Force -ErrorAction SilentlyContinue
  New-Item -ItemType Directory -Force -Path $pythonDir | Out-Null
  Copy-Item (Join-Path $pythonStage "*") $pythonDir -Recurse -Force
  Remove-Item $pythonStage -Recurse -Force -ErrorAction SilentlyContinue

  $pth = Get-ChildItem -LiteralPath $pythonDir -Filter "python*._pth" -File |
    Select-Object -First 1
  if (-not $pth) {
    throw "BOOTSTRAP_PYTHON_EMBEDDED_PTH_MISSING"
  }

  # The embeddable distribution intentionally disables site by default.
  # Enable only the private site-packages directory used by Lex Machina.
  $pipWheelEntry = "pip-bootstrap.whl"
  $newPth = @()
  $hasSitePackages = $false
  $hasPipWheelEntry = $false
  $hasImportSite = $false
  foreach ($line in @(Get-Content -LiteralPath $pth.FullName)) {
    $trimmed = $line.Trim()
    if ($trimmed -eq "Lib\site-packages") {
      $hasSitePackages = $true
    }
    if ($trimmed -eq $pipWheelEntry) {
      $hasPipWheelEntry = $true
    }
    if ($trimmed -eq "#import site" -or $trimmed -eq "import site") {
      if (-not $hasSitePackages) {
        $newPth += "Lib\site-packages"
        $hasSitePackages = $true
      }
      if (-not $hasPipWheelEntry) {
        $newPth += $pipWheelEntry
        $hasPipWheelEntry = $true
      }
      $newPth += "import site"
      $hasImportSite = $true
      continue
    }
    $newPth += $line
  }
  if (-not $hasSitePackages) {
    $newPth += "Lib\site-packages"
  }
  if (-not $hasPipWheelEntry) {
    $newPth += $pipWheelEntry
  }
  if (-not $hasImportSite) {
    $newPth += "import site"
  }
  [IO.File]::WriteAllLines($pth.FullName, [string[]]$newPth, [Text.Encoding]::ASCII)

  $sitePackages = Join-Path $pythonDir "Lib\site-packages"
  New-Item -ItemType Directory -Force -Path $sitePackages | Out-Null

  # Bootstrap a pinned pip wheel without invoking any globally installed Python.
  # CPython's embeddable distribution runs in isolated ._pth mode. Rather than
  # relying on site-package discovery, place the verified wheel directly on the
  # explicit ._pth search path. zipimport can load pip from the wheel itself,
  # while packages installed by pip continue to land in private Lib\site-packages.
  $pipBootstrap = $manifest.runtime.python.pipBootstrap
  if (-not $pipBootstrap -or -not $pipBootstrap.url -or
      -not $pipBootstrap.sha256 -or -not $pipBootstrap.version) {
    throw "BOOTSTRAP_PIP_MANIFEST_INVALID"
  }
  $pipWheel = Join-Path $cache "pip-$($pipBootstrap.version)-py3-none-any.whl"
  Get-VerifiedDownload $pipBootstrap.url $pipBootstrap.sha256 $pipWheel "pip-bootstrap-wheel"

  $privatePipWheel = Join-Path $pythonDir $pipWheelEntry
  Copy-Item -LiteralPath $pipWheel -Destination $privatePipWheel -Force
}

$pythonActual = Get-CommandVersionText $pythonExe @("--version")
if ($pythonActual -ne $pythonExpected) {
  $pythonActualDisplay = if ($null -eq $pythonActual) { "<missing-or-unreadable>" } else { $pythonActual }
  throw "BOOTSTRAP_PYTHON_VERSION_INVALID expected=$pythonExpected actual=$pythonActualDisplay executable=$pythonExe"
}

$pipLogs = Join-Path $runtime "bootstrap-logs\pip-version"
$pipVersionProcess = Invoke-RedirectedNativeProcess `
  -Executable $pythonExe `
  -ArgumentLine "-X utf8 -m pip --version" `
  -LogBase $pipLogs
$pipVersionOutput = @()
if (Test-Path -LiteralPath $pipVersionProcess.StdoutPath -PathType Leaf) {
  $pipVersionOutput += @(Get-Content -LiteralPath $pipVersionProcess.StdoutPath)
}
if (Test-Path -LiteralPath $pipVersionProcess.StderrPath -PathType Leaf) {
  $pipVersionOutput += @(Get-Content -LiteralPath $pipVersionProcess.StderrPath)
}
$pipActual = @(
  $pipVersionOutput |
    ForEach-Object { $_.ToString().Trim() } |
    Where-Object { $_ -like "pip *" } |
    Select-Object -First 1
)
$pipActual = if ($pipActual.Count -gt 0) { $pipActual[0] } else { $null }
$pipExpectedPrefix = "pip $($manifest.runtime.python.pipBootstrap.version) "
if ($pipVersionProcess.ExitCode -ne 0 -or $null -eq $pipActual -or
    -not $pipActual.StartsWith($pipExpectedPrefix, [StringComparison]::Ordinal)) {
  $pipActualDisplay = if ($null -eq $pipActual) {
    ($pipVersionOutput | ForEach-Object { $_.ToString().Trim() }) -join " | "
  } else {
    $pipActual
  }
  if ([string]::IsNullOrWhiteSpace($pipActualDisplay)) {
    $pipActualDisplay = "<missing-or-unreadable>"
  }
  throw "BOOTSTRAP_PIP_VERSION_INVALID expected=$($manifest.runtime.python.pipBootstrap.version) exit=$($pipVersionProcess.ExitCode) actual=$pipActualDisplay executable=$pythonExe"
}

Write-Host "[4/6] Pinned Python/ML packages"
Set-BootstrapProgress "Przygotowanie analizy dokumentów…"
$packageVerifier = Join-Path $bootstrapRoot "verify-python-package-set.py"
if (-not (Test-Path -LiteralPath $packageVerifier -PathType Leaf)) {
  throw "BOOTSTRAP_PYTHON_PACKAGE_VERIFIER_MISSING"
}
$verifierLogBase = Join-Path $runtime "bootstrap-logs\package-verifier"
$verifierArguments = ('-X utf8 "{0}" "{1}"' -f $packageVerifier, $manifestPath)
$verifyProcess = Invoke-RedirectedNativeProcess `
  -Executable $pythonExe `
  -ArgumentLine $verifierArguments `
  -LogBase $verifierLogBase
if (Test-Path -LiteralPath $verifyProcess.StdoutPath -PathType Leaf) {
  Get-Content -LiteralPath $verifyProcess.StdoutPath | Out-Host
}
if ($verifyProcess.ExitCode -ne 0) {
  $pipInstallLogBase = Join-Path $runtime "bootstrap-logs\pip-install"
  $pipInstallArguments = ('-X utf8 -m pip install --quiet --disable-pip-version-check --no-warn-script-location --upgrade-strategy only-if-needed -r "{0}"' -f $requirements)
  $pipInstallProcess = Invoke-RedirectedNativeProcess `
    -Executable $pythonExe `
    -ArgumentLine $pipInstallArguments `
    -LogBase $pipInstallLogBase

  if (Test-Path -LiteralPath $pipInstallProcess.StdoutPath -PathType Leaf) {
    Get-Content -LiteralPath $pipInstallProcess.StdoutPath | Out-Host
  }
  if (Test-Path -LiteralPath $pipInstallProcess.StderrPath -PathType Leaf) {
    Get-Content -LiteralPath $pipInstallProcess.StderrPath | Out-Host
  }
  if ($pipInstallProcess.ExitCode -ne 0) {
    throw "BOOTSTRAP_PYTHON_PACKAGES_FAILED:$($pipInstallProcess.ExitCode)"
  }

  $verifyProcess = Invoke-RedirectedNativeProcess `
    -Executable $pythonExe `
    -ArgumentLine $verifierArguments `
    -LogBase $verifierLogBase
  if (Test-Path -LiteralPath $verifyProcess.StdoutPath -PathType Leaf) {
    Get-Content -LiteralPath $verifyProcess.StdoutPath | Out-Host
  }
  if (Test-Path -LiteralPath $verifyProcess.StderrPath -PathType Leaf) {
    Get-Content -LiteralPath $verifyProcess.StderrPath | Out-Host
  }
  if ($verifyProcess.ExitCode -ne 0) {
    throw "BOOTSTRAP_PYTHON_PACKAGE_VERSION_MISMATCH:$($verifyProcess.ExitCode)"
  }
}

$pipFreezeLogBase = Join-Path $runtime "bootstrap-logs\pip-freeze"
$pipFreezeProcess = Invoke-RedirectedNativeProcess `
  -Executable $pythonExe `
  -ArgumentLine "-X utf8 -m pip freeze --all" `
  -LogBase $pipFreezeLogBase
if ($pipFreezeProcess.ExitCode -ne 0) {
  if (Test-Path -LiteralPath $pipFreezeProcess.StderrPath -PathType Leaf) {
    Get-Content -LiteralPath $pipFreezeProcess.StderrPath | Out-Host
  }
  throw "BOOTSTRAP_PYTHON_PROVENANCE_FAILED:$($pipFreezeProcess.ExitCode)"
}
$freezeLines = @()
if (Test-Path -LiteralPath $pipFreezeProcess.StdoutPath -PathType Leaf) {
  $freezeLines = @(Get-Content -LiteralPath $pipFreezeProcess.StdoutPath)
}
$freezeLines | Sort-Object |
  Out-File -FilePath (Join-Path $runtime "python-dependency-tree.txt") -Encoding utf8

Write-Host "[5/6] OCR/NER models"
Set-BootstrapProgress "Przygotowanie rozpoznawania tekstu…"
$modelRoot = Join-Path $runtime "models"
$paddleOfficial = Join-Path $modelRoot "paddle\official_models"
$stanzaPl = Join-Path $modelRoot "stanza\pl"
$requiredPaddle = @(
  "PP-LCNet_x1_0_doc_ori",
  "UVDoc",
  "PP-LCNet_x1_0_textline_ori",
  "PP-OCRv6_medium_det",
  "PP-OCRv6_medium_rec"
)
# Optional OCR model: its absence must not trigger another download.
$optionalPaddle = @("latin_PP-OCRv5_mobile_rec")
$stanzaReady = Test-Path -LiteralPath (Join-Path $modelRoot "stanza\resources.json") -PathType Leaf
foreach ($kind in @("tokenize", "ner", "pretrain")) {
  $files = @(Get-ChildItem -LiteralPath (Join-Path $stanzaPl $kind) -Filter "*.pt" -File -ErrorAction SilentlyContinue | Where-Object { $_.Length -gt 0 })
  if ($files.Count -eq 0) { $stanzaReady = $false }
}
$modelsReady = $stanzaReady
# A model counts only with its weights: an earlier install cut short during the
# download leaves directories that exist but are empty or partial.
foreach ($name in $requiredPaddle) {
  $modelDir = Join-Path $paddleOfficial $name
  if (-not (Test-CompletePaddleModel $modelDir)) { $modelsReady = $false }
}
if (-not $modelsReady) {
  New-Item -ItemType Directory -Force -Path $modelRoot | Out-Null
  # PaddleX treats an existing model directory as downloaded: remove the partial
  # ones so the prefetch fetches them again (complete ones are kept).
  foreach ($name in ($requiredPaddle + $optionalPaddle)) {
    $modelDir = Join-Path $paddleOfficial $name
    if ((Test-Path -LiteralPath $modelDir -PathType Container) -and -not (Test-CompletePaddleModel $modelDir)) {
      Remove-Item -LiteralPath $modelDir -Recurse -Force -ErrorAction SilentlyContinue
    }
  }

  # PaddleX supports several official hosters. Prefer BOS because it serves
  # the official inference tarballs directly and avoids the HuggingFace API
  # response path that can intermittently return an empty JSON document on
  # clean Windows installs. Each fallback runs in a fresh Python process so
  # PaddleX re-reads PADDLE_PDX_MODEL_SOURCE. Failed partial model directories
  # are removed before the next source to avoid treating an incomplete cache
  # as a valid installed model.
  $modelSources = @("bos", "huggingface", "modelscope", "aistudio")
  $prefetchScript = Join-Path $bootstrapRoot "prefetch-release-models.py"
  if (-not (Test-Path -LiteralPath $prefetchScript -PathType Leaf)) {
    throw "BOOTSTRAP_MODEL_PREFETCH_SCRIPT_MISSING"
  }

  $previousSkipStanza = $env:LEX_PREFETCH_SKIP_STANZA
  $previousSkipOptional = $env:LEX_PREFETCH_SKIP_OPTIONAL
  $env:LEX_PREFETCH_SKIP_STANZA = if ($stanzaReady) { "1" } else { "0" }
  $env:LEX_PREFETCH_SKIP_OPTIONAL = "1"
  $previousModelSource = $env:PADDLE_PDX_MODEL_SOURCE
  $prefetchSucceeded = $false
  try {
    foreach ($source in $modelSources) {
      Set-BootstrapProgress "Pobieranie brakujących narzędzi rozpoznawania tekstu…"
      $env:PADDLE_PDX_MODEL_SOURCE = $source
      Write-Host "Model prefetch attempt via official source: $source"

      # Windows PowerShell 5.1 promotes native stderr records into the
      # PowerShell error stream. With ErrorActionPreference=Stop that would
      # terminate this bootstrap before the fallback loop can inspect the
      # native exit code. Redirect both streams and treat ExitCode as the
      # authoritative success/failure signal.
      $prefetchStdout = Join-Path $modelRoot ("prefetch-" + $source + ".stdout.log")
      $prefetchStderr = Join-Path $modelRoot ("prefetch-" + $source + ".stderr.log")
      Remove-Item -LiteralPath $prefetchStdout -Force -ErrorAction SilentlyContinue
      Remove-Item -LiteralPath $prefetchStderr -Force -ErrorAction SilentlyContinue

      $prefetchArguments = ('-X utf8 "{0}" "{1}"' -f $prefetchScript, $modelRoot)
      $prefetchProcess = Start-Process -FilePath $pythonExe `
        -ArgumentList $prefetchArguments `
        -Wait `
        -PassThru `
        -NoNewWindow `
        -RedirectStandardOutput $prefetchStdout `
        -RedirectStandardError $prefetchStderr

      if (Test-Path -LiteralPath $prefetchStdout -PathType Leaf) {
        Get-Content -LiteralPath $prefetchStdout | Out-Host
      }
      if (Test-Path -LiteralPath $prefetchStderr -PathType Leaf) {
        Get-Content -LiteralPath $prefetchStderr | Out-Host
      }

      $prefetchExit = $prefetchProcess.ExitCode
      if ($prefetchExit -eq 0) {
        $prefetchSucceeded = $true
        Write-Host "Model prefetch source accepted: $source"
        break
      }

      Write-Warning "Model prefetch source failed: $source exit=$prefetchExit"
      foreach ($name in $requiredPaddle) {
        $candidate = Join-Path $paddleOfficial $name
        if (-not (Test-CompletePaddleModel $candidate)) {
          Remove-Item -LiteralPath $candidate -Recurse -Force -ErrorAction SilentlyContinue
        }
      }
      Start-Sleep -Seconds 2
    }
  } finally {
    $env:LEX_PREFETCH_SKIP_STANZA = $previousSkipStanza
    $env:LEX_PREFETCH_SKIP_OPTIONAL = $previousSkipOptional
    if ($null -eq $previousModelSource) {
      Remove-Item Env:PADDLE_PDX_MODEL_SOURCE -ErrorAction SilentlyContinue
    } else {
      $env:PADDLE_PDX_MODEL_SOURCE = $previousModelSource
    }
  }

  if (-not $prefetchSucceeded) {
    throw "BOOTSTRAP_MODEL_PREFETCH_FAILED_ALL_OFFICIAL_SOURCES"
  }
}

Write-Host "[6/6] Integrity lock and offline acceptance"
Set-BootstrapProgress "Sprawdzanie gotowości aplikacji…"
# A system Visual C++ runtime that could not be upgraded: the required one goes
# next to every executable of the runtime before the integrity lock is made.
if ($script:VcAppLocalDir) {
  $vcTargets = @($runtime, $nodeDir, $pythonDir) + @(
    Get-ChildItem -LiteralPath $runtime -Recurse -File -Filter "*.exe" -ErrorAction SilentlyContinue |
      Where-Object { $_.FullName -notmatch '\\(prerequisites|bootstrap)\\' } |
      ForEach-Object { $_.DirectoryName }
  ) | Sort-Object -Unique
  Copy-VcRuntimeAppLocal $script:VcAppLocalDir $vcTargets
}
& (Join-Path $bootstrapRoot "generate-component-lock.ps1") `
  -PayloadRoot $runtime `
  -Output (Join-Path $runtime "component-lock.json") `
  -NetworkRequiredAtInstall $true `
  -IncludeBundledVisualCppRuntime $false
if ($LASTEXITCODE -ne 0) { throw "BOOTSTRAP_COMPONENT_LOCK_FAILED" }

& (Join-Path $bootstrapRoot "windows-payload-selftest.ps1") -PayloadRoot $runtime
if ($LASTEXITCODE -ne 0) { throw "BOOTSTRAP_RUNTIME_SELFTEST_FAILED" }

$nativeWebConfigurator = Join-Path $bootstrapRoot "configure-llama-native-web.ps1"
if (-not (Test-Path -LiteralPath $nativeWebConfigurator -PathType Leaf)) {
  throw "BOOTSTRAP_LLAMA_NATIVE_WEB_CONFIGURATOR_MISSING"
}
& $nativeWebConfigurator -RuntimeRoot $runtime | Out-Host

Write-Host "LEX_ONLINE_BOOTSTRAP_PASS:LOCAL_AI_OPTIONAL"
