﻿param(
  [Parameter(Mandatory=$true)][string]$ReceiptPath,
  [Parameter(Mandatory=$true)][string]$RuntimeRoot,
  [Parameter(Mandatory=$true)][string]$InstallRoot,
  [Parameter(Mandatory=$true)][string]$AppExecutable,
  [Parameter(Mandatory=$true)][int]$ParentPid
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

# Paths may arrive in the verbatim form \\?\C:\... (Tauri's resource directory on Windows):
# Join-Path, Split-Path and Test-Path of Windows PowerShell 5.1 reject it, which stopped the
# update before its first journal line (0.1.54 -> 0.1.61). Plain form for every path.
function ConvertTo-PlainPath([string]$Value) {
  if ($Value.StartsWith('\\?\UNC\')) { return '\\' + $Value.Substring(8) }
  if ($Value.StartsWith('\\?\')) { return $Value.Substring(4) }
  return $Value
}
$ReceiptPath = ConvertTo-PlainPath $ReceiptPath
$RuntimeRoot = ConvertTo-PlainPath $RuntimeRoot
$InstallRoot = ConvertTo-PlainPath $InstallRoot
$AppExecutable = ConvertTo-PlainPath $AppExecutable
$scriptRoot = ConvertTo-PlainPath $PSScriptRoot

$verificationHelper = Join-Path $scriptRoot "app-update-verification.ps1"
if (-not (Test-Path -LiteralPath $verificationHelper -PathType Leaf)) {
  throw "UPDATE_VERIFICATION_HELPER_MISSING:$verificationHelper"
}
. $verificationHelper

function Full-Path([string]$Value) {
  return [IO.Path]::GetFullPath($Value)
}

# A visible progress window while the application is closed for the update (user report
# 2026-11-06: the update ran hidden after the app closed and the user did not know what was
# happening). Its own STA runspace; any failure to show it never touches the update itself.
$script:UpdateProgress = $null
$UpdateProgressSteps = @{
  PREPARED = @(10, "Przygotowanie aktualizacji…")
  BACKED_UP = @(30, "Kopia zapasowa gotowa. Instaluję nową wersję…")
  INSTALLING = @(50, "Instaluję nową wersję Lex Machina…")
  VERIFYING = @(85, "Sprawdzam zainstalowaną wersję…")
  COMMITTED = @(100, "Aktualizacja zainstalowana. Uruchamiam Lex Machina…")
  ROLLING_BACK = @(60, "Aktualizacja się nie powiodła. Przywracam poprzednią wersję…")
  ROLLED_BACK = @(100, "Przywrócono poprzednią wersję. Uruchamiam Lex Machina…")
  ROLLBACK_FAILED = @(100, "Nie udało się przywrócić poprzedniej wersji. Zainstaluj Lex Machina ponownie z instalatora.")
  ABORTED_BEFORE_INSTALL = @(100, "Aktualizacja przerwana przed instalacją. Uruchamiam Lex Machina…")
  REJECTED = @(100, "Pobrany instalator nie przeszedł weryfikacji. Aktualizacja nie została zainstalowana.")
}

function Start-UpdateProgress([string]$TargetVersion) {
  if ($script:UpdateProgress -or $env:LEX_UPDATE_NO_PROGRESS_WINDOW -eq "1" -or -not [Environment]::UserInteractive) { return }
  try {
    $sync = [hashtable]::Synchronized(@{ CloseAt = $null; Text = "Przygotowanie aktualizacji…"; Value = 5; Installing = $false; Title = "Aktualizacja Lex Machina do wersji $TargetVersion" })
    $runspace = [runspacefactory]::CreateRunspace()
    $runspace.ApartmentState = "STA"
    $runspace.ThreadOptions = "ReuseThread"
    $runspace.Open()
    $runspace.SessionStateProxy.SetVariable("sync", $sync)
    $shell = [powershell]::Create()
    $shell.Runspace = $runspace
    [void]$shell.AddScript({
      Add-Type -AssemblyName System.Windows.Forms, System.Drawing
      $form = New-Object System.Windows.Forms.Form
      $form.Text = $sync.Title
      $form.Width = 460; $form.Height = 170
      $form.StartPosition = "CenterScreen"
      $form.FormBorderStyle = "FixedDialog"
      $form.ControlBox = $false
      $form.TopMost = $true
      $label = New-Object System.Windows.Forms.Label
      $label.Left = 20; $label.Top = 20; $label.Width = 410; $label.Height = 40
      $label.Text = $sync.Text
      $bar = New-Object System.Windows.Forms.ProgressBar
      $bar.Left = 20; $bar.Top = 70; $bar.Width = 410; $bar.Height = 22
      $bar.Minimum = 0; $bar.Maximum = 100; $bar.Value = $sync.Value
      $hint = New-Object System.Windows.Forms.Label
      $hint.Left = 20; $hint.Top = 100; $hint.Width = 410; $hint.Height = 20
      $hint.Text = "Nie wyłączaj komputera. Okno zamknie się samo."
      $form.Controls.AddRange([System.Windows.Forms.Control[]]@($label, $bar, $hint))
      $timer = New-Object System.Windows.Forms.Timer
      $timer.Interval = 300
      $timer.Add_Tick({
        $form.TopMost = -not $sync.Installing
        $label.Text = $sync.Text
        $bar.Value = [Math]::Max(0, [Math]::Min(100, [int]$sync.Value))
        if ($sync.CloseAt -and [DateTime]::UtcNow -ge $sync.CloseAt) { $timer.Stop(); $form.Close() }
      })
      $timer.Start()
      [void]$form.ShowDialog()
    })
    [void]$shell.BeginInvoke()
    $script:UpdateProgress = $sync
  } catch {
    $script:UpdateProgress = $null
  }
}

function Set-UpdateProgress([string]$State) {
  if (-not $script:UpdateProgress -or -not $UpdateProgressSteps.ContainsKey($State)) { return }
  try {
    $script:UpdateProgress.Installing = $State -eq "INSTALLING"
    $step = $UpdateProgressSteps[$State]
    $script:UpdateProgress.Value = $step[0]
    $script:UpdateProgress.Text = $step[1]
    # A final state closes the window by itself; a failure stays readable a little longer.
    if ($step[0] -ge 100) {
      $seconds = if ($State -in @("ROLLBACK_FAILED", "REJECTED")) { 10 } else { 2 }
      $script:UpdateProgress.CloseAt = [DateTime]::UtcNow.AddSeconds($seconds)
    }
  } catch { }
}

function Write-JsonAtomic([string]$Path, [object]$Value) {
  # Every journal state is a step of the progress window.
  if ($Value -is [System.Collections.IDictionary] -and $Value.Contains("state")) { Set-UpdateProgress ([string]$Value["state"]) }
  $parent = Split-Path -Parent $Path
  if ($parent) { New-Item -ItemType Directory -Force -Path $parent | Out-Null }
  $temporary = $Path + ".tmp"
  [IO.File]::WriteAllText(
    $temporary,
    (($Value | ConvertTo-Json -Depth 12) + [Environment]::NewLine),
    [Text.UTF8Encoding]::new($false)
  )
  Move-Item -LiteralPath $temporary -Destination $Path -Force
}

function Read-Json([string]$Path, [string]$Code) {
  if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
    throw "${Code}_MISSING:$Path"
  }
  try {
    return Get-Content -Raw -LiteralPath $Path | ConvertFrom-Json
  } catch {
    throw "${Code}_INVALID:$Path"
  }
}

function Assert-SimpleToken([string]$Value, [string]$Code, [string]$Extension) {
  if (
    [string]::IsNullOrWhiteSpace($Value) -or
    $Value.Contains('/') -or
    $Value.Contains('\') -or
    $Value.Contains('..') -or
    $Value.Contains(':') -or
    -not $Value.EndsWith($Extension, [StringComparison]::OrdinalIgnoreCase) -or
    $Value -notmatch '^[A-Za-z0-9._-]+$'
  ) {
    throw ($Code + ":" + $Value)
  }
}

function Stop-LexProcesses([string]$ApplicationRoot) {
  $normalizedRoot = (Full-Path $ApplicationRoot).TrimEnd('\') + '\'
  $localAiRoot = if ($env:LOCALAPPDATA) {
    (Full-Path (Join-Path $env:LOCALAPPDATA "LexMachina\local-ai")).TrimEnd('\') + '\'
  } else { $null }

  Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
    Where-Object {
      $path = [string]$_.ExecutablePath
      if (-not $path) { return $false }
      $full = try { Full-Path $path } catch { return $false }
      return (
        $full.StartsWith($normalizedRoot, [StringComparison]::OrdinalIgnoreCase) -or
        ($localAiRoot -and $full.StartsWith($localAiRoot, [StringComparison]::OrdinalIgnoreCase))
      )
    } |
    ForEach-Object {
      Stop-Process -Id ([int]$_.ProcessId) -Force -ErrorAction SilentlyContinue
    }
}

function Test-LexRunning([string]$ApplicationRoot) {
  $normalizedRoot = (Full-Path $ApplicationRoot).TrimEnd('\') + '\'
  $running = @(
    Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
      Where-Object {
        $path = [string]$_.ExecutablePath
        if (-not $path) { return $false }
        $full = try { Full-Path $path } catch { return $false }
        return $full.StartsWith($normalizedRoot, [StringComparison]::OrdinalIgnoreCase)
      }
  )
  return ($running.Count -gt 0)
}

function Wait-ParentExit([int]$ProcessId) {
  if ($ProcessId -le 0) { return }
  $process = Get-Process -Id $ProcessId -ErrorAction SilentlyContinue
  if (-not $process) { return }
  if (-not $process.WaitForExit(120000)) {
    throw "UPDATE_PARENT_EXIT_TIMEOUT:$ProcessId"
  }
}

function Get-InstallSize([string]$Root) {
  $sum = Get-ChildItem -LiteralPath $Root -File -Recurse -Force -ErrorAction Stop |
    Measure-Object -Property Length -Sum
  # Windows PowerShell 5.1 (runner aktualizacji) nie zna operatora ??.
  $total = $sum.Sum
  if ($null -eq $total) { $total = 0 }
  return [int64]$total
}

function Assert-BackupCapacity([string]$BackupBase, [int64]$InstallBytes) {
  $root = [IO.Path]::GetPathRoot((Full-Path $BackupBase))
  $driveName = $root.TrimEnd('\').TrimEnd(':')
  $drive = Get-PSDrive -Name $driveName -ErrorAction Stop
  $required = $InstallBytes + 536870912L
  if ([int64]$drive.Free -lt $required) {
    throw "UPDATE_BACKUP_SPACE_INSUFFICIENT:required=$required free=$($drive.Free)"
  }
}

function Copy-DirectoryContents([string]$Source, [string]$Destination) {
  Copy-TreeLong $Source $Destination
}

function Get-LexUninstallKeys {
  $root = "Registry::HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Uninstall"
  if (-not (Test-Path $root)) { return @() }
  return @(
    Get-ChildItem $root -ErrorAction SilentlyContinue |
      Where-Object {
        try {
          (Get-ItemProperty -LiteralPath $_.PSPath -Name DisplayName -ErrorAction Stop).DisplayName -eq "Lex Machina"
        } catch { $false }
      }
  )
}

function Backup-UninstallRegistry([string]$Destination) {
  New-Item -ItemType Directory -Force -Path $Destination | Out-Null
  $index = 0
  foreach ($key in Get-LexUninstallKeys) {
    $target = Join-Path $Destination ("uninstall-$index.reg")
    & reg.exe export $key.Name $target /y | Out-Null
    if ($LASTEXITCODE -ne 0) {
      throw "UPDATE_REGISTRY_BACKUP_FAILED:$($key.Name)"
    }
    $index++
  }
}

function Restore-UninstallRegistry([string]$Source) {
  foreach ($key in Get-LexUninstallKeys) {
    Remove-Item -LiteralPath $key.PSPath -Recurse -Force -ErrorAction SilentlyContinue
  }
  if (-not (Test-Path -LiteralPath $Source -PathType Container)) { return }
  foreach ($file in Get-ChildItem -LiteralPath $Source -Filter '*.reg' -File | Sort-Object Name) {
    & reg.exe import $file.FullName | Out-Null
    if ($LASTEXITCODE -ne 0) {
      throw "UPDATE_REGISTRY_RESTORE_FAILED:$($file.FullName)"
    }
  }
}

function Restore-Backup(
  [string]$ApplicationRoot,
  [string]$BackupRoot,
  [string]$RegistryBackup
) {
  Stop-LexProcesses $ApplicationRoot
  Remove-TreeLong $ApplicationRoot
  New-Item -ItemType Directory -Force -Path $ApplicationRoot | Out-Null
  Copy-DirectoryContents $BackupRoot $ApplicationRoot
  Restore-UninstallRegistry $RegistryBackup
}

# Every attempt leaves its reason in the journal the application reads on its next start,
# and a rejected update starts the unchanged application again: before, a check failing
# here (receipt, manifest, signature, installer version) left the app closed with no trace,
# and the next start offered the same update again.
$journal = if ($env:LOCALAPPDATA) {
  Join-Path $env:LOCALAPPDATA "LexMachina\update-transaction.json"
} else {
  Join-Path $env:TEMP "LexMachinaUpdate\update-transaction.json"
}
$runnerLog = Join-Path (Split-Path -Parent $journal) "update-runner.log"
try { Start-Transcript -LiteralPath $runnerLog -Append -ErrorAction Stop | Out-Null } catch { }

function Exit-Rejected([string]$Failure, [string]$TargetVersion) {
  try {
    Write-JsonAtomic $journal ([ordered]@{
      schemaVersion = 1
      state = "REJECTED"
      startedAt = (Get-Date).ToUniversalTime().ToString("o")
      targetVersion = $TargetVersion
      lastError = $Failure
    })
  } catch { }
  try { Wait-ParentExit $ParentPid } catch { }
  try {
    $root = Split-Path -Parent (Full-Path $AppExecutable)
    if (-not (Test-LexRunning $root) -and (Test-Path -LiteralPath $AppExecutable -PathType Leaf)) {
      Start-Process -FilePath $AppExecutable | Out-Null
    }
  } catch { }
  [Console]::Error.WriteLine("LEX_APPLICATION_UPDATE_REJECTED:$Failure")
  try { Stop-Transcript | Out-Null } catch { }
  exit 29
}

$offeredVersion = $null
try {
$receipt = Full-Path $ReceiptPath
$runtime = Full-Path $RuntimeRoot
$install = Full-Path $InstallRoot
$appExe = Full-Path $AppExecutable
$staging = Full-Path (Join-Path $env:TEMP "LexMachinaUpdate")

if (-not $receipt.StartsWith($staging.TrimEnd('\') + '\', [StringComparison]::OrdinalIgnoreCase)) {
  throw "UPDATE_RECEIPT_OUTSIDE_STAGING"
}
if ($runtime -ne (Full-Path (Join-Path $install "runtime"))) {
  throw "UPDATE_RUNTIME_ROOT_MISMATCH"
}
if (-not $appExe.StartsWith($install.TrimEnd('\') + '\', [StringComparison]::OrdinalIgnoreCase)) {
  throw "UPDATE_APP_EXECUTABLE_OUTSIDE_INSTALL_ROOT"
}

$currentManifestPath = Join-Path $runtime "release-source.json"
$currentManifest = Read-Json $currentManifestPath "UPDATE_CURRENT_MANIFEST"
$verificationMode = Get-UpdateVerificationMode $currentManifest
$trustedSigners = Get-TrustedSignerThumbprints $currentManifest
$currentVersion = try { [Version]([string]$currentManifest.applicationVersion) } catch {
  throw "UPDATE_CURRENT_VERSION_INVALID"
}

$receiptObject = Read-Json $receipt "UPDATE_RECEIPT"
if (
  [int]$receiptObject.schemaVersion -ne 1 -or
  [string]$receiptObject.kind -ne "LEX_MACHINA_APPLICATION_UPDATE"
) {
  throw "UPDATE_RECEIPT_SCHEMA_INVALID"
}
Assert-SimpleToken ([string]$receiptObject.installerToken) "UPDATE_INSTALLER_TOKEN_INVALID" ".exe"
if ([string]$receiptObject.sha256 -notmatch '^[a-fA-F0-9]{64}$') {
  throw "UPDATE_RECEIPT_HASH_INVALID"
}
if ($null -eq $receiptObject.publisher) {
  throw "UPDATE_RECEIPT_PUBLISHER_INVALID"
}

$receiptVerification = [string]$receiptObject.publisher.verification
if (
  $verificationMode -eq "SIGNED_REQUIRED" -and
  $receiptVerification -ne "AUTHENTICODE"
) {
  throw "UPDATE_RECEIPT_PUBLISHER_INVALID"
}
if (
  $verificationMode -eq "UNSIGNED_ALLOWED" -and
  $receiptVerification -notin @("AUTHENTICODE", "UNSIGNED_ALLOWED")
) {
  throw "UPDATE_RECEIPT_PUBLISHER_INVALID"
}
$offeredVersion = [string]$receiptObject.version
$targetVersion = try { [Version]([string]$receiptObject.version) } catch {
  throw "UPDATE_TARGET_VERSION_INVALID"
}
if ($targetVersion -le $currentVersion) {
  throw "UPDATE_TARGET_NOT_NEWER:current=$currentVersion target=$targetVersion"
}

$installer = Full-Path (Join-Path (Split-Path -Parent $receipt) ([string]$receiptObject.installerToken))
if (-not (Test-Path -LiteralPath $installer -PathType Leaf)) {
  throw "UPDATE_INSTALLER_MISSING:$installer"
}
$actualHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $installer).Hash.ToLowerInvariant()
if ($actualHash -ne ([string]$receiptObject.sha256).ToLowerInvariant()) {
  throw "UPDATE_INSTALLER_HASH_MISMATCH"
}
$verifiedThumbprint = $null
if ($receiptVerification -eq "AUTHENTICODE") {
  $verifiedThumbprint = Assert-Authenticode `
    $installer `
    $trustedSigners `
    ([string]$receiptObject.publisher.thumbprint)
} elseif ($verificationMode -eq "UNSIGNED_ALLOWED") {
  [void](Assert-InstallerProductVersion $installer $targetVersion)
} else {
  throw "UPDATE_RECEIPT_PUBLISHER_INVALID"
}
} catch {
  Exit-Rejected $_.Exception.Message $offeredVersion
}

Start-UpdateProgress $targetVersion.ToString()

$backupBase = if ($env:LOCALAPPDATA) {
  Join-Path $env:LOCALAPPDATA "LexMachina\update-backups"
} else {
  Join-Path $env:TEMP "LexMachinaUpdateBackups"
}
New-Item -ItemType Directory -Force -Path $backupBase | Out-Null
# Short: every character here lengthens the deepest path of the backup copy.
$backupRoot = Join-Path $backupBase (
  (Get-Date).ToUniversalTime().ToString("yyyyMMddHHmmss") +
  "-" + [Guid]::NewGuid().ToString("N").Substring(0, 6)
)
$filesBackup = Join-Path $backupRoot "install"
$registryBackup = Join-Path $backupRoot "registry"
$journalState = [ordered]@{
  schemaVersion = 1
  state = "PREPARED"
  startedAt = (Get-Date).ToUniversalTime().ToString("o")
  currentVersion = $currentVersion.ToString()
  targetVersion = $targetVersion.ToString()
  installRoot = $install
  backupRoot = $backupRoot
  receiptPath = $receipt
  installerPath = $installer
  verificationMode = $verificationMode
  publisherVerification = $receiptVerification
  signerThumbprint = $verifiedThumbprint
  unsignedWarning = if ($receiptVerification -eq "UNSIGNED_ALLOWED") {
    "TEMPORARY_UNSIGNED_UPDATE_ALLOWED"
  } else {
    $null
  }
  lastError = $null
}
Write-JsonAtomic $journal $journalState

# Failures before the install step (parent timeout, no space, locked file during
# backup, reg export) must not leave the app closed with a partial backup on disk:
# remove the partial backup and start the unchanged application again.
try {
  Wait-ParentExit $ParentPid
  Stop-LexProcesses $install
  Start-Sleep -Milliseconds 500

  $installBytes = Get-InstallSize $install
  Assert-BackupCapacity $backupBase $installBytes
  New-Item -ItemType Directory -Force -Path $backupRoot | Out-Null
  Copy-DirectoryContents $install $filesBackup
  Backup-UninstallRegistry $registryBackup
  $journalState.state = "BACKED_UP"
  $journalState.backupBytes = $installBytes
  Write-JsonAtomic $journal $journalState
} catch {
  $abortFailure = $_.Exception.Message
  Remove-TreeLong $backupRoot
  $journalState.state = "ABORTED_BEFORE_INSTALL"
  $journalState.lastError = $abortFailure
  Write-JsonAtomic $journal $journalState
  if (-not (Test-LexRunning $install) -and (Test-Path -LiteralPath $appExe -PathType Leaf)) {
    Start-Process -FilePath $appExe | Out-Null
  }
  # Write-Error would terminate here ($ErrorActionPreference = Stop) before exit 30.
  [Console]::Error.WriteLine("LEX_APPLICATION_UPDATE_ABORTED:$abortFailure")
  exit 30
}

$rollbackRequired = $true
try {
  $journalState.state = "INSTALLING"
  Write-JsonAtomic $journal $journalState

  $installProcess = Start-Process -FilePath $installer -ArgumentList @(
    "/S",
    "/UPDATE",
    "/D=$install"
  ) -Wait -PassThru
  if ($installProcess.ExitCode -notin @(0, 3010)) {
    throw "UPDATE_INSTALLER_FAILED:$($installProcess.ExitCode)"
  }

  $journalState.state = "VERIFYING"
  Write-JsonAtomic $journal $journalState

  $newRuntime = Join-Path $install "runtime"
  $newManifestPath = Join-Path $newRuntime "release-source.json"
  $newManifest = Read-Json $newManifestPath "UPDATE_NEW_MANIFEST"
  $installedVersion = try { [Version]([string]$newManifest.applicationVersion) } catch {
    throw "UPDATE_INSTALLED_VERSION_INVALID"
  }
  if ($installedVersion -ne $targetVersion) {
    throw "UPDATE_INSTALLED_VERSION_MISMATCH:expected=$targetVersion actual=$installedVersion"
  }

  if (-not (Test-Path -LiteralPath $appExe -PathType Leaf)) {
    throw "UPDATE_POSTCHECK_APP_MISSING"
  }
  $sidecar = Join-Path $newRuntime "lex-runtime-sidecar.exe"
  if (-not (Test-Path -LiteralPath $sidecar -PathType Leaf)) {
    throw "UPDATE_POSTCHECK_SIDECAR_MISSING"
  }
  $postcheck = Start-Process -FilePath $sidecar -ArgumentList @("--self-test") -Wait -PassThru -WindowStyle Hidden
  if ($postcheck.ExitCode -ne 0) {
    throw "UPDATE_POSTCHECK_FAILED:$($postcheck.ExitCode)"
  }

  $rollbackRequired = $false
  $journalState.state = "COMMITTED"
  $journalState.committedAt = (Get-Date).ToUniversalTime().ToString("o")
  Write-JsonAtomic $journal $journalState

  Remove-TreeLong $backupRoot
  Remove-Item -LiteralPath $receipt -Force -ErrorAction SilentlyContinue
  Remove-Item -LiteralPath $installer -Force -ErrorAction SilentlyContinue

  if (Test-Path -LiteralPath $appExe -PathType Leaf) {
    Start-Process -FilePath $appExe | Out-Null
  }
  Write-Host "LEX_APPLICATION_UPDATE_COMMITTED:$targetVersion"
  exit 0
} catch {
  $failure = $_.Exception.Message
  $journalState.state = "ROLLING_BACK"
  $journalState.lastError = $failure
  Write-JsonAtomic $journal $journalState

  if ($rollbackRequired) {
    try {
      Restore-Backup $install $filesBackup $registryBackup
      $restoredSidecar = Join-Path $install "runtime\lex-runtime-sidecar.exe"
      if (-not (Test-Path -LiteralPath $restoredSidecar -PathType Leaf)) {
        throw "UPDATE_ROLLBACK_SIDECAR_MISSING"
      }
      $rollbackCheck = Start-Process -FilePath $restoredSidecar -ArgumentList @("--self-test") -Wait -PassThru -WindowStyle Hidden
      if ($rollbackCheck.ExitCode -ne 0) {
        throw "UPDATE_ROLLBACK_HEALTHCHECK_FAILED:$($rollbackCheck.ExitCode)"
      }
      $journalState.state = "ROLLED_BACK"
      $journalState.rolledBackAt = (Get-Date).ToUniversalTime().ToString("o")
      Write-JsonAtomic $journal $journalState
      # Restored and health-checked: the backup copy is no longer needed.
      Remove-TreeLong $backupRoot
      if (Test-Path -LiteralPath $appExe -PathType Leaf) {
        Start-Process -FilePath $appExe | Out-Null
      }
      # Write-Error would throw here ($ErrorActionPreference = Stop) and mark the rollback failed.
      [Console]::Error.WriteLine("LEX_APPLICATION_UPDATE_ROLLED_BACK:$failure")
      exit 31
    } catch {
      $rollbackFailure = $_.Exception.Message
      $journalState.state = "ROLLBACK_FAILED"
      $journalState.rollbackError = $rollbackFailure
      Write-JsonAtomic $journal $journalState
      [Console]::Error.WriteLine("LEX_APPLICATION_UPDATE_ROLLBACK_FAILED:update=$failure rollback=$rollbackFailure")
      exit 32
    }
  }
  throw
}
