﻿param(
  [Parameter(Mandatory=$true)][string]$PayloadRoot
)

$ErrorActionPreference = "Stop"
$root = (Resolve-Path $PayloadRoot).Path

function Require-File([string]$Relative) {
  $path = Join-Path $root $Relative
  if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
    throw "SELFTEST_FILE_MISSING:$Relative"
  }
  return $path
}
function Require-Dir([string]$Relative) {
  $path = Join-Path $root $Relative
  if (-not (Test-Path -LiteralPath $path -PathType Container)) {
    throw "SELFTEST_DIR_MISSING:$Relative"
  }
  return $path
}

$node = Require-File "node\node.exe"
$python = Require-File "python\python.exe"
$server = Require-File "app\dist\http\server.js"
$sidecar = Require-File "lex-runtime-sidecar.exe"
$lockPath = Require-File "component-lock.json"
$appUpdateTransaction = Require-File "bootstrap\app-update-transaction.ps1"
$appUpdateVerification = Require-File "bootstrap\app-update-verification.ps1"
$llamaWebConfigurator = Require-File "bootstrap\configure-llama-native-web.ps1"
$visionInstaller = Require-File "bootstrap\install-local-vision.ps1"
$llamaWebMcp = Require-File "bootstrap\llama-web-mcp.py"
$llamaLegalMcp = Require-File "bootstrap\llama-legal-skills-mcp.py"
$llamaDocumentsMcp = Require-File "bootstrap\llama-local-documents-mcp.py"
$llamaMistralTemplate = Require-File "bootstrap\mistral-nemo-web-grounded.jinja"
$llamaBielikTemplate = Require-File "bootstrap\bielik-web-grounded.jinja"
$ocrWorker = Require-File "ocr\paddle_worker.py"
# Speech-to-text of recordings (model downloaded later, on the administrator's request).
$sttWorker = Require-File "ocr\whisper_worker.py"
# OCR on the graphics card (models downloaded later) and the page it is measured on.
$accelWorker = Require-File "ocr\onnx_accel.py"
$accelFixture = Require-File "ocr\fixtures\ocr-benchmark.pdf"
# Transcription on an NVIDIA card: the recording it is measured on (NVIDIA libraries downloaded later).
$sttFixture = Require-File "ocr\fixtures\stt-benchmark.opus"
$nerWorker = Require-File "privacy\stanza_ner_worker.py"
# Morfeusz with the PESEL and TERYT registers: the anonymizer's gazetteer, run as the runtime runs it.
$gazetteerWorker = Require-File "privacy\polish_pii_gazetteer.py"
$documentWorker = Require-File "storage\legal_document_worker.py"
$corpus = Require-Dir "corpus"
$paddle = Require-Dir "models\paddle\official_models"
$stanza = Require-Dir "models\stanza"
$pythonSelftest = Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) "windows-payload-python-selftest.py"
if (-not (Test-Path -LiteralPath $pythonSelftest -PathType Leaf)) {
  throw "SELFTEST_PYTHON_HELPER_MISSING"
}

$oldEnv = @{
  LEX_PADDLE_MODEL_DIR = $env:LEX_PADDLE_MODEL_DIR
  PADDLE_PDX_DISABLE_MODEL_SOURCE_CHECK = $env:PADDLE_PDX_DISABLE_MODEL_SOURCE_CHECK
  STANZA_RESOURCES_DIR = $env:STANZA_RESOURCES_DIR
  PYTHONNOUSERSITE = $env:PYTHONNOUSERSITE
  PYTHONUTF8 = $env:PYTHONUTF8
  PYTHONDONTWRITEBYTECODE = $env:PYTHONDONTWRITEBYTECODE
  HTTP_PROXY = $env:HTTP_PROXY
  HTTPS_PROXY = $env:HTTPS_PROXY
  ALL_PROXY = $env:ALL_PROXY
  NO_PROXY = $env:NO_PROXY
}
$env:LEX_PADDLE_MODEL_DIR = $paddle
$env:PADDLE_PDX_DISABLE_MODEL_SOURCE_CHECK = "True"
$env:STANZA_RESOURCES_DIR = $stanza
$env:PYTHONNOUSERSITE = "1"
$env:PYTHONUTF8 = "1"
# Locked runtime files must stay byte-identical: offline extraction resets
# source mtimes, so Python would otherwise rewrite locked __pycache__ files.
$env:PYTHONDONTWRITEBYTECODE = "1"
$env:HTTP_PROXY = "http://127.0.0.1:9"
$env:HTTPS_PROXY = "http://127.0.0.1:9"
$env:ALL_PROXY = "http://127.0.0.1:9"
$env:NO_PROXY = "127.0.0.1,localhost"

Write-Host "SELFTEST_STAGE:native-component-lock"
& $sidecar --self-test | Out-Host
if ($LASTEXITCODE -ne 0) {
  throw "SELFTEST_NATIVE_COMPONENT_LOCK_FAILED"
}

Write-Host "SELFTEST_STAGE:node"
& $node --version | Out-Host
if ($LASTEXITCODE -ne 0) { throw "SELFTEST_NODE_FAILED" }

Write-Host "SELFTEST_STAGE:optional-account-clients-not-bundled"
foreach ($forbidden in @(
  "app\node_modules\.bin\codex.cmd",
  "app\node_modules\.bin\claude.cmd",
  "app\node_modules\@openai\codex",
  "app\node_modules\@anthropic-ai\claude-code"
)) {
  if (Test-Path -LiteralPath (Join-Path $root $forbidden)) {
    throw "SELFTEST_OPTIONAL_ACCOUNT_CLIENT_BUNDLED:$forbidden"
  }
}
Write-Host "SELFTEST_OPTIONAL_ACCOUNT_CLIENTS_ON_DEMAND_PASS"

Write-Host "SELFTEST_STAGE:python-core"
& $python $pythonSelftest core | Out-Host
if ($LASTEXITCODE -ne 0) { throw "SELFTEST_PYTHON_CORE_IMPORT_FAILED" }

Write-Host "SELFTEST_STAGE:llama-native-web-mcp"
& $python $llamaWebMcp --self-test | Out-Host
if ($LASTEXITCODE -ne 0) { throw "SELFTEST_LLAMA_NATIVE_WEB_MCP_FAILED" }

Write-Host "SELFTEST_STAGE:llama-native-legal-skills-mcp"
& $python $llamaLegalMcp --skills-root $corpus --self-test | Out-Host
if ($LASTEXITCODE -ne 0) { throw "SELFTEST_LLAMA_NATIVE_LEGAL_SKILLS_MCP_FAILED" }

Write-Host "SELFTEST_STAGE:llama-native-local-documents-mcp"
& $python $llamaDocumentsMcp --runtime-root $root --self-test | Out-Host
if ($LASTEXITCODE -ne 0) { throw "SELFTEST_LLAMA_NATIVE_LOCAL_DOCUMENTS_MCP_FAILED" }

$skillFiles = @(Get-ChildItem -LiteralPath $corpus -Directory | Where-Object {
  Test-Path -LiteralPath (Join-Path $_.FullName "SKILL.md") -PathType Leaf
})
if ($skillFiles.Count -ne 32) {
  throw "SELFTEST_LLAMA_LEGAL_SKILL_COUNT_INVALID:expected=32:actual=$($skillFiles.Count)"
}

$templateText = Get-Content -Raw -LiteralPath $llamaMistralTemplate
if ($templateText -notmatch "LEX_WEB_GROUNDED_POLICY_V1" -or
    $templateText -notmatch "web_research" -or
    $templateText -notmatch "LEX_LEGAL_SKILLS_AUTO_POLICY_V1" -or
    $templateText -notmatch "legal_auto_route" -or
    $templateText -notmatch "LEX_LOCAL_DOCUMENT_PRIVACY_POLICY_V1" -or
    $templateText -notmatch "privacy_deanonymize_text" -or
    $templateText -notmatch "LEX_LEGAL_MCP_FEDERATION_POLICY_V1") {
  throw "SELFTEST_LLAMA_GROUNDED_TEMPLATE_INVALID"
}

$bielikTemplateText = Get-Content -Raw -LiteralPath $llamaBielikTemplate
if ($bielikTemplateText -notmatch "LEX_WEB_GROUNDED_POLICY_V1" -or
    $bielikTemplateText -notmatch "LEX_LEGAL_SKILLS_AUTO_POLICY_V1" -or
    $bielikTemplateText -notmatch "LEX_DIRECT_LEGAL_MCP_POLICY_V1" -or
    $bielikTemplateText -notmatch "documents_privacy_ocr_anonymize_file" -or
    $bielikTemplateText -notmatch "<tool_call>") {
  throw "SELFTEST_LLAMA_BIELIK_GROUNDED_TEMPLATE_INVALID"
}

$llamaConfiguratorText = Get-Content -Raw -LiteralPath $llamaWebConfigurator
if ($llamaConfiguratorText -notmatch [Regex]::Escape("audyt-systemu-v4\mcp-servers\dist\lex-mcp.mjs")) {
  throw "SELFTEST_LLAMA_LEX_MCP_PACKAGE_MISSING"
}
if ($llamaConfiguratorText -match "matematicsolutions|prawo-pl-mcp") {
  throw "SELFTEST_LLAMA_FOREIGN_MCP_PRESENT"
}
foreach ($server in @("isap","eurlex","saos","cbosa","krs","wl","nbp","eureka","sudop","uodo")) {
  if ($llamaConfiguratorText -notmatch ('"' + [Regex]::Escape($server) + '"')) {
    throw "SELFTEST_LLAMA_DIRECT_MCP_SERVER_MISSING:$server"
  }
}
if ($llamaConfiguratorText -notmatch "(?m)^\s{4}uodo_official\s*=\s*\[ordered\]@\{") {
  throw "SELFTEST_LLAMA_DIRECT_MCP_SERVER_MISSING:uodo_official"
}

# Keep native ML stacks in separate interpreter processes. Paddle/PaddleX and
# Torch load independent native DLL graphs on Windows; production OCR and NER
# workers are separate processes as well.
Write-Host "SELFTEST_STAGE:python-ocr-import"
& $python $pythonSelftest ocr-import | Out-Host
if ($LASTEXITCODE -ne 0) { throw "SELFTEST_PYTHON_OCR_IMPORT_FAILED" }

Write-Host "SELFTEST_STAGE:python-ner-import"
# Windows PowerShell 5.1 with "Stop" turns a native command's redirected stderr (a Python
# warning) into a terminating error: the exit code decides here, not the stream.
$previousPreference = $ErrorActionPreference
$ErrorActionPreference = "Continue"
try {
  $nerImport = & $python $pythonSelftest ner-import 2>&1 | Out-String
  $nerImportExit = $LASTEXITCODE
} finally {
  $ErrorActionPreference = $previousPreference
}
Write-Host $nerImport
if ($nerImportExit -ne 0) {
  # Stanza, torch and the Morfeusz dictionary: the Python error in the log the acceptance prints.
  Add-Content -LiteralPath (Join-Path $root "bootstrap\offline-payload-selftest.log") -Encoding UTF8 -Value ("SELFTEST_PYTHON_NER_IMPORT_FAILED`r`n" + $nerImport)
  throw "SELFTEST_PYTHON_NER_IMPORT_FAILED"
}

Write-Host "SELFTEST_STAGE:python-stt-import"
$previousPreference = $ErrorActionPreference
$ErrorActionPreference = "Continue"
try {
  $sttImport = & $python $pythonSelftest stt-import 2>&1 | Out-String
  $sttImportExit = $LASTEXITCODE
} finally {
  $ErrorActionPreference = $previousPreference
}
Write-Host $sttImport
if ($sttImportExit -ne 0) {
  Add-Content -LiteralPath (Join-Path $root "bootstrap\offline-payload-selftest.log") -Encoding UTF8 -Value ("SELFTEST_PYTHON_STT_IMPORT_FAILED`r`n" + $sttImport)
  throw "SELFTEST_PYTHON_STT_IMPORT_FAILED"
}

$requiredPaddle = @(
 "PP-LCNet_x1_0_doc_ori",
 "UVDoc",
 "PP-LCNet_x1_0_textline_ori",
 "PP-OCRv6_medium_det",
 "PP-OCRv6_medium_rec"
)
foreach ($name in $requiredPaddle) {
  if (-not (Test-Path (Join-Path $paddle $name) -PathType Container)) {
    throw "SELFTEST_PADDLE_MODEL_MISSING:$name"
  }
}
if (-not (Test-Path (Join-Path $stanza "resources.json") -PathType Leaf)) {
  throw "SELFTEST_STANZA_RESOURCES_MISSING"
}
if (-not (Test-Path (Join-Path $stanza "pl") -PathType Container)) {
  throw "SELFTEST_STANZA_PL_MISSING"
}

$lock = Get-Content -Raw -LiteralPath $lockPath | ConvertFrom-Json
if ($null -eq $lock.networkRequiredAtInstall) {
  throw "SELFTEST_LOCK_INSTALL_NETWORK_POLICY_MISSING"
}
if ($lock.runtimeNetworkRequiredAfterBootstrap -ne $false) {
  throw "SELFTEST_LOCK_RUNTIME_NETWORK_POLICY_INVALID"
}
if ($lock.expectedUserActionAfterInstall -ne "PROVIDER_API_KEY_OR_OPTIONAL_LOCAL_AI_SETUP") {
  throw "SELFTEST_LOCK_USER_ACTION_POLICY_INVALID"
}
if ($null -eq $lock.localAi -or $lock.localAi.requiredForApplicationHealth -ne $false) {
  throw "SELFTEST_LOCK_LOCAL_AI_POLICY_INVALID"
}
if (@($lock.optionalNetworkActionsAfterInstall) -notcontains "LOCAL_AI_PROVISIONING") {
  throw "SELFTEST_LOCK_LOCAL_AI_PROVISIONING_POLICY_MISSING"
}
if (@($lock.optionalNetworkActionsAfterInstall) -notcontains "ACCOUNT_SESSION_CLIENT_PROVISIONING") {
  throw "SELFTEST_LOCK_ACCOUNT_CLIENT_PROVISIONING_POLICY_MISSING"
}
foreach ($entry in $lock.files) {
  $path = Join-Path $root ($entry.path -replace '/','\')
  if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
    throw "SELFTEST_LOCK_FILE_MISSING:$($entry.path)"
  }
  $actual = (Get-FileHash -Algorithm SHA256 -LiteralPath $path).Hash.ToLowerInvariant()
  if ($actual -ne $entry.sha256) {
    throw "SELFTEST_LOCK_HASH_MISMATCH:$($entry.path)"
  }
}

$temp = Join-Path $env:TEMP ("lex-installer-selftest-" + [Guid]::NewGuid().ToString("N"))
New-Item $temp -ItemType Directory | Out-Null

try {
  Write-Host "Self-test: actual local OCR inference"
  $image = Join-Path $temp "ocr.png"
  $ocrOut = Join-Path $temp "ocr.json"
  & $python $pythonSelftest make-ocr-fixture $image
  if ($LASTEXITCODE -ne 0) { throw "SELFTEST_OCR_FIXTURE_FAILED" }
  & $python $ocrWorker --input $image --output $ocrOut --pages 1 --mode image --device cpu
  if ($LASTEXITCODE -ne 0) { throw "SELFTEST_OCR_INFERENCE_FAILED" }
  $ocrJson = Get-Content -Raw $ocrOut | ConvertFrom-Json
  if (@($ocrJson).Count -ne 1 -or $ocrJson[0].page -ne 1) {
    throw "SELFTEST_OCR_OUTPUT_INVALID"
  }

  Write-Host "Self-test: actual local Stanza NER inference"
  $nerInput = Join-Path $temp "ner.txt"
  $nerOut = Join-Path $temp "ner.json"
  [IO.File]::WriteAllText($nerInput, "Jan Kowalski spotkał Annę Nowak w Warszawie.", [Text.UTF8Encoding]::new($false))
  & $python $nerWorker --input $nerInput --output $nerOut
  if ($LASTEXITCODE -ne 0) { throw "SELFTEST_NER_INFERENCE_FAILED" }
  $nerJson = Get-Content -Raw $nerOut | ConvertFrom-Json
  if ($null -eq $nerJson) { throw "SELFTEST_NER_OUTPUT_INVALID" }

  Write-Host "Self-test: Morfeusz gazetteer (names, surnames, addresses)"
  $gazInput = Join-Path $temp "gazetteer.txt"
  $gazOut = Join-Path $temp "gazetteer.json"
  $gazErr = Join-Path $temp "gazetteer.err"
  [IO.File]::WriteAllText($gazInput, "Pozwany Jan Kowalski, zamieszkały przy ul. Długiej 5 w Krakowie, nie stawił się.", [Text.UTF8Encoding]::new($false))
  $previousPreference = $ErrorActionPreference
  $ErrorActionPreference = "Continue"
  try {
    & $python -X utf8 $gazetteerWorker --input $gazInput --output $gazOut 2> $gazErr
    $gazExit = $LASTEXITCODE
  } finally {
    $ErrorActionPreference = $previousPreference
  }
  if ($gazExit -ne 0) {
    # The Python error itself (a missing module, a DLL that does not load): what the app would show.
    $detail = if (Test-Path -LiteralPath $gazErr) { (Get-Content -Raw -LiteralPath $gazErr).Trim() } else { "" }
    if ($detail.Length -gt 1500) { $detail = $detail.Substring($detail.Length - 1500) }
    Write-Host $detail
    # The installer's message is cut short (NSIS): the whole error goes to the self-test log,
    # which the acceptance and the support read.
    $selftestLog = Join-Path $root "bootstrap\offline-payload-selftest.log"
    Add-Content -LiteralPath $selftestLog -Encoding UTF8 -Value ("SELFTEST_GAZETTEER_FAILED python=$python worker=$gazetteerWorker`r`n" + $detail)
    throw "SELFTEST_GAZETTEER_FAILED:$($detail -replace '\s+', ' ')"
  }
  $gazJson = Get-Content -Raw -Encoding UTF8 $gazOut | ConvertFrom-Json
  if (-not (@($gazJson) | Where-Object { $_.kind -eq "PERSON" })) { throw "SELFTEST_GAZETTEER_NO_PERSON" }
  if (-not (@($gazJson) | Where-Object { $_.kind -eq "ADDRESS" })) { throw "SELFTEST_GAZETTEER_NO_ADDRESS" }

  Write-Host "Self-test: deterministic local DOCX renderer"
  $renderRequest = Join-Path $temp "render.json"
  $renderOut = Join-Path $temp "render-result.json"
  $request = [ordered]@{
    operation = "render"
    format = "docx"
    ast = [ordered]@{
      schemaVersion = "1"
      documentType = "letter"
      locale = "pl-PL"
      styleProfile = "lex-classic-clean-v1"
      blocks = @(
        [ordered]@{
          type = "paragraph"
          content = @([ordered]@{ type = "text"; text = "Lex Machina self-test" })
        }
      )
    }
  } | ConvertTo-Json -Depth 12 -Compress
  [IO.File]::WriteAllText($renderRequest, $request, [Text.UTF8Encoding]::new($false))
  Get-Content -Raw $renderRequest | & $python $documentWorker | Out-File -FilePath $renderOut -Encoding utf8
  if ($LASTEXITCODE -ne 0) { throw "SELFTEST_DOCX_RENDER_FAILED" }
  $renderJson = Get-Content -Raw $renderOut | ConvertFrom-Json
  if (-not $renderJson.packageBase64 -or $renderJson.bytes -le 0) {
    throw "SELFTEST_DOCX_RENDER_OUTPUT_INVALID"
  }

  Write-Host "Self-test: loopback sidecar startup and authenticated health"
  $bootstrap = ([Guid]::NewGuid().ToString("N")) + ([Guid]::NewGuid().ToString("N"))
  $stdout = Join-Path $temp "sidecar.out"
  $stderr = Join-Path $temp "sidecar.err"
  $oldHost = $env:LEX_HOST
  $oldPort = $env:LEX_PORT
  $oldBootstrap = $env:LEX_DESKTOP_BOOTSTRAP_TOKEN
  $env:LEX_HOST = "127.0.0.1"
  $env:LEX_PORT = "0"
  $env:LEX_DESKTOP_BOOTSTRAP_TOKEN = $bootstrap
  $process = $null
  try {
    $process = Start-Process -FilePath $sidecar -WorkingDirectory $root -PassThru -RedirectStandardOutput $stdout -RedirectStandardError $stderr
    $deadline = (Get-Date).AddSeconds(90)
    $address = $null
    while ((Get-Date) -lt $deadline -and -not $process.HasExited) {
      Start-Sleep -Milliseconds 250
      if (Test-Path $stdout) {
        $text = Get-Content -Raw -ErrorAction SilentlyContinue $stdout
        if ($text -match '(http://127\.0\.0\.1:\d+)') {
          $address = $Matches[1]
          break
        }
      }
    }
    if (-not $address) {
      $details = ""
      if (Test-Path $stderr) { $details = Get-Content -Raw $stderr }
      throw "SELFTEST_SIDECAR_START_FAILED:$details"
    }
    $blocked = $false
    try {
      Invoke-WebRequest -UseBasicParsing -Uri ($address + "/health") -TimeoutSec 5 | Out-Null
    } catch {
      if ($_.Exception.Response.StatusCode.value__ -eq 401) { $blocked = $true }
    }
    if (-not $blocked) { throw "SELFTEST_BOOTSTRAP_GUARD_NOT_ENFORCED" }
    $health = Invoke-RestMethod -Uri ($address + "/health") -Headers @{ "X-Lex-Desktop-Bootstrap" = $bootstrap } -TimeoutSec 10
    if ($health.status -ne "ok" -or $health.localOnly -ne $true) {
      throw "SELFTEST_RUNTIME_HEALTH_INVALID"
    }
  } finally {
    if ($process) {
      # Kill the whole tree: the sidecar's Node child otherwise survives,
      # keeps the installer log open and blocks the install from finishing.
      # Its "not found" stderr must not turn into a terminating error.
      try {
        Start-Process -FilePath (Join-Path $env:SystemRoot "System32\taskkill.exe") `
          -ArgumentList @("/PID", $process.Id, "/T", "/F") `
          -WindowStyle Hidden -Wait -ErrorAction Stop | Out-Null
      } catch {
        Write-Host "Self-test tree cleanup note: $($_.Exception.Message)"
      }
      if (-not $process.HasExited) {
        Stop-Process -Id $process.Id -Force -ErrorAction SilentlyContinue
      }
    }

    # The Rust sidecar owns a child Node runtime. Stopping only the parent can
    # leave that child alive on Windows and make the release payload mutable
    # while the offline archive is being assembled.
    $runtimePrefix = $root.TrimEnd([char]92, [char]47) + [IO.Path]::DirectorySeparatorChar
    Get-Process -ErrorAction SilentlyContinue | ForEach-Object {
      try {
        if ($_.Path -and (
            $_.Path.StartsWith($runtimePrefix, [StringComparison]::OrdinalIgnoreCase) -or
            [string]::Equals($_.Path, $node, [StringComparison]::OrdinalIgnoreCase))) {
          Write-Host "Self-test cleanup: stopping runtime child $($_.ProcessName) pid=$($_.Id)"
          Stop-Process -Id $_.Id -Force -ErrorAction SilentlyContinue
        }
      } catch {
        Write-Host "Self-test runtime child cleanup note: $($_.Exception.Message)"
      }
    }
    Start-Sleep -Milliseconds 500

    $env:LEX_HOST = $oldHost
    $env:LEX_PORT = $oldPort
    $env:LEX_DESKTOP_BOOTSTRAP_TOKEN = $oldBootstrap
  }

  Write-Host "LEX_INSTALLER_SELFTEST_PASS:LOCAL_AI_OPTIONAL"
} finally {
  foreach ($key in $oldEnv.Keys) {
    Set-Item -Path ("Env:" + $key) -Value $oldEnv[$key] -ErrorAction SilentlyContinue
    if ($null -eq $oldEnv[$key]) {
      Remove-Item -Path ("Env:" + $key) -ErrorAction SilentlyContinue
    }
  }
  Remove-Item $temp -Recurse -Force -ErrorAction SilentlyContinue
}
