/**
 * The court a case signature belongs to, read from its repertory: a signature
 * is looked up only where that court publishes (II CSKP 89/26 is SN, never
 * CBOSA). Repertories of common courts are case-sensitive (II Cz is a common
 * court, III CZP is SN).
 */
export type SignatureCourt = "SN" | "NSA_WSA" | "POWSZECHNY" | "KIO" | "TK" | "DYSCYPLINARNY";

/** Repertories of Sąd Najwyższy (the sn.pl database). */
export const SN_REPERTORIES: ReadonlySet<string> = new Set([
  "CSK", "CSKP", "KK", "NKK", "UK", "NSNC", "NSNU", "NKN", "CNP", "CNPP", "SDI", "ZK", "CZP", "KZP",
  "UZP", "PZP", "NSNZP", "SNO", "DSI", "DSP", "CZ", "KO", "KSP", "NSW",
  // Izba Pracy i Ubezpieczeń Społecznych (II PSKP 12/23, III USK 5/22, I PZ 3/21, II PK 1/18).
  "PSK", "PSKP", "PZ", "PK", "PO", "USK", "USKP", "UZ", "UO",
  // Izba Kontroli Nadzwyczajnej i Spraw Publicznych (I NSNc 5/21, I NSNk 2/22, II NSNp 3/23, I NO 1/20).
  "NSNK", "NSNP", "NSK", "NO", "NW", "NWW", "NZP",
  // Izba Karna, Wojskowa, Odpowiedzialności Zawodowej (II KZ 1/22, III KS 2/21, WZ 1/20, ZO 5/22).
  "KZ", "KS", "WZ", "WK", "ZO", "ZZ", "ZP"
]);
// Izba Kontroli Nadzwyczajnej writes its repertories in mixed case ("I NSNc 5/21").
const SN_MIXED_CASE = /^NSN(?:c|k|p|u|zp)$/u;
const NSA = new Set(["OSK", "FSK", "GSK", "OZ", "FZ", "GZ", "OPS", "FPS", "GPS", "OW", "FW", "GW", "OPK", "FPK", "GPK"]);
const COMMON = new Set([
  "C", "Ca", "ACa", "ACz", "Cz", "Ns", "Nc", "Co", "Cps", "Nkd", "Nsm", "RC", "RCa", "RCz",
  "GC", "GCo", "GNc", "GNs", "Ga", "Gz", "AGa", "AGz", "GU", "Gzt",
  "K", "Ka", "Kz", "Kp", "Ko", "AKa", "AKz", "AKo", "W", "Wz", "Kop", "Kow",
  "P", "Pa", "Pz", "Po", "APa", "APz", "U", "Ua", "Uz", "AUa", "AUz", "Nmo"
]);
const TK = new Set(["K", "P", "SK", "U", "Kp", "Kpt", "Pp", "Ts", "Tw", "S"]);

// "II CSKP 89/26", "I SA/Wa 123/20", "KIO 512/25", "SK 3/20", "V ACa 12/2024".
const SIGNATURE = /(?<![\p{L}\d])((?:[IVXL]{1,5}\s+)?([A-Z][A-Za-z]{0,5})(?:\/([A-Z][a-z]{1,2}))?\s+\d{1,6}\/\d{2,4})(?![\p{L}\d])/gu;

export function courtOfSignature(value: string): SignatureCourt | null {
  const text = value.normalize("NFKC").replace(/\./g, "").replace(/\s+/g, " ").trim();
  const match = /^(?:([IVXL]{1,5})\s+)?([A-Z][A-Za-z]{0,5})(?:\/([A-Z][a-z]{1,2}))?\s+\d{1,6}\/\d{2,4}$/u.exec(text);
  if (!match) return null;
  const [, roman, repertory, seat] = match as unknown as [string, string | undefined, string, string | undefined];
  if (repertory === "KIO") return "KIO";
  // Wyższy Sąd Dyscyplinarny Adwokatury ("WSD 113/22"): its own portal, not sn.pl or SAOS (RD 121/26).
  if (!roman && repertory === "WSD") return "DYSCYPLINARNY";
  if (seat) return /^SAB?$/.test(repertory) ? "NSA_WSA" : null;
  if (NSA.has(repertory)) return "NSA_WSA";
  if ((repertory === repertory.toUpperCase() || SN_MIXED_CASE.test(repertory)) && SN_REPERTORIES.has(repertory.toUpperCase())) return "SN";
  if (roman && COMMON.has(repertory)) return "POWSZECHNY";
  if (!roman && TK.has(repertory)) return "TK";
  return null;
}

/** Signatures in free text (a query, a claim) with their courts. */
export function signaturesIn(text: string): Array<{ signature: string; court: SignatureCourt }> {
  const found: Array<{ signature: string; court: SignatureCourt }> = [];
  for (const match of text.normalize("NFKC").matchAll(SIGNATURE)) {
    const signature = match[1]!.replace(/\s+/g, " ").trim();
    const court = courtOfSignature(signature);
    if (court && !found.some((item) => item.signature === signature)) found.push({ signature, court });
  }
  return found;
}

const WHERE: Record<SignatureCourt, { label: string; use: string; card: string }> = {
  SN: {
    label: "Sąd Najwyższy",
    use: "verify_case_reference (courtFamily=SN); źródłem jest karta orzeczenia na sn.pl",
    card: "https://www.sn.pl/pl/wyszukiwarka-orzeczen"
  },
  NSA_WSA: {
    label: "NSA/WSA",
    use: "search_case_law source=CBOSA albo cbosa_sprawdz_sygnature (snapshot, bez awansu)",
    card: "https://orzeczenia.nsa.gov.pl/cbo/query"
  },
  POWSZECHNY: {
    label: "sąd powszechny",
    use: "sp_sprawdz_sygnature (Portal Orzeczeń; link do samego orzeczenia; sad=miasto.so rozstrzyga powtórzenia), SAOS tylko zastępczo",
    card: "https://orzeczenia.ms.gov.pl"
  },
  KIO: { label: "Krajowa Izba Odwoławcza", use: "kio_sprawdz_sygnature (UZP)", card: "https://orzeczenia.uzp.gov.pl" },
  TK: { label: "Trybunał Konstytucyjny", use: "tk_sprawdz_sygnature (karta sprawy IPO, OTK ZU; nie SAOS), a dokument sprawdź tk_pobierz", card: "https://ipo.trybunal.gov.pl" },
  DYSCYPLINARNY: {
    label: "Wyższy Sąd Dyscyplinarny Adwokatury",
    use: "web_search (site:wsd.adwokatura.pl) i fetch_auxiliary_legal_source na stronie orzeczenia w portalu WSD; dyscyplinarne orzeczenia SN (SDI, DSI) przez verify_case_reference",
    card: "https://wsd.adwokatura.pl"
  }
};

// Courts each search source publishes.
const COVERS: Record<string, readonly SignatureCourt[]> = {
  cbosa: ["NSA_WSA"],
  kio: ["KIO"],
  saos: ["SN", "POWSZECHNY", "KIO"],
  sn: ["SN"],
  sp: ["POWSZECHNY"],
  tk: ["TK"]
};

/**
 * A search for a signature in a source that does not publish its court:
 * the redirect to the right source instead of a misleading "no hits".
 */
export function misroutedSignature(
  source: string,
  text: string
): { status: "OUT_OF_SCOPE"; reason: "SIGNATURE_OF_OTHER_COURT"; signature: string; court: string; useInstead: string; officialSearch: string; note: string } | null {
  const covers = COVERS[source.toLowerCase()];
  if (!covers) return null;
  const signatures = signaturesIn(text);
  if (!signatures.length || signatures.some((item) => covers.includes(item.court))) return null;
  const { signature, court } = signatures[0]!;
  const where = WHERE[court];
  return {
    status: "OUT_OF_SCOPE",
    reason: "SIGNATURE_OF_OTHER_COURT",
    signature,
    court: where.label,
    useInstead: where.use,
    officialSearch: where.card,
    note: `Sygnatura ${signature} należy do: ${where.label}. Źródło ${source} nie publikuje tych orzeczeń; brak trafień tutaj nic nie mówi o istnieniu orzeczenia.`
  };
}

export function signatureRedirect(signature: string): { court: string; useInstead: string; officialSearch: string } | null {
  const court = courtOfSignature(signature);
  return court ? { court: WHERE[court].label, useInstead: WHERE[court].use, officialSearch: WHERE[court].card } : null;
}

/**
 * Links that are not sources: a blob: address exists only in one browser tab;
 * the old sn.pl PDF directory (/sites/orzecznictwo/Orzeczenia3/II CSKP 89-26.pdf)
 * no longer serves decisions. The signature in an old PDF name is recovered.
 */
export function caseLinkProblem(value: string): { kind: "BLOB" | "SN_LEGACY_PDF"; signature?: string } | null {
  const text = value.trim();
  if (/^blob:/i.test(text)) return { kind: "BLOB" };
  let url: URL;
  try {
    url = new URL(text);
  } catch {
    return null;
  }
  if (!/(^|\.)sn\.pl$/i.test(url.hostname) || !/\/sites\/orzecznictwo\//i.test(url.pathname)) return null;
  const name = decodeURIComponent(url.pathname.split("/").pop() ?? "").replace(/\.(pdf|docx?|rtf)$/i, "");
  const signature = /^(.*\S)\s+(\d{1,6})-(\d{2,4})(?:-\d+)?$/u.exec(name.replace(/_/g, " "));
  const recovered = signature ? `${signature[1]} ${signature[2]}/${signature[3]}` : undefined;
  return { kind: "SN_LEGACY_PDF", ...(recovered && courtOfSignature(recovered) === "SN" ? { signature: recovered } : {}) };
}

// Official case-law databases: the court's or the authority's own (sn.pl, CBOSA, the courts'
// portal, TK, KIO, CURIA/EUR-Lex, the MS database of ECHR judgments, UODO). SAOS (an
// aggregator), LEX, Legalis and other legal portals, law firms' pages and blogs are leads.
const OFFICIAL_CASE_LAW_SOURCES: ReadonlySet<string> = new Set(["sn", "cbosa", "sp", "tk", "kio", "eurlex", "etpcz", "uodo"]);
const OFFICIAL_CASE_LAW_HOSTS =
  // Disciplinary courts of the professions publish their own rulings (bar, legal advisers,
  // doctors, bailiffs, auditors, engineers): an official anchor, shown 🟨 without promotion.
  /(?:^|\.)(?:sn\.pl|wsd\.adwokatura\.pl|wsd\.kirp\.pl|nil\.org\.pl|komornik\.pl|pibr\.org\.pl|piib\.org\.pl|orzeczenia\.nsa\.gov\.pl|orzeczenia\.ms\.gov\.pl|orzeczenia\.[a-z-]+\.(?:so|sa|sr)\.gov\.pl|trybunal\.gov\.pl|ipo\.trybunal\.gov\.pl|orzeczenia\.uzp\.gov\.pl|curia\.europa\.eu|eur-lex\.europa\.eu|hudoc\.echr\.coe\.int|etpcz\.ms\.gov\.pl|uodo\.gov\.pl)$/iu;

/** A tool call that reads an official case-law database (its signatures are an official anchor). */
export function officialCaseLawCall(call: { name: string; input?: unknown }): boolean {
  const input = (call.input ?? {}) as Record<string, unknown>;
  if (typeof input.source === "string") return OFFICIAL_CASE_LAW_SOURCES.has(input.source);
  if (typeof input.url === "string") {
    try {
      return OFFICIAL_CASE_LAW_HOSTS.test(new URL(input.url).hostname);
    } catch {
      return false;
    }
  }
  return false;
}
