import { ChatTurnJournal, errorCode, modelKindOf, PhaseClock, type ChatTurnRecord } from "./chat-turn-journal.js";
import type { LlmImage } from "./providers/types.js";
import { directImageNote, type DirectImage } from "./direct-images.js";
import { todayWarsaw } from "./warsaw-date.js";
import { DOCUMENT_OUTPUT_CONTRACT_HEADING } from "./document-output-contract.js";
import { detectHealthData } from "./privacy/health-data.js";
import { WAIT_FOR_USER_MARKER, waitsForUser } from "./workflow-wait.js";
import { escalationOffer, reductionOffer, type SkillSwitchOffer } from "./skill-switch.js";
import { compactForModel, laterTurn, reachedStages, stageTailPrompt } from "./skill-sections.js";
import { decodePromptBudget } from "./prompt-budget.js";
import type { CheckpointRegisterEntry } from "./process-checkpoint-contract.js";
import {
  FinalizationGate,
  addMissingVerificationMarkers,
  verifiedLedgerMarkers,
  markUnverifiedReferences
} from "./finalization-gate.js";
import type { MatterComplexity } from "./matter-complexity.js";
import { verificationSourceLink } from "./source-anchor.js";
import {
  evaluateStatusConsistency,
  unifyConflictingProvisions,
  qualifyCompleteVerificationClaims,
  reconcileStatusMarkers,
  stripUnbackedVerificationMarkers
} from "./status-consistency-gate.js";
import { genericWords } from "./privacy/generic-words.js";
import { compactActAbbreviations, provisionsForDetection } from "./legal-act-abbreviations.js";
import { exampleDataKeepDirectives } from "./privacy/example-data.js";
import { registryEnrichmentFor, type RegistryEnrichment } from "./privacy/registry-enrichment.js";
import type { EvidenceImage } from "./document-evidence.js";
import type { PseudonymizationVaultSnapshot } from "./privacy/pseudonymizer.js";
import {
  placeholderGrammar,
  partyGroups,
  placeholderKeyPrompt,
  type PlaceholderGrammar
} from "./privacy/token-legend.js";
import { citedArticles, citedArticlesPrompt, coreLawRetrievalPrompt } from "./core-law-tool-runtime.js";
import {
  restoreWithReport,
  type Restoration
} from "./privacy/restoration-report.js";
import type {
  PersonMorphology
} from "./privacy/person-morphology.js";
import {
  AuditTrail,
  type AuditEvent
} from "./audit-trail.js";
import { AuditedFinalizer } from "./audited-finalizer.js";
import { withoutModelRoutingTrace } from "./routing-trace-leak.js";
import { discloseRegistryIdentifiers } from "./tool-broker-policy.js";
import {
  LexExecutionEngine,
  latestUserTurn,
  isTrivialChatCommand,
  withoutCorrectionPreface,
  type ExecutionEvent
} from "./execution-engine.js";
import { ProviderGateway } from "./providers/gateway.js";
import type { ExecutionStepReporter } from "./execution-steps.js";
import type {
  NormalizedToolCall,
  NormalizedToolResult,
  ProviderId,
  ProviderStreamParams,
  StreamCallbacks
} from "./providers/types.js";
import { LexSkillRegistry } from "./registry.js";
import {
  VerificationLedger,
  type VerificationRecord
} from "./verification-ledger.js";
import type {
  LegalVerificationToolFactory
} from "./verification-tool-runtime.js";
import {
  coreLawEliCaution,
  type CoreLawIndex
} from "./core-law-index.js";
import {
  CoreLawToolRuntime
} from "./core-law-tool-runtime.js";
import {
  LegalCorpusToolRuntime
} from "./legal-corpus-tool-runtime.js";
import {
  LegalFederationToolRuntime,
  type LegalFederationAuditEvent
} from "./legal-federation-tool-runtime.js";
import type {
  LegalSourceCrossCheckStatus,
  LegalSourceTier
} from "./legal-source-policy.js";
import { WidgetToolRuntime, widgetsFromAnswer, type WidgetSpec } from "./widget-runtime.js";
import { CaseFileToolRuntime, type CaseFileAccess } from "./case-file-tool-runtime.js";
import { astTextLines } from "./ast-text-lines.js";
import {
  revalidateThreadEvidence,
  threadEvidencePrompt,
  type ThreadEvidence
} from "./thread-evidence.js";
import type { LegalActDescriptor } from "./legal-act-resolver.js";
import { MAX_SUMMARY_CHARS } from "./thread-summary.js";
import { documentCoverage, type DocumentCoverage } from "./document-coverage.js";
import { CAUSAL_QUESTION, CAUSAL_RESOURCE, isoDates, supervisedChecks, type SupervisedCheck } from "./supervised-content.js";
export { CAUSAL_QUESTION } from "./supervised-content.js";

// Skills whose result rests on reading the documents through (a partial read is unfinished).
const COVERAGE_SKILLS: ReadonlySet<string> = new Set([
  "analiza-sadowa-v6",
  "analizator-dowodow-v3",
  "analizator-umow-v1",
  "chronologia-sprawy-v1",
  "raport-sytuacyjny-v2",
  "raport-klienta-v1",
  "przesluchanie-swiadkow-v2-min90",
  "pisma-procesowe-v3"
]);
import fs from "node:fs";
import path from "node:path";
import { randomUUID } from "node:crypto";
import {
  ROUTER_SKILL,
  evaluateMandatoryPath,
  gateCorrectionPrompt,
  loadMandatoryPathModel,
  foreignJurisdiction,
  mandatoryPathInstructions,
  missingGateBlocks,
  pathProfile,
  analysisRequested,
  preloadForTurn,
  routingTrace,
  type MandatoryPathModel,
  type MandatoryPathReport,
  type PathProfile
} from "./mandatory-path.js";
import { queryModePrompt, type QueryModeDecision } from "./query-mode.js";
import { meterUsage, type ModelUsage } from "./providers/usage-meter.js";
import type { TemporalFreshnessResult } from "./temporal-source-freshness.js";
import {
  ReportBlueprintToolRuntime,
  type AcceptedReportBlueprint,
  type ReportBlueprintKind
} from "./report-blueprint-tool-runtime.js";
import { blueprintFinalizationText } from "./report-blueprint-finalization.js";
import { BLUEPRINT_REPAIR_REQUEST, blueprintRepairSchema } from "./report-blueprint-repair.js";
import {
  evaluateDeterministicWorkflowOutput,
  evaluateDeterministicWorkflowReads,
  type DeterministicWorkflowReadReport
} from "./deterministic-workflow.js";
import {
  documentCitationSystemPrompt,
  processDocumentCitationMarkers,
  type PublicDocumentCitation
} from "./document-citations.js";
import type {
  ProcessPleadingCheckpoint,
  ProcessPleadingCheckpointStatus,
  ProcessPleadingMode,
  ProcessPleadingStage
} from "./process-pleading-state.js";
import type {
  CourtAnalysisCheckpoint,
  CourtAnalysisStage
} from "./court-analysis-state.js";
import type {
  ChronologyCheckpoint,
  ChronologyStage
} from "./chronology-state.js";
import type {
  ContractCheckpoint,
  ContractStage,
  ContractWorkflowMode
} from "./contract-analysis-state.js";
import {
  orchestrateDocumentContext,
  type ContextBudgetReport
} from "./context-orchestrator.js";
import {
  evaluateGuideOutput,
  type GuideSessionState
} from "./guide-session-state.js";
import {
  evaluateGateIInvariants,
  type GateIInvariantReport
} from "./gate-i-invariants.js";
import {
  blockGateITurn,
  createGateITurnState,
  passGateITurnPhase,
  type GateITurnState
} from "./gate-i-turn-state.js";
import {
  evaluateModelTaskOwnershipGate,
  resolveReferencePreflightOwnership
} from "./model-task-ownership.js";
import { officialCaseLawCall, signaturesIn } from "./court-of-signature.js";
import { addVerifiedJournalAddresses, ambiguousBareArticles, completeBareArticleActs, detectLegalReferences, mentionedCaseNumbers, ownCaseFileNumbers, type LegalReferenceKind } from "./finalization-gate.js";
import { amountKeysIn } from "./amount-references.js";
import { checkProvisionsAtEventDates, eventDates } from "./event-date-check.js";
import { parseDisclaimer, splitTrailingDisclaimer, withDisclaimer } from "./legal-disclaimer.js";
import { criminalDocument, criminalMatter } from "./matter-signals.js";
import { buildAccentMap, restoreAccents, type AccentMap } from "./accent-restoration.js";
import { answerCorrection, CORRECTED_ANSWER_FORM, emptyDeferral, NO_ANSWER_CORRECTION, removedSentences, type AnswerCorrection } from "./answer-corrections.js";
import { executiveSkillTexts } from "./accent-restoration-corpus.js";
import { classifyDocument, recognisedDocumentsPrompt, type RecognisedDocument } from "./document-kind.js";
import {
  ANALYSIS_INTENT,
  classifyTask,
  decideTask,
  type DeliveredMaterial,
  parseActivationMatrix,
  parseCombinations,
  parseRedactionTest,
  parseRoutingTable,
  nextChoices,
  pipelineNext,
  stepSummary,
  type NextChoice,
  type MatrixRule,
  type RedactionTest,
  type SkillCombination,
  type TaskDecision,
  type TaskRoute,
  opponentPleadingTrigger,
  replyRolesPrompt
} from "./task-routing.js";
import { CONTRACT_BUDGET_CHARS, contractPrompt, executiveContract, loadContract } from "./executive-skill-contract.js";
import { loadModules, modulesPrompt, schemaCatalog, skillModules } from "./skill-module-map.js";
import { domainHintPrompt, parseFlashRouting, rankDomains, suggestDomainModules, type DomainModule, type FlashRoute } from "./domain-module-map.js";
import { domainFallbackChoice, domainFallbackTarget, fallbackDomains } from "./domain-fallback.js";
import { isNonLegalMessage } from "./turn-gate.js";
import { actModulesPrompt, loadActModules, resolveActModulesWithChecks } from "./act-map-resolver.js";
import { issueKey } from "./case-work.js";
import { longDocumentRule } from "./long-document.js";
import { CourtToolRuntime } from "./courts/court-tool-runtime.js";
import { addresseeCourt, caseCourtPrompt, type CaseCourt } from "./courts/case-court.js";
import { districtCourt, regionalCourt } from "./courts/court-base.js";
import {
  applyAutomaticVerificationMarkers,
  releaseModelUnverifiedMarkers,
  detectHistoricalAsOf,
  planAutomaticLegalVerification
} from "./gate-i-auto-verification.js";
import {
  runGateIRuntimePrelude
} from "./gate-i-runtime-prelude.js";
import {
  evaluateGateIInputCompleteness,
  evaluateGateIWorkflowContract,
  gateIWorkflowContract,
  type GateIWorkflowContractReport
} from "./gate-i-contracts.js";
import type {
  OrderedCaseWorkflowId
} from "./ordered-case-workflow-state.js";
import {
  LocalPolishPseudonymizer,
  PseudonymizationVault,
  sealResidualValues,
  type NamedEntityRecognizer
} from "./privacy/pseudonymizer.js";
import {
  ModelAutoRouter,
  type ModelAutoRoutingResult
} from "./model-auto-routing.js";
import {
  privacyRecognizerFor
} from "./privacy/local-llm-ner.js";
import {
  earlierUserTurns,
  parseSkillSelectionEnvelope,
  SKILL_SELECTION_ENVELOPE_PREFIX,
  threadUserText
} from "./skill-selection.js";
import { withoutOutputContract } from "./document-output-contract.js";
import { markdownSection } from "./checkpoint-skill-sections.js";
import { caseContentCorrectionPrompt, caseContentFindings, caseContentWarning, caseSignaturesIn, citedDocuments, courtAttributionFindings, courtCorrectionPrompt, courtWarning } from "./case-content-grounding.js";
import { AUTHORITY_RULE, ROLE_LEGEND, SEMANTIC_JUDGE_SYSTEM, type SemanticVerdict, parseSemanticVerdicts, semanticCorrectionPrompt, semanticJudgePrompt, semanticProblems, semanticWarning } from "./case-semantic-check.js";

// analizator-umow-v1 1.52: the whole-document check of a delivered contract-like document.
const CONTRACT_WHOLE_DOCUMENT_RESOURCE = "analizator-umow-v1/SKILL.md";
const CONTRACT_WHOLE_DOCUMENT_HEADING = "## KONTROLA CAŁOŚCIOWA DOKUMENTU (CAL-GATE)";

// The judge: the competent authority's decision only, on passages labelled by role
// (calibration on 1000 cases, 2026-10-13).
// The question the cited documents are judged against: the latest user message whole, and for a
// short follow-up ("a inny wyrok?") the two earlier ones that carry its criteria (court, period,
// legal problem). Three trailing lines of the thread lost both.
export function judgedQuestion(query: string): string {
  const users = query
    .split(/\n\n(?=Użytkownik: |Asystent: )/u)
    .filter((part, index) => (index === 0 ? !part.startsWith("Asystent: ") : part.startsWith("Użytkownik: ")))
    .map((part) => part.replace(/^Użytkownik: /u, "").trim())
    .filter(Boolean);
  const latest = users.at(-1) ?? query.trim();
  const earlier = users.slice(0, -1).reverse().slice(0, 2);
  return latest.length < 300 && earlier.length
    ? `${latest}\n\n[Wcześniej w wątku, od najnowszego:]\n${earlier.map((turn) => turn.slice(0, 600)).join("\n")}`
    : latest.slice(0, 2_000);
}

const JUDGE_SYSTEM = `${SEMANTIC_JUDGE_SYSTEM} ${AUTHORITY_RULE}${ROLE_LEGEND}`;

export type SessionDocumentAttachment = {
  documentId: string;
  caseId?: string;
  grammar?: PlaceholderGrammar[];
  totalPages?: number;
  // Uses the case's shared key: its tokens are the chat's tokens, not namespaced.
  sharedKey?: boolean;
  sourceScope?:
    | "MANUAL"
    | "CASE_KNOWLEDGE"
    | "FIRM_KNOWLEDGE"
    | "FIRM_TEMPLATE";
  // Shown to the model for firm templates (a filename, no case data).
  title?: string;
  // Picked by the user (not retrieved): sent whole or not at all.
  selectedByUser?: boolean;
  // Page images (photos; text pages on request), personal data masked.
  images?: EvidenceImage[];
  chunks: Array<{
    index: number;
    pageStart: number;
    pageEnd: number;
    text: string;
    representation?:
      | "FULL"
      | "EXTRACTIVE_DIGEST";
    originalChars?: number;
  }>;
};

export type SessionExecutionRequest = {
  query: string;
  // The case's shared key: names in the message get the documents' symbols.
  privacySeed?: PseudonymizationVaultSnapshot;
  documentAttachments?: SessionDocumentAttachment[];
  // Images sent as they are (base64, unmasked), chosen by the user per file (direct-images.ts).
  directImages?: DirectImage[];
  provider: ProviderId;
  model: string;
  accountSessionKey?: string;
  // "none": fresh account host session, no resumed or recorded thread (document generator).
  accountContinuity?: "none";
  modelRouting?: {
    primary: {
      provider: ProviderId;
      model: string;
    };
  };
  primarySkill: string;
  mode: "LAIK" | "PRAWNIK";
  // Set only by the AUTO router (decision.legal === false): answer without
  // loading legal skills, modules or legal tools.
  conversationalOnly?: boolean;
  // The message corrects a fact of the conversation (applyFactCorrectionGate).
  factCorrection?: boolean;
  // AUTO for account/API models: the model picks skills itself.
  modelSelectsSkills?: boolean;
  // Runtime-only (never parsed from HTTP): result of the entry gate.
  matterComplexity?: MatterComplexity;
  // Runtime-only (never parsed from HTTP): receives the live draft text of
  // the model answer with the chat pseudonyms already restored.
  onDraft?: (text: string) => void;
  // Runtime-only: a document alias token ([PII:KIND:NNNN|CASE] of one
  // document's own vault) restored for the live draft; throws when unknown.
  restoreDocumentToken?: (documentId: string, sourceToken: string) => string;
  // Runtime-only: the stage of the turn and what was done in it (skills, tools).
  onStep?: ExecutionStepReporter;
  // Runtime-only (never parsed from HTTP): the matter's full files for the
  // case file tools, bound to the caller's access.
  caseFiles?: CaseFileAccess;
  // Runtime-only: the case's files searched for signatures the answer names (no model tool;
  // also for a local model and the file's generation).
  caseSignatureSearch?: Pick<CaseFileAccess, "search">;
  // Runtime-only (never parsed from HTTP): the court of the case from its memory (case-court.ts).
  caseCourt?: CaseCourt;
  // Runtime-only (never parsed from HTTP): the matter's evidence memory from
  // the encrypted case workspace.
  threadEvidence?: ThreadEvidence;
  // Runtime-only: references earlier turns left unverified (the case's open issues):
  // verified by the application before the model answers, so the register can close them.
  openIssueClaims?: string[];
  // Dates (yyyy-mm-dd) of the case's timeline the application put before the conversation
  // (http/app.ts): the answer is checked for using it.
  caseTimelineDates?: string[];
  // Runtime-only: LAIK / PRAWNIK decided at the entry from the question (KROK 1).
  modeDecision?: QueryModeDecision;
  modelContextTokens?: number;
  tokenCharsPerToken?: number;
  // The current user message without chat history (grammar of placeholders).
  auxiliaryText?: string;
  guideContext?: Pick<
    GuideSessionState,
    | "revision"
    | "audience"
    | "interactionMode"
    | "rawAnalysis"
    | "step"
    | "guidedQuestionIndex"
    | "pendingIrreversibleAction"
  >;
  // Sesja generatora pisma (LegalDocumentAstGenerator): wynik to JSON AST.
  documentAstOutput?: boolean;
  // The .docx of a pleading the case's pipeline already wrote (route checked the state).
  processRenderOnly?: { stage: ProcessPleadingStage };
  // The .docx of a contract the case's contract pipeline drafted (route checked AU-HYBRID and
  // AU-STRIP): rendered from the conversation, no AU checkpoint runs.
  contractRenderOnly?: boolean;
  processWorkflowContext?: {
    stage: ProcessPleadingStage;
    checkpoint: ProcessPleadingCheckpoint;
    mode: ProcessPleadingMode;
    // The case's checkpoint register (closed / N/A with reason / open), from the workflow state.
    register?: CheckpointRegisterEntry[];
    // The newest pleading text kept between stages and the user's remarks to a step
    // sent back for correction (process-pleading-draft.ts).
    draft?: { version: number; source: "PIPELINE" | "USER"; stage: ProcessPleadingStage; text: string };
    remarks?: string;
  };
  courtWorkflowContext?: {
    stage: Exclude<
      CourtAnalysisStage,
      "COMPLETE"
    >;
    checkpoint:
      CourtAnalysisCheckpoint;
  };
  chronologyWorkflowContext?: {
    stage: Exclude<
      ChronologyStage,
      "COMPLETE"
    >;
    checkpoint:
      ChronologyCheckpoint;
    temporalGateRequired: boolean;
  };
  contractWorkflowContext?: {
    mode: ContractWorkflowMode;
    stage: Exclude<
      ContractStage,
      "COMPLETE"
    >;
    checkpoint:
      ContractCheckpoint;
  };
  orderedCaseWorkflowContext?: {
    workflowId:
      OrderedCaseWorkflowId;
    checkpoint: string;
    revision: number;
  };
};

// A follow-up this short ("ok, robisz to.") carries no task of its own.
const FOLLOW_UP_MAX_CHARS = 160;
const CRIMINAL_QUALIFIER_RESOURCE = "dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-kwalifikator-karnomaterialny.md";
  /(?<![\p{L}])(?:związ\p{L}*\s+przyczynow\p{L}*|przyczynowo[-\s]skutkow\p{L}*|co\s+z\s+czego\s+wynika|post\s+hoc|csqn|conditio\s+sine\s+qua\s+non|(?:czy|co)\s+(?:\p{L}+\s+){0,6}(?:spowodował\p{L}*|doprowadził\p{L}*|wywołał\p{L}*)|przerw\p{L}*\s+(?:\p{L}+\s+){0,2}związ\p{L}*|wyklucz\p{L}*\s+(?:\p{L}+\s+){0,3}(?:związ\p{L}*|przyczyn\p{L}*)|łańcuch\p{L}*\s+przyczyn\p{L}*)(?![\p{L}])/iu;

// Skills in the corpus under one base name in several versions ("x-v1", "x-v2").
// Host CLI thread per matter (Claude --resume, Codex resume): off unless LEX_ACCOUNT_RESUME=1.
export function resumeHostThread(env: NodeJS.ProcessEnv = process.env): boolean {
  return env.LEX_ACCOUNT_RESUME === "1";
}

// Mechanical mode: the user pinned an executive skill (envelope with auto:false from the
// chat), not the model's own selection (AUTO) or the model-routed prepass.
// Court names: the procedure a question names, not the domain of its matter.
const COURT_NAME = /^(?:NSA|WSA|SN|SA|SO|SR|TK|TSUE|ETPC|ETPCz|Sąd(?:u|em|zie)?(?:\s+\S+)?|sąd\S*)$/u;

export function mechanicalTurn(request: Pick<SessionExecutionRequest, "query" | "modelSelectsSkills">): boolean {
  if (request.modelSelectsSkills) return false;
  const envelope = parseSkillSelectionEnvelope(request.query);
  return !envelope.automatic && !envelope.modelRouted && envelope.manualSkills.length > 0;
}

function duplicateSkills(names: string[]): string[] {
  const byBase = new Map<string, string[]>();
  for (const name of names) {
    const base = name.replace(/-v\d+$/u, "");
    byBase.set(base, [...(byBase.get(base) ?? []), name]);
  }
  return [...byBase.values()].filter((group) => group.length > 1).map((group) => group.sort().join(" i "));
}

export type PublicBlockedReference = {
  claim: string;
  kind: LegalReferenceKind;
  line: number;
  status: string;
};

export type PublicAuxiliarySourceItem = {
  claim?: string;
  sourceUrl: string;
  sourceTier:
    LegalSourceTier;
  classification:
    "KNOWN_DOMAIN" |
    "CONSERVATIVE_R3";
  classificationBasis:
    string;
  crossCheckStatus:
    LegalSourceCrossCheckStatus;
  crossCheckUrl?: string;
  crossCheckTier?:
    | "R1"
    | "R2A";
  publishedAt?: string;
  updatedAt?: string;
  staleOrUndatedWarning:
    boolean;
  higherTierCrossCheckSatisfied:
    boolean;
  conflict: boolean;
  instruction: string;
};

export type PublicEvidenceItem = {
  claim: string;
  kind: VerificationRecord["kind"];
  status: VerificationRecord["status"];
  sourceUrl?: string;
  sourceAnchorUrl?: string;
  sourceTier?: VerificationRecord["sourceTier"];
  fetchedAt: string;
  verificationMethod?: VerificationRecord["verificationMethod"];
  temporalMode?: VerificationRecord["temporalMode"];
  asOf?: string;
  sourceFormat?: VerificationRecord["sourceFormat"];
  caseScope?: VerificationRecord["caseScope"];
  caseSignature?: string;
  evidenceHash?: string;
  supportQuoteHash?: string;
  // Judgment passage checked in the official text (exact quote or the quote
  // supporting a proposition): marked in the full-text preview.
  passage?: string;
  // Przepis powołany wyłącznie w bloku bramki (np. sąsiedni z WYJ-GATE S1).
  role?: "gate";
};

export function publicAuxiliarySourceFromToolResult(
  result:
    NormalizedToolResult
): PublicAuxiliarySourceItem | null {
  let payload:
    unknown;
  try {
    payload =
      JSON.parse(
        result.content
      );
  } catch {
    return null;
  }

  if (
    !payload ||
    typeof payload !==
      "object"
  ) {
    return null;
  }

  const value =
    payload as {
      status?: unknown;
      classification?: unknown;
      candidate?: {
        claim?: unknown;
        url?: unknown;
        tier?: unknown;
        provenance?: {
          classificationBasis?: unknown;
          publishedAt?: unknown;
          updatedAt?: unknown;
        };
        crossCheckStatus?: unknown;
        crossCheckUrl?: unknown;
        crossCheckTier?: unknown;
      };
      assessment?: {
        auxiliaryOnly?: unknown;
        staleOrUndatedWarning?: unknown;
        higherTierCrossCheckSatisfied?: unknown;
        conflict?: unknown;
        instruction?: unknown;
      };
    };

  const candidate =
    value.candidate;
  const assessment =
    value.assessment;
  const tier =
    candidate?.tier;

  if (
    value.status !== "OK" ||
    assessment
      ?.auxiliaryOnly !==
      true ||
    typeof candidate
      ?.url !== "string" ||
    (
      tier !== "R2B" &&
      tier !== "R3"
    ) ||
    (
      value.classification !==
        "KNOWN_DOMAIN" &&
      value.classification !==
        "CONSERVATIVE_R3"
    ) ||
    typeof candidate
      .provenance
      ?.classificationBasis !==
      "string" ||
    typeof candidate
      .crossCheckStatus !==
      "string" ||
    typeof assessment
      .staleOrUndatedWarning !==
      "boolean" ||
    typeof assessment
      .higherTierCrossCheckSatisfied !==
      "boolean" ||
    typeof assessment
      .conflict !==
      "boolean" ||
    typeof assessment
      .instruction !==
      "string"
  ) {
    return null;
  }

  const crossCheckStatus =
    candidate
      .crossCheckStatus;
  if (
    crossCheckStatus !==
      "NOT_REQUIRED" &&
    crossCheckStatus !==
      "PENDING" &&
    crossCheckStatus !==
      "CONFIRMED_R1_R2A" &&
    crossCheckStatus !==
      "CONFLICT" &&
    crossCheckStatus !==
      "UNAVAILABLE"
  ) {
    return null;
  }

  return {
    ...(typeof candidate
      .claim === "string" &&
    candidate.claim.trim()
      ? {
          claim:
            candidate.claim
              .trim()
        }
      : {}),
    sourceUrl:
      candidate.url,
    sourceTier:
      tier,
    classification:
      value
        .classification,
    classificationBasis:
      candidate
        .provenance
        .classificationBasis,
    crossCheckStatus,
    ...(typeof candidate
      .crossCheckUrl ===
      "string"
      ? {
          crossCheckUrl:
            candidate
              .crossCheckUrl
        }
      : {}),
    ...(candidate
      .crossCheckTier ===
        "R1" ||
    candidate
      .crossCheckTier ===
        "R2A"
      ? {
          crossCheckTier:
            candidate
              .crossCheckTier
        }
      : {}),
    ...(typeof candidate
      .provenance
      .publishedAt ===
      "string"
      ? {
          publishedAt:
            candidate
              .provenance
              .publishedAt
        }
      : {}),
    ...(typeof candidate
      .provenance
      .updatedAt ===
      "string"
      ? {
          updatedAt:
            candidate
              .provenance
              .updatedAt
        }
      : {}),
    staleOrUndatedWarning:
      assessment
        .staleOrUndatedWarning,
    higherTierCrossCheckSatisfied:
      assessment
        .higherTierCrossCheckSatisfied,
    conflict:
      assessment.conflict,
    instruction:
      assessment.instruction
  };
}

function normalizedAuxiliaryClaim(
  value: string
): string {
  return value
    .normalize("NFKC")
    .toLocaleLowerCase("pl")
    .replace(/\s+/gu, " ")
    .trim();
}

export function reconcileAuxiliarySourcesWithVerification(
  sources:
    PublicAuxiliarySourceItem[],
  records:
    VerificationRecord[]
): PublicAuxiliarySourceItem[] {
  return sources.map(
    (source) => {
      if (
        !source.claim ||
        source.conflict
      ) {
        return {
          ...source
        };
      }

      const claim =
        normalizedAuxiliaryClaim(
          source.claim
        );
      const verified =
        [...records]
          .reverse()
          .find(
            (record) =>
              normalizedAuxiliaryClaim(
                record.claim
              ) === claim &&
              (
                record.status ===
                  "VERIFIED" ||
                record.status ===
                  "SUPPORTED"
              ) &&
              (
                record.sourceTier ===
                  "R1" ||
                record.sourceTier ===
                  "R2A"
              ) &&
              Boolean(
                record.sourceUrl
                  ?.trim()
              )
          );

      if (
        !verified ||
        !verified.sourceUrl ||
        (
          verified.sourceTier !==
            "R1" &&
          verified.sourceTier !==
            "R2A"
        )
      ) {
        return {
          ...source,
          crossCheckStatus:
            source.crossCheckStatus ===
              "NOT_REQUIRED"
              ? "NOT_REQUIRED"
              : "PENDING",
          higherTierCrossCheckSatisfied:
            false
        };
      }

      return {
        ...source,
        crossCheckStatus:
          "CONFIRMED_R1_R2A",
        crossCheckUrl:
          verified.sourceUrl,
        crossCheckTier:
          verified.sourceTier,
        higherTierCrossCheckSatisfied:
          true
      };
    }
  );
}

// "art. 233 § 1 KK" next to "art. 233 KK" from the same place of the same
// source is one entry: the article is listed, its unit is not repeated.
function withoutRepeatedUnits(records: VerificationRecord[]): VerificationRecord[] {
  const key = (claim: string) => compactActAbbreviations(claim).toLocaleLowerCase("pl").replace(/\s+/g, " ").trim();
  const parts = (claim: string) => /^art\.?\s*(\d+[a-ząćęłńóśźż]*)(.*?)\s+(kc|kpc|kk|kpk|kpa|kp|kro|ksh|kw|kpw|pzp)$/u.exec(key(claim));
  const latest = new Map<string, VerificationRecord>();
  for (const record of records) {
    const id = `${record.kind}\u0000${key(record.claim)}\u0000${record.asOf ?? ""}`;
    latest.delete(id);
    latest.set(id, record);
  }
  const unique = [...latest.values()];
  return unique.filter((record) => {
    if (record.kind !== "statute" || record.status !== "VERIFIED") return true;
    const unit = parts(record.claim);
    if (!unit || !unit[2]!.trim()) return true;
    return !unique.some((other) => {
      const article = other.kind === "statute" && other.status === "VERIFIED" ? parts(other.claim) : null;
      return (
        article !== null &&
        !article[2]!.trim() &&
        article[1] === unit[1] &&
        article[3] === unit[3] &&
        (other.asOf ?? "") === (record.asOf ?? "") &&
        verificationSourceLink(other) === verificationSourceLink(record)
      );
    });
  });
}

// Wiersze bloków CN/WYJ/REM-GATE: nagłówek, CN-n, REM-n, „Oś n:”, „Art. X: S1 —”.
const GATE_LINE = /^\s*(?:(?:CN|WYJ|REM)-GATE\b|CN-\d|REM-\d|Oś \d+:|[^:\n]{0,80}:\s*S1\s*[—–-])/u;

function articleKey(claim: string): string | null {
  const article = /art\.\s*(\d+[a-z]*)/iu.exec(claim);
  const act = claim.trim().split(/\s+/u).at(-1);
  return article && act ? `${article[1]!.toLocaleLowerCase("pl")} ${act.toLocaleLowerCase("pl")}` : null;
}

// Przepisy zweryfikowane przez model tylko na potrzeby bramek (sąsiednie
// artykuły z WYJ-GATE S1/S2), których odpowiedź nie powołuje poza blokami bramek.
export function gateOnlyStatutes(answer: string): Set<string> {
  const lines = answer.split(/\r?\n/u);
  const inGate = new Set<string>();
  const outside = new Set<string>();
  for (const reference of detectLegalReferences(answer)) {
    if (reference.kind !== "statute") continue;
    const key = articleKey(reference.claim);
    if (!key) continue;
    (GATE_LINE.test(lines[reference.line - 1] ?? "") ? inGate : outside).add(key);
  }
  return new Set([...inGate].filter((key) => !outside.has(key)));
}

export function publicEvidenceBundle(
  records: VerificationRecord[],
  answer?: string
): PublicEvidenceItem[] {
  const gateOnly = answer ? gateOnlyStatutes(answer) : new Set<string>();
  const items = withoutRepeatedUnits(records).map((record) => ({
    ...(record.kind === "statute" && gateOnly.has(articleKey(record.claim) ?? "")
      ? { role: "gate" as const }
      : {}),
    claim: record.claim,
    kind: record.kind,
    status: record.status,
    ...(record.sourceUrl ? { sourceUrl: record.sourceUrl } : {}),
    ...(verificationSourceLink(record) !== record.sourceUrl
      ? { sourceAnchorUrl: verificationSourceLink(record)! }
      : {}),
    ...(record.sourceTier ? { sourceTier: record.sourceTier } : {}),
    fetchedAt: record.fetchedAt,
    ...(record.verificationMethod
      ? { verificationMethod: record.verificationMethod }
      : {}),
    ...(record.temporalMode ? { temporalMode: record.temporalMode } : {}),
    ...(record.asOf ? { asOf: record.asOf } : {}),
    ...(record.sourceFormat ? { sourceFormat: record.sourceFormat } : {}),
    ...(record.caseScope ? { caseScope: record.caseScope } : {}),
    ...(record.caseSignature ? { caseSignature: record.caseSignature } : {}),
    ...(record.evidenceHash ? { evidenceHash: record.evidenceHash } : {}),
    ...(record.supportQuoteHash
      ? { supportQuoteHash: record.supportQuoteHash }
      : {}),
    ...(record.kind === "case" && record.caseScope === "EXACT_QUOTE"
      ? { passage: record.claim }
      : record.kind === "case" && record.supportQuote
        ? { passage: record.supportQuote }
        : {})
  }));
  return [...items.filter((item) => !item.role), ...items.filter((item) => item.role)];
}

/** The text of a document AST (JSON), one line per block; anything else as it is. */
/** Signatures of the text found literally in the case's files: case references of the ledger. */
export async function registerCaseFileSignatures(
  text: string,
  ledger: VerificationLedger,
  caseFiles: Pick<CaseFileAccess, "search"> | undefined
): Promise<void> {
  if (!caseFiles) return;
  const known = new Set([...ledger.caseReferences(), ...ledger.caseFileNumbers(), ...ledger.retrievedCases()]);
  for (const signature of mentionedCaseNumbers([text]).filter((key) => !known.has(key)).slice(0, 20)) {
    const hits = await caseFiles.search(signature, 5).catch(() => []);
    if (hits.some((hit) => mentionedCaseNumbers([hit.text]).includes(signature))) ledger.addCaseReference(signature);
  }
}

export function astBlockLines(text: string): string {
  let parsed: unknown;
  try {
    parsed = JSON.parse(text.slice(text.indexOf("{"), text.lastIndexOf("}") + 1));
  } catch {
    return text;
  }
  const texts = (node: unknown): string =>
    typeof node === "string"
      ? ""
      : Array.isArray(node)
        ? node.map(texts).join("")
        : node && typeof node === "object"
          ? Object.entries(node as Record<string, unknown>).map(([key, value]) => (key === "text" && typeof value === "string" ? value : texts(value))).join("")
          : "";
  const blocks = (parsed as { blocks?: unknown })?.blocks;
  if (!Array.isArray(blocks)) return text;
  const lines: string[] = [];
  const walk = (block: unknown) => {
    if (!block || typeof block !== "object") return;
    const record = block as Record<string, unknown>;
    if (Array.isArray(record.items)) for (const item of record.items) lines.push(texts(item));
    else if (Array.isArray(record.rows)) for (const row of record.rows) lines.push(texts(row));
    else lines.push(texts(record));
  };
  for (const block of blocks) walk(block);
  return lines.filter((line) => line.trim()).join("\n");
}

export type SessionExecutionInternalState = {
  verificationRecords: VerificationRecord[];
  // The proceeding's own case numbers (not case law), for the file generated from this turn.
  caseFileNumbers?: string[];
  // Signatures the case's materials name (another proceeding): marked, never blocking, also in the file.
  caseReferences?: string[];
  factAmounts?: string[];
  auditEvents: AuditEvent[];
  documentAliasDocumentIds?: string[];
};

export const SESSION_EXECUTION_INTERNAL =
  Symbol("LEX_SESSION_EXECUTION_INTERNAL");

/** CHAT_PRIVACY_GATE_FAILED with the cause (recognizer codes, never the text) for diagnostics. */
export function privacyGateFailure(error: unknown): Error & { reason?: string } {
  const reason = (error instanceof Error ? error.message : String(error)).replace(/\s+/g, " ").slice(0, 400);
  return Object.assign(new Error("CHAT_PRIVACY_GATE_FAILED"), reason ? { reason } : {});
}

// A request to the user: a question, or a line opening with an asking verb.
const ASKS = /\?|(?:^|\n)\s*(?:[-*•]|\d+[.)])?\s*(?:\*\*)?(?:Podaj|Wskaż|Prześlij|Dołącz|Załącz|Wklej|Potwierdź|Wybierz|Określ|Uzupełnij|Doprecyzuj|Napisz,|Proszę)/u;

// Gate I checks that a G8 DEGRADED answer (citations marked, none unmarked) fails by design.
const MARKED_DRAFT_CHECKS = new Set(["CITATION_LEDGER", "LEGAL_CITATIONS", "FINALIZATION"]);

// The report frame's header of a done step: "✅ CHECKPOINT [CP-1b] … — ZAKOŃCZONY".
const FRAME_WAITS =
  /⛔\s*CHECKPOINT|CHECKPOINT[^\n]*WSTRZYMAN|czeka\p{L}*\s+na\s+(?:\p{L}+\s+)?(?:plik|dokument|materiał)\p{L}*|odpowie\p{L}*\s+na\s+(?:\d+\s+|wszystkie\s+|te\s+)?pytani\p{L}*/iu;
// The report frame's header of a step that stops ("⏸ CHECKPOINT [CP-1c-lancuch] — OTWARTY (czeka na decyzję)").
const HELD_FRAME = /⏸|⛔|OTWART\p{L}*|WSTRZYMAN\p{L}*|W\s+TOKU|czeka\p{L}*\s+na/iu;

/**
 * The active checkpoint's frame header, with its wrapped continuation ("✅ CHECKPOINT [CP-PRE-W2] —
 * PRE-W2-VERIFICATION-GATE —" / "ZAKOŃCZONY"), and where it starts; the last one before `end`.
 */
function frameHeader(answer: string, checkpoint: string, end = answer.length): { text: string; at: number } | null {
  const lines = answer.slice(0, end).split("\n");
  for (let index = lines.length - 1; index >= 0; index -= 1) {
    const line = lines[index]!;
    if (!/CHECKPOINT/iu.test(line) || !line.includes(`[${checkpoint}`)) continue;
    const next = (lines[index + 1] ?? "").replace(/[│|]/gu, " ").trim();
    const wrapped = /[—–-]\s*[│|]?\s*$/u.test(line) && next && !/^\p{L}[\p{L} ]*:/u.test(next) ? ` ${next}` : "";
    return { text: line + wrapped, at: lines.slice(0, index).join("\n").length + (index ? 1 : 0) };
  }
  return null;
}

/** The active checkpoint's frame says the step stops for the user, with or without the marker. */
export function frameHeld(answer: string, checkpoint: string | undefined): boolean {
  if (!checkpoint) return false;
  const header = frameHeader(answer, checkpoint)?.text;
  return header !== undefined && !DONE_FRAME.test(header) && HELD_FRAME.test(header);
}

const DONE_FRAME = /CHECKPOINT[^\n]*(?<!NIE[\s-]?)(?:ZAKOŃCZON|ZAMKNIĘT|WYKONAN)/iu;

/**
 * The answer is the active checkpoint's report, the marker added after it without asking.
 * A done step's frame ends with its confirmation prompt (➡️ …?, AUTOMAT-STANOW "Odpowiedz:
 * tak / ok / lub uwagi"): that question is the confirmation, not missing data, so only a
 * request after the frame keeps the step open (E2E: CP-1b re-run on every reply).
 */
export function reportOnly(answer: string, checkpoint: string | undefined): boolean {
  if (!checkpoint) return false;
  const marker = answer.lastIndexOf(WAIT_FOR_USER_MARKER);
  // The report starts at its frame header ("✅ CHECKPOINT [CP-1d-anomalie] …"), not at a later
  // mention of the id inside the frame ("Wyniki: [CP-1d-anomalie] N/A").
  const found = frameHeader(answer, checkpoint, Math.max(0, marker));
  const report = found ? found.at : answer.lastIndexOf(`[${checkpoint}`);
  if (report < 0 || marker <= report) return false;
  let tail = answer.slice(report, marker);
  // The frame itself says the step waits ("⛔ … WSTRZYMANY", "czeka na pliki", "czeka na
  // odpowiedź na 3 pytania", "➡️ Odpowiedz na pytania 1–3"): "ok" must not close it unanswered.
  if (FRAME_WAITS.test(tail)) return false;
  const header = found?.text ?? tail.slice(0, tail.indexOf("\n") + 1 || tail.length);
  const frameEnd = tail.search(/└|\n```/u);
  if (DONE_FRAME.test(header) && frameEnd >= 0) tail = tail.slice(frameEnd).replace(/^[^\n]*/u, "");
  return !ASKS.test(tail);
}

// Executive skills that work on the case's material, and what to ask for when there is none.
// Every citation carries its act: a bare "art. 36a" leaves the reader and the gates to guess the
// act (test 500: 43% of answers cited articles bare).
const CITATION_FORM_RULE = [
  "# FORMA POWOŁANIA PRZEPISU (aplikacja)",
  "Każde powołanie przepisu pisz z nazwą albo skrótem aktu, także przy kolejnym powołaniu tego samego przepisu: „art. 415 KC”, „art. 36a ustawy o kosztach sądowych w sprawach cywilnych”, „art. 35 ust. 3 Prawa budowlanego”. Nie pisz samego „art. 36a”.",
  "",
  "# PLIK PISMA (aplikacja)",
  // RD 121/26, live: "Pliku .docx nie mogę zapisać… wklej tekst do Worda" while the application makes it.
  "Plik .docx (i PDF) tworzy aplikacja z treści pisma: etap pisma albo przycisk „Generuj dokument”. Krok skilla „generowanie pliku” jest więc wykonywany przez aplikację — nie pisz, że nie możesz utworzyć pliku, i nie odsyłaj do Worda ani do kopiowania tekstu."
].join("\n");

const MATERIAL_SKILLS: Record<string, string> = {
  "analizator-umow-v1": "umowa (plik albo pełny tekst)",
  "analiza-sadowa-v6": "orzeczenie, pisma albo akta sprawy",
  "analizator-dowodow-v3": "dowody (dokumenty, zeznania, korespondencja)",
  "chronologia-sprawy-v1": "dokumenty sprawy, z których ma powstać oś czasu",
  "przesluchanie-swiadkow-v2-min90": "akta sprawy (zeznania, protokoły, pisma) i dane o świadku"
};
// A message this long carries the material itself (a pasted contract or statement).
const MATERIAL_PASTED_CHARS = 1_500;
// Test 500: "Zrób chronologię: 2.02.2026 umowa…, 5.02 zaliczka…, 15.04 brak montażu…" and a
// described defence ("świadek A zeznał…, na rozprawie…, monitoring od 23:41") were answered
// with a request for the material. Dated events or described evidence in the message are the
// material of a timeline, a court or evidence analysis or a witness plan (a contract still
// needs its text).
const MATERIAL_IN_WORDS_SKILLS = new Set(["chronologia-sprawy-v1", "analiza-sadowa-v6", "analizator-dowodow-v3", "przesluchanie-swiadkow-v2-min90"]);
const EVENT_DATE = /(?<![\d.])\d{1,2}\.\d{1,2}(?:\.\d{2,4})?(?![\d.])|(?<![\p{L}])\d{1,2}\s+(?:stycznia|lutego|marca|kwietnia|maja|czerwca|lipca|sierpnia|września|października|listopada|grudnia)(?![\p{L}])/giu;
const EVIDENCE_WORDS = /(?<![\p{L}])(?:zezna\p{L}*|świad\p{L}*|monitoring\p{L}*|nagrani\p{L}*|protok\p{L}*|opini\p{L}*\s+biegł\p{L}*|dowod\p{L}*|dowód|faktur\p{L}*|korespondencj\p{L}*|wiadomoś\p{L}*|SMS\p{L}*|e-?mail\p{L}*)(?![\p{L}])/giu;
export function materialInWords(skill: string, message: string): boolean {
  if (!MATERIAL_IN_WORDS_SKILLS.has(skill)) return false;
  const dates = message.match(EVENT_DATE)?.length ?? 0;
  const evidence = new Set((message.match(EVIDENCE_WORDS) ?? []).map((word) => word.toLocaleLowerCase("pl").slice(0, 5))).size;
  return dates >= 3 || (message.length >= 300 && evidence >= 2 && dates + evidence >= 3);
}

export type SessionExecutionResponse = {
  sessionId: string;
  status: "DRAFT_PRESENTABLE" | "BLOCKED";
  // Model tokens of the turn; unmeteredCalls = calls through account clients.
  usage?: ModelUsage;
  // Mandatory path of the turn (router, skills, verification, hard gate) from the audit.
  mandatoryPath?: MandatoryPathReport;
  // ACTIVATION-MATRIX: the next skill of the pipeline after this one (entry -> next).
  pipelineNext?: { skill: string; reason: string; choices?: NextChoice[] };
  // AUTO: the executive skill the router's table chose and the application loaded.
  taskSkill?: string;
  // Courts court_for_address returned in this turn (a letter's addressee is checked against them).
  courtsFound?: string[];
  // A letter addressed to a court that came neither from court_for_address nor from the case.
  courtCheck?: { unverified: string[] };
  // The court of the case the turn used or saved (http/app.ts, case memory).
  caseCourt?: { nazwa: string; zrodlo: "AKTA" | "PISMO" | "UZYTKOWNIK"; sygnatura?: string };
  // The answer is itself a letter kept with its session's trail: "Generuj dokument" makes its
  // file from this text mechanically (answer-document.ts), with no model turn.
  answerDocument?: { sessionId: string };
  // A long letter written in parts (long-document.ts): this answer's part and its check.
  longDocument?: {
    id: string;
    title: string;
    part: number;
    parts: number;
    ok: boolean;
    problems: string[];
    complete: boolean;
    next: number | null;
  };
  // pisma-procesowe-v3 Test A: the user's own pleading corrected (MOD-REDAKCJA), not a new one.
  taskMode?: "REDACTION";
  // The firm's default template the application used (none picked by the user).
  firmTemplateApplied?: { templateId: string; filename: string; kind: string };
  modeDecision?: QueryModeDecision;
  provider: ProviderId;
  model: string;
  modelRouting?: {
    primary: {
      provider: ProviderId;
      model: string;
    };
  };
  primarySkill: string;
  loadedSkills?: string[];
  executionSkills?: string[];
  domainSkills?: string[];
  answer?: string;
  documentCitations?: PublicDocumentCitation[];
  restorations?: Restoration[];
  unresolvedTokens?: string[];
  documentCitationFreshness?: {
    result: "PASS";
    checked: number;
  };
  reportBlueprint?: AcceptedReportBlueprint;
  finalization: "PASS" | "DEGRADED" | "BLOCKED";
  blockedReferences: PublicBlockedReference[];
  verification: {
    records: number;
    verified: number;
    supported: number;
    unverified: number;
  };
  evidence: PublicEvidenceItem[];
  auxiliarySources?:
    PublicAuxiliarySourceItem[];
  // sn.pl zablokował zapytanie konektora: czat pokazuje ramkę weryfikacji (captcha rozwiązuje użytkownik).
  sourceVerification?: { source: "sn"; url: string };
  // Widgety pokazane narzędziem show_widget (czat renderuje je w izolowanej ramce).
  widgets?: WidgetSpec[];
  audit: {
    result: "PASS" | "BLOCKED";
    eventCount: number;
    closed: boolean;
    missing?: string[];
    violations?: string[];
    // Zdarzenia BLOCKED: typ, cel i kod przyczyny, bez treści odpowiedzi i danych sprawy.
    blockedEvents?: string[];
  };
  workflow?: {
    id: string;
    result: "PASS" | "BLOCKED";
    requiredResources: string[];
    missingResources: string[];
    // BLOCKED only by citations marked ⚠️ [NIEWERYFIKOWANE] (G8 DEGRADED): a working draft.
    markedDraftOnly?: boolean;
  };
  gateI?: GateIInvariantReport;
  gateIWorkflowContract?: GateIWorkflowContractReport;
  gateITurn?: GateITurnState;
  context?: ContextBudgetReport;
  courtWorkflow?: {
    caseId: string;
    revision: number;
    stage:
      CourtAnalysisStage;
    nextCheckpoint:
      CourtAnalysisCheckpoint | null;
    closedCheckpoints:
      CourtAnalysisCheckpoint[];
  };
  chronologyWorkflow?: {
    caseId: string;
    revision: number;
    stage: ChronologyStage;
    temporalGateRequired: boolean;
    nextCheckpoint:
      ChronologyCheckpoint | null;
    closedCheckpoints:
      ChronologyCheckpoint[];
  };
  contractWorkflow?: {
    caseId: string;
    revision: number;
    mode: ContractWorkflowMode;
    stage: ContractStage;
    nextCheckpoint:
      ContractCheckpoint | null;
    closedCheckpoints:
      ContractCheckpoint[];
  };
  orderedCaseWorkflow?: {
    workflowId:
      OrderedCaseWorkflowId;
    caseId: string;
    revision: number;
    status:
      | "ACTIVE"
      | "COMPLETE";
    nextCheckpoint:
      string | null;
    closedCheckpoints:
      string[];
  };
  // The answer ends a checkpoint with a question to the user (workflow-wait.ts).
  waitingForUser?: boolean;
  // Pages of the case's documents read this turn; PARTIAL = the analysis of it is unfinished.
  documentCoverage?: DocumentCoverage[];
  // The turn analysed the documents: a PARTIAL one is open work the chat asks to finish.
  documentAnalysis?: boolean;
  // What the application's correcting rounds changed: findings and the removed sentences.
  corrections?: AnswerCorrection[];
  // The answer was kept as the case's timeline (case memory; http/app.ts).
  chronologySaved?: { updatedAt: string };
  // A workflow checkpoint left open: a step was refused during the turn (http/app.ts).
  checkpointHeld?: { reason: "BLOCKED_STEP"; steps: string[] };
  // The letter skill hands the matter to the other one (skill-switch.ts); the chat offers the switch.
  skillSwitch?: SkillSwitchOffer;
  processAuto?: {
    maxSteps: number;
    stopped:
      | "FINAL"
      | "LIMIT_REACHED"
      | "NODE_BLOCKED"
      | "WAITING_FOR_USER";
    limitReached: boolean;
    steps: Array<{
      stage: Exclude<
        ProcessPleadingStage,
        "CG_ACCEPTANCE" | "FINAL"
      >;
      checkpoint:
        ProcessPleadingCheckpoint;
      revisionAfter: number;
      status:
        "DRAFT_PRESENTABLE" | "BLOCKED";
      answer?: string;
    }>;
  };
  processWorkflow?: {
    caseId: string;
    mode: ProcessPleadingMode;
    revision: number;
    stage: ProcessPleadingStage;
    documentStatus: "DRAFT" | "FINAL";
    pendingCheckpoint: ProcessPleadingCheckpoint | null;
    checkpoints: Record<
      ProcessPleadingCheckpoint,
      ProcessPleadingCheckpointStatus
    >;
    // A new version of the pleading text written by this turn (the UI makes its file).
    draftWritten?: { version: number; checkpoint: ProcessPleadingCheckpoint };
  };
  [SESSION_EXECUTION_INTERNAL]?: SessionExecutionInternalState;
};

/**
 * Prefixes D01, D02... of own-key documents, in the order they reach the
 * model (context first, then case files read by tools). Shared-key documents
 * get none: their tokens are the chat's. Restoring an alias reads the
 * document id at position n-1 of documentIds().
 */
// Act modules of the case's second domains loaded with the prompt (one each, at most this).
const SECONDARY_DOMAIN_MODULES_BUDGET_CHARS = 25_000;

export class DocumentAliasRegistry {
  private readonly prefixes = new Map<string, string>();

  prefixFor(documentId: string): string {
    const existing = this.prefixes.get(documentId);
    if (existing) return existing;
    const prefix = "D" + String(this.prefixes.size + 1).padStart(2, "0");
    this.prefixes.set(documentId, prefix);
    return prefix;
  }

  documentIds(): string[] {
    return [...this.prefixes.keys()];
  }
}

export function namespaceChunkTokens(text: string, prefix: string): string {
  return text.replace(
    /\[PII:([A-Z_]+):(\d{4})\]/g,
    (_token, kind, sequence) => `[LMPII:${prefix}:${kind}:${sequence}]`
  );
}

export function namespaceDocumentAttachmentTokens(
  attachments: SessionDocumentAttachment[],
  registry = new DocumentAliasRegistry()
): SessionDocumentAttachment[] {
  const prefixFor = (documentId: string): string => registry.prefixFor(documentId);

  return attachments.map(
    (attachment) => {
      if (attachment.sharedKey) {
        return { ...attachment, chunks: attachment.chunks.map((chunk) => ({ ...chunk })) };
      }
      const prefix =
        prefixFor(
          attachment.documentId
        );
      return {
        ...attachment,
        ...(attachment.grammar
          ? {
              grammar: attachment.grammar.map((entry) => ({
                ...entry,
                token: entry.token.replace(
                  /^\[PII:/,
                  `[LMPII:${prefix}:`
                ),
                ...(entry.owner ? { owner: entry.owner.replace(/^\[PII:/, `[LMPII:${prefix}:`) } : {})
              }))
            }
          : {}),
        chunks:
          attachment.chunks.map(
            (chunk) => ({
              ...chunk,
              text: namespaceChunkTokens(chunk.text, prefix)
            })
          )
      };
    }
  );
}

/**
 * Stored page headers ("[STRONA 3 · CZĘŚĆ 1/2 · OCR]") as an explicit page
 * boundary with the page count, so a model knows how long the document is
 * and where each page starts.
 */
export function markPages(text: string, totalPages?: number): string {
  return text.replace(
    /^\[STRONA (\d+)(?: · CZĘŚĆ (\d+)\/(\d+))? · ([A-Z]+)\]$/gm,
    (_header, page: string, part?: string, parts?: string, source?: string) =>
      `=== STRONA ${page}${totalPages ? `/${totalPages}` : ""}` +
      (part && part !== "1" ? ` (ciąg dalszy, część ${part}/${parts})` : part ? ` (część ${part}/${parts})` : "") +
      (source === "OCR" ? " · tekst z OCR" : source === "BLANK" ? " · pusta" : "") +
      " ==="
  );
}

export type SelectedEvidenceImage = EvidenceImage & { documentId: string };

// At most this many images per message, and this much image data.
export const MAX_EVIDENCE_IMAGES = 20;
const MAX_EVIDENCE_BASE64 = 20 * 1024 * 1024;

/** Images of the pages whose chunks made it into the context, in order. */
export function selectEvidenceImages(
  requested: SessionDocumentAttachment[],
  inContext: SessionDocumentAttachment[]
): SelectedEvidenceImage[] {
  const selected: SelectedEvidenceImage[] = [];
  let size = 0;
  for (const attachment of inContext) {
    const source = requested.find((item) => item.documentId === attachment.documentId && item.images?.length);
    if (!source?.images) continue;
    for (const image of source.images) {
      const covered = attachment.chunks.some((chunk) => chunk.pageStart <= image.page && image.page <= chunk.pageEnd);
      if (!covered || selected.length >= MAX_EVIDENCE_IMAGES || size + image.data.length > MAX_EVIDENCE_BASE64) continue;
      size += image.data.length;
      selected.push({ ...image, documentId: attachment.documentId });
    }
  }
  return selected;
}

export const EVIDENCE_IMAGE_NOTE = [
  "# OBRAZY JAKO DOWÓD",
  "Do kontekstu dołączono obrazy (zdjęcia, strony) w kolejności podanej przy znacznikach [OBRAZ n].",
  "Czarne prostokąty zasłaniają dane osobowe i nieczytelne napisy: nie zgaduj, co pod nimi jest.",
  "Opisuj to, co widać (stan rzeczy, uszkodzenia, miejsce, układ, podpisy i pieczęcie jako fakt ich obecności); oddziel obserwację od wniosku i nie przypisuj osób na podstawie wyglądu.",
  "Nazwy i dane z dokumentu bierz z tekstu z symbolami [PII:...], nie z obrazu."
].join("\n");

function buildDocumentContext(
  attachments: SessionDocumentAttachment[],
  images: SelectedEvidenceImage[] = []
): string {
  const sections = attachments.map((attachment) => {
    const chunks = attachment.chunks.map((chunk) => {
      const sourceLabel =
        attachment.sourceScope === "FIRM_TEMPLATE"
          ? "WZÓR KANCELARII"
          : attachment.sourceScope === "FIRM_KNOWLEDGE"
            ? "KNOW-HOW KANCELARII"
            : attachment.sourceScope === "CASE_KNOWLEDGE"
              ? "CASE KNOWLEDGE"
              : "DOCUMENT";
      const representation =
        chunk.representation ===
          "EXTRACTIVE_DIGEST"
          ? " · EXTRACTIVE DIGEST · BACKLINK=ORIGINAL_CHUNK"
          : "";
      return [
        `[${sourceLabel} ${attachment.documentId} · CHUNK ${chunk.index} · PAGES ${chunk.pageStart}-${chunk.pageEnd}${representation}]`,
        markPages(chunk.text, attachment.totalPages)
      ].join("\n");
    });
    return [
      ...(attachment.title
        ? [`[${attachment.documentId} · PLIK: ${attachment.title}]`]
        : []),
      ...(attachment.totalPages
        ? [
            `[${attachment.documentId} · STRON: ${attachment.totalPages} · każda strona zaczyna się znacznikiem "=== STRONA n/${attachment.totalPages} ==="]`
          ]
        : []),
      ...chunks
    ].join("\n\n");
  });

  const firm = attachments.some(
    (attachment) => attachment.sourceScope === "FIRM_TEMPLATE" || attachment.sourceScope === "FIRM_KNOWLEDGE"
  );
  const imageIndex = images.length
    ? [
        EVIDENCE_IMAGE_NOTE,
        ...images.map(
          (image, index) =>
            `[OBRAZ ${index + 1}: ${image.documentId} · STRONA ${image.page} · zamaskowane obszary: ${image.masked}]`
        )
      ].join("\n")
    : null;
  return [...(firm ? [FIRM_MATERIAL_NOTE] : []), ...sections, ...(imageIndex ? [imageIndex] : [])].join("\n\n---\n\n");
}

export const buildDocumentContextForTest = buildDocumentContext;

export const FIRM_MATERIAL_NOTE = [
  "# MATERIAŁY KANCELARII",
  "Bloki oznaczone WZÓR KANCELARII i KNOW-HOW KANCELARII pochodzą z biblioteki kancelarii, nie z akt sprawy.",
  "- Wzór: przejmij jego układ, kolejność części, styl i stałe formuły; treść merytoryczną bierz z dokumentów sprawy i wiadomości użytkownika.",
  "- Nie przenoś do pisma danych przykładowych z wzoru (stron, sygnatur, kwot, dat, adresów); w miejsca bez danych wstaw neutralne pole w nawiasie kwadratowym, np. [Kwota], [Termin].",
  "- Materiały kancelarii nie są dowodami ani faktami w sprawie; nie cytuj ich jako źródła faktów.",
  "- Papier firmowy wzoru (nagłówek, logo, stopka, marginesy) aplikacja wstawia do pliku .docx sama; nie powtarzaj go w treści pisma."
].join("\n");

function transferExecutionEvents(
  events: ExecutionEvent[],
  audit: AuditTrail
): void {
  for (const event of events) {
    if (
      event.type === "skill_read" ||
      event.type === "resource_read" ||
      event.type === "route" ||
      event.type === "provider_start" ||
      event.type === "provider_end" ||
      event.type === "gate"
    ) {
      audit.record(
        event.type,
        event.target,
        event.status === "BLOCKED" ? "BLOCKED" : "OK",
        event.detail ? { detail: event.detail } : undefined
      );
    }
  }
}

function positiveEnvInt(name: string, fallback: number): number {
  const value = Number.parseInt(process.env[name] ?? "", 10);
  return Number.isInteger(value) && value > 0 ? value : fallback;
}

const DRAFT_PII_TOKEN =
  /\[PII:([A-Z_]+):(\d{4})(?:\|([A-Z]{2,4}))?\]/g;
const DRAFT_DOCUMENT_TOKEN =
  /\[LMPII:D(\d{2}):([A-Z_]+):(\d{4})(?:\|([A-Z]{2,4}))?\]/g;
// An incomplete token at the end of the stream is held back until complete.
const DRAFT_PARTIAL_TOKEN_TAIL =
  /\[(?:P(?:I(?:I(?::[A-Z_]*(?::\d{0,4}(?:\|[A-Z]{0,4})?)?)?)?)?)?$|\[L(?:M(?:P(?:I(?:I(?::[A-Z0-9_:|]{0,30})?)?)?)?)?$/;

export function createDraftCallbacks(
  vault: PseudonymizationVault,
  onDraft: (text: string) => void,
  // Document alias D01..: the token in that document's own vault, or null.
  restoreDocument?: (documentNumber: number, sourceToken: string) => string | null
): StreamCallbacks {
  let raw = "";
  const publish = () => {
    const visible =
      raw.replace(
        DRAFT_PARTIAL_TOKEN_TAIL,
        ""
      );
    onDraft(
      visible.replace(
        DRAFT_PII_TOKEN,
        (token, kind: string, sequence: string, requestedCase?: string) => {
          const base = `[PII:${kind}:${sequence}]`;
          return vault.hasToken(base)
            ? vault.restore(base, requestedCase ?? null).text
            : token;
        }
      ).replace(
        DRAFT_DOCUMENT_TOKEN,
        (token, documentNumber: string, kind: string, sequence: string, requestedCase?: string) =>
          restoreDocument?.(
            Number(documentNumber),
            requestedCase ? `[PII:${kind}:${sequence}|${requestedCase}]` : `[PII:${kind}:${sequence}]`
          ) ?? token
      )
    );
  };
  return {
    onContentDelta: (text: string) => {
      raw += text;
      publish();
    },
    // A tool round starts a new model turn; the previous partial text was
    // only a preamble to the tool call.
    onToolCallStart: () => {
      raw = "";
      publish();
    }
  };
}

export type ThreadSummaryRequest = {
  provider: ProviderId;
  model: string;
  privacySeed?: PseudonymizationVaultSnapshot;
  // Summary so far (also one corrected by the user); updated, not replaced.
  previousSummary?: string;
  messages: Array<{ role: "user" | "assistant"; content: string }>;
  threadEvidence?: ThreadEvidence;
};

export const THREAD_SUMMARY_PROMPT = [
  "Jesteś asystentem Lex Machina. Tworzysz streszczenie wcześniejszej części rozmowy w sprawie, które zastąpi te wiadomości w kontekście kolejnych odpowiedzi.",
  "Układ (nagłówki dokładnie takie): ## Fakty, ## Stanowiska stron, ## Ustalenia prawne, ## Dokumenty i dowody, ## Otwarte kwestie.",
  "- Tylko to, co jest w rozmowie; nic nie dopisuj, nie oceniaj na nowo i nie rozstrzygaj.",
  "- Ustalenia prawne: przepis z oznaczeniem aktu tak, jak w rozmowie. Nie przepisuj znaczników weryfikacji i nie podawaj brzmienia przepisów; status nada aplikacja z rejestru weryfikacji.",
  "- Symbole [PII:...] przepisuj dokładnie; nie zgaduj, kto się pod nimi kryje.",
  "- Jeśli jest dotychczasowe streszczenie, zaktualizuj je o nowe wiadomości i zachowaj jego poprawki (mogła je wprowadzić osoba prowadząca sprawę).",
  "- Najwyżej ok. 6000 znaków; zwięźle, w punktach."
].join("\n");

export interface SessionExecutor {
  resolveAutoRouting?(
    request: SessionExecutionRequest
  ): Promise<ModelAutoRoutingResult>;
  execute(request: SessionExecutionRequest): Promise<SessionExecutionResponse>;
  // Structured summary of older thread messages (pseudonymized for the model).
  summarizeThread?(request: ThreadSummaryRequest): Promise<string>;
  // The router's executive skill for a message without delivered material (AUTO).
  executiveSkillFor?(message: string): string | null;
  // The skills the task needs with the delivered files (entry and next stage of the matrix).
  executiveSkillsWithMaterials?(message: string, attachments: ReadonlyArray<{ chunks: ReadonlyArray<{ text: string }>; images?: readonly unknown[]; sourceScope?: string }>): string[];
  pleadingRedactionFor?(message: string, attachments?: ReadonlyArray<{ chunks: ReadonlyArray<{ text: string }>; images?: readonly unknown[]; sourceScope?: string }>): boolean;
}

/**
 * Wiadomość w postaci NFC przed pseudonimizacją: tekst wklejony z macOS bywa
 * rozłożony (NFD) i wtedy znane nazwiska oraz granice słów nie trafiają.
 */
export function nfcRequest(request: SessionExecutionRequest): SessionExecutionRequest {
  const query = request.query.normalize("NFC");
  const auxiliaryText = request.auxiliaryText?.normalize("NFC");
  if (query === request.query && auxiliaryText === request.auxiliaryText) return request;
  return { ...request, query, ...(auxiliaryText !== undefined ? { auxiliaryText } : {}) };
}

export class SafeSessionExecutor implements SessionExecutor {
  private readonly engine: LexExecutionEngine;
  private readonly autoRouter:
    ModelAutoRouter;

  constructor(
    private readonly registry: LexSkillRegistry,
    private readonly providers: ProviderGateway,
    private readonly finalizer = new AuditedFinalizer(),
    private readonly verificationToolFactory?: LegalVerificationToolFactory,
    private readonly chatNamedEntityRecognizer?: NamedEntityRecognizer,
    private readonly legalFederationTools?: LegalFederationToolRuntime,
    private readonly coreLawIndex?: CoreLawIndex,
    private readonly personMorphology?: PersonMorphology,
    // Current consolidated text of an act in Sejm ELI (evidence memory reuse).
    private readonly actFreshness?: (act: LegalActDescriptor) => Promise<TemporalFreshnessResult>
  ) {
    this.engine = new LexExecutionEngine(
      registry,
      providers
    );
    this.autoRouter =
      new ModelAutoRouter(
        registry,
        providers
      );
  }

  private mandatoryModelCache: { root: string; model: MandatoryPathModel } | null = null;

  // Corpus files of the mandatory path, by canonical path (router-relative or skill-qualified).
  private readCorpus(resource: string): string | null {
    const relative = resource.startsWith(`${ROUTER_SKILL}/`) ? resource.slice(ROUTER_SKILL.length + 1) : resource;
    const resolved = this.registry.resolveResource(ROUTER_SKILL, relative);
    if (!resolved) return null;
    try {
      return fs.readFileSync(resolved, "utf8");
    } catch {
      return null;
    }
  }

  /**
   * The executive skill the router gives a message on its own (KROK 2 table,
   * ACTIVATION-MATRIX, simple-letter catalogue), as this executor decides it in
   * AUTO for a turn without delivered material. Null: no executive skill.
   */
  executiveSkillFor(message: string): string | null {
    const query = /[ąćęłńóśźż]/iu.test(message) ? message : restoreAccents(message, this.accentMap());
    return (
      decideTask(this.taskRoutes(), this.activationMatrix(), query, [], this.redactionTest(), {
        skill: "pisma-proste-v2",
        entries: schemaCatalog(this.registry, "pisma-proste-v2")
      })?.primary ?? null
    );
  }

  /**
   * The router's task with the delivered files (ACTIVATION-MATRIX: "dostarcza akta / pismo
   * przeciwnika", "pismo procesowe + dostarczone akta"): the entry skill and its next stage.
   * Empty when the table names no task.
   */
  /** Stage the request names after a stateful workflow's own skill (router `then`). */
  statefulNextStage(question: string, materials: readonly DeliveredMaterial[], workflowSkill: string): string | null {
    const routed = decideTask(this.taskRoutes(), this.activationMatrix(), question, [...materials], this.redactionTest(), {
      skill: "pisma-proste-v2",
      entries: schemaCatalog(this.registry, "pisma-proste-v2")
    });
    return routed?.primary === workflowSkill ? routed.then ?? null : null;
  }

  executiveSkillsWithMaterials(
    message: string,
    attachments: ReadonlyArray<{ chunks: ReadonlyArray<{ text: string }>; images?: readonly unknown[]; sourceScope?: string }>
  ): string[] {
    const query = /[ąćęłńóśźż]/iu.test(message) ? message : restoreAccents(message, this.accentMap());
    const materials = attachments
      .filter((attachment) => attachment.sourceScope !== "FIRM_TEMPLATE" && attachment.sourceScope !== "FIRM_KNOWLEDGE")
      .map((attachment) => classifyDocument({ text: attachment.chunks.map((chunk) => chunk.text).join("\n"), images: attachment.images?.length ?? 0 }));
    const decision = decideTask(this.taskRoutes(), this.activationMatrix(), query, materials, this.redactionTest(), {
      skill: "pisma-proste-v2",
      entries: schemaCatalog(this.registry, "pisma-proste-v2")
    });
    return decision ? [decision.primary, ...(decision.then ? [decision.then] : [])] : [];
  }

  /**
   * pisma-procesowe-v3 KROK 0 Test A: the message delivers a finished pleading and asks for
   * its form (shorter, firmer, smoother), handled by MOD-REDAKCJA without W1–W3.
   */
  pleadingRedactionFor(
    message: string,
    // Files delivered with the message: an attached pleading ("popraw ten pozew" + file)
    // is Test A as well; before, only text pasted into the chat was.
    attachments: ReadonlyArray<{ chunks: ReadonlyArray<{ text: string }>; images?: readonly unknown[]; sourceScope?: string }> = []
  ): boolean {
    const query = /[ąćęłńóśźż]/iu.test(message) ? message : restoreAccents(message, this.accentMap());
    const materials = attachments
      .filter((attachment) => attachment.sourceScope !== "FIRM_TEMPLATE" && attachment.sourceScope !== "FIRM_KNOWLEDGE")
      .map((attachment) => classifyDocument({ text: attachment.chunks.map((chunk) => chunk.text).join("\n"), images: attachment.images?.length ?? 0 }));
    const decision = decideTask(this.taskRoutes(), this.activationMatrix(), query, materials, this.redactionTest(), {
      skill: "pisma-proste-v2",
      entries: schemaCatalog(this.registry, "pisma-proste-v2")
    });
    return decision?.primary === "pisma-procesowe-v3" && (decision.modules ?? []).some((module) => /MOD-REDAKCJA/u.test(module));
  }

  private taskRoutesCache: { root: string; routes: TaskRoute[] } | null = null;

  // The router's KROK 2 table, re-read after a skill update.
  private taskRoutes(): TaskRoute[] {
    if (this.taskRoutesCache?.root === this.registry.root) return this.taskRoutesCache.routes;
    const routes = parseRoutingTable(this.readCorpus(`${ROUTER_SKILL}/SKILL.md`) ?? "");
    this.taskRoutesCache = { root: this.registry.root, routes };
    return routes;
  }

  private accentCache: { root: string; map: AccentMap } | null = null;

  // Polish spelling of the executive skills' words, for a message typed without it.
  private accentMap(): AccentMap {
    if (this.accentCache?.root === this.registry.root) return this.accentCache.map;
    this.accentCache = { root: this.registry.root, map: buildAccentMap(executiveSkillTexts(this.registry)) };
    return this.accentCache.map;
  }

  private flashRoutesCache: { root: string; rows: FlashRoute[] } | null = null;

  // prawo-polskie-v2 "Routing błyskawiczny", re-read after a skill update.
  private flashRoutes(): FlashRoute[] {
    if (this.flashRoutesCache?.root === this.registry.root) return this.flashRoutesCache.rows;
    const rows = parseFlashRouting(this.readCorpus("prawo-polskie-v2/SKILL.md") ?? "");
    this.flashRoutesCache = { root: this.registry.root, rows };
    return rows;
  }

  private combinationsCache: { root: string; rows: SkillCombination[] } | null = null;

  private skillCombinations(): SkillCombination[] {
    if (this.combinationsCache?.root === this.registry.root) return this.combinationsCache.rows;
    const rows = parseCombinations(this.readCorpus("shared/ACTIVATION-MATRIX.md") ?? "");
    this.combinationsCache = { root: this.registry.root, rows };
    return rows;
  }

  private redactionCache: { root: string; test: RedactionTest | null } | null = null;

  // pisma-procesowe-v3 KROK 0 Test A (editing a finished pleading), from the corpus.
  private redactionTest(): RedactionTest | null {
    if (this.redactionCache?.root === this.registry.root) return this.redactionCache.test;
    const record = this.registry.get("pisma-procesowe-v3");
    let test: RedactionTest | null = null;
    try {
      test = record ? parseRedactionTest(fs.readFileSync(record.skillFile, "utf8")) : null;
    } catch {
      test = null;
    }
    this.redactionCache = { root: this.registry.root, test };
    return test;
  }

  private activationMatrixCache: { root: string; rules: MatrixRule[] } | null = null;

  // shared/ACTIVATION-MATRIX.md, re-read after a skill update.
  private activationMatrix(): MatrixRule[] {
    if (this.activationMatrixCache?.root === this.registry.root) return this.activationMatrixCache.rules;
    const rules = parseActivationMatrix(this.readCorpus("shared/ACTIVATION-MATRIX.md") ?? "");
    this.activationMatrixCache = { root: this.registry.root, rules };
    return rules;
  }

  private mandatoryModel(): MandatoryPathModel | null {
    if (this.mandatoryModelCache?.root === this.registry.root) return this.mandatoryModelCache.model;
    try {
      const model = loadMandatoryPathModel((resource) => this.readCorpus(resource));
      this.mandatoryModelCache = { root: this.registry.root, model };
      return model;
    } catch {
      return null;
    }
  }

  /**
   * Summary of older thread messages: the text goes to the model
   * pseudonymized like a chat message, without tools; provisions in the
   * summary get their status from the verification registry only (reused
   * evidence after the ELI check, otherwise NIEWERYFIKOWANE).
   */
  async summarizeThread(request: ThreadSummaryRequest): Promise<string> {
    const vault = new PseudonymizationVault(request.privacySeed);
    const pseudonymizer = new LocalPolishPseudonymizer(vault, this.chatRecognizerFor(request.model), this.personMorphology, this.registryForms());
    const transcript = [
      ...(request.previousSummary ? [`[DOTYCHCZASOWE STRESZCZENIE]\n${request.previousSummary}\n[KONIEC STRESZCZENIA]`] : []),
      "[WIADOMOŚCI DO STRESZCZENIA]",
      ...request.messages.map((message) => `${message.role === "user" ? "Użytkownik" : "Asystent"}: ${message.content}`)
    ].join("\n\n");
    const protectedText = (await pseudonymizer.pseudonymize(transcript)).text;
    const ledger = new VerificationLedger();
    if (request.threadEvidence?.provisions.length && this.actFreshness) {
      for (const record of (await revalidateThreadEvidence(request.threadEvidence, this.actFreshness)).reused) ledger.add(record);
    }
    const key = placeholderKeyPrompt(placeholderGrammar(protectedText, vault));
    const response = await this.providers.stream(request.provider, {
      model: request.model,
      systemPrompt: [...(key ? [key] : []), THREAD_SUMMARY_PROMPT].join("\n\n"),
      messages: [{ role: "user", content: protectedText }],
      accountContinuity: "none",
      reasoning: "none"
    });
    let text = stripUnbackedVerificationMarkers(response.fullText.trim(), ledger).text;
    const gate = new FinalizationGate().evaluate(text, ledger);
    text = reconcileStatusMarkers(addMissingVerificationMarkers(markUnverifiedReferences(text, gate, new Set(ledger.caseReferences()), new Set(ledger.retrievedCases())), gate, verifiedLedgerMarkers(ledger)), ledger).text;
    return restoreWithReport(text, vault).text.slice(0, MAX_SUMMARY_CHARS);
  }

  // A local primary model keeps the text on this machine, so the chat does
  // not also wait for local-model PII detection before answering.
  // One register cache per executor: a NIP/KRS is looked up once, not per message.
  private registryEnrichment: RegistryEnrichment | undefined | null = null;
  private registryForms(): RegistryEnrichment | undefined {
    if (this.registryEnrichment === null) this.registryEnrichment = registryEnrichmentFor(this.legalFederationTools);
    return this.registryEnrichment;
  }

  private chatRecognizerFor(
    model: string
  ): NamedEntityRecognizer | undefined {
    return this.chatNamedEntityRecognizer
      ? privacyRecognizerFor(
          this.chatNamedEntityRecognizer,
          !model.startsWith("local/")
        )
      : undefined;
  }

  async resolveAutoRouting(
    request: SessionExecutionRequest
  ): Promise<ModelAutoRoutingResult> {
    request = nfcRequest(request);
    const vault =
      new PseudonymizationVault(request.privacySeed);
    const pseudonymizer =
      new LocalPolishPseudonymizer(
        vault,
        this.chatRecognizerFor(
          request.model
        ),
        this.personMorphology,
        this.registryForms()
      );
    let protectedQuery: string;
    try {
      protectedQuery =
        (
          await pseudonymizer
            .pseudonymize(
              request.query
            )
        ).text;
    } catch (error) {
      throw privacyGateFailure(error);
    }

    const routed =
      await this.autoRouter
        .resolve({
          query:
            protectedQuery,
          provider:
            request.provider,
          model:
            request.model,
          ...(request.matterComplexity
            ? { matterComplexity: request.matterComplexity }
            : {})
        });

    // Keep the user's original text for the actual execution. Only the
    // model-selected routing envelope is copied from the protected prepass.
    const originalEnvelope =
      parseSkillSelectionEnvelope(
        request.query
      );
    const firstBreak =
      routed.query.indexOf(
        "\n"
      );
    const routingHeader =
      firstBreak >= 0
        ? routed.query.slice(
            0,
            firstBreak
          )
        : routed.query;

    return {
      decision:
        routed.decision,
      query:
        routingHeader +
        "\n" +
        originalEnvelope.query
    };
  }

  // Times of every chat turn by path and stage (chat-turn-journal.ts), on this computer.
  turnJournal: ChatTurnJournal | null = process.env.VITEST ? null : new ChatTurnJournal();

  async execute(
    request: SessionExecutionRequest
  ): Promise<SessionExecutionResponse> {
    request = nfcRequest(request);
    const started = performance.now();
    const clock = new PhaseClock();
    const report = request.onStep;
    request = {
      ...request,
      onStep: (phase, detail) => {
        clock.mark(phase);
        report?.(phase, detail);
      }
    };
    const record = (status: ChatTurnRecord["status"], pathName: string, error?: unknown) => {
      clock.close();
      this.turnJournal?.append({
        at: new Date().toISOString(),
        modelKind: modelKindOf(request.provider, request.model),
        provider: request.provider,
        path: pathName,
        attachments: request.documentAttachments?.length ?? 0,
        totalMs: Math.round(performance.now() - started),
        phasesMs: clock.phasesMs,
        status,
        ...(error !== undefined ? { error: errorCode(error) } : {})
      });
    };
    const basePath = request.processWorkflowContext
      ? "workflow"
      : request.conversationalOnly
        ? "rozmowa"
        : `czat ${request.mode}`;
    try {
      // Tokens of every model call in this turn (benchmark and cost display).
      const { result, usage } = await meterUsage(() => this.executeTurn(request));
      result.usage = usage;
      record(result.status === "BLOCKED" ? "BLOCKED" : "OK", result.taskSkill ?? basePath);
      return result;
    } catch (error) {
      record("ERROR", basePath, error);
      throw error;
    }
  }

  private async executeTurn(
    request: SessionExecutionRequest
  ): Promise<SessionExecutionResponse> {
    const step: ExecutionStepReporter = request.onStep ?? (() => undefined);
    step("PREPARE", "anonimizacja wiadomości");
    if (request.documentAttachments?.length) {
      step("PREPARE", `pliki w kontekście: ${request.documentAttachments.length}`);
    }
    const audit = new AuditTrail();
    audit.start({
      provider: request.provider,
      model: request.model,
      mode: request.mode
    });

    const chatPrivacyVault =
      new PseudonymizationVault(request.privacySeed);
    const chatPseudonymizer =
      new LocalPolishPseudonymizer(
        chatPrivacyVault,
        this.chatRecognizerFor(
          request.model
        ),
        this.personMorphology,
        this.registryForms()
      );
    let protectedQuery:
      string;
    let protectedProcessContext = request.processWorkflowContext;
    let protectedAuxiliaryText:
      string | undefined;
    // A trivial command ("ok", "dzięki") is a fixed word of a closed list: it holds no
    // personal data, and only that latest message reaches the model. The thread history is
    // not run through PII detection (with a local model ready, one local inference per chunk).
    // The web client sends the message also as auxiliaryText: that is the same text.
    const latestMessage = latestUserTurn(parseSkillSelectionEnvelope(request.query).query).trim();
    const trivialTurn =
      request.conversationalOnly === true &&
      isTrivialChatCommand(parseSkillSelectionEnvelope(request.query).query) &&
      !request.documentAttachments?.length &&
      (request.auxiliaryText === undefined || request.auxiliaryText.trim() === latestMessage) &&
      !request.processWorkflowContext;
    try {
      if (trivialTurn) {
        const header = request.query.startsWith(SKILL_SELECTION_ENVELOPE_PREFIX)
          ? request.query.slice(0, request.query.indexOf("\n") + 1)
          : "";
        protectedQuery = header + latestMessage;
        if (request.auxiliaryText !== undefined) protectedAuxiliaryText = latestMessage;
        audit.record("gate", "G39I_CHAT_PRIVACY", "OK", {
          pseudonymized: 0,
          exampleDataKept: 0,
          kinds: [],
          vaultTokens: chatPrivacyVault.size,
          residualSealed: 0,
          detail: "trivial-command;latest-turn-only"
        });
      } else {
        // Example data the assistant wrote earlier (a model letter) stays as written.
        const exampleData =
          /(?:^|\n\n)Asystent: /.test(request.query)
            ? exampleDataKeepDirectives(
                request.query,
                (
                  await new LocalPolishPseudonymizer(
                    new PseudonymizationVault(request.privacySeed),
                    this.chatRecognizerFor(request.model),
                    this.personMorphology
                  ).pseudonymize(request.query)
                ).findings,
                request.auxiliaryText ?? "",
                request.threadEvidence?.realValueHashes ? new Set(request.threadEvidence.realValueHashes) : null
              )
            : [];
        // The document generator's contract (the application's own instructions and its alias
        // map, no personal data) follows the user's text: only that text is pseudonymized.
        // Run through the recognizers, "PII ALIAS" and "I. Section" became PERSON symbols.
        const contractAt = request.query.indexOf(DOCUMENT_OUTPUT_CONTRACT_HEADING);
        const userText = contractAt >= 0 ? request.query.slice(0, contractAt) : request.query;
        const contractText = contractAt >= 0 ? request.query.slice(contractAt) : "";
        const pseudonymizedUser =
          await chatPseudonymizer
            .pseudonymize(
              userText,
              exampleData.filter((directive) => directive.end <= userText.length)
            );
        const protectedPrimary = { ...pseudonymizedUser, text: pseudonymizedUser.text + contractText };
        // Health data (art. 9 RODO) goes as written (the injury is often the matter); the log says so.
        const health = detectHealthData(latestMessage);
        if (health.length) {
          step("PREPARE", `dane o zdrowiu w wiadomości (art. 9 RODO): ${health.length}, wysłane bez zakrycia; gdy analiza ich nie potrzebuje, pomiń je w wiadomości`);
          audit.record("gate", "HEALTH_DATA_SENT", "OK", { count: health.length });
        }
        // Leak test before sending: a replaced value left elsewhere in the text is sealed too.
        const primarySeal = sealResidualValues(request.query, protectedPrimary.text, protectedPrimary.findings);
        protectedQuery =
          primarySeal.text;
        let sealedValues = primarySeal.sealed;

        if (
          request.auxiliaryText !==
            undefined &&
          request.auxiliaryText !==
            request.query
        ) {
          const auxiliary =
            await chatPseudonymizer
              .pseudonymize(
                request.auxiliaryText
              );
          const auxiliarySeal = sealResidualValues(request.auxiliaryText, auxiliary.text, auxiliary.findings);
          protectedAuxiliaryText =
            auxiliarySeal.text;
          sealedValues += auxiliarySeal.sealed;
        } else if (
          request.auxiliaryText !==
            undefined
        ) {
          protectedAuxiliaryText =
            protectedQuery;
        }

        // The stored pleading draft and remarks reach the model like the chat text:
        // pseudonymized with the same vault (restored in the answer).
        if (request.processWorkflowContext?.draft || request.processWorkflowContext?.remarks) {
          const context = request.processWorkflowContext;
          protectedProcessContext = {
            ...context,
            ...(context.draft
              ? { draft: { ...context.draft, text: (await chatPseudonymizer.pseudonymize(context.draft.text)).text } }
              : {}),
            ...(context.remarks ? { remarks: (await chatPseudonymizer.pseudonymize(context.remarks)).text } : {})
          };
        }
        audit.record(
          "gate",
          "G39I_CHAT_PRIVACY",
          "OK",
          {
            pseudonymized:
              protectedPrimary
                .findings.length,
            exampleDataKept:
              exampleData.length,
            kinds:
              Object.keys(
                protectedPrimary
                  .counts
              ).sort(),
            vaultTokens:
              chatPrivacyVault
                .size,
            // Occurrences of already replaced values found again by the leak test.
            residualSealed:
              sealedValues
          }
        );
      }
    } catch (error) {
      audit.record(
        "gate",
        "G39I_CHAT_PRIVACY",
        "BLOCKED",
        {
          error:
            error instanceof Error
              ? error.message
              : String(error)
        }
      );
      audit.close(
        "BLOCKED",
        {
          finalization:
            "PRIVACY_GATE"
        }
      );
      throw privacyGateFailure(error);
    }

    const requestedHistoricalAsOf =
      detectHistoricalAsOf(
        protectedQuery
      );

    const ledger = new VerificationLedger();
    // Evidence memory: provisions verified in earlier messages are reused only
    // when ELI still has the same consolidated text and no amendment after it.
    let evidencePrompt: string | null = null;
    const memory = request.threadEvidence;
    // Signatures of the case's materials named in earlier turns: still from the case, here too.
    for (const signature of memory?.caseReferences ?? []) ledger.addCaseReference(signature);
    if (
      memory &&
      // A conversational turn reads no provisions: no ELI round trip for them.
      !request.conversationalOnly &&
      (memory.provisions.length || memory.sources.length || memory.skills.length || memory.lastPath)
    ) {
      const reuse = this.actFreshness
        ? await revalidateThreadEvidence(memory, this.actFreshness)
        : { reused: [], recheck: memory.provisions.map((record) => ({ claim: record.claim, reason: "ELI_CHECK_UNAVAILABLE" })) };
      for (const record of reuse.reused) ledger.add(record);
      evidencePrompt = threadEvidencePrompt(memory, reuse);
      step("VERIFY", `pamięć sprawy: ${reuse.reused.length} przepisów aktualnych w ELI, ${reuse.recheck.length} do ponownej weryfikacji`);
      audit.record("gate", "THREAD_EVIDENCE_REUSE", "OK", {
        reused: reuse.reused.map((record) => record.claim),
        recheck: reuse.recheck
      });
    }
    // Modele lokalne (Bielik, Mistral) weryfikują najpierw na lokalnej kopii ELI (RAG).
    const verificationTools = this.verificationToolFactory?.(ledger, {
      localModel: request.model.startsWith("local/")
    });
    // Open issues of the case (references left unverified earlier): to verification first,
    // without waiting for the model to cite them again.
    if (request.openIssueClaims?.length && verificationTools && !request.model.startsWith("local/") && !request.conversationalOnly) {
      const plan = planAutomaticLegalVerification(request.openIssueClaims.join("\n"), ledger, requestedHistoricalAsOf);
      if (plan.calls.length) {
        await verificationTools.runTools(plan.calls.slice(0, 12));
        const keys = new Set([...request.openIssueClaims, ...plan.calls.map((call) => String((call.input as { claim?: unknown }).claim ?? ""))].map(issueKey));
        const settled = ledger.all().filter((record) => keys.has(issueKey(record.claim)));
        const verified = settled.filter((record) => record.status === "VERIFIED" || record.status === "SUPPORTED");
        step("VERIFY", `kwestie otwarte sprawy: ${verified.length} z ${request.openIssueClaims.length} potwierdzonych w źródle`);
        const lines = settled.map((record) => `- ${record.claim}: ${record.status}${record.sourceUrl ? ` (${record.sourceUrl})` : ""}`);
        if (lines.length) {
          evidencePrompt = [evidencePrompt, ["[Kwestie otwarte sprawy sprawdzone przez aplikację przed tą odpowiedzią:]", ...lines, "[Niepotwierdzone nadal oznaczaj jako do weryfikacji; nie opieraj na nich wniosków.]"].join("\n")]
            .filter(Boolean)
            .join("\n\n");
        }
      }
    }
    const corpusTools = new LegalCorpusToolRuntime(
      this.registry,
      {
        modelSelectsSkills:
          request.modelSelectsSkills === true
      }
    );
    const reportTools = new ReportBlueprintToolRuntime();
    // Modele lokalne: bez widgetów (minimalny zestaw narzędzi i promptu).
    const widgetTools = request.model.startsWith("local/")
      ? undefined
      : new WidgetToolRuntime(this.registry);
    // Modele lokalne (Bielik, Mistral): bez federacji MCP. Jej instrukcje i schematy to
    // ~12 tys. znaków promptu przy oknie 32k, a lokalny model dostaje przepisy z RAG
    // rdzeniowego i verify_legal_reference na lokalnej kopii ELI.
    const federationTools =
      request.model.startsWith("local/")
        ? undefined
        : this.legalFederationTools;
    // Instancja federacji jest wspólna dla wszystkich sesji; ta sesja audytuje tylko własne wywołania.
    const federationEvents:
      LegalFederationAuditEvent[] =
      [];
    const auxiliarySources:
      PublicAuxiliarySourceItem[] =
      [];
    let snVerificationRequired = false;
    // Texts the source tools returned in this turn (judgments, hit lists): what the
    // answer may say a judgment is about (case-content-grounding).
    const caseSourceTexts: string[] = [];
    // Tool results of an official case-law database, and of a lead (SAOS, web search, a portal).
    const officialCaseLawTexts: string[] = [];
    const leadCaseLawTexts: string[] = [];

    // References in the message are checked by the Gate I runtime prelude
    // (ELI); no model is asked to extract them.
    const modelTaskOwnership =
      evaluateModelTaskOwnershipGate(
        resolveReferencePreflightOwnership(
          detectLegalReferences(
            protectedAuxiliaryText ??
              protectedQuery
          ).length > 0
        )
      );
    audit.record(
      "gate",
      modelTaskOwnership.gate,
      modelTaskOwnership.result ===
        "PASS"
        ? "OK"
        : "BLOCKED",
      {
        registry:
          modelTaskOwnership.registry,
        resolution:
          modelTaskOwnership.resolution,
        errors:
          modelTaskOwnership.errors
      }
    );
    if (
      modelTaskOwnership.result !==
        "PASS"
    ) {
      audit.close(
        "BLOCKED",
        {
          finalization:
            "MODEL_TASK_OWNERSHIP"
        }
      );
      throw new Error(
        "MODEL_TASK_OWNERSHIP_GATE_FAILED"
      );
    }

    // Only the newest user turn asserts attachments: earlier turns and assistant
    // replies in the history ("w pliku", "te dokumenty") are not this request's input.
    const gateIInput =
      evaluateGateIInputCompleteness(
        withoutOutputContract(latestUserTurn(request.query)),
        request.documentAttachments
          ?.length ?? 0
      );

    audit.record(
      "gate",
      "G39I_INPUT_COMPLETENESS",
      gateIInput.result ===
        "PASS"
        ? "OK"
        : "BLOCKED",
      {
        attachmentAssertion:
          gateIInput.attachmentAssertion,
        attachmentCount:
          gateIInput.attachmentCount,
        reason:
          gateIInput.reason
      }
    );

    const contextSelection =
      orchestrateDocumentContext({
        attachments:
          request.documentAttachments ?? [],
        query: request.query,
        ...(request.modelContextTokens
          ? {
              modelContextTokens:
                request.modelContextTokens
            }
          : {}),
        ...(request.tokenCharsPerToken
          ? {
              tokenCharsPerToken:
                request.tokenCharsPerToken
            }
          : {})
      });
    const aliasRegistry =
      new DocumentAliasRegistry();
    const attachments =
      namespaceDocumentAttachmentTokens(
        contextSelection.attachments,
        aliasRegistry
      );
    // The proceeding's own case number (header of the case's documents, the user's own
    // words) is not case law: G8 does not ask to verify it as a judgment.
    for (const signature of ownCaseFileNumbers(
      attachments.map((attachment) => attachment.chunks.map((chunk) => chunk.text).join("\n")),
      threadUserText(request.query)
    )) {
      ledger.addCaseFileNumber(signature);
    }
    for (const signature of mentionedCaseNumbers([
      threadUserText(request.query),
      ...attachments.map((attachment) => attachment.chunks.map((chunk) => chunk.text).join("\n"))
    ])) {
      ledger.addCaseReference(signature);
    }
    for (const key of amountKeysIn([threadUserText(request.query), ...attachments.map((attachment) => attachment.chunks.map((chunk) => chunk.text).join("\n"))].join("\n"))) {
      ledger.addFactAmount(key);
    }
    // Chunks read by the case file tools are added after the model turn.
    const citationSources =
      [...contextSelection.citationSources];
    // Page images of the attachments in context (masked evidence), for
    // models that see images; others work from the text.
    const evidence = selectEvidenceImages(request.documentAttachments ?? [], attachments);
    const imagesDelivered =
      evidence.length > 0 && this.providers.supportsImages(request.provider, request.model);
    if (evidence.length) {
      step(
        "PREPARE",
        imagesDelivered
          ? `obrazy jako dowód: ${evidence.length} (dane osobowe zamaskowane)`
          : `obrazy pominięte: model przyjmuje tylko tekst (${evidence.length})`
      );
      audit.record("resource_read", "evidence-images", "OK", {
        delivered: imagesDelivered,
        images: evidence.map((image) => `${image.documentId}:${image.page}`),
        masked: evidence.reduce((sum, image) => sum + image.masked, 0)
      });
    }
    const direct = request.directImages ?? [];
    const directDelivered = direct.length > 0 && this.providers.supportsImages(request.provider, request.model);
    if (direct.length) {
      step(
        "PREPARE",
        directDelivered
          ? `obrazy wysłane bezpośrednio: ${direct.length} (bez OCR i bez anonimizacji)`
          : `obrazy pominięte: model przyjmuje tylko tekst (${direct.length})`
      );
      audit.record("resource_read", "direct-images", "OK", { delivered: directDelivered, count: direct.length, unmasked: true });
    }
    const attachedContext =
      attachments.length > 0
        ? buildDocumentContext(
            attachments,
            imagesDelivered ? evidence : []
          )
        : undefined;
    const documentContext = direct.length
      ? [attachedContext, directImageNote(direct, directDelivered)].filter(Boolean).join("\n\n---\n\n")
      : attachedContext;
    const modelImages: LlmImage[] = [
      ...(imagesDelivered ? evidence.map((image) => ({ mediaType: image.mediaType, data: image.data })) : []),
      ...(directDelivered ? direct.map((image) => ({ mediaType: image.mediaType, data: image.data })) : [])
    ];

    audit.record(
      "gate",
      "G39C_CONTEXT_BUDGET",
      "OK",
      {
        ...contextSelection.report
      }
    );

    for (const attachment of attachments) {
      audit.record(
        "resource_read",
        `local-document:${attachment.documentId}`,
        "OK",
        {
          chunks: attachment.chunks.map((chunk) => chunk.index),
          representations:
            attachment.chunks.map(
              (chunk) =>
                chunk.representation ??
                "FULL"
            ),
          protectedOnly: true,
          ...(attachment.caseId ? { caseId: attachment.caseId } : {}),
          ...(attachment.sourceScope ? { sourceScope: attachment.sourceScope } : {})
        }
      );
    }

    const coreLawTools =
      this.coreLawIndex
        ? new CoreLawToolRuntime(
            this.coreLawIndex
          )
        : undefined;
    // The context holds what fits the window; the tools reach the rest of the
    // matter's files. Not for local models (window and tool reliability).
    const caseFileTools =
      request.caseFiles && !request.model.startsWith("local/")
        ? new CaseFileToolRuntime(request.caseFiles, {
            inContext: new Map(
              attachments
                .filter((attachment) => attachment.caseId === request.caseFiles!.caseId)
                .map((attachment) => [attachment.documentId, new Set(attachment.chunks.map((chunk) => chunk.index))])
            ),
            prefixFor: (documentId) => aliasRegistry.prefixFor(documentId),
            namespace: namespaceChunkTokens,
            markPages,
            ...(request.modelContextTokens
              ? {
                  maxTurnChars: Math.min(
                    120_000,
                    Math.floor(request.modelContextTokens * (request.tokenCharsPerToken ?? 3) * 0.3)
                  )
                }
              : {})
          })
        : undefined;
    // Local 11-12B models call tools unreliably: they get the most relevant
    // core law articles in the prompt (retrieval, not training).
    const coreLawRag =
      this.coreLawIndex && request.model.startsWith("local/")
        ? coreLawRetrievalPrompt(this.coreLawIndex, protectedQuery)
        : null;
    // Claude account in AUTO: skills are read natively from the corpus
    // directory, so the corpus tools are not offered; the rest go over MCP.
    const nativeCorpus =
      request.modelSelectsSkills === true &&
      this.providers.nativeCorpusAccess(request.provider, request.model);
    // The court of a party's address (a letter's addressee): the alias restored from the case's
    // local vaults (the chat's own key and the documents' D01.. keys), never shown to the model.
    const courtTools = request.conversationalOnly
      ? undefined
      : new CourtToolRuntime((token) => {
          const match = /^\[(?:LMPII:D(\d{2})|PII):([A-Z_]+):(\d{4})\]$/u.exec(token);
          if (!match) return null;
          const raw = `[PII:${match[2]}:${match[3]}]`;
          const documentNumber = match[1] ? Number(match[1]) : 0;
          if (documentNumber === 0) return chatPrivacyVault.hasToken(raw) ? chatPrivacyVault.restore(raw, null).text : null;
          const documentId = aliasRegistry.documentIds()[documentNumber - 1];
          if (!documentId || !request.restoreDocumentToken) return null;
          try {
            return request.restoreDocumentToken(documentId, raw);
          } catch {
            return null;
          }
        });
    const toolSchemas = [
      ...(nativeCorpus ? [] : corpusTools.schemas()),
      ...(courtTools ? courtTools.schemas() : []),
      ...(coreLawTools
        ? coreLawTools.schemas()
        : []),
      ...(caseFileTools ? caseFileTools.schemas() : []),
      ...reportTools.schemas(),
      ...(widgetTools ? widgetTools.schemas() : []),
      ...(federationTools
        ? federationTools.schemas()
        : []),
      ...(verificationTools ? verificationTools.schemas() : [])
    ];
    // Mandatory path (hosted models): the profile, the corpus files the router's
    // mandatory gates require, loaded up front, and the mode decided at the entry.
    const mandatoryModel = request.model.startsWith("local/") ? null : this.mandatoryModel();
    const legalTurn = !request.conversationalOnly && !isTrivialChatCommand(withoutOutputContract(latestUserTurn(request.query)));
    const pathFacts = {
      query: withoutOutputContract(request.auxiliaryText ?? latestUserTurn(request.query)),
      legal: legalTurn,
      // AUTO: primarySkill is a placeholder until the model reads a domain skill,
      // so the criminal matter comes from the question itself.
      criminal:
        (!request.modelSelectsSkills && request.primarySkill.startsWith("dr-03-")) ||
        criminalMatter(withoutOutputContract(request.auxiliaryText ?? latestUserTurn(request.query))) ||
        // A follow-up of a criminal matter ("a jaki termin?") stays one. The chat always
        // sends the latest message apart (auxiliaryText), so the thread is read as well.
        criminalMatter(withoutOutputContract(threadUserText(request.query))) ||
        // An attached judgment, indictment or charges of a criminal case.
        attachments.some((attachment) => criminalDocument(attachment.chunks.slice(0, 4).map((chunk) => chunk.text).join("\n"))),
      documents: attachments.length > 0,
      documentsTruncated: contextSelection.report.documents?.some((item) => item.status !== "FULL") ?? false,
      documentGeneration: Boolean(request.documentAstOutput || request.processWorkflowContext),
      foreignJurisdiction: foreignJurisdiction(withoutOutputContract(request.query))
    };
    // The wording of the articles the question cites, read by number from the core law copy
    // before the model starts: no tool round trip (each one re-sends the whole prompt) and
    // no quoting from memory. The act comes from the code ("art. 286 KK") or from the act
    // maps ("art. 23 ustawy o obszarach morskich" -> its Dz.U.).
    const citedLaw =
      this.coreLawIndex && legalTurn
        ? citedArticlesPrompt(
            this.coreLawIndex,
            citedArticles(
              pathFacts.query,
              resolveActModulesWithChecks(this.registry, pathFacts.query).modules.flatMap((module) => (module.basis ? [module.basis] : [])),
              provisionsForDetection
            ),
            request.model.startsWith("local/") ? 1_800 : undefined
          )
        : null;
    // PROFIL-LEKKI forbids the light profile for router category [11] (someone else's material).
    // A message typed without Polish letters gets them back for the executive routing phrases.
    const taskQuery = legalTurn && !/[ąćęłńóśźż]/iu.test(pathFacts.query) ? restoreAccents(pathFacts.query, this.accentMap()) : pathFacts.query;
    const verification = legalTurn && classifyTask(this.taskRoutes(), taskQuery)?.route.id === "11";
    const profile: PathProfile = pathProfile({
      mode: request.modeDecision?.mode ?? request.mode,
      simple: request.matterComplexity?.level === "SIMPLE",
      criminal: pathFacts.criminal,
      documentGeneration: pathFacts.documentGeneration,
      verification,
      analysis: legalTurn && analysisRequested(pathFacts.query)
    });
    // Already in the model's context: the router skill (AUTO gives it in full)
    // and the core legal resources.
    const contextResources = new Set<string>([
      ...(request.modelSelectsSkills ? [`${ROUTER_SKILL}/SKILL.md`] : []),
      "shared/PRAWO-HARDGATE.md",
      `${ROUTER_SKILL}/references/KROK0A-anonimizer.md`,
      `${ROUTER_SKILL}/references/KROK1-detekcja.md`,
      // Route-based path: the engine puts the qualifier in the prompt itself.
      ...(pathFacts.criminal && !request.modelSelectsSkills ? [CRIMINAL_QUALIFIER_RESOURCE] : [])
    ]);
    corpusTools.setInContext(contextResources);
    const pathSections: string[] = [];
    // The kind of every document the user sent (court decision, pleading, contract,
    // evidence...), recognised locally from its protected text; the router chooses
    // the skill also by what the user delivers (ACTIVATION-MATRIX).
    const recognisedDocuments: RecognisedDocument[] =
      mandatoryModel && legalTurn
        ? attachments
            .filter((attachment) => attachment.sourceScope !== "FIRM_TEMPLATE" && attachment.sourceScope !== "FIRM_KNOWLEDGE")
            .map((attachment) => ({
              documentId: attachment.documentId,
              ...classifyDocument({
                text: attachment.chunks.map((chunk) => chunk.text).join("\n"),
                images: attachment.images?.length ?? 0
              })
            }))
        : [];
    if (recognisedDocuments.length) {
      audit.record("gate", "DOCUMENT_KINDS", "OK", {
        documents: recognisedDocuments.map((document) => `${document.documentId}:${document.kind}`)
      });
      pathSections.push(recognisedDocumentsPrompt(recognisedDocuments));
      // A document between the parties is assessed as a whole whatever skill leads (a demand with
      // the agreement it relies on): the contract analyser's CAL-GATE goes in with it (user report
      // 2026-11-06: pkt 10 waiving all claims cancelled the employee's side of pkt 5, unseen).
      if (recognisedDocuments.some((document) => document.category === "UMOWA")) {
        const cal = markdownSection(this.readCorpus(CONTRACT_WHOLE_DOCUMENT_RESOURCE) ?? "", CONTRACT_WHOLE_DOCUMENT_HEADING);
        if (cal) {
          // Only the section: the whole SKILL.md still comes in when the analyser is the executive skill.
          audit.record("resource_read", CONTRACT_WHOLE_DOCUMENT_RESOURCE, "OK", { detail: "runtime-preload;delivered-contract;CAL-GATE" });
          pathSections.push(`# MANDATORY PATH RESOURCE: ${CONTRACT_WHOLE_DOCUMENT_RESOURCE} — ${CONTRACT_WHOLE_DOCUMENT_HEADING.replace(/^#+\s*/u, "")}\n\n${cal}`);
        }
      }
      const roles = replyRolesPrompt(request.query, recognisedDocuments);
      if (roles) pathSections.push(roles);
      step("PREPARE", `rozpoznane dokumenty: ${recognisedDocuments.map((document) => document.label).join(", ")}`);
    }
    // AUTO: a criminal question gets the qualifier up front (Karne: +kwalifikator).
    if (mandatoryModel && legalTurn && pathFacts.criminal && request.modelSelectsSkills) {
      const qualifier = this.readCorpus(CRIMINAL_QUALIFIER_RESOURCE);
      if (qualifier) {
        contextResources.add(CRIMINAL_QUALIFIER_RESOURCE);
        audit.record("resource_read", CRIMINAL_QUALIFIER_RESOURCE, "OK", { detail: "runtime-preload;mandatory-path;criminal-question" });
        pathSections.push(`# MANDATORY PATH RESOURCE: ${CRIMINAL_QUALIFIER_RESOURCE}\n\n${qualifier}`);
      }
    }
    // A causal question about the case: the causal graph method up front, so the link is
    // examined (mechanism, evidence of each link), not read off the order of the dates.
    if (mandatoryModel && legalTurn && CAUSAL_QUESTION.test(pathFacts.query)) {
      const causal = this.readCorpus(CAUSAL_RESOURCE);
      if (causal) {
        contextResources.add(CAUSAL_RESOURCE);
        audit.record("resource_read", CAUSAL_RESOURCE, "OK", { detail: "runtime-preload;causal-question" });
        pathSections.push(`# MANDATORY PATH RESOURCE: ${CAUSAL_RESOURCE}\n\n${causal}`);
        step("SKILLS", "pytanie o związek przyczynowy: metoda grafu przyczynowego (MOD-GRAF-PRZYCZYNOWY)");
      }
    }
    // AUTO: the domain (prawo-polskie-v2 flash routing) and its act modules
    // (MAPA-AKTOW) the case points to; the model decides and reads them.
    // A checkpoint workflow's turn ("Kontynuuj"): the matter is everything the user wrote.
    const workflowTurn = Boolean(
      request.contractWorkflowContext ||
        request.processWorkflowContext ||
        request.courtWorkflowContext ||
        request.chronologyWorkflowContext ||
        request.orderedCaseWorkflowContext
    );
    const caseText = [
      workflowTurn ? withoutOutputContract(threadUserText(request.query)) : pathFacts.query,
      ...recognisedDocuments.map((document) => document.label)
    ].join("\n");
    corpusTools.setCaseText(caseText);
    // AUTO with a model choosing the skills: primarySkill is a placeholder (the first DR by
    // name, dr-01). A stateful workflow does not take the model-selected path, so the engine
    // read that placeholder as the matter's domain (constitutional law for an SMS evidence
    // report). The workflow gets the domain the routing phrases name, else DR-16.
    const mechanicalEnvelope = parseSkillSelectionEnvelope(request.query);
    const workflowPrimarySkill = (): string => {
      const workflowContext =
        request.guideContext || request.processWorkflowContext || request.courtWorkflowContext ||
        request.chronologyWorkflowContext || request.contractWorkflowContext || request.orderedCaseWorkflowContext;
      // Mechanical mode: the user pinned the skill, not the domain; the chat's guess at the
      // domain (word overlap with skill descriptions — "art. 415 KC" read as DR-01) gives way
      // to the act the question cites, then to a routing phrase. A domain the user picked
      // (a DR in the selection, or the domain allow-list) stays.
      const mechanical = mechanicalTurn(request) && !mechanicalEnvelope.manualSkills.some((name) => name.startsWith("dr-"));
      if (!mechanical && (!request.modelSelectsSkills || !workflowContext)) return request.primarySkill;
      // An act the matter cites ("art. 233 k.p.c." in the appeal), then a routing phrase of
      // the matter or of its thread; two shared words of an act-map row ("wyrok", "apelacja")
      // do not name the domain of a whole workflow.
      const documentText = attachments
        .filter((attachment) => attachment.sourceScope !== "FIRM_TEMPLATE" && attachment.sourceScope !== "FIRM_KNOWLEDGE")
        .map((attachment) => attachment.chunks.map((chunk) => chunk.text).join("\n"))
        .join("\n")
        .slice(0, 30_000);
      const cited = resolveActModulesWithChecks(this.registry, [caseText, documentText].join("\n"))
        .modules.map((item) => item.skill)
        .find((skill) => skill.startsWith("dr-"));
      const phrased = (text: string) => {
        const ranked = rankDomains(this.registry, this.flashRoutes(), text);
        return (ranked.find((domain) => domain.strong) ?? ranked.find((domain) => !/^mapa aktów:/u.test(domain.matched[0] ?? "")))?.skill;
      };
      const procedural = [...this.registry.skills.keys()].find((name) => name.startsWith("dr-16-"));
      if (mechanical) {
        const allowed = (skill: string | undefined) =>
          skill && (!mechanicalEnvelope.domainRestrictionActive || mechanicalEnvelope.domainAllowList.includes(skill)) ? skill : undefined;
        // A court named in the question (NSA, SN, WSA) tells the procedure, not the matter:
        // "wyrok NSA ... VAT" is a tax matter. The matter's domain wins when only the court
        // name matched the other one.
        const ofMatter = (text: string) => {
          const ranked = rankDomains(this.registry, this.flashRoutes(), text).filter((domain) => allowed(domain.skill));
          const courtOnly = (domain: (typeof ranked)[number]) => domain.matched.length > 0 && domain.matched.every((phrase) => COURT_NAME.test(phrase));
          // A domain the ranking only adds by the matter's kind (no phrase matched) names nothing here.
          const named = ranked.filter((domain) => domain.matched.length > 0 && !courtOnly(domain));
          return (named.find((domain) => domain.strong) ?? named.find((domain) => !/^mapa aktów:/u.test(domain.matched[0] ?? "")))?.skill;
        };
        // The documents of a workflow (a witness to question, an evidence file) name the
        // matter when the question does not ("Przygotuj przesłuchanie świadka Jana Nowaka").
        return allowed(cited) ?? allowed(ofMatter(caseText)) ?? allowed(ofMatter(threadUserText(request.query))) ?? allowed(documentText.trim() ? ofMatter(documentText) : undefined) ?? request.primarySkill;
      }
      return cited ?? phrased(caseText) ?? phrased(threadUserText(request.query)) ?? procedural ?? request.primarySkill;
    };
    // MAPA-AKTOW resolved mechanically (Dz.U. number, article of a code, act or scope
    // named): those modules are loaded and required; the hint below covers the rest.
    if (mandatoryModel && legalTurn) {
      const documentText = attachments
        .filter((attachment) => attachment.sourceScope !== "FIRM_TEMPLATE" && attachment.sourceScope !== "FIRM_KNOWLEDGE")
        .map((attachment) => attachment.chunks.map((chunk) => chunk.text).join("\n"))
        .join("\n")
        .slice(0, 30_000);
      const acts = resolveActModulesWithChecks(this.registry, [caseText, documentText].join("\n"));
      if (acts.modules.length || acts.rejected.length) {
        const loaded = loadActModules(this.registry, acts.modules, contextResources);
        for (const item of loaded.loaded) {
          contextResources.add(item.resource);
          audit.record("resource_read", item.resource, "OK", { detail: `runtime-preload;act-map;${item.rule}` });
        }
        audit.record("gate", "ACT_MAP_MODULES", acts.rejected.length ? "DEGRADED" : "OK", {
          detail: [
            ...acts.modules.map((item) => `${item.skill}:${item.resource}:${item.rule}`),
            ...acts.rejected.map((item) => `ODRZUCONY:${item.resource}`)
          ].join(";"),
          ...(acts.rejected.length ? { rejected: acts.rejected.map((item) => `${item.resource} — ${item.reason}`) } : {})
        });
        if (acts.modules.length) pathSections.push(actModulesPrompt(loaded));
        if (acts.rejected.length) {
          pathSections.push(
            [
              "# MAPA-AKTOW: WIERSZ WSKAZUJE NIEWŁAŚCIWY MODUŁ (aplikacja go nie wczytała)",
              ...acts.rejected.map((item) => `- ${item.resource}: ${item.reason}`),
              "Ustal właściwy moduł z mapy dziedziny albo powiedz wprost, że go brak; zgłoś rozbieżność mapy."
            ].join("\n")
          );
        }
        step("PREPARE", `moduły aktów z mapy (mechanicznie): ${acts.modules.map((item) => path.basename(item.resource, ".md")).join(", ") || "brak"}`);
      }
    }
    if (mandatoryModel && legalTurn && request.modelSelectsSkills) {
      // A follow-up naming no domain of its own keeps the domain of the thread.
      const ownDomains = rankDomains(this.registry, this.flashRoutes(), caseText);
      let domains: Array<{ skill: string; matched: string[]; modules: DomainModule[]; strong: boolean }> =
        ownDomains.length || request.auxiliaryText || !laterTurn(request.query)
          ? ownDomains
          : rankDomains(this.registry, this.flashRoutes(), [threadUserText(request.query), caseText].join("\n"));
      // No phrase and no act map named a domain: the optional fallback model (Settings)
      // names it from the domains' descriptions, on the pseudonymized question only.
      const fallbackTarget = domains.length || isNonLegalMessage(request.query, this.flashRoutes())
        ? null
        : domainFallbackTarget(domainFallbackChoice(), { provider: request.provider, model: request.model });
      if (fallbackTarget) {
        const fallback = await fallbackDomains(this.providers, this.registry, fallbackTarget, protectedAuxiliaryText ?? latestUserTurn(protectedQuery));
        audit.record("gate", "DOMAIN_FALLBACK", fallback.domains.length ? "OK" : "DEGRADED", {
          detail: `${fallbackTarget.model}:${fallback.domains.join(",") || "brak"}${fallback.error ? `;${fallback.error}` : ""}`
        });
        domains = fallback.domains.map((skill) => ({
          skill,
          matched: [`model zapasowy routingu (${fallbackTarget.model})`],
          modules: suggestDomainModules(this.registry, skill, caseText),
          strong: false
        }));
        step("PREPARE", `model zapasowy routingu: ${fallback.domains.join(", ") || "brak dziedziny"}`);
      }
      if (domains.length) {
        audit.record("gate", "DOMAIN_HINT", "OK", {
          detail: domains.map((domain) => `${domain.skill}:${domain.modules.map((module) => module.resource).join(",")}`).join(";")
        });
        pathSections.push(domainHintPrompt(domains));
        step("PREPARE", `dziedzina wg routingu błyskawicznego: ${domains.map((domain) => domain.skill).join(", ")}`);
        // A second domain the case's kind or its own phrase names: its act module goes in
        // with the prompt, not as one more round of the model (the whole context again).
        const secondary = loadActModules(
          this.registry,
          domains
            .slice(1)
            .filter((domain) => domain.strong && domain.modules[0])
            .map((domain) => ({ skill: domain.skill, resource: domain.modules[0]!.resource, rule: "NAZWA" as const, why: domain.modules[0]!.why })),
          contextResources,
          SECONDARY_DOMAIN_MODULES_BUDGET_CHARS
        );
        for (const item of secondary.loaded) {
          contextResources.add(item.resource);
          audit.record("resource_read", item.resource, "OK", { detail: "runtime-preload;domain-hint;secondary-domain" });
        }
        if (secondary.loaded.length) {
          pathSections.push(
            [
              "# MODUŁ AKTU DZIEDZINY WTÓRNEJ (wskazówka routingu; aplikacja wczytała go za ciebie — nie czytaj go ponownie)",
              ...secondary.loaded.map((item) => `## ${item.resource} (${item.why})\n\n${item.content}`)
            ].join("\n\n")
          );
          step("PREPARE", `moduł dziedziny wtórnej wczytany: ${secondary.loaded.map((item) => path.basename(item.resource, ".md")).join(", ")}`);
        }
      }
    }
    // Sections the skill's author marked as executed by the application go to the
    // model as a one-line reference (skill-sections.ts); the audit names them.
    // KROK 7 is the application's only where it appends the canonical text after the
    // gates (free-text answer of a non-local model, not a report or a pipeline document).
    const appendsDisclaimer =
      !request.model.startsWith("local/") &&
      !request.documentAstOutput &&
      !request.processWorkflowContext &&
      !/^raport-/u.test(request.primarySkill);
    const inactiveComponents = new Set([
      ...(appendsDisclaimer ? [] : ["DISCLAIMER"]),
      // show_widget (with template data) exists for every model except a local one.
      ...(request.model.startsWith("local/") ? ["WIDGET-DANE"] : [])
    ]);
    // Stages of the skill reached in this thread (sections marked lex:wczytaj-gdy).
    const stages = reachedStages(request.query);
    // Mechanical mode: the user chose the executive skill and the application the domain,
    // so the router's routing sections (lex:wykonuje-aplikacja: ROUTING) go as a reference;
    // its mandatory core, gates and self-check stay whole.
    const optInComponents = new Set(mechanicalTurn(request) ? ["ROUTING", "REJESTR-MODULOW"] : []);
    // Prompt cache: the stage sections of these resources go after the cached prefix.
    const stageTail = { reached: stages, sections: [] as string[] };
    const forModel = (resource: string, content: string): string => {
      const result = compactForModel(content, undefined, inactiveComponents, stages, optInComponents, stageTail);
      if (result.compacted.length) {
        audit.record("gate", "SECTIONS_EXECUTED_BY_APP", "OK", {
          resource,
          sections: result.compacted.map((item) => `${item.component}:${item.heading}`),
          chars: result.compacted.reduce((sum, item) => sum + item.chars, 0)
        });
      }
      return result.text;
    };
    // PROFIL-LEKKI: a mandatory resource the application could not read is named to the
    // model before it answers and in the answer (⛔ TRYB ZDEGRADOWANY), never silently replaced by memory.
    const unreadableResources: string[] = [];
    if (mandatoryModel && legalTurn) {
      const preloaded = preloadForTurn(mandatoryModel, { ...pathFacts, profile }).filter((resource) => !contextResources.has(resource));
      for (const resource of preloaded) {
        const content = this.readCorpus(resource);
        if (!content) {
          audit.record("resource_read", resource, "BLOCKED", { detail: "runtime-preload;mandatory-path;missing" });
          unreadableResources.push(resource);
          continue;
        }
        contextResources.add(resource);
        audit.record("resource_read", resource, "OK", { detail: "runtime-preload;mandatory-path", profile });
        pathSections.push(`# MANDATORY PATH RESOURCE: ${resource}\n\n${forModel(resource, content)}`);
      }
      if (unreadableResources.length) {
        pathSections.push(
          [
            "# ⛔ TRYB ZDEGRADOWANY — ZASOBY NIEWCZYTANE (ustalone przez aplikację)",
            `Aplikacja nie wczytała: ${unreadableResources.join(", ")}.`,
            "Nie odtwarzaj ich reguł z pamięci. Wskaż w odpowiedzi, której kontroli z tych zasobów nie wykonano."
          ].join("\n")
        );
      }
      step("SKILLS", `ścieżka obowiązkowa: profil ${profile === "PELNY" ? "PEŁNY" : "LEKKI"}, wczytano ${preloaded.length - unreadableResources.length} plików`);
      pathSections.unshift(mandatoryPathInstructions(mandatoryModel, profile, [...contextResources]));
    }
    // AUTO: the task type from the router's table [1]–[11] names the executive skill
    // the router requires; the app loads it in full with its contract (mechanically,
    // as in the mechanical mode) instead of leaving the choice to the model.
    // Mechanical mode: the user pinned the executive skill. A request the activation matrix
    // gives to another skill ("napisz pozew" with the simple letter or the statute analysis
    // pinned) is not dropped: a pleading asked of pisma-proste-v2 gets its M7 escalation
    // (offered by the application even when the model writes the letter anyway), any other
    // one a "next stage" choice under the answer. The pinned skill still answers this turn.
    let mechanicalTask: TaskDecision | null = null;
    if (mechanicalTurn(request) && legalTurn) {
      const pinned = parseSkillSelectionEnvelope(request.query).manualSkills.filter((name) => !name.startsWith("dr-"));
      const letters = { skill: "pisma-proste-v2", entries: schemaCatalog(this.registry, "pisma-proste-v2") };
      const decided = decideTask(this.taskRoutes(), this.activationMatrix(), taskQuery, [...recognisedDocuments], this.redactionTest(), letters);
      // The request itself (without the delivered files' own rows) asks the pinned skill's work:
      // a contract in the files of "przygotuj pozew" is the pleading's material, not a task.
      const asked = decideTask(this.taskRoutes(), this.activationMatrix(), taskQuery, [], this.redactionTest(), letters);
      if (decided && pinned.length && !pinned.includes(decided.primary) && !(asked && pinned.includes(asked.primary)) && this.registry.get(decided.primary)) {
        mechanicalTask = decided;
      }
    }
    const appEscalation: SkillSwitchOffer | null =
      mechanicalTask?.primary === "pisma-procesowe-v3" && parseSkillSelectionEnvelope(request.query).manualSkills.includes("pisma-proste-v2")
        ? { from: "pisma-proste-v2", to: "pisma-procesowe-v3", direction: "ESCALATION", reason: `rozpoznanie aplikacji — ${mechanicalTask.reason}` }
        : null;
    if (appEscalation) {
      pathSections.push(
        [
          "# ROZPOZNANIE APLIKACJI: PISMO PROCESOWE (M7-eskalacja)",
          `Aplikacja (macierz aktywacji) rozpoznała pismo procesowe: ${mechanicalTask!.reason}.`,
          "Nie pisz pisma w tym wątku. Napisz komunikat M7: „ESKALACJA DO pisma-procesowe-v3” i linię „Przyczyna: …”, a potem zapytaj, czy przełączyć wątek; aplikacja zaproponuje przełączenie."
        ].join("\n")
      );
    } else if (mechanicalTask) {
      pathSections.push(
        `# ROZPOZNANIE APLIKACJI: KOLEJNY ETAP\nCzęść prośby należy do ${mechanicalTask.primary} (${mechanicalTask.reason}). Odpowiedz w ramach przypiętego skilla; aplikacja zaproponuje użytkownikowi przejście do ${mechanicalTask.primary} pod odpowiedzią. Nie wykonuj tej części ani jej nie symuluj.`
      );
    }
    let taskRoute: TaskDecision | null = null;
    let routingMaterials: Array<{ category: string; evidence: boolean; label: string; kind?: string }> = [];
    if (
      mandatoryModel &&
      legalTurn &&
      request.modelSelectsSkills &&
      !request.guideContext &&
      !request.processWorkflowContext &&
      !request.courtWorkflowContext &&
      !request.chronologyWorkflowContext &&
      !request.contractWorkflowContext &&
      !request.orderedCaseWorkflowContext
    ) {
      // ACTIVATION-MATRIX first (phrases and delivered materials), then the
      // router table [1]–[11] on the question and the documents' kinds.
      // The matter's own files (case search on) count as delivered case files for a
      // request to analyse the matter ("całościowa analiza sprawy").
      const materials = [
        ...recognisedDocuments,
        ...(request.caseFiles && !recognisedDocuments.length && ANALYSIS_INTENT.test(pathFacts.query)
          ? [{ category: "AKTA", evidence: false, label: "akta sprawy" }]
          : [])
      ];
      routingMaterials = materials;
      taskRoute = decideTask(this.taskRoutes(), this.activationMatrix(), taskQuery, materials, this.redactionTest(), {
        skill: "pisma-proste-v2",
        entries: schemaCatalog(this.registry, "pisma-proste-v2")
      });
      // A short follow-up with no task of its own ("ok, robisz to.", "tak, szukaj dalej")
      // continues the thread's last routed request instead of dropping its executive skill.
      if (!taskRoute && !materials.length && pathFacts.query.trim().length <= FOLLOW_UP_MAX_CHARS) {
        for (const earlier of earlierUserTurns(request.query).slice(0, 3)) {
          const inherited = decideTask(this.taskRoutes(), this.activationMatrix(), withoutOutputContract(earlier), [], this.redactionTest(), {
            skill: "pisma-proste-v2",
            entries: schemaCatalog(this.registry, "pisma-proste-v2")
          });
          if (inherited) {
            taskRoute = { ...inherited, reason: `kontynuacja wątku (${inherited.reason})` };
            break;
          }
        }
      }
      const record = taskRoute ? this.registry.get(taskRoute.primary) : undefined;
      if (taskRoute && record) {
        const skill = record.name;
        const text = fs.readFileSync(record.skillFile, "utf8");
        corpusTools.recordPreloaded(`${path.basename(record.directory)}/SKILL.md`);
        contextResources.add(`${path.basename(record.directory)}/SKILL.md`);
        audit.record("gate", "TASK_ROUTING", "OK", {
          source: taskRoute.source,
          skill,
          ...(taskRoute.then ? { then: taskRoute.then } : {}),
          reason: taskRoute.reason
        });
        pathSections.push(
          [
            `# SKILL WYKONAWCZY WG ROUTERA: ${skill} (wczytany przez aplikację w całości; nie czytaj go ponownie)`,
            `Rozpoznanie aplikacji — ${taskRoute.reason}. To jest PRIMARY tej sprawy${taskRoute.route?.secondary.length ? `; SECONDARY: ${taskRoute.route.secondary.join(", ")}` : ""}.` +
              (taskRoute.then ? ` Dalszy etap pipeline'u według macierzy: ${taskRoute.then} (po wyniku tego skilla).` : "") +
              " Gdy treść sprawy wskazuje inny wiersz routingu, powiedz to wprost i wczytaj właściwy skill.",
            ...(skill === "pisma-procesowe-v3" || skill === "pisma-proste-v2" || taskRoute.then === "pisma-procesowe-v3"
              ? ["Pełny pipeline pisma (etapy, HYBRID-VAL, .docx) prowadzi tryb mechaniczny: zaproponuj użytkownikowi wybór tego skilla w trybie mechanicznym."]
              : []),
            forModel(`${skill}/SKILL.md`, text)
          ].join("\n\n")
        );
        const contract = executiveContract(this.registry, skill, (body) => compactForModel(body, undefined, inactiveComponents, stages, optInComponents).text);
        if (contract) {
          const loaded = loadContract(this.registry, contract, { inContext: contextResources, budget: CONTRACT_BUDGET_CHARS / 2 });
          for (const item of loaded.loaded) {
            contextResources.add(item.resource);
            audit.record("resource_read", item.resource, "OK", { detail: "runtime-preload;executive-contract" });
          }
          audit.record("gate", "EXECUTIVE_CONTRACT", "OK", {
            detail: `skill=${skill};gates=${contract.gates.length};loaded=${loaded.loaded.map((item) => item.resource).join(",")};toRead=${loaded.toRead.join(",")}`
          });
          pathSections.push(contractPrompt(loaded));
        }
        // Shared files every executive skill names for this case: the runtime adapter
        // ("przed wykonaniem zastosuj"), and FAKTY_v2 for a letter drafted from the
        // delivered material (router KROK 5-6: "Materiały źródłowe? TAK -> FAKTY_v2").
        const draftsLetter = [skill, taskRoute.then].some((name) => /^pisma-/.test(name ?? ""));
        // A letter, a regulation or a contract over ~10 pages: written in parts (long-document.ts).
        if (draftsLetter || skill === "analizator-umow-v1") pathSections.push(longDocumentRule(request.model.startsWith("local/")));
        const sharedForSkill = [
          "shared/UNIVERSAL-RUNTIME-ADAPTER.md",
          ...(draftsLetter && attachments.length > 0 ? ["shared/FAKTY_v2.md"] : [])
        ];
        for (const resource of sharedForSkill) {
          if (contextResources.has(resource)) continue;
          const content = this.readCorpus(resource);
          if (!content) continue;
          contextResources.add(resource);
          audit.record("resource_read", resource, "OK", { detail: "runtime-preload;executive-shared" });
          pathSections.push(`# ZASÓB SHARED WYMAGANY PRZEZ SKILL ${skill}: ${resource}\n\n${forModel(resource, content)}`);
        }
        // Modules the decision itself requires (Test A: MOD-REDAKCJA for a finished pleading).
        for (const resource of taskRoute.modules ?? []) {
          if (contextResources.has(resource)) continue;
          const content = this.readCorpus(resource);
          if (!content) continue;
          contextResources.add(resource);
          audit.record("resource_read", resource, "OK", { detail: "runtime-preload;task-decision" });
          pathSections.push(`# MODUŁ WYMAGANY PRZEZ ROZPOZNANIE ZADANIA: ${resource}\n\n${content}`);
        }
        // Conditional modules of the skill's module map that this case triggers.
        const modules = loadModules(
          this.registry,
          skill,
          skillModules(this.registry, skill, {
            // The kinds of the delivered material in the words module maps use.
            text: [
              pathFacts.query,
              ...recognisedDocuments.map((document) => document.label),
              recognisedDocuments.some((document) => document.evidence) ? "materiał zawiera dowody do oceny (dokumenty)" : "",
              recognisedDocuments.some((document) => document.category === "PISMO_PROCESOWE" || document.category === "ORZECZENIE")
                ? "materiał zawiera pisma procesowe, akta"
                : "",
              opponentPleadingTrigger(pathFacts.query, recognisedDocuments)
            ].join("\n")
          }),
          contextResources
        );
        if (modules.loaded.length || modules.toRead.length) {
          for (const item of modules.loaded) {
            contextResources.add(item.resource);
            audit.record("resource_read", item.resource, "OK", { detail: "runtime-preload;skill-module-map" });
          }
          audit.record("gate", "SKILL_MODULES", "OK", {
            detail: `skill=${skill};loaded=${modules.loaded.map((item) => item.resource).join(",")};toRead=${modules.toRead.map((item) => item.resource).join(",")}`
          });
          pathSections.push(modulesPrompt(skill, modules));
        }
        step("SKILLS", `skill wykonawczy (${taskRoute.source === "MATRIX" ? "macierz aktywacji" : taskRoute.source === "SKILL" ? "rozpoznanie w skillu" : "routing"}): ${skill}`);
      }
    }
    const identityPrompt = [
      "# MODEL TEJ SESJI (podaje aplikacja)",
      `Dostawca: ${request.provider}; identyfikator modelu w aplikacji: ${request.model}.` +
        (request.model.startsWith("account/") ? " Przy koncie konkretną wersję wybiera klient dostawcy; aplikacja jej nie zna." : ""),
      "Pytany, jakim jesteś modelem, podaj te dane; nie zgaduj nazwy ani wersji z pamięci."
    ].join("\n");

    // Prompt cache: what is the same for every turn of this skill path (identity, the
    // mandatory path and shared resources, tool contracts) goes first and is cached by
    // the provider; what this turn adds (mode, recognitions, act modules, evidence,
    // cited law, retrieval) goes after it.
    const turnScoped = new Set([CRIMINAL_QUALIFIER_RESOURCE, CAUSAL_RESOURCE]);
    const stablePath = (section: string): boolean => {
      const resource = /^# (?:MANDATORY PATH RESOURCE|ZASÓB SHARED WYMAGANY PRZEZ SKILL [^:]+): (\S+)/.exec(section)?.[1];
      return Boolean(resource) && !turnScoped.has(resource as string);
    };
    // The head shared by every case on this path (identity, the mandatory path's modules): the
    // provider caches the system prompt up to its end; skill-specific resources and the tools
    // of this case follow it.
    const sharedPath = (section: string): boolean => stablePath(section) && section.startsWith("# MANDATORY PATH RESOURCE:");
    const toolPromptStable = [identityPrompt, CITATION_FORM_RULE, ...pathSections.filter(sharedPath)].join("\n\n");
    const toolPrompt = [
      toolPromptStable,
      ...pathSections.filter((section) => stablePath(section) && !sharedPath(section)),
      ...(nativeCorpus ? [] : [corpusTools.systemPromptAppendix()]),
      ...(coreLawTools ? [coreLawTools.systemPromptAppendix()] : []),
      ...(caseFileTools ? [caseFileTools.systemPromptAppendix()] : []),
      reportTools.systemPromptAppendix(),
      ...(courtTools ? [courtTools.systemPromptAppendix()] : []),
      ...(widgetTools ? [widgetTools.systemPromptAppendix()] : []),
      ...(federationTools ? [federationTools.systemPromptAppendix()] : []),
      ...(verificationTools ? [verificationTools.systemPromptAppendix()] : [])
    ].join("\n\n");
    const toolPromptTurn = [
      ...(request.modeDecision ? [queryModePrompt(request.modeDecision)] : []),
      ...[stageTailPrompt(stageTail.sections)].filter((block): block is string => Boolean(block)),
      ...pathSections.filter((section) => !stablePath(section)),
      ...(evidencePrompt ? [evidencePrompt] : []),
      ...(citedLaw ? [citedLaw] : []),
      // Statute analysis pinned by the user, no article number in the question ("zasiedzenie"):
      // the articles the core law search ranks first, as local models get them.
      ...(!citedLaw && !coreLawRag && this.coreLawIndex && legalTurn && mechanicalTurn(request) &&
      parseSkillSelectionEnvelope(request.query).manualSkills.includes("analizator-przepisow-v2")
        ? [coreLawRetrievalPrompt(this.coreLawIndex, protectedQuery)].filter((block): block is string => Boolean(block))
        : []),
      ...(request.caseCourt && !request.conversationalOnly ? [caseCourtPrompt(request.caseCourt)] : []),
      ...(attachments.length > 0 ? [documentCitationSystemPrompt(attachments)] : []),
      ...(coreLawRag ? [coreLawRag] : [])
    ].join("\n\n");

    // Kind and gender of every placeholder the model will see: it inflects
    // around them without ever seeing a name.
    const roles = genericWords().partyRoles;
    const placeholderKey = placeholderKeyPrompt([
      ...placeholderGrammar(
        [
          protectedQuery,
          protectedAuxiliaryText ?? "",
          // Shared-key documents use the chat's own (seeded) tokens.
          ...attachments
            .filter((attachment) => attachment.sharedKey)
            .flatMap((attachment) => attachment.chunks.map((chunk) => chunk.text))
        ].join("\n"),
        chatPrivacyVault
      ),
      ...attachments
        .filter((attachment) => !attachment.sharedKey)
        .flatMap((attachment) => attachment.grammar ?? [])
    ], partyGroups(
      // Parties of several persons named after a role word ("powodowie [..] i [..]").
      [protectedQuery, protectedAuxiliaryText ?? "", ...attachments.flatMap((attachment) => attachment.chunks.map((chunk) => chunk.text))],
      (word) => roles.has(word)
    ));

    const toolBudget = {
      calls: 0,
      skillReads: 0,
      callLimit: positiveEnvInt("LEX_TOOL_CALL_BUDGET", 60),
      skillReadLimit: positiveEnvInt("LEX_SKILL_READ_BUDGET", 40),
      // LEX_TOOL_BROKER_MODE=audit: record the decisions, block nothing (rollout).
      auditOnly: process.env.LEX_TOOL_BROKER_MODE === "audit"
    };
    const draftCallbacks =
      request.onDraft
        ? createDraftCallbacks(
            chatPrivacyVault,
            request.onDraft,
            request.restoreDocumentToken
              ? (documentNumber, sourceToken) => {
                  const documentId = aliasRegistry.documentIds()[documentNumber - 1];
                  if (!documentId) return null;
                  try {
                    return request.restoreDocumentToken!(documentId, sourceToken);
                  } catch {
                    return null;
                  }
                }
              : undefined
          )
        : undefined;
    // Material gate: a pinned skill that works on documents, the first turn, no file in the
    // message, none in the case and no pasted text - the application asks for the material
    // itself (no model call, ~100k tokens saved; the checkpoint stays open until it comes).
    const materialSkill = mechanicalTurn(request)
      ? mechanicalEnvelope.manualSkills.find(
          (name) => name in MATERIAL_SKILLS && !(name === "analizator-umow-v1" && request.contractWorkflowContext?.mode === "DRAFT")
        )
      : undefined;
    let caseDocuments = 0;
    if (materialSkill && request.caseFiles) {
      try {
        caseDocuments = (await request.caseFiles.listDocuments()).length;
      } catch {
        caseDocuments = 1;
      }
    }
    // Only at the workflow's first step: a later checkpoint means the work is under way.
    const firstStep =
      (!request.contractWorkflowContext || request.contractWorkflowContext.checkpoint === "AU-F0") &&
      (!request.orderedCaseWorkflowContext || /INTAKE/u.test(request.orderedCaseWorkflowContext.checkpoint)) &&
      (!request.chronologyWorkflowContext || request.chronologyWorkflowContext.stage === "INVENTORY") &&
      (!request.courtWorkflowContext || request.courtWorkflowContext.stage === "EVIDENCE_SCAN");
    const fixedAnswer =
      materialSkill && firstStep && attachments.length === 0 && caseDocuments === 0 && !laterTurn(request.query) && latestMessage.length < MATERIAL_PASTED_CHARS &&
      !materialInWords(materialSkill, latestMessage)
        ? `Do tej pracy potrzebny jest materiał: ${MATERIAL_SKILLS[materialSkill]}. Dołącz plik do wiadomości albo wklej jego treść; dokumenty już zapisane w aktach wybierz w sprawie.\n\n${WAIT_FOR_USER_MARKER}`
        : undefined;
    if (fixedAnswer) {
      step("MODEL", "brak materiału: pytanie aplikacji, bez wywołania modelu");
      audit.record("gate", "MATERIAL_REQUIRED", "OK", { skill: materialSkill, waitingForUser: true });
    }
    const execution = await this.engine.executePolishLegalQuery({
      ...(fixedAnswer ? { fixedAnswer } : {}),
      instructionCompaction: { inactive: [...inactiveComponents], stages: [...stages], optIn: [...optInComponents] },
      ...(this.coreLawIndex
        ? {
            coreLaw: this.coreLawIndex.distinctSummaries().map((act) => ({
              eli: act.eli,
              title: act.title,
              labels: act.labels,
              domains: act.domains,
              articleCount: act.articleCount,
              origin: act.origin,
              eliCaution: coreLawEliCaution(act)
            }))
          }
        : {}),
      onEvent: (event) => {
        if (event.status !== "OK") return;
        if (event.type === "route") step("ROUTING", event.target);
        else if (event.target === "MODEL_SKILL_SELECTION") step("ROUTING", "model dobiera skille według routera v3");
        else if (event.target === "LOCAL_QUICK_LEGAL") step("SKILLS", "szybka odpowiedź: węzły kwalifikatora i przepisy z ELI");
        else if (event.type === "skill_read") step("SKILLS", `skill ${event.target}`);
        else if (event.type === "resource_read") step("SKILLS", event.target);
        else if (event.type === "provider_start") step("MODEL", `model ${event.detail ?? event.target}`);
      },
      query: protectedQuery,
      ...(draftCallbacks
        ? {
            draftCallbacks
          }
        : {}),
      ...(documentContext ? { documentContext } : {}),
      ...(modelImages.length ? { documentImages: modelImages } : {}),
      ...(placeholderKey ? { placeholderKey } : {}),
      ...(request.conversationalOnly
        ? {
            conversationalOnly: true,
            ...(request.factCorrection ? { factCorrection: true } : {})
          }
        : {}),
      ...(request.modelSelectsSkills
        ? {
            modelSelectsSkills: true
          }
        : {}),
      ...(request.modelSelectsSkills && !nativeCorpus
        ? {
            onCorpusPreloaded: (relativePath: string) => {
              corpusTools.recordPreloaded(relativePath);
              step("SKILLS", relativePath);
            }
          }
        : {}),
      ...(nativeCorpus
        ? {
            nativeCorpus: {
              root: this.registry.root,
              onRead: (relativePath: string) => {
                corpusTools.recordNativeRead(relativePath);
                step("SKILLS", relativePath);
              },
              onMissing: (relativePath: string) => corpusTools.recordNativeMissing(relativePath),
              missingQualifier: () => corpusTools.missingCriminalQualifier()
            }
          }
        : {}),
      provider: request.provider,
      model: request.model,
      // The app sends the instructions and the thread (summary + recent turns) on
      // every call, so a resumed host thread only repeated them: each turn and each
      // tool round appended the whole prompt again, and with no matter key the CLI
      // took over the user's latest unrelated session. LEX_ACCOUNT_RESUME=1 restores it.
      ...(request.accountSessionKey && resumeHostThread()
        ? {
            continuityKey:
              request.accountSessionKey
          }
        : {}),
      ...(request.accountContinuity || !resumeHostThread()
        ? { accountContinuity: request.accountContinuity ?? "none" }
        : {}),
      route: {
        jurisdiction: "PL",
        primarySkill: workflowPrimarySkill(),
        mode: request.mode
      },
      ...(request.guideContext
        ? {
            guideContext:
              request.guideContext
          }
        : {}),
      ...(request.documentAstOutput
        ? { documentAstOutput: true }
        : {}),
      ...(request.processRenderOnly && request.documentAstOutput
        ? { processRenderOnly: request.processRenderOnly }
        : {}),
      ...(request.contractRenderOnly && request.documentAstOutput
        ? { contractRenderOnly: true }
        : {}),
      ...(protectedProcessContext
        ? {
            processWorkflowContext:
              protectedProcessContext
          }
        : {}),
      ...(request.courtWorkflowContext
        ? {
            courtWorkflowContext:
              request.courtWorkflowContext
          }
        : {}),
      ...(request.chronologyWorkflowContext
        ? {
            chronologyWorkflowContext:
              request.chronologyWorkflowContext
          }
        : {}),
      resourcesInContext: [...contextResources],
      criminalMatter: pathFacts.criminal,
      ...(request.contractWorkflowContext
        ? {
            contractWorkflowContext:
              request.contractWorkflowContext
          }
        : {}),
      ...(request.orderedCaseWorkflowContext
        ? {
            orderedCaseWorkflowContext:
              request.orderedCaseWorkflowContext
          }
        : {}),
      tools: toolSchemas,
      toolSystemPromptAppendix: toolPrompt,
      toolSystemPromptStableChars: toolPromptStable.length,
      toolSystemPromptTurn: toolPromptTurn,
      // A SIMPLE matter (entry gate) on a local model takes the compact
      // lane: core-law texts in the prompt, core-law tools for the rest.
      ...(coreLawTools && request.model.startsWith("local/") && attachments.length === 0
        ? {
            quickLocalLegal: {
              toolPrompt: [
                coreLawTools.systemPromptAppendix(),
                ...(citedLaw ? [citedLaw] : []),
                coreLawRag ??
                  "# LOKALNE TEKSTY USTAW\nDla tego pytania nie dobrano automatycznie artykułów. Znajdź przepis search_core_law, a jego brzmienie weź z read_core_law_article; bez tego nie podawaj treści przepisu."
              ].join("\n\n")
            }
          }
        : {}),
      ...(request.matterComplexity
        ? { matterComplexity: request.matterComplexity }
        : {}),
      runGateIRuntimePrelude:
        (workflowPlan) =>
          runGateIRuntimePrelude({
            workflow:
              workflowPlan.id,
            query:
              protectedQuery,
            ledger,
            ...(verificationTools
              ? {
                  runTools:
                    (calls) =>
                      verificationTools
                        .runTools(
                          calls
                        )
                }
              : {})
          }),
      runTools: async (requestedCalls) => {
        // Per-turn budgets: a looping model stops here, not at the bill.
        const overBudget = new Set<string>();
        for (const call of requestedCalls) {
          const corpus = corpusTools.handles(call.name);
          const used = corpus ? ++toolBudget.skillReads : ++toolBudget.calls;
          if (used > (corpus ? toolBudget.skillReadLimit : toolBudget.callLimit)) overBudget.add(call.id);
        }
        if (overBudget.size) {
          audit.record("gate", "TOOL_CALL_BUDGET", toolBudget.auditOnly ? "DEGRADED" : "BLOCKED", {
            calls: toolBudget.calls,
            skillReads: toolBudget.skillReads,
            callLimit: toolBudget.callLimit,
            skillReadLimit: toolBudget.skillReadLimit,
            enforced: !toolBudget.auditOnly
          });
          if (toolBudget.auditOnly) overBudget.clear();
        }
        const calls = requestedCalls
          .filter((call) => !overBudget.has(call.id))
          .map((call) => {
            if (!federationTools?.handles(call.name)) return call;
            // A business identifier of the case to the public register that answers for it.
            const shared = discloseRegistryIdentifiers(call, (token) =>
              chatPrivacyVault.hasToken(token) ? chatPrivacyVault.restore(token, null).text : null
            );
            if (shared.disclosed.length) {
              audit.record("gate", "REGISTRY_IDENTIFIER_DISCLOSED", "OK", {
                tool: call.name,
                source: String(call.input.source ?? call.input.sourceId ?? ""),
                kinds: [...new Set(shared.disclosed)]
              });
            }
            return shared.call;
          });
        for (const call of calls) {
          if (corpusTools.handles(call.name)) {
            const target = [call.input.skill, call.input.path].filter((part) => typeof part === "string").join("/");
            step("SKILLS", target || call.name);
          } else {
            step("MODEL", `narzędzie ${call.name}`);
          }
        }
        const corpusCalls = calls.filter((call) => corpusTools.handles(call.name));
        const reportCalls = calls.filter((call) => reportTools.handles(call.name));
        const courtCalls = calls.filter((call) => courtTools?.handles(call.name) ?? false);
        const caseFileCalls = calls.filter((call) => caseFileTools?.handles(call.name) ?? false);
        const widgetCalls = calls.filter((call) => widgetTools?.handles(call.name) ?? false);
        const federationCalls = calls.filter(
          (call) =>
            federationTools?.handles(
              call.name
            ) ?? false
        );
        const coreLawCalls = calls.filter(
          (call) =>
            coreLawTools?.handles(
              call.name
            ) ?? false
        );
        const verificationCalls = calls.filter(
          (call) =>
            !(coreLawTools?.handles(call.name) ?? false) &&
            !corpusTools.handles(call.name) &&
            !reportTools.handles(call.name) &&
            !(courtTools?.handles(call.name) ?? false) &&
            !(caseFileTools?.handles(call.name) ?? false) &&
            !(widgetTools?.handles(call.name) ?? false) &&
            !(federationTools?.handles(call.name) ?? false)
        );

        const corpusResults = corpusCalls.length > 0
          ? await corpusTools.runTools(corpusCalls)
          : [];
        const coreLawResults =
          coreLawTools &&
          coreLawCalls.length > 0
            ? await coreLawTools.runTools(
                coreLawCalls
              )
            : [];
        const reportResults = reportCalls.length > 0
          ? await reportTools.runTools(reportCalls)
          : [];
        const courtResults = courtTools && courtCalls.length > 0 ? await courtTools.runTools(courtCalls) : [];
        for (const event of courtTools?.auditEvents().slice(-courtCalls.length) ?? []) {
          // The address went to the GUGiK geocoder (a public register), the party's name never.
          audit.record("gate", "ADDRESS_GEOCODED", event.status === "FOUND" ? "OK" : "DEGRADED", {
            status: event.status,
            method: event.method ?? "",
            court: event.court ?? "",
            kinds: event.disclosed.join(",")
          });
        }
        const caseFileResults = caseFileTools && caseFileCalls.length > 0
          ? await caseFileTools.runTools(caseFileCalls)
          : [];
        const widgetResults = widgetTools && widgetCalls.length > 0
          ? await widgetTools.runTools(widgetCalls)
          : [];
        const federationResults =
          federationTools &&
          federationCalls.length > 0
            ? await federationTools
                .runTools(
                  federationCalls,
                  federationEvents
                )
            : [];

        if (federationResults.some((result) => result.content.includes("SN_WERYFIKACJA_WYMAGANA"))) {
          snVerificationRequired = true;
        }
        for (const result of federationResults) {
          caseSourceTexts.push(result.content);
          const call = federationCalls.find((item) => item.id === result.tool_use_id);
          (call && officialCaseLawCall(call) ? officialCaseLawTexts : leadCaseLawTexts).push(result.content);
        }
        for (
          const result
          of federationResults
        ) {
          const source =
            publicAuxiliarySourceFromToolResult(
              result
            );
          if (!source) {
            continue;
          }
          const key =
            [
              source.sourceUrl,
              source.claim ?? "",
              source.crossCheckStatus
            ].join("|");
          const exists =
            auxiliarySources.some(
              (item) =>
                [
                  item.sourceUrl,
                  item.claim ?? "",
                  item.crossCheckStatus
                ].join("|") ===
                key
            );
          if (!exists) {
            auxiliarySources.push(
              source
            );
          }
        }

        const verificationResults =
          verificationCalls.length > 0 &&
          verificationTools
            ? await verificationTools
                .runTools(
                  verificationCalls
                )
            : [];

        // The chat's own SN tools stopped by sn.pl's check: the same verification window
        // as the case-law search (the connector), then the question again.
        if (verificationResults.some((result) => /SN_WERYFIKACJA_WYMAGANA/.test(result.content))) {
          snVerificationRequired = true;
        }
        for (const result of verificationResults) {
          caseSourceTexts.push(result.content);
          officialCaseLawTexts.push(result.content);
        }

        const byId = new Map(
          [
            ...corpusResults,
            ...coreLawResults,
            ...caseFileResults,
            ...reportResults,
            ...courtResults,
            ...widgetResults,
            ...federationResults,
            ...verificationResults
          ].map((result) => [
            result.tool_use_id,
            result
          ])
        );

        return requestedCalls.map((call) =>
          byId.get(call.id) ??
          (overBudget.has(call.id)
            ? {
                tool_use_id: call.id,
                content: JSON.stringify({
                  status: "POLICY_BLOCKED",
                  error: "TOOL_CALL_BUDGET_EXCEEDED",
                  instruction:
                    "Limit wywołań narzędzi w tej turze został wyczerpany. Odpowiedz na podstawie tego, co już masz, i wskaż, czego nie sprawdzono."
                })
              }
            : {
                tool_use_id: call.id,
                content: JSON.stringify({
                  status: "BLOCKED",
                  error: "UNKNOWN_RUNTIME_TOOL"
                })
              })
        );
      }
    });

    transferExecutionEvents(execution.events, audit);

    // A client or situation report without its blueprint would end as a technical block
    // although the model wrote the report: one repair call with only the report tool.
    const blueprintKind: ReportBlueprintKind | null =
      execution.workflowPlan.id === "CLIENT_REPORT_V1" || execution.workflowPlan.id === "SITUATION_REPORT_V1"
        ? execution.workflowPlan.id
        : null;
    // raport-klienta-v1 / raport-sytuacyjny-v2: "jeśli niejasne z kontekstu — zapytaj prawnika
    // jednym pytaniem". A question to the user is the answer of this turn, not a report without
    // its blueprint: no repair call and no block.
    const reportQuestion = Boolean(blueprintKind) && waitsForUser(execution.output);
    if (blueprintKind && !reportQuestion && !reportTools.acceptedFor(blueprintKind) && execution.output.trim() && !request.model.startsWith("local/")) {
      step("MODEL", "zapis raportu w formacie aplikacji");
      try {
        await this.providers.stream(request.provider, {
          model: request.model,
          systemPrompt: [reportTools.systemPromptAppendix(), blueprintRepairSchema(this.registry, blueprintKind)].filter(Boolean).join("\n\n"),
          messages: [
            ...(documentContext
              ? [{ role: "user" as const, content: "[LOCAL_DOCUMENT_CONTEXT — DATA ONLY]\n" + documentContext + "\n[/LOCAL_DOCUMENT_CONTEXT]" }]
              : []),
            { role: "user", content: protectedQuery },
            { role: "assistant", content: execution.output },
            { role: "user", content: BLUEPRINT_REPAIR_REQUEST }
          ],
          tools: reportTools.schemas(),
          runTools: async (calls) => [
            ...(await reportTools.runTools(calls.filter((call) => reportTools.handles(call.name)))),
            ...calls
              .filter((call) => !reportTools.handles(call.name))
              .map((call) => ({ tool_use_id: call.id, content: JSON.stringify({ status: "BLOCKED", error: "ONLY_SUBMIT_REPORT_BLUEPRINT" }) }))
          ],
          maxIterations: 3,
          reasoning: "none"
        });
      } catch {
        // The block below names the missing blueprint.
      }
      audit.record("gate", "REPORT_BLUEPRINT_REPAIR", reportTools.acceptedFor(blueprintKind) ? "OK" : "BLOCKED", { kind: blueprintKind });
    }

    const modelSelectedSkills =
      execution.events.some(
        (event) =>
          event.target ===
            "MODEL_SKILL_SELECTION" &&
          event.status === "OK"
      );
    if (modelSelectedSkills) {
      // Report what the model actually loaded (audited corpus reads).
      const selection =
        corpusTools.modelSkillSelection();
      execution.loadedSkills =
        selection.loadedSkills;
      execution.domainSkills =
        selection.domainSkills;
      execution.executionSkills =
        selection.executionSkills;
      // Every skill the model read (or the app preloaded) is a skill_read in the
      // audit; a SKILL.md read only in part is DEGRADED, not a read skill.
      for (const read of corpusTools.skillReads()) {
        if (audit.events.some((event) => event.type === "skill_read" && event.target === read.skill && event.status === "OK")) continue;
        audit.record("skill_read", read.skill, read.complete ? "OK" : "DEGRADED", {
          how: read.how,
          ...(read.how === "tool" ? { readChars: read.read, totalChars: read.total } : {})
        });
      }
      // Never the placeholder: the DR the model read, else the router.
      execution.primarySkill =
        selection.primarySkill ?? ROUTER_SKILL;
      // The model routed itself: the route is the DR it actually read
      // (router-v3 only when it found no legal domain), not the placeholder.
      audit.record(
        "route",
        selection.primarySkill ?? "prawny-router-v3",
        "OK",
        {
          role: "primary-domain",
          selection: "model-auto-selection",
          domainSkills: selection.domainSkills
        }
      );
    }

    for (const event of caseFileTools?.auditEvents() ?? []) {
      audit.record(
        event.tool === "read_case_file" ? "resource_read" : "tool_decision",
        event.tool === "read_case_file" ? `local-document:${event.target}` : `case-files:${event.target}`,
        event.decision === "ALLOW" ? "OK" : "BLOCKED",
        { tool: event.tool, protectedOnly: true, ...(event.detail ?? {}) }
      );
    }
    const readCaseTexts: string[] = [];
    for (const read of caseFileTools?.readChunks() ?? []) {
      citationSources.push({
        caseId: request.caseFiles!.caseId,
        documentId: read.documentId,
        sourceScope: "CASE_KNOWLEDGE",
        chunks: read.chunks
      });
      readCaseTexts.push(read.chunks.map((chunk) => chunk.text).join("\n"));
    }
    // Dokumenty sprawy czytane narzędziem w tej turze: ich sygnatury i kwoty to fakty sprawy
    // (jak przy załącznikach), nie orzecznictwo ani stawki ustawowe do weryfikacji.
    if (readCaseTexts.length > 0) {
      for (const signature of ownCaseFileNumbers(readCaseTexts, "")) ledger.addCaseFileNumber(signature);
      for (const signature of mentionedCaseNumbers(readCaseTexts)) ledger.addCaseReference(signature);
      for (const key of amountKeysIn(readCaseTexts.join("\n"))) ledger.addFactAmount(key);
    }

    for (const event of coreLawTools?.auditEvents() ?? []) {
      audit.record(
        event.tool === "read_core_law_article"
          ? "resource_read"
          : "tool_decision",
        `core-law:${event.target}`,
        event.decision === "ALLOW" ? "OK" : "BLOCKED",
        {
          tool: event.tool,
          ...(event.detail ? event.detail : {})
        }
      );
    }

    const corpusAudit = corpusTools.auditEvents();
    // A refused read that grants no content and that the model can correct
    // (router-v3 not read yet, a guessed file name, a malformed or binary read,
    // an unknown corpus tool) is guidance, not a failed turn - also when the
    // runtime routed the skills (document generation), where the required
    // reads are enforced separately by G39H. Path escapes (INVALID_RESOURCE_PREFIX,
    // PATH_ESCAPE), the criminal qualifier and other refusals still block.
    const correctableCorpusRefusal =
      /^(ROUTER_V3_REQUIRED_FIRST|LEGAL_RESOURCE_NOT_FOUND|LEGAL_SKILL_NOT_FOUND|LEGAL_RESOURCE_NOT_FILE|LEGAL_RESOURCE_NOT_TEXT|LEGAL_RESOURCE_REQUEST_INVALID|INVALID_RESOURCE_OFFSET|INVALID_RESOURCE_CURSOR|UNKNOWN_LEGAL_CORPUS_TOOL)/;
    const correctable = (event: (typeof corpusAudit)[number]) =>
      correctableCorpusRefusal.test(
        String(event.detail?.error ?? "")
      );
    // Poprawialna odmowa = DEGRADED, nie BLOCKED: HYBRID-VAL przed .docx odrzuca każde
    // zdarzenie BLOCKED sesji źródłowej, a bramka G36 takiej odmowy nie blokuje.
    for (const event of corpusAudit) {
      audit.record(
        event.tool === "read_legal_resource" || event.tool === "Read"
          ? "resource_read"
          : "tool_decision",
        event.target,
        event.decision === "ALLOW"
          ? "OK"
          : correctable(event)
            ? "DEGRADED"
            : "BLOCKED",
        {
          tool: event.tool,
          ...(event.detail ? event.detail : {})
        }
      );
    }

    const corpusBlocked = corpusAudit.some(
      (event) =>
        event.decision === "BLOCK" &&
        !correctable(event)
    );
    audit.record(
      "gate",
      "G36_LEGAL_CORPUS_RUNTIME",
      corpusBlocked ? "BLOCKED" : "OK",
      { toolEvents: corpusAudit.length }
    );

    const reportAudit =
      reportTools.auditEvents();
    for (const event of reportAudit) {
      audit.record(
        "tool_decision",
        event.target,
        event.decision === "ALLOW"
          ? "OK"
          : "BLOCKED",
        {
          tool: event.tool,
          ...(event.detail
            ? event.detail
            : {})
        }
      );
    }

    if (federationTools) {
      const federationAudit =
        federationEvents;
      for (
        const event
        of federationAudit
      ) {
        audit.record(
          "tool_decision",
          event.source
            ? "federated-legal:" +
              event.source
            : "federated-legal",
          // Niedostępne źródło = DEGRADED (jak bramka G40); odmowa polityki = BLOCKED.
          event.decision ===
            "ALLOW"
            ? "OK"
            : event.outcome ===
                "SOURCE_UNAVAILABLE"
              ? "DEGRADED"
              : "BLOCKED",
          {
            tool:
              event.tool,
            ...(event.detail
              ? event.detail
              : {})
          }
        );
      }
      audit.record(
        "gate",
        "G40_FEDERATED_LEGAL_RESEARCH",
        federationAudit.some(
          (event) =>
            event.decision ===
              "BLOCK"
        )
          ? "DEGRADED"
          : "OK",
        {
          toolEvents:
            federationAudit.length,
          verificationAuthority:
            "LEX_NATIVE_ONLY"
        }
      );
    }

    const workflowReads: DeterministicWorkflowReadReport =
      evaluateDeterministicWorkflowReads(
        execution.workflowPlan,
        corpusAudit,
        execution.events
      );
    const workflowResourcesBlocked =
      workflowReads.result === "BLOCKED";
    audit.record(
      "gate",
      "G39H_WORKFLOW_RESOURCE_READS",
      workflowResourcesBlocked ? "BLOCKED" : "OK",
      {
        workflow: workflowReads.workflow,
        required: workflowReads.required,
        observed: workflowReads.observed,
        missing: workflowReads.missing
      }
    );

    // Mandatory path, profile PEŁNY: the router's gate blocks (CN, REM, WYJ) must be
    // visible in the answer. One correcting round with the gate modules; what is
    // still missing after it degrades the answer (⛔ TRYB ZDEGRADOWANY).
    // The profile after the answer: a criminal domain the model read makes it PEŁNY.
    // Gate modules not yet in the context are loaded for the correcting round.
    const criminalAfter =
      pathFacts.criminal || [...(execution.domainSkills ?? []), execution.primarySkill].some((skill) => skill.startsWith("dr-03-"));
    const effectiveProfile: PathProfile = pathProfile({
      mode: request.modeDecision?.mode ?? request.mode,
      simple: request.matterComplexity?.level === "SIMPLE",
      criminal: criminalAfter,
      documentGeneration: pathFacts.documentGeneration,
      verification,
      analysis: legalTurn && analysisRequested(pathFacts.query)
    });
    if (mandatoryModel && legalTurn && effectiveProfile !== profile) {
      for (const resource of preloadForTurn(mandatoryModel, { ...pathFacts, criminal: criminalAfter, profile: effectiveProfile })) {
        if (contextResources.has(resource)) continue;
        const content = this.readCorpus(resource);
        if (!content) continue;
        contextResources.add(resource);
        audit.record("resource_read", resource, "OK", { detail: "runtime-preload;mandatory-path;escalated", profile: effectiveProfile });
        pathSections.push(`# MANDATORY PATH RESOURCE: ${resource}\n\n${forModel(resource, content)}`);
      }
      pathSections.push(mandatoryPathInstructions(mandatoryModel, effectiveProfile, [...contextResources]));
    }
    let modelOutput = execution.output;
    const corrections: AnswerCorrection[] = [];
    // A legal answer (router: "odpowiedź prawna"): it cites the law or a domain skill was read.
    const domainSkillRead = audit.events.some(
      (event) => event.type === "skill_read" && event.status === "OK" && event.target !== ROUTER_SKILL && event.target !== "prawo-polskie-v2"
    );
    const legalAnswer = (text: string) => legalTurn && (domainSkillRead || detectLegalReferences(text).length > 0 || caseSignaturesIn(text).length > 0);
    const correctionEligible = Boolean(
      mandatoryModel &&
      legalTurn &&
      !request.model.startsWith("local/") &&
      // Plain legal chat only: structured outputs and workflow checkpoints have their own contracts.
      !request.documentAstOutput &&
      !request.guideContext &&
      !request.processWorkflowContext &&
      !request.courtWorkflowContext &&
      !request.chronologyWorkflowContext &&
      !request.contractWorkflowContext &&
      !request.orderedCaseWorkflowContext &&
      // Questions to the user (missing facts) are not the legal answer the gates belong to.
      !waitsForUser(modelOutput) &&
      legalAnswer(modelOutput)
    );
    const missingGates = correctionEligible ? missingGateBlocks(mandatoryModel!, effectiveProfile, modelOutput) : [];
    // Supervised content (supervised-content.ts): the causal method on a causal question, the
    // case's timeline when the request concerns the course of events.
    const readResources = () =>
      new Set([...contextResources, ...audit.events.filter((event) => event.type === "resource_read" && event.status === "OK").map((event) => event.target)]);
    const supervisedFor = (text: string): SupervisedCheck[] =>
      supervisedChecks({
        query: pathFacts.query,
        answer: text,
        readResources: readResources(),
        ...(request.caseTimelineDates?.length ? { timelineDates: request.caseTimelineDates } : {})
      });
    // A correcting round over an API model: the main call's system prompt, tools and messages
    // (the provider reads them from its cache; the system prompt already holds every path
    // section) followed by the answer and the request, tools defined but not callable. Before,
    // each round sent its own ~65k-token prompt and wrote it to the cache again. Local models
    // and account clients keep the short prompt.
    const reusable = execution.modelPrompt && !request.model.startsWith("local/") && !request.model.startsWith("account/") ? execution.modelPrompt : null;
    const correctingRound = (answer: string, instruction: string, systemPrompt?: string): Partial<ProviderStreamParams> & Pick<ProviderStreamParams, "systemPrompt" | "messages"> =>
      reusable
        ? {
            ...reusable,
            ...(reusable.tools?.length ? { toolChoice: "none" as const } : {}),
            messages: [...reusable.messages, { role: "assistant" as const, content: answer }, { role: "user" as const, content: `${instruction}\n\n${CORRECTED_ANSWER_FORM}` }]
          }
        : {
            systemPrompt:
              systemPrompt ??
              [
                ...(placeholderKey ? [placeholderKey] : []),
                identityPrompt,
                ...(request.modeDecision ? [queryModePrompt(request.modeDecision)] : []),
                ...pathSections
              ].join("\n\n"),
            messages: [
              { role: "user" as const, content: protectedQuery },
              { role: "assistant" as const, content: answer },
              { role: "user" as const, content: `${instruction}\n\n${CORRECTED_ANSWER_FORM}` }
            ]
          };
    const supervisedMissing = correctionEligible ? supervisedFor(modelOutput).filter((check) => check.correction) : [];

    if (missingGates.length || supervisedMissing.length) {
      step(
        "MODEL",
        `ścieżka obowiązkowa: uzupełnienie ${[...missingGates.map((item) => item.block), ...supervisedMissing.map((check) => check.id)].join(", ")}`
      );
      try {
        const corrected = await this.providers.stream(request.provider, {
          model: request.model,
          ...correctingRound(modelOutput, [
                ...(missingGates.length ? [gateCorrectionPrompt(missingGates)] : []),
                ...(supervisedMissing.length
                  ? [
                      "Nadzór aplikacji nad treścią odpowiedzi — uzupełnij i zwróć PEŁNĄ poprawioną odpowiedź (nie opis zmian):",
                      ...supervisedMissing.map((check) => `- ${check.correction}`),
                      ...(missingGates.length ? [] : ["Nie dodawaj przepisów, sygnatur ani wartości liczbowych, których nie było w odpowiedzi; zachowaj bez zmian istniejące znaczniki ✅/🟨/⚠️."])
                    ]
                  : [])
              ].join("\n")),
          accountContinuity: "none",
          reasoning: "none"
        });
        const text = withoutCorrectionPreface(corrected.fullText).trim();
        const remaining = text ? missingGateBlocks(mandatoryModel!, effectiveProfile, text) : missingGates;
        const remainingSupervised = text ? supervisedFor(text).filter((check) => check.correction) : supervisedMissing;
        const accepted =
          Boolean(text) && remaining.length + remainingSupervised.length < missingGates.length + supervisedMissing.length;
        if (accepted) {
          corrections.push(
            answerCorrection(
              "MANDATORY_PATH",
              [...missingGates.map((item) => `brak bloku ${item.block}`), ...supervisedMissing.map((check) => check.correction!)],
              modelOutput,
              text
            )
          );
          modelOutput = text;
        }
        audit.record("gate", "MANDATORY_PATH_CORRECTION", accepted && remaining.length + remainingSupervised.length === 0 ? "OK" : "DEGRADED", {
          missing: [...missingGates.map((item) => item.block), ...supervisedMissing.map((check) => check.id)],
          remaining: accepted
            ? [...remaining.map((item) => item.block), ...remainingSupervised.map((check) => check.id)]
            : [...missingGates.map((item) => item.block), ...supervisedMissing.map((check) => check.id)],
          // The correction's own cost, apart from the turn's total.
          ...(corrected.usage ? { inputTokens: corrected.usage.inputTokens, outputTokens: corrected.usage.outputTokens } : {})
        });
      } catch (error) {
        audit.record("gate", "MANDATORY_PATH_CORRECTION", "DEGRADED", {
          missing: [...missingGates.map((item) => item.block), ...supervisedMissing.map((check) => check.id)],
          error: error instanceof Error ? error.message.slice(0, 200) : "CORRECTION_FAILED"
        });
      }
    }

    // A bare article whose number this turn verified in several acts ("art. 11": KC and PrUp):
    // the application cannot tell which is meant, so one correcting round asks the model to name
    // the act at those citations only. Bare articles with one verified act are completed by the
    // application (completeBareArticleActs); unverified ones are marked ⚠️, not asked about.
    const ambiguous = legalTurn && !request.documentAstOutput && !request.model.startsWith("local/") && !waitsForUser(modelOutput)
      ? ambiguousBareArticles(modelOutput, ledger)
      : [];
    if (ambiguous.length > 0) {
      step("MODEL", `nazwa aktu przy ${ambiguous.length} powołaniach: runda poprawcza`);
      const instruction = [
        "KONTROLA APLIKACJI — nazwa aktu: w odpowiedzi są powołania przepisów bez nazwy aktu, a ten sam numer artykułu zweryfikowano w tej turze w kilku aktach:",
        ...ambiguous.map((item) => `- ${item.claim} (wiersz ${item.line}): ${item.acts.join(" albo ")}`),
        "Przy każdym z tych powołań dopisz nazwę albo skrót właściwego aktu. Nie zmieniaj niczego innego (treści, układu, znaczników ✅/⚠️, ramek etapów). Zwróć PEŁNĄ odpowiedź."
      ].join("\n");
      try {
        const corrected = await this.providers.stream(request.provider, {
          model: request.model,
          ...correctingRound(modelOutput, instruction),
          accountContinuity: "none",
          reasoning: "none"
        });
        const text = corrected.fullText.trim();
        const remaining = text ? ambiguousBareArticles(text, ledger) : ambiguous;
        // The same answer with the acts named: about the same length, fewer ambiguous citations.
        // Nothing of the answer may go: the round only names acts (a removed paragraph, RD 121/26).
        const accepted = Boolean(text) && remaining.length < ambiguous.length && text.length >= modelOutput.length * 0.9 && text.length <= modelOutput.length * 1.2 && removedSentences(modelOutput, text).length === 0;
        if (accepted) {
          corrections.push(answerCorrection("ACT_NAME", ambiguous.map((item) => `${item.claim}: ${item.acts.join(" / ")}`), modelOutput, text));
          modelOutput = text;
        }
        audit.record("gate", "ACT_NAME_CORRECTION", accepted && remaining.length === 0 ? "OK" : "DEGRADED", {
          ambiguous: ambiguous.map((item) => `${item.claim} -> ${item.acts.join("|")}`),
          remaining: accepted ? remaining.map((item) => item.claim) : ambiguous.map((item) => item.claim)
        });
      } catch (error) {
        audit.record("gate", "ACT_NAME_CORRECTION", "DEGRADED", { error: error instanceof Error ? error.message.slice(0, 200) : "CORRECTION_FAILED" });
      }
    }

    // What the answer says a judgment or interpretation is about must come from the text read
    // from the source (0.1.27: II SAB/Po 175/26 presented as an AI-hallucination ruling).
    // 1) Semantic: the connected model, in a separate context with only the question, the
    //    answer's claim and the document, judges topic and claim; each verdict quotes the
    //    document and the application checks the quote.
    // 2) Lexical, for documents without a valid verdict: the user's topic words and quotations
    //    given to it are in its text.
    // One correcting round for both; what remains is shown to the user next to the answer.
    // An answer that only defers ("nie mogę jeszcze…, odpowiedź zostanie przygotowana po…")
    // without the substance or a question: one correcting round; what stays is no basis for a file.
    if (legalTurn && !waitsForUser(modelOutput) && emptyDeferral(modelOutput)) {
      step("MODEL", "odpowiedź bez treści i bez pytania: runda poprawcza");
      let text = "";
      try {
        const corrected = await this.providers.stream(request.provider, {
          model: request.model,
          ...correctingRound(modelOutput, NO_ANSWER_CORRECTION),
          accountContinuity: "none",
          reasoning: "none"
        });
        text = corrected.fullText.trim();
      } catch {
        text = "";
      }
      const fixed = Boolean(text) && !emptyDeferral(text);
      audit.record("gate", "ANSWER_SUBSTANCE", fixed ? "OK" : "DEGRADED", { corrected: fixed });
      if (fixed) {
        corrections.push(answerCorrection("NO_ANSWER", ["odpowiedź odroczona bez treści i bez pytania do użytkownika"], modelOutput, text));
        modelOutput = text;
      }
    }

    if (legalTurn && caseSourceTexts.length && !waitsForUser(modelOutput)) {
      const topic = judgedQuestion(protectedQuery);
      const correctionPrompt = [
        ...(placeholderKey ? [placeholderKey] : []),
        identityPrompt,
        ...(request.modeDecision ? [queryModePrompt(request.modeDecision)] : []),
        ...pathSections
      ].join("\n\n");
      const correct = async (instruction: string): Promise<string> => {
        try {
          const corrected = await this.providers.stream(request.provider, {
            model: request.model,
            ...correctingRound(modelOutput, instruction, correctionPrompt),
            accountContinuity: "none",
            reasoning: "none"
          });
          return corrected.fullText.trim();
        } catch {
          return "";
        }
      };
      const judge = async (answer: string) => {
        const documents = citedDocuments(answer, caseSourceTexts);
        if (!documents.length || request.model.startsWith("local/")) return null;
        try {
          const verdict = await this.providers.stream(request.provider, {
            model: request.model,
            systemPrompt: JUDGE_SYSTEM,
            messages: [{ role: "user", content: semanticJudgePrompt(topic, documents, { roles: true }) }],
            accountContinuity: "none",
            reasoning: "none"
          });
          return parseSemanticVerdicts(verdict.fullText, documents);
        } catch {
          return null;
        }
      };
      // The semantic verdict decides where there is one; the lexical check covers the documents
      // without a valid verdict (local model, judge failure, a quote not in the document). Lexically
      // a correct paraphrase can look like a missing word, so it does not override a verdict.
      const review = async (answer: string) => {
        const check = await judge(answer);
        const judged = new Set((check?.verdicts ?? []).map((item) => item.signature.replace(/\s+/g, " ")));
        return {
          check,
          semantic: check ? semanticProblems(check) : [],
          lexical: caseContentFindings(answer, caseSourceTexts, topic).filter((item) => !judged.has(item.signature)),
          courts: courtAttributionFindings(answer)
        };
      };
      const size = (state: Awaited<ReturnType<typeof review>>) =>
        state.semantic.length + state.lexical.flatMap((item) => item.missing).length + state.courts.length;
      const first = await review(modelOutput);
      let final = first;
      if (size(first)) {
        step("MODEL", `kontrola zgodności powołanych tekstów: ${[...first.semantic, ...first.lexical, ...first.courts].map((item) => item.signature).join(", ")}`);
        const text = await correct(
          [
            ...(first.semantic.length ? [semanticCorrectionPrompt(first.semantic)] : []),
            ...(first.lexical.length ? [caseContentCorrectionPrompt(first.lexical)] : []),
            ...(first.courts.length ? [courtCorrectionPrompt(first.courts)] : [])
          ].join("\n\n")
        );
        if (text) {
          const second = await review(text);
          if (size(second) < size(first)) {
            corrections.push(
              answerCorrection(
                "CASE_GROUNDING",
                [
                  ...first.semantic.map((item) => `${item.signature}: ${item.topic}/${item.claim}`),
                  ...first.lexical.map((item) => `${item.signature}: brak w tekście dokumentu: ${item.missing.join(", ")}`),
                  ...first.courts.map((item) => `${item.signature}: sąd ${item.named}, w źródle ${item.actual}`)
                ],
                modelOutput,
                text
              )
            );
            modelOutput = text;
            final = second;
          }
        }
      }
      if (first.check) {
        audit.record("gate", "CASE_SEMANTIC_CHECK", final.semantic.length ? "DEGRADED" : "OK", {
          verdicts: first.check.verdicts.map((item) => `${item.signature}: ${item.topic}/${item.claim}`),
          ...(first.check.rejected.length ? { rejectedQuotes: first.check.rejected } : {}),
          corrected: first.semantic.map((item) => item.signature),
          remaining: final.semantic.map((item) => `${item.signature}: ${item.topic}/${item.claim}`)
        });
      }
      if (first.lexical.length) {
        audit.record("gate", "CASE_CONTENT_GROUNDING", final.lexical.length ? "DEGRADED" : "OK", {
          findings: first.lexical.map((item) => `${item.signature}: ${item.missing.join(", ")}`),
          remaining: final.lexical.map((item) => `${item.signature}: ${item.missing.join(", ")}`)
        });
      }
      if (first.courts.length) {
        audit.record("gate", "CASE_COURT_ATTRIBUTION", final.courts.length ? "DEGRADED" : "OK", {
          findings: first.courts.map((item) => `${item.signature}: ${item.named}≠${item.actual}`),
          remaining: final.courts.map((item) => `${item.signature}: ${item.named}≠${item.actual}`)
        });
      }
      const lexical = final.lexical;
      const semantic: SemanticVerdict[] = final.semantic;

      const warnings = [
        ...(lexical.length ? [caseContentWarning(lexical)] : []),
        ...(semantic.length ? [semanticWarning(semantic.filter((item) => !lexical.some((finding) => finding.signature === item.signature)))] : []),
        ...(final.courts.length ? [courtWarning(final.courts)] : [])
      ].filter(Boolean);
      if (warnings.length) {
        // Before the model's closing disclaimer, which stays the last element.
        const parts = splitTrailingDisclaimer(modelOutput);
        modelOutput = parts.disclaimer
          ? `${parts.body.trimEnd()}\n\n${warnings.join("\n")}\n\n${parts.disclaimer}`
          : `${modelOutput.trimEnd()}\n\n${warnings.join("\n")}`;
      }
    }

    // The model's own ⚠️ at a statute does not stop the application from
    // verifying it: status comes from the registry only.
    // Asked for a widget, a model without show_widget (local) or one that did not call it
    // (ChatGPT, 2026-10-22) writes the widget's code in the answer: shown as a widget, out of
    // the text the gates mark (before, the markers landed inside the HTML).
    let answerWidgets: WidgetSpec[] = [];
    if (!widgetTools?.widgets().length && /widget|wizualizacj/iu.test(latestUserTurn(parseSkillSelectionEnvelope(request.query).query))) {
      const extracted = widgetsFromAnswer(modelOutput);
      if (extracted.widgets.length) {
        modelOutput = extracted.text;
        answerWidgets = extracted.widgets;
        step("MODEL", `widget z kodu w odpowiedzi modelu (${extracted.widgets.length})`);
      }
    }
    modelOutput = withOneClosingDisclaimer(modelOutput);
    // KROK 7: the model's closing disclaimer is the fixed text of shared/DISCLAIMER.md.
    // It is cut off before the gates and put back after them (the canonical text, or
    // the model's own when the application adds none).
    const modelDisclaimer =
      legalTurn && !request.documentAstOutput && !request.model.startsWith("local/")
        ? splitTrailingDisclaimer(modelOutput)
        : { body: modelOutput, disclaimer: null };
    if (modelDisclaimer.disclaimer) modelOutput = modelDisclaimer.body;
    // A document AST goes through the gates as lines, one per text node, and back to JSON at
    // the end (ast-text-lines.ts): the act, the quote and the markers of a provision are its own.
    const astLines = request.documentAstOutput ? astTextLines(modelOutput) : null;
    if (astLines) modelOutput = astLines.text;
    const releasedDraft = releaseModelUnverifiedMarkers(modelOutput);
    const automaticVerificationPlan =
      planAutomaticLegalVerification(
        // A document AST is one line of JSON: the act of a provision is read from its line, so
        // every block is a line of its own (RD 121/26: 9 of 14 provisions of the file were left
        // unverified, "art. 95n pkt 1" taken as KPK from the whole document).
        request.documentAstOutput && !astLines ? astBlockLines(releasedDraft.text) : releasedDraft.text,
        ledger,
        requestedHistoricalAsOf
      );
    let automaticVerificationExecuted = 0;

    if (
      automaticVerificationPlan.calls.length > 0 &&
      verificationTools
    ) {
      const results =
        await verificationTools.runTools(
          automaticVerificationPlan.calls
        );
      automaticVerificationExecuted =
        results.length;
    }

    // Model-written ✅ markers are claims, not verification: only the ledger
    // marker is shown, so a rewritten link or date cannot block the answer.
    const ledgerBackedOutput =
      stripUnbackedVerificationMarkers(
        // The KROK 3A trace is the application's (mandatoryPath.routingTrace), not the answer's.
        withoutModelRoutingTrace(releasedDraft.text),
        ledger
      );
    const automaticVerification =
      applyAutomaticVerificationMarkers(
        ledgerBackedOutput.text,
        ledger,
        requestedHistoricalAsOf
      );

    audit.record(
      "gate",
      "G39I_AUTO_POST_DRAFT_VERIFICATION",
      automaticVerificationPlan.calls.length > 0 &&
      !verificationTools
        ? "BLOCKED"
        : "OK",
      {
        planned:
          automaticVerificationPlan.calls.length,
        executed:
          automaticVerificationExecuted,
        insertedMarkers:
          automaticVerification.inserted,
        removedUnbackedMarkers:
          ledgerBackedOutput.removed,
        releasedModelUnverifiedMarkers:
          releasedDraft.released,
        skipped:
          automaticVerificationPlan.skipped
      }
    );

    if (verificationTools) {
      for (const toolEvent of verificationTools.auditEvents()) {
        audit.record(
          "tool_decision",
          toolEvent.tool,
          toolEvent.decision === "ALLOW" ? "OK" : "BLOCKED",
          {
            decision: toolEvent.decision,
            capability: toolEvent.capability ?? null,
            reason: toolEvent.reason ?? null
          }
        );
      }
    }

    // "art. 36a" with no act: written with the one act this turn verified that article (and its
    // unit) in, before any gate reads it; an article verified in several acts, or none, stays
    // as written. No model call (W3 and test 500: bare articles were half of the conflicts).
    const actCompletion = completeBareArticleActs(automaticVerification.text, ledger);
    if (actCompletion.completed.length > 0) {
      audit.record("gate", "BARE_ARTICLE_ACT_COMPLETION", "OK", {
        completed: actCompletion.completed.map((item) => `${item.claim} -> ${item.act}`)
      });
    }
    // The Dz.U. address of the text each act was read from, once per act, from the ledger.
    const journalAddresses = addVerifiedJournalAddresses(actCompletion.text, ledger);
    if (journalAddresses.added.length > 0) {
      audit.record("gate", "VERIFIED_JOURNAL_ADDRESSES", "OK", { added: journalAddresses.added });
    }
    const citedAnswer =
      processDocumentCitationMarkers(
        journalAddresses.text,
        citationSources,
        {
          otherTexts: [
            request.query,
            ...officialCaseLawTexts,
            ...leadCaseLawTexts,
            // "Tekst dokumentu: „W transakcjach handlowych…”" quoted art. 7 of the act read in this
            // turn (C12-011): the wording of a provision is checked by its own gates.
            ...ledger.all().map((record) => record.evidence ?? "").filter(Boolean)
          ]
        }
      );
    const { autoLinked, mismatched, unsourced } = citedAnswer.quoteFindings;
    if (autoLinked + mismatched + unsourced > 0) {
      audit.record(
        "gate",
        "DOCUMENT_QUOTE_FIDELITY",
        mismatched + unsourced > 0 ? "DEGRADED" : "OK",
        { autoLinked, mismatched, unsourced }
      );
    }
    // HARD GATE: an unverified statute or Dz.U. reference is shown only with
    // its [NIEWERYFIKOWANE] marker, placed at the claim itself.
    // Signatures an official database returned in this turn (sn.pl, CBOSA, the courts' portal,
    // TK, KIO, CURIA, ETPCz): real, though not verified in full; from nowhere stays blocking.
    for (const { signature } of signaturesIn(officialCaseLawTexts.join("\n"))) ledger.addRetrievedCase(signature);
    // Any court's "sygn. …" on such a page (a disciplinary court's own numbering the repertory
    // list does not know): the same anchor, never guessed from a format.
    for (const reference of detectLegalReferences(officialCaseLawTexts.join("\n"))) if (reference.kind === "case") ledger.addRetrievedCase(reference.claim);
    // Found only in SAOS, a web search or a legal portal (LEX, Legalis, a law firm, a blog): a
    // lead, shown ⚠️ until verified in the court's own database.
    for (const { signature } of signaturesIn(leadCaseLawTexts.join("\n"))) ledger.addCaseReference(signature);
    for (const reference of detectLegalReferences(leadCaseLawTexts.join("\n"))) if (reference.kind === "case") ledger.addCaseReference(reference.claim);
    // A signature the answer names that the case's own files hold (a judgment or a proceeding of
    // the case's documents, not read again in this turn: a file written from the conversation) is
    // "z materiałów sprawy", not a judgment to verify (RD 121/26 blocked VIII W 633/25 so).
    await registerCaseFileSignatures(citedAnswer.text, ledger, request.caseFiles ?? request.caseSignatureSearch);
    const preFinalization =
      new FinalizationGate().evaluate(
        citedAnswer.text,
        ledger
      );
    const markedAnswer =
      preFinalization.result === "BLOCKED"
        ? {
            ...citedAnswer,
            // Najpierw prawdziwe znaczniki z rejestru dla przepisów powtórzonych bez
            // znacznika (np. tabela porównawcza), potem ⚠️ dla niezweryfikowanych.
            text: addMissingVerificationMarkers(
              markUnverifiedReferences(
                citedAnswer.text,
                preFinalization,
                new Set(ledger.caseReferences()),
                new Set(ledger.retrievedCases())
              ),
              preFinalization,
              verifiedLedgerMarkers(ledger)
            )
          }
        : citedAnswer;
    // Końcowa kontrola spójności: jeden status źródła dla każdego przepisu w całej
    // odpowiedzi. Sprzeczność z rejestrem VERIFIED jest naprawiana według rejestru;
    // sprzeczność, której rejestr nie rozstrzyga, blokuje prezentację.
    const statusReconciliation =
      reconcileStatusMarkers(
        markedAnswer.text,
        ledger
      );
    // A conflict the registry does not settle: the provision is shown ⚠️ everywhere (a
    // draft with it marked), never ✅ in one place and ⚠️ in another, and never a blocked turn.
    const unifiedStatus = unifyConflictingProvisions(statusReconciliation.text, ledger);
    const reconciledAnswer =
      statusReconciliation.repaired > 0 || unifiedStatus.unified.length > 0
        ? {
            ...markedAnswer,
            text: unifiedStatus.text
          }
        : markedAnswer;
    // Uzgodnienie statusów mogło zdjąć lub przesunąć znaczniki: jeszcze dwie rundy całego
    // przebiegu (oznaczenie, uzgodnienie, ujednolicenie), zamiast blokować całą odpowiedź
    // z powodu jednego powołania. Samo oznaczenie bez uzgodnienia zostawiało w wierszu ✅ obok
    // ⚠️ i bramka spójności blokowała turę (zrzuty testu 500: 8 takich tur).
    let remarkedText = reconciledAnswer.text;
    for (let round = 0; round < 2; round += 1) {
      const check = new FinalizationGate().evaluate(remarkedText, ledger);
      if (check.result !== "BLOCKED") break;
      const marked = addMissingVerificationMarkers(
        markUnverifiedReferences(remarkedText, check, new Set(ledger.caseReferences()), new Set(ledger.retrievedCases())),
        check,
        verifiedLedgerMarkers(ledger)
      );
      const reconciled = reconcileStatusMarkers(marked, ledger);
      const unified = unifyConflictingProvisions(reconciled.text, ledger);
      const next = reconciled.repaired > 0 || unified.unified.length > 0 ? unified.text : marked;
      if (next === remarkedText) break;
      remarkedText = next;
    }
    remarkedText = qualifyCompleteVerificationClaims(remarkedText);
    const processedDocumentCitations =
      remarkedText === reconciledAnswer.text ? reconciledAnswer : { ...reconciledAnswer, text: remarkedText };
    const statusConsistency =
      evaluateStatusConsistency(
        processedDocumentCitations.text,
        ledger
      );
    const statusConsistencyBlocked =
      statusConsistency.result ===
        "BLOCKED";
    // Diagnostyka prób (LEX_DEBUG_FINALIZATION_DIR): etapy tekstu i rejestr weryfikacji tury.
    if (process.env.LEX_DEBUG_FINALIZATION_DIR?.trim()) {
      try {
        const dir = process.env.LEX_DEBUG_FINALIZATION_DIR.trim();
        fs.mkdirSync(dir, { recursive: true });
        fs.writeFileSync(
          path.join(dir, `${Date.now()}-${randomUUID()}.json`),
          JSON.stringify({ automatic: automaticVerification.text, cited: citedAnswer.text, pre: preFinalization, marked: markedAnswer.text, final: processedDocumentCitations.text, consistency: statusConsistency, ledger: ledger.all(), context: { caseFileNumbers: ledger.caseFileNumbers(), caseReferences: ledger.caseReferences(), retrievedCases: ledger.retrievedCases(), factAmounts: ledger.factAmountKeys() } }, null, 1)
        );
      } catch {
        // Diagnostyka nie wpływa na turę.
      }
    }
    audit.record(
      "gate",
      statusConsistency.gate,
      statusConsistencyBlocked
        ? "BLOCKED"
        : "OK",
      {
        repairedMarkers:
          statusReconciliation.repaired,
        unifiedUnverified:
          unifiedStatus.unified,
        provisions:
          statusConsistency.provisions.length,
        findings:
          statusConsistency.findings,
        orphanUnverifiedLines:
          statusConsistency.orphanUnverifiedLines
      }
    );
    audit.record(
      "gate",
      "LOCAL_DOCUMENT_DEEP_LINKS",
      "OK",
      {
        accepted: processedDocumentCitations.citations.length,
        rejected: processedDocumentCitations.rejectedMarkers,
        exactHighlights: processedDocumentCitations.citations.filter(
          (item) => item.highlightStart !== undefined && item.highlightEnd !== undefined
        ).length
      }
    );

    const workflowOutput =
      evaluateDeterministicWorkflowOutput(
        execution.workflowPlan,
        processedDocumentCitations.text,
        request.processWorkflowContext ||
        request.courtWorkflowContext ||
        request.orderedCaseWorkflowContext ||
        request.contractWorkflowContext ||
        request.chronologyWorkflowContext ||
        request.processRenderOnly ||
        execution.workflowPlan.executionSkill
          ? {
              checkpointTurn: true,
              ...(request.processRenderOnly ? { processRenderStage: request.processRenderOnly.stage } : {}),
              ...(request.processWorkflowContext
                ? {
                    processCheckpoint:
                      request
                        .processWorkflowContext
                        .checkpoint
                  }
                : {}),
              ...(request.courtWorkflowContext
                ? {
                    courtCheckpoint:
                      request
                        .courtWorkflowContext
                        .checkpoint
                  }
                : {}),
              ...(request.orderedCaseWorkflowContext
                ? {
                    orderedCheckpoint:
                      request
                        .orderedCaseWorkflowContext
                        .checkpoint
                  }
                : {})
            }
          : undefined
      );
    const workflowOutputBlocked =
      workflowOutput.result ===
        "BLOCKED";
    audit.record(
      "gate",
      "G39H_WORKFLOW_OUTPUT",
      workflowOutputBlocked
        ? "BLOCKED"
        : "OK",
      {
        workflow:
          workflowOutput.workflow,
        mode:
          workflowOutput.mode,
        required:
          workflowOutput.required,
        observed:
          workflowOutput.observed,
        missing:
          workflowOutput.missing,
        orderValid:
          workflowOutput.orderValid
      }
    );

    const guideOutput =
      request.guideContext
        ? evaluateGuideOutput(
            request.guideContext,
            processedDocumentCitations.text
          )
        : null;
    const guideOutputBlocked =
      guideOutput?.result ===
        "BLOCKED";
    audit.record(
      "gate",
      "G39I_GUIDE_OUTPUT",
      guideOutputBlocked
        ? "BLOCKED"
        : "OK",
      guideOutput
        ? {
            questionCount:
              guideOutput.questionCount,
            oneQuestionRuleActive:
              guideOutput
                .oneQuestionRuleActive,
            irreversibleWarningRequired:
              guideOutput
                .irreversibleWarningRequired,
            irreversibleWarningPresent:
              guideOutput
                .irreversibleWarningPresent,
            violations:
              guideOutput.violations
          }
        : {
            active: false
          }
    );

    const requiredReportKind:
      ReportBlueprintKind | null =
        execution.workflowPlan.id ===
          "CLIENT_REPORT_V1"
          ? "CLIENT_REPORT_V1"
          : execution.workflowPlan.id ===
              "SITUATION_REPORT_V1"
            ? "SITUATION_REPORT_V1"
            : null;
    const reportBlueprint =
      requiredReportKind
        ? reportTools.acceptedFor(
            requiredReportKind
          )
        : null;
    const reportBlueprintBlocked =
      requiredReportKind !== null &&
      reportBlueprint === null &&
      !reportQuestion;

    audit.record(
      "gate",
      "G39I_REPORT_BLUEPRINT",
      reportBlueprintBlocked
        ? "BLOCKED"
        : "OK",
      {
        required:
          requiredReportKind,
        accepted:
          reportBlueprint?.kind ??
          null,
        ...(reportQuestion ? { waitingForUser: true } : {}),
        toolEvents:
          reportAudit.length
      }
    );

    const blueprintText =
      reportBlueprint
        ? blueprintFinalizationText(processedDocumentCitations.text, reportBlueprint.blueprint, ledger)
        : null;
    // A value of the report's plan without a source is marked as in the chat (⚠️), so the report is
    // a draft with a warning instead of a blocked turn (live C09-062: a client report blocked for
    // "84 dni" and invoice sums; user request 2026-11-06: block only as the last resort).
    const blueprintCheck = blueprintText ? new FinalizationGate().evaluate(blueprintText, ledger) : null;
    const finalizationText =
      blueprintText && blueprintCheck?.result === "BLOCKED"
        ? addMissingVerificationMarkers(
            markUnverifiedReferences(blueprintText, blueprintCheck, new Set(ledger.caseReferences()), new Set(ledger.retrievedCases())),
            blueprintCheck,
            verifiedLedgerMarkers(ledger)
          )
        : blueprintText ?? processedDocumentCitations.text;

    step("VERIFY", "przepisy, orzeczenia i cytaty w odpowiedzi");
    const finalization = this.finalizer.finalize({
      text: finalizationText,
      ledger,
      audit,
      closeSession: false
    });

    const verificationRecords =
      ledger.all();
    const publicAuxiliarySources =
      reconcileAuxiliarySourcesWithVerification(
        auxiliarySources,
        verificationRecords
      );
    const gateI =
      evaluateGateIInvariants({
        events:
          execution.events,
        workflowReads,
        verificationRecords,
        finalization,
        outputValidation: {
          result:
            workflowOutputBlocked ||
            guideOutputBlocked ||
            reportBlueprintBlocked
              ? "BLOCKED"
              : "PASS",
          detail:
            [
              `workflow=${workflowOutput.result}`,
              `guide=${guideOutput?.result ?? "N/A"}`,
              `reportBlueprint=${reportBlueprintBlocked ? "BLOCKED" : "PASS"}`
            ].join(";")
        },
        documentCitations: {
          accepted:
            processedDocumentCitations
              .citations.length,
          rejected:
            processedDocumentCitations
              .rejectedMarkers,
          quotedWithoutExactHighlight:
            processedDocumentCitations
              .citations
              .filter(
                (citation) =>
                  Boolean(
                    citation.quote
                  ) &&
                  (
                    citation
                      .highlightStart ===
                      undefined ||
                    citation
                      .highlightEnd ===
                      undefined
                  )
              )
              .length
        }
      });
    const gateIBlocked =
      gateI.result ===
        "BLOCKED";

    const gateIContract =
      gateIWorkflowContract(
        execution.workflowPlan.id,
        execution.workflowPlan
          .executionSkill
      );

    const stateTransition:
      | "PASS"
      | "BLOCKED"
      | "NOT_APPLICABLE" =
      gateIContract.stateModel ===
        "DURABLE_CASE"
        ? (
            (
              execution.workflowPlan.id ===
                "PROCESS_PLEADING_V1" &&
              // The file of the pipeline's pleading: its state bound by the route (render-only).
              (request.processWorkflowContext || (request.processRenderOnly && request.documentAstOutput))
            ) ||
            (
              execution.workflowPlan.id ===
                "COURT_ANALYSIS_V1" &&
              request
                .courtWorkflowContext
            ) ||
            (
              execution.workflowPlan.id ===
                "CHRONOLOGY_V1" &&
              request
                .chronologyWorkflowContext
            ) ||
            (
              execution.workflowPlan.id ===
                "CONTRACT_ANALYSIS_V1" &&
              (request.contractWorkflowContext || (request.contractRenderOnly && request.documentAstOutput))
            ) ||
            (
              (
                execution.workflowPlan.id ===
                  "EVIDENCE_ANALYSIS_V1" ||
                execution.workflowPlan.id ===
                  "WITNESS_QUESTIONING_V1"
              ) &&
              request
                .orderedCaseWorkflowContext
            )
          )
          ? "PASS"
          : "BLOCKED"
        : gateIContract.stateModel ===
            "DURABLE_SESSION"
          ? (
              execution.workflowPlan.id ===
                "LEGAL_GUIDE_V1" &&
              request.guideContext
            )
            ? "PASS"
            : "BLOCKED"
          : "NOT_APPLICABLE";

    const gateIWorkflowContractReport =
      evaluateGateIWorkflowContract({
        contract:
          gateIContract,
        invariants:
          gateI,
        input:
          gateIInput,
        stateTransition
      });
    const gateIWorkflowContractBlocked =
      gateIWorkflowContractReport.result ===
        "BLOCKED";

    audit.record(
      "gate",
      gateIWorkflowContractReport.gate,
      gateIWorkflowContractBlocked
        ? "BLOCKED"
        : "OK",
      {
        workflow:
          gateIWorkflowContractReport.workflow,
        stateModel:
          gateIWorkflowContractReport.stateModel,
        commonInvariants:
          gateIWorkflowContractReport.commonInvariants,
        checks:
          gateIWorkflowContractReport.checks
      }
    );

    let gateITurn =
      createGateITurnState(
        execution.workflowPlan.id
      );
    const check = (
      id:
        GateIInvariantReport["checks"][number]["id"]
    ) =>
      gateI.checks.find(
        (item) =>
          item.id === id
      );

    if (
      check("ROUTER_FIRST")
        ?.result !== "PASS"
    ) {
      gateITurn =
        blockGateITurn(
          gateITurn,
          "ROUTER_FIRST"
        );
    } else {
      gateITurn =
        passGateITurnPhase(
          gateITurn,
          "ROUTER_PREFLIGHT",
          "prawny-router-v3 first"
        );

      const workflowPreflight =
        execution.events.find(
          (event) =>
            event.type ===
              "gate" &&
            event.target ===
              "G39H_WORKFLOW_PREFLIGHT"
        );
      if (
        workflowPreflight
          ?.status !== "OK"
      ) {
        gateITurn =
          blockGateITurn(
            gateITurn,
            "SKILL_PREFLIGHT"
          );
      } else {
        gateITurn =
          passGateITurnPhase(
            gateITurn,
            "SKILL_PREFLIGHT",
            execution.workflowPlan.id
          );

        if (
          corpusBlocked ||
          check("CORE_RESOURCES")
            ?.result !==
              "PASS" ||
          check("WORKFLOW_RESOURCES")
            ?.result !==
              "PASS"
        ) {
          gateITurn =
            blockGateITurn(
              gateITurn,
              "RESOURCE_READS"
            );
        } else {
          gateITurn =
            passGateITurnPhase(
              gateITurn,
              "RESOURCE_READS",
              `workflowReads=${workflowReads.observed.length}`
            );

          const providerComplete =
            execution.events.find(
              (event) =>
                event.type ===
                  "gate" &&
                event.target ===
                  "G39H_WORKFLOW_PROVIDER_COMPLETE"
            );
          if (
            providerComplete
              ?.status !== "OK"
          ) {
            gateITurn =
              blockGateITurn(
                gateITurn,
                "SEMANTIC_EXECUTION"
              );
          } else {
            gateITurn =
              passGateITurnPhase(
                gateITurn,
                "SEMANTIC_EXECUTION"
              );

            if (
              check("SOURCE_PROVENANCE")
                ?.result !==
                  "PASS" ||
              check("SOURCE_HIERARCHY")
                ?.result !==
                  "PASS" ||
              check("TEMPORAL_FRESHNESS")
                ?.result !==
                  "PASS"
            ) {
              gateITurn =
                blockGateITurn(
                  gateITurn,
                  "SOURCE_VERIFICATION"
                );
            } else {
              gateITurn =
                passGateITurnPhase(
                  gateITurn,
                  "SOURCE_VERIFICATION",
                  `records=${gateI.verifiedOrSupportedRecords}`
                );

              if (
                check("CITATION_LEDGER")
                  ?.result !==
                    "PASS" ||
                check("LEGAL_CITATIONS")
                  ?.result !==
                    "PASS" ||
                check("CASE_SIGNATURES")
                  ?.result !==
                    "PASS" ||
                check("DOCUMENT_CITATIONS")
                  ?.result !==
                    "PASS"
              ) {
                gateITurn =
                  blockGateITurn(
                    gateITurn,
                    "CITATION_VALIDATION"
                  );
              } else {
                gateITurn =
                  passGateITurnPhase(
                    gateITurn,
                    "CITATION_VALIDATION",
                    `references=${gateI.legalReferences};cases=${gateI.caseReferences}`
                  );

                if (
                  workflowOutputBlocked ||
                  guideOutputBlocked ||
                  reportBlueprintBlocked
                ) {
                  gateITurn =
                    blockGateITurn(
                      gateITurn,
                      "OUTPUT_VALIDATION"
                    );
                } else {
                  gateITurn =
                    passGateITurnPhase(
                      gateITurn,
                      "OUTPUT_VALIDATION"
                    );

                  if (
                    check("FINALIZATION")
                      ?.result !==
                        "PASS"
                  ) {
                    gateITurn =
                      blockGateITurn(
                        gateITurn,
                        "FINALIZATION"
                      );
                  } else {
                    gateITurn =
                      passGateITurnPhase(
                        gateITurn,
                        "FINALIZATION"
                      );
                  }
                }
              }
            }
          }
        }
      }
    }

    audit.record(
      "gate",
      "G39I_TURN_STATE",
      gateITurn.result ===
        "PASS"
        ? "OK"
        : "BLOCKED",
      {
        workflow:
          gateITurn.workflowId,
        phase:
          gateITurn.phase,
        result:
          gateITurn.result,
        events:
          gateITurn.events.length
      }
    );

    audit.record(
      "gate",
      gateI.gate,
      gateIBlocked
        ? "BLOCKED"
        : "OK",
      {
        checks:
          gateI.checks,
        verifiedOrSupportedRecords:
          gateI.verifiedOrSupportedRecords,
        legalReferences:
          gateI.legalReferences,
        caseReferences:
          gateI.caseReferences
      }
    );

    const workflowFinalizationBlocked =
      finalization.result !== "PASS" ||
      statusConsistencyBlocked ||
      corpusBlocked ||
      workflowResourcesBlocked ||
      workflowOutputBlocked ||
      guideOutputBlocked ||
      reportBlueprintBlocked ||
      gateIBlocked ||
      gateIWorkflowContractBlocked;

    const presentationCriticalGateIds =
      new Set([
        "ROUTER_FIRST",
        "CORE_RESOURCES",
        "ROUTER_REQUIRED_MODULES",
        "WORKFLOW_RESOURCES",
        "OUTPUT_CONTRACT"
      ] as const);
    const criticalGateIBlocked =
      gateI.checks.some(
        (item) =>
          presentationCriticalGateIds.has(
            item.id as
              | "ROUTER_FIRST"
              | "CORE_RESOURCES"
              | "ROUTER_REQUIRED_MODULES"
              | "WORKFLOW_RESOURCES"
              | "OUTPUT_CONTRACT"
          ) &&
          item.result === "BLOCKED"
      );
    const workflowContractExtensionBlocked =
      gateIWorkflowContractReport
        .checks
        .some(
          (item) =>
            item.result ===
              "BLOCKED"
        );
    const verificationDegraded =
      finalization.result !==
        "PASS" ||
      gateIBlocked ||
      gateITurn.result !==
        "PASS";

    // Blocking is the last resort (user request 2026-11-06): a gate the corrective rounds did not
    // settle is shown as a named warning over the answer; the answer itself is kept. Still blocked:
    // after marking, a case-law claim without evidence or a verification marker that does not match
    // its source; no skill corpus; a structured document (AST) the application must parse.
    const structuredOutput = Boolean(request.documentAstOutput);
    const softGateWarnings = [
      ...(statusConsistencyBlocked ? ["ten sam przepis ma w odpowiedzi różne oznaczenia weryfikacji — przyjmij ostrożniejsze (⚠️)"] : []),
      ...(workflowResourcesBlocked ? ["nie wszystkie materiały tego rodzaju pracy zostały wczytane"] : []),
      ...(workflowOutputBlocked ? ["odpowiedź może nie mieć wszystkich części wymaganych dla tego rodzaju pracy"] : []),
      ...(guideOutputBlocked ? ["przewodnik nie domknął kroku — odpowiedz na pytania z odpowiedzi"] : []),
      ...(reportBlueprintBlocked ? ["raport przygotowano bez planu struktury — może wymagać uporządkowania"] : []),
      ...(gateIWorkflowContractReport.checks.some((item) => item.subgate === "I-I_INPUT_COMPLETENESS" && item.result === "BLOCKED")
        ? ["wiadomość mówi o załączniku, którego nie ma w rozmowie — dołącz plik, żeby odpowiedź go uwzględniła"]
        : workflowContractExtensionBlocked
          ? ["nie wszystkie kontrole przebiegu pracy zostały spełnione"]
          : [])
    ];
    const presentationBlocked =
      finalization.result === "BLOCKED" ||
      corpusBlocked ||
      (structuredOutput && softGateWarnings.length > 0);
    audit.record(
      "gate",
      "G39H_WORKFLOW_FINALIZATION",
      workflowFinalizationBlocked ? "BLOCKED" : "OK",
      {
        workflow: execution.workflowPlan.id,
        finalization: finalization.result,
        statusConsistency: statusConsistency.result,
        corpusBlocked,
        workflowResourcesBlocked,
        workflowOutputBlocked,
        guideOutputBlocked,
        reportBlueprintBlocked
      }
    );

    // KROK 4: provisions verified in their current wording, checked again on the
    // event date from the question (separate ledger: answer markers stay as they are).
    const dates =
      mandatoryModel && legalTurn && this.verificationToolFactory && !requestedHistoricalAsOf
        ? eventDates(pathFacts.query, todayWarsaw())
        : [];
    const eventDateCheck = dates.length
      ? await checkProvisionsAtEventDates({
          records: ledger.all(),
          dates,
          runTools: (calls) => this.verificationToolFactory!(new VerificationLedger(), { localModel: false }).runTools(calls)
        })
      : undefined;
    if (eventDateCheck?.items.length) {
      audit.record("gate", "EVENT_DATE_CHECK", eventDateCheck.items.every((item) => item.result === "SAME") ? "OK" : "DEGRADED", {
        dates: eventDateCheck.dates,
        items: eventDateCheck.items.map((item) => `${item.claim}@${item.asOf}:${item.result}`)
      });
    }

    // KROK 7: the disclaimer from shared/DISCLAIMER.md is the last element of a
    // legal answer; the application adds it when the model did not end with it.
    const mode = request.modeDecision?.mode ?? request.mode;
    // Structured output (document AST, report blueprint) is parsed by the app: no text around it.
    const freeText = !request.documentAstOutput && !reportBlueprint;
    const disclaimerTexts =
      // The model's own closing disclaimer says the answer is legal content: the canonical text replaces it.
      (legalAnswer(processedDocumentCitations.text) || Boolean(modelDisclaimer.disclaimer)) && freeText && !request.model.startsWith("local/") ? parseDisclaimer(this.readCorpus("shared/DISCLAIMER.md") ?? "") : null;
    const disclaimed = disclaimerTexts
      ? (({ text, appended }) => ({ text: withOneClosingDisclaimer(text), appended }))(
          withDisclaimer(processedDocumentCitations.text, disclaimerTexts, { mode, pleading: pathFacts.documentGeneration })
        )
      : modelDisclaimer.disclaimer
        ? { text: `${processedDocumentCitations.text.trimEnd()}\n\n${modelDisclaimer.disclaimer}`, appended: false }
        : { text: processedDocumentCitations.text, appended: false };
    const disclaimerBy = modelDisclaimer.disclaimer ? "MODEL" : disclaimed.appended ? "APLIKACJA" : "MODEL";
    if (disclaimed.appended) audit.record("gate", "DISCLAIMER_LAST", "OK", { by: disclaimerBy, mode, canonical: true });

    // The register of the mandatory path, from what really happened in the turn.
    const evaluatedPath =
      mandatoryModel && legalTurn
        ? evaluateMandatoryPath(mandatoryModel, {
            ...pathFacts,
            criminal: criminalAfter,
            profile: effectiveProfile,
            contextResources,
            // Mechanical routing: the runtime routes, the model holds only the
            // router's semantic contract (not its text).
            ...(request.modelSelectsSkills
              ? {}
              : { executedByApp: new Map([[`${ROUTER_SKILL}/SKILL.md`, "routing wykonany przez aplikację (model ma kontrakt semantyczny routera)"]]) }),
            answer: processedDocumentCitations.text,
            ...(disclaimerTexts ? { disclaimerBy } : {}),
            records: ledger.all(),
            events: audit.events.map((event) => ({
              type: event.type,
              target: event.target,
              status: event.status,
              ...(event.detail ? { detail: event.detail } : {})
            })),
            loadedSkills: execution.loadedSkills ?? [],
            primarySkill: execution.primarySkill,
            finalization: finalization.result,
            federationTools: Boolean(federationTools),
            ...(eventDateCheck ? { eventDateCheck } : {}),
            supervised: supervisedFor(processedDocumentCitations.text)
          })
        : undefined;
    // KROK 3A written by the application from the audit.
    const trace = evaluatedPath
      ? routingTrace({
          mode,
          report: evaluatedPath,
          // AUTO with a recognised task type: PRIMARY is the router's executive skill.
          primarySkill: taskRoute ? taskRoute.primary : execution.primarySkill,
          loadedSkills: [...(execution.loadedSkills ?? []), ...(taskRoute ? [execution.primarySkill] : [])],
          events: audit.events.map((event) => ({ type: event.type, target: event.target, status: event.status })),
          routerVersion: String(this.registry.get(ROUTER_SKILL)?.frontmatter.version ?? "") || null,
          sharedRoot: `${path.basename(this.registry.root)}/shared`,
          duplicates: duplicateSkills([...this.registry.skills.keys()])
        })
      : null;
    const mandatoryPath = evaluatedPath && trace ? { ...evaluatedPath, routingTrace: trace.text } : evaluatedPath;
    // Router: a missing mandatory read or gate is declared, never silent.
    const degradedReasons = mandatoryPath
      ? [
          ...(trace && !trace.primaryRead ? ["router niewczytany (PRIMARY)"] : []),
          ...(unreadableResources.length ? [`nie wczytano: ${unreadableResources.join(", ")}`] : []),
          ...(mandatoryPath.degraded
            ? [`brak obowiązkowego kroku: ${mandatoryPath.steps.filter((item) => item.requirement === "CORE" && item.layer === "ROUTER" && item.status === "MISSING").map((item) => item.id).join(", ")}`]
            : [])
        ]
      : [];
    // The user reads what to watch for; the gate names and step ids stay in the audit.
    const userWarnings = [
      ...(degradedReasons.length && legalAnswer(processedDocumentCitations.text) ? ["nie wszystkie kroki kontroli zostały wykonane — sprawdź kluczowe przepisy przed użyciem odpowiedzi"] : []),
      ...(structuredOutput ? [] : softGateWarnings)
    ];
    const presentedText = astLines
      ? astLines.restore(disclaimed.text)
      : userWarnings.length && freeText
        ? `⚠️ Uwaga: ${userWarnings.join("; ")}.\n\n${disclaimed.text}`
        : disclaimed.text;
    if (softGateWarnings.length && !structuredOutput) {
      audit.record("gate", "SOFT_GATE_WARNINGS", "DEGRADED", { warnings: softGateWarnings });
    }
    if (mandatoryPath) {
      audit.record("gate", "MANDATORY_PATH", mandatoryPath.complete ? "OK" : "DEGRADED", {
        profile: mandatoryPath.profile,
        missing: mandatoryPath.missing
      });
    }

    const safeToPresent =
      !presentationBlocked;
    audit.record(
      "gate",
      "G15_SAFE_SESSION_EXECUTION",
      presentationBlocked
        ? "BLOCKED"
        : verificationDegraded
          ? "DEGRADED"
          : "OK",
      {
        finalization:
          finalization.result,
        verificationDegraded,
        criticalGateIBlocked,
        workflowContractExtensionBlocked
      }
    );
    audit.close(
      presentationBlocked
        ? "BLOCKED"
        : verificationDegraded
          ? "DEGRADED"
          : "OK",
      {
        finalization:
          finalization.result,
        verificationDegraded
      }
    );

    const completeness = audit.validateCompletion({
      requireVerification: finalization.references.length > 0,
      requireToolActivity:
        finalization.references.length > 0 && Boolean(verificationTools),
      requireDeterministicWorkflow: true
    });
    const blockedReferences: PublicBlockedReference[] = finalization.findings
      .filter((finding) => finding.status !== "VERIFIED")
      .map((finding): PublicBlockedReference => ({
        claim: finding.reference.claim,
        kind: finding.reference.kind,
        line: finding.reference.line,
        status: finding.status
      }))
      .concat(
        statusConsistency.findings.flatMap((finding) =>
          finding.lines.map((line) => ({
            claim: finding.key,
            kind: "statute" as const,
            line,
            status: finding.code
          }))
        )
      )
      // Znaczniki orzeczeń bez dowodu (zmyślone albo cytat zmieniony po weryfikacji).
      .concat(
        [...finalization.caseQuoteFindings.filter((finding) => finding.status !== "VERIFIED"),
          ...finalization.caseSupportFindings.filter((finding) => finding.status !== "SUPPORTED")]
          .map((finding) => ({
            claim: finding.record?.caseSignature ?? `znacznik orzeczenia ${finding.evidenceHash}`,
            kind: "case" as const,
            line: finding.line,
            status: finding.status
          }))
      );

    step("RESTORE", "symbole zastępcze → dane z lokalnego klucza");
    // Every restored value is reported so the UI can mark it for review.
    const restoredAnswer = restoreWithReport(
      presentedText,
      chatPrivacyVault
    );
    // Next step of the pipeline: after the AUTO entry skill, or after the final
    // result of the mechanical workflow.
    const nextContext = { question: pathFacts.query, materials: routingMaterials, answer: restoredAnswer.text };
    // A stateful workflow keeps the stage the request itself names ("dowody w pozwie"
    // -> pisma-procesowe-v3) when the router's entry is the workflow's own skill.
    const workflowSkill = execution.workflowPlan.executionSkill;
    // The options after the result (generate the document / a further analysis): the user
    // chooses; the first one is kept as the single "next stage" of older clients.
    // The result is itself a document of its skill (a pleading; a contract redacted, drafted
    // or supplemented): "Generuj dokument" makes its file at any step, through that pipeline.
    // Only inside the running pipeline: before it starts the server refuses the file, the
    // request came back to the chat and the same button followed every answer (a loop); the
    // chat offers the pipeline start instead (pleadingPipelineNeeded).
    // A pleading: once its pipeline keeps a draft (the file renders that draft). A contract:
    // once its text is complete (AU-GENSHARED, then AU-HYBRID); each checkpoint is one turn,
    // so an earlier button would only move one step and come back with every answer. After
    // AU-STRIP the file is made on its own.
    const ownDocumentSkill = (skill: string | null | undefined) =>
      (skill === "pisma-procesowe-v3" && request.processWorkflowContext?.draft !== undefined) ||
      (skill === "analizator-umow-v1" &&
        request.contractWorkflowContext !== undefined &&
        request.contractWorkflowContext.mode !== "ANALYSIS" &&
        (request.contractWorkflowContext.checkpoint === "AU-GENSHARED" || request.contractWorkflowContext.checkpoint === "AU-HYBRID"));
    const nextFrom =
      taskRoute
        ? { skill: taskRoute.primary, then: taskRoute.then }
        : workflowSkill && (workflowOutput.mode.endsWith("_FINAL") || ownDocumentSkill(workflowSkill))
          ? { skill: workflowSkill, then: workflowOutput.mode.endsWith("_FINAL") ? this.statefulNextStage(pathFacts.query, recognisedDocuments, workflowSkill) : null }
          : null;
    const choices = nextFrom
      ? nextChoices(nextFrom.skill, nextFrom.then, this.skillCombinations(), nextContext, {
          ownDocument: ownDocumentSkill(nextFrom.skill),
          // The pleading's step register: what the file rests on (done, skipped and why, open).
          ...(nextFrom.skill === "pisma-procesowe-v3" && request.processWorkflowContext?.register
            ? { steps: stepSummary(request.processWorkflowContext.register) }
            : {})
        })
      : [];
    // An answer without substance (deferred, no question) is no basis for a file: no "Generuj dokument".
    const deferred = emptyDeferral(restoredAnswer.text);
    const offered = deferred ? choices.filter((choice) => choice.kind !== "DOCUMENT") : choices;
    const legacy = nextFrom ? pipelineNext(nextFrom.skill, nextFrom.then, this.skillCombinations(), nextContext) : null;
    const legacyNext = legacy && deferred && /^pisma-/u.test(legacy.skill) ? null : legacy;
    // An answer that still only announces a step (a verification to be done): a visible
    // "Kontynuuj" instead of nothing, so the user does not wait for what will not come.
    const resumeSkill = nextFrom?.skill ?? taskRoute?.primary ?? execution.workflowPlan.executionSkill ?? request.primarySkill;
    const choicesShown: NextChoice[] = deferred
      ? [{ skill: resumeSkill, kind: "CONTINUE", reason: "odpowiedź zapowiada krok, którego nie wykonała" }, ...offered]
      : offered;
    // A switch the answer offers (Test B reduction, M7 escalation) is the choice already.
    const switchOffered = workflowOutput.mode === "REDUCTION_OFFERED" || workflowOutput.mode === "ESCALATION_REQUIRED";
    // The mechanical turn's request for another skill (not an escalation, which is the offer below).
    const mechanicalChoice: NextChoice | null =
      mechanicalTask && !appEscalation && !switchOffered && !choicesShown.some((choice) => choice.skill === mechanicalTask!.primary)
        ? { skill: mechanicalTask.primary, kind: /^pisma-/u.test(mechanicalTask.primary) ? "DOCUMENT" : "ANALYSIS", reason: `rozpoznanie aplikacji: ${mechanicalTask.reason}` }
        : null;
    // Several executive skills pinned, one workflow per turn: the others are not dropped
    // silently but offered as the next stage (chronologia-sprawy-v1 next to a pleading).
    const pinnedLater: NextChoice[] = mechanicalTurn(request) && !switchOffered
      ? parseSkillSelectionEnvelope(request.query)
          .manualSkills.filter((name) => !name.startsWith("dr-") && name !== execution.workflowPlan.executionSkill && this.registry.get(name))
          // Both letter skills pinned: the stricter pleading workflow controls (no offer of the simple one).
          .filter((name) => !(name === "pisma-proste-v2" && execution.workflowPlan.executionSkill === "pisma-procesowe-v3"))
          .filter((name) => name !== mechanicalChoice?.skill && !choicesShown.some((choice) => choice.skill === name))
          .map((name) => ({ skill: name, kind: /^pisma-/u.test(name) ? ("DOCUMENT" as const) : ("ANALYSIS" as const), reason: "skill przypięty przez użytkownika, nie wykonany w tej turze" }))
      : [];
    const shown = [...(mechanicalChoice ? [mechanicalChoice] : []), ...choicesShown, ...pinnedLater];
    const next = shown.length
      ? { skill: shown[0]!.skill, reason: shown[0]!.reason, choices: shown }
      : legacyNext;
    // A step that asks the user (WAIT_FOR_USER_MARKER): flagged; the marker stays for the chat.
    // Escalation / reduction between the letter skills: an offer to the user, nothing closed.
    const skillSwitch =
      (workflowOutput.mode === "ESCALATION_REQUIRED"
        ? escalationOffer(restoredAnswer.text)
        : workflowOutput.mode === "REDUCTION_OFFERED"
          ? reductionOffer(restoredAnswer.text)
          : null) ??
      appEscalation ??
      // The same offer asked outside the simple-letter plan (an automatic turn, live C12-027):
      // a question to switch, not a letter to save as a file; the chat offers the switch.
      (!request.processWorkflowContext && execution.workflowPlan.id !== "PROCESS_PLEADING_V1" ? escalationOffer(restoredAnswer.text) : null);
    // A checkpoint's report followed by the marker without a question or request after it
    // (the skill's "STOP, czekaj na użytkownika") is a report to confirm: otherwise the
    // checkpoint never reached confirmation and the chain asked for it again (E2E: 18 turns
    // on CP-1a). A question or a request ("Podaj…") still waits for the user's reply.
    const activeCheckpoint =
      request.processWorkflowContext?.checkpoint ??
      request.contractWorkflowContext?.checkpoint ??
      request.orderedCaseWorkflowContext?.checkpoint ??
      request.chronologyWorkflowContext?.checkpoint ??
      request.courtWorkflowContext?.checkpoint;
    const waitingForUser =
      (waitsForUser(restoredAnswer.text) && !reportOnly(restoredAnswer.text, activeCheckpoint)) ||
      frameHeld(restoredAnswer.text, activeCheckpoint) ||
      skillSwitch !== null;
    // A letter's addressee court: from court_for_address or the case's court (its regional and
    // appeal court too: an appeal goes through the district court), never from the model alone.
    const letterSkill = /^pisma-/u.test(taskRoute?.primary ?? execution.primarySkill ?? "") || /===\s*PISMO\s*===|^@TYTUL:/mu.test(restoredAnswer.text);
    const addressee = letterSkill ? addresseeCourt(restoredAnswer.text) : null;
    const known = new Set(courtTools?.courts() ?? []);
    if (request.caseCourt) {
      known.add(request.caseCourt.nazwa);
      const district = regionalCourt(request.caseCourt.nazwa)?.so ?? request.caseCourt.nazwa;
      known.add(district);
      const appeal = districtCourt(district)?.sa;
      if (appeal) known.add(appeal);
    }
    const courtCheck = addressee && !known.has(addressee) ? { unverified: [addressee] } : null;
    if (courtCheck) {
      restoredAnswer.text += `\n\n[SĄD DO SPRAWDZENIA: „${addressee}” nie pochodzi z ustalenia aplikacji (court_for_address) ani z akt sprawy. Sprawdź właściwość dla adresu strony.]`;
    }
    const response: SessionExecutionResponse = {
      sessionId: audit.sessionId,
      status: safeToPresent ? "DRAFT_PRESENTABLE" : "BLOCKED",
      ...(next && safeToPresent ? { pipelineNext: next } : {}),
      // The application's own escalation stands even when the answer was blocked (a simple
      // letter written for a pleading): the user still gets the switch to pisma-procesowe-v3.
      ...(appEscalation && !safeToPresent ? { skillSwitch: appEscalation } : {}),
      ...(taskRoute ? { taskSkill: taskRoute.primary } : {}),
      ...(courtTools?.courts().length ? { courtsFound: courtTools.courts() } : {}),
      ...(courtCheck ? { courtCheck } : {}),
      ...(taskRoute?.modules?.some((module) => /MOD-REDAKCJA/u.test(module)) ? { taskMode: "REDACTION" as const } : {}),
      ...(mandatoryPath ? { mandatoryPath } : {}),
      ...(request.modeDecision ? { modeDecision: request.modeDecision } : {}),
      provider: request.provider,
      model: request.model,
      modelRouting: {
        primary: {
          provider:
            request.provider,
          model:
            request.model
        }
      },
      primarySkill: execution.primarySkill,
      loadedSkills: execution.loadedSkills,
      executionSkills: execution.executionSkills,
      domainSkills: execution.domainSkills,
      ...(safeToPresent
        ? {
            answer:
              restoredAnswer.text,
            ...(waitingForUser ? { waitingForUser: true } : {}),
            ...(skillSwitch ? { skillSwitch } : {}),
            ...(restoredAnswer.restorations.length > 0
              ? { restorations: restoredAnswer.restorations }
              : {}),
            ...(restoredAnswer.unresolved.length > 0
              ? { unresolvedTokens: restoredAnswer.unresolved }
              : {}),
            documentCitations: processedDocumentCitations.citations,
            ...(reportBlueprint
              ? {
                  reportBlueprint
                }
              : {})
          }
        : {}),
      finalization: finalization.result,
      blockedReferences,
      verification: {
        records: verificationRecords.length,
        verified: verificationRecords.filter((record) => record.status === "VERIFIED").length,
        supported: verificationRecords.filter((record) => record.status === "SUPPORTED").length,
        unverified: verificationRecords.filter((record) => record.status === "UNVERIFIED").length
      },
      evidence: publicEvidenceBundle(verificationRecords, restoredAnswer.text),
      ...(publicAuxiliarySources.length > 0
        ? {
            auxiliarySources:
              publicAuxiliarySources
          }
        : {}),
      ...(snVerificationRequired
        ? { sourceVerification: { source: "sn" as const, url: "https://www.sn.pl/pl/wyszukiwarka-orzeczen" } }
        : {}),
      ...((widgetTools?.widgets().length ?? 0) + answerWidgets.length > 0
        ? { widgets: [...(widgetTools?.widgets() ?? []), ...answerWidgets] }
        : {}),
      ...(() => {
        // Pages of the case's documents the model read this turn (sent chunks in full, and
        // read_case_file): a document read in part is reported as unfinished work.
        const coverage = documentCoverage([
          ...attachments
            .filter((attachment) => attachment.sourceScope !== "FIRM_TEMPLATE" && attachment.sourceScope !== "FIRM_KNOWLEDGE")
            .map((attachment) => ({
              documentId: attachment.documentId,
              ...(attachment.title ? { title: attachment.title } : {}),
              ...(attachment.totalPages ? { totalPages: attachment.totalPages } : {}),
              chunks: attachment.chunks.filter((chunk) => chunk.representation !== "EXTRACTIVE_DIGEST")
            })),
          ...(caseFileTools?.readChunks() ?? [])
        ]);
        // An analysis of the documents (asked for, or by an analysing skill) is unfinished while
        // pages are unread; a lookup ("jaki termin w umowie?") reads what it needs.
        const analysing =
          ANALYSIS_INTENT.test(pathFacts.query) ||
          COVERAGE_SKILLS.has(taskRoute?.primary ?? execution.workflowPlan.executionSkill ?? "");
        return coverage.length ? { documentCoverage: coverage, ...(analysing ? { documentAnalysis: true } : {}) } : {};
      })(),
      // Shown with the user's data restored, as the answer is.
      ...(corrections.length
        ? {
            corrections: corrections.map((item) => ({
              round: item.round,
              findings: item.findings.map((text) => restoreWithReport(text, chatPrivacyVault).text),
              removed: item.removed.map((text) => restoreWithReport(text, chatPrivacyVault).text)
            }))
          }
        : {}),
      context: {
        ...contextSelection.report,
        ...(() => {
          const budget = decodePromptBudget(
            String([...execution.events].reverse().find((event) => event.target === "PROMPT_BUDGET")?.detail ?? "")
          );
          return budget ? { instructionChars: budget.chars, instructionSections: budget.sections } : {};
        })()
      },
      audit: {
        result: completeness.result,
        eventCount: completeness.eventCount,
        closed: audit.isClosed,
        missing: [...completeness.missing],
        violations: [...completeness.violations],
        blockedEvents: audit.events
          .filter((event) => event.status === "BLOCKED")
          .slice(0, 12)
          .map((event) => {
            const code = [event.detail?.error, event.detail?.reason, event.detail?.decision]
              .find((value) => typeof value === "string" && value.trim());
            return `${event.type}: ${event.target.slice(0, 120)}${code ? ` — ${String(code).slice(0, 160)}` : ""}`;
          })
      },
      workflow: {
        id: execution.workflowPlan.id,
        result:
          workflowResourcesBlocked ||
          workflowOutputBlocked ||
          guideOutputBlocked ||
          reportBlueprintBlocked ||
          finalization.result !== "PASS" ||
          gateIBlocked
            ? "BLOCKED"
            : "PASS",
        requiredResources: workflowReads.required,
        missingResources: workflowReads.missing,
        ...(!workflowResourcesBlocked &&
        !workflowOutputBlocked &&
        !guideOutputBlocked &&
        !reportBlueprintBlocked &&
        finalization.result === "DEGRADED" &&
        gateI.checks.every((item) => item.result === "PASS" || MARKED_DRAFT_CHECKS.has(item.id))
          ? { markedDraftOnly: true }
          : {})
      },
      gateI,
      gateIWorkflowContract:
        gateIWorkflowContractReport,
      gateITurn
    };

    Object.defineProperty(
      response,
      SESSION_EXECUTION_INTERNAL,
      {
        value: {
          verificationRecords: verificationRecords.map((record) => ({ ...record })),
          caseFileNumbers: ledger.caseFileNumbers(),
          caseReferences: ledger.caseReferences(),
          factAmounts: ledger.factAmountKeys(),
          auditEvents: audit.events.map((event) => ({
            ...event,
            ...(event.detail ? { detail: { ...event.detail } } : {})
          })),
          // Own-key documents by prefix (D01 = [0]); shared-key ones have none.
          documentAliasDocumentIds:
            aliasRegistry.documentIds()
        } satisfies SessionExecutionInternalState,
        enumerable: false,
        configurable: false,
        writable: false
      }
    );

    return response;
  }
}

/**
 * A local model writes the skill's closing note and the shared disclaimer one after the other
 * ("⚖️ To wyjaśnienie…", "⚖️ Ważna informacja: …"): the last one, the full disclaimer, stays.
 * A "⚖️" block runs to a blank line or the next "⚖️" line.
 */
export function withOneClosingDisclaimer(text: string): string {
  const lines = text.split("\n");
  const blocks: Array<[number, number]> = [];
  for (let index = 0; index < lines.length; index += 1) {
    if (!/^\s*⚖️/u.test(lines[index]!)) continue;
    let end = index + 1;
    while (end < lines.length && lines[end]!.trim() && !/^\s*⚖️/u.test(lines[end]!)) end += 1;
    blocks.push([index, end]);
    index = end - 1;
  }
  if (blocks.length < 2) return text;
  const dropped = new Set(blocks.slice(0, -1).flatMap(([from, to]) => Array.from({ length: to - from }, (_, offset) => from + offset)));
  return lines.filter((_, index) => !dropped.has(index)).join("\n");
}
