import { personalDataIn } from "./tool-broker-policy.js";
import { LegalSourceFallbackStore, withSourceFallback } from "./legal-source-fallback.js";
import { courtOfSignature, misroutedSignature } from "./court-of-signature.js";
import {
  Client
} from "@modelcontextprotocol/sdk/client/index.js";
import {
  StdioClientTransport
} from "@modelcontextprotocol/sdk/client/stdio.js";
import type {
  NormalizedToolCall,
  NormalizedToolResult,
  NormalizedToolSchema
} from "./providers/types.js";
import {
  assessLegalSourceCandidate,
  classifyKnownLegalSourceUrl,
  federatedSourcePolicy
} from "./legal-source-policy.js";
import {
  AuxiliarySourceFetchError,
  SafeAuxiliarySourceFetcher
} from "./auxiliary-source-fetcher.js";
import {
  LEX_MCP_CATALOG,
  LEX_MCP_SERVER_IDS,
  type LexMcpConnectorStore,
  type LexMcpServerId
} from "./lex-mcp-connectors.js";
import {
  PublicWebSearch,
  WebSearchError,
  assertPublicWebSearchQuery,
  classifyWebSearchHits,
  webSearchLeads,
  type WebSearchProvider
} from "./web-search.js";

// Konektory MCP Lex Machina (audyt-systemu-v4/mcp-servers, dist/lex-mcp.mjs) zastępują
// agregator prawo-pl-mcp i flotę @matematicsolutions/*. Które serwery działają, decyduje
// instalator w Ustawieniach → Konektory MCP (LexMcpConnectorStore).
const CONNECTOR_PACKAGE =
  "lex-mcp.mjs (audyt-systemu-v4/mcp-servers)";

const SOURCE_IDS =
  LEX_MCP_SERVER_IDS;

const SOURCE_ENUM = [
  ...SOURCE_IDS
];

type SourceId =
  LexMcpServerId;

type NativeRequest = {
  tool: string;
  args: Record<string, unknown>;
};

type SearchInput = {
  query?: string;
  dateFrom?: string;
  dateTo?: string;
  page?: number;
  limit?: number;
};

function eliOfPublication(query: string): string | null {
  const text = query.trim();
  const eli = /^(DU|MP)\/(\d{4})\/(\d{1,5})$/iu.exec(text);
  if (eli) return `${eli[1]!.toUpperCase()}/${eli[2]}/${eli[3]}`;
  const publication = /^(Dz\.?\s*U\.?|M\.?\s*P\.?)\s*(?:z\s*)?(\d{4})\s*(?:r\.?)?\s*,?\s*(?:nr\s*\d{1,4}\s*,?\s*)?poz\.?\s*(\d{1,5})$/iu.exec(text);
  return publication ? `${/^M/iu.test(publication[1]!) ? "MP" : "DU"}/${publication[2]}/${publication[3]}` : null;
}

// Ujednolicone search/get → natywne narzędzie serwera lex-*. Źródło bez odpowiednika
// (np. get w SAOS) mapuje się na najbliższe narzędzie odczytu; resztę daje call_federated_legal_source.
export const NATIVE_SEARCH: Record<
  SourceId,
  (input: SearchInput) => NativeRequest
> = {
  // "Dz.U. 1964 nr 16 poz. 93", "Dz. U. z 2023 r. poz. 1610", "DU/1964/93": the ELI read; else a title.
  isap: (input) => {
    const eli = eliOfPublication(input.query ?? "");
    return eli ? { tool: "isap_lookup", args: { eli } } : { tool: "isap_lookup", args: { query: input.query } };
  },
  // A CELEX of an act (32016R0679) is looked up in Cellar; a CJEU case number, ECLI or case-law
  // CELEX (6…) goes to the case-law tool by that key; anything else is a title phrase. Before,
  // every query went to eurlex_tsue as a phrase and an act's CELEX came back NOT_FOUND.
  eurlex: (input) => {
    const query = input.query?.trim() ?? "";
    if (/^[0-9CE]\d{4}[A-Z]{1,2}[0-9A-Z()_.-]{1,20}$/u.test(query) && !query.startsWith("6")) return { tool: "eurlex_lookup", args: { celex: query } };
    if (/^6\d{4}[A-Z]{2}\d{4}$/u.test(query)) return { tool: "eurlex_tsue", args: { celex: query, limit: input.limit } };
    if (/^ECLI:EU:/iu.test(query)) return { tool: "eurlex_tsue", args: { ecli: query.toUpperCase(), limit: input.limit } };
    const caseNumber = /^(?:sprawa\s+)?([CTF])\s*-\s*(\d{1,4})\s*\/\s*(\d{2})$/iu.exec(query);
    if (caseNumber) return { tool: "eurlex_tsue", args: { sygnatura: `${caseNumber[1]!.toUpperCase()}-${caseNumber[2]}/${caseNumber[3]}`, limit: input.limit } };
    return { tool: "eurlex_tsue", args: { fraza: input.query, dataOd: input.dateFrom, limit: input.limit } };
  },
  // A case number is checked as such; as a phrase it matched unrelated rulings.
  saos: (input) =>
    input.query && courtOfSignature(input.query)
      ? { tool: "saos_search", args: { sygnatura: input.query.trim().replace(/\s+/gu, " "), pageSize: input.limit } }
      : { tool: "saos_search", args: { fraza: input.query, dataOd: input.dateFrom, dataDo: input.dateTo, pageSize: input.limit } },
  cbosa: (input) => ({ tool: "cbosa_szukaj", args: { fraza: input.query, odDaty: input.dateFrom, doDaty: input.dateTo, strona: input.page } }),
  // A signature goes to the signature check; anything else to the sn.pl search form (text of the decision).
  sn: (input) =>
    input.query && courtOfSignature(input.query) === "SN"
      ? { tool: "sn_sprawdz_sygnature", args: { sygnatura: input.query } }
      : { tool: "sn_szukaj", args: { tresc: input.query, dataOd: input.dateFrom, dataDo: input.dateTo, strona: input.page } },
  // The portal searches by signature or phrase only (no dates).
  sp: (input) =>
    input.query && courtOfSignature(input.query) === "POWSZECHNY"
      ? { tool: "sp_sprawdz_sygnature", args: { sygnatura: input.query } }
      : { tool: "sp_szukaj", args: { fraza: input.query } },
  tk: (input) => ({ tool: "tk_sprawdz_sygnature", args: { sygnatura: input.query } }),
  // An application number (43447/19) is checked exactly; anything else is a phrase.
  etpcz: (input) =>
    input.query && /^\s*\d{1,6}\s*\/\s*(\d{2}|\d{4})\s*$/.test(input.query)
      ? { tool: "etpcz_szukaj", args: { numer_skargi: input.query } }
      : { tool: "etpcz_szukaj", args: { fraza: input.query } },
  kio: (input) => ({ tool: "kio_szukaj", args: { fraza: input.query, dataOd: input.dateFrom, dataDo: input.dateTo, strona: input.page } }),
  krs: (input) => ({ tool: "krs_lookup", args: { numerKrs: input.query } }),
  wl: (input) => ({ tool: "wl_sprawdz_nip", args: { nip: input.query, data: input.dateTo } }),
  ceidg: (input) => ({ tool: "ceidg_szukaj_firmy", args: { nip: input.query } }),
  nbp: (input) => ({ tool: "nbp_kurs_waluty", args: { kodWaluty: input.query, data: input.dateTo } }),
  eureka: (input) => ({ tool: "eureka_szukaj", args: { fraza: input.query, dataOd: input.dateFrom, dataDo: input.dateTo, rozmiar: input.limit } }),
  sudop: (input) => ({ tool: "sudop_szukaj_pomocy", args: { nip: input.query } }),
  uodo: (input) => ({ tool: "uodo_szukaj", args: { fraza: input.query, dataOd: input.dateFrom, dataDo: input.dateTo, strona: input.page } })
};

// Sources whose get tool takes an offset and serves 20 000-character portions.
const PORTIONED_SOURCES = new Set<string>(["isap", "kio", "eureka", "uodo"]);
const PORTION_CHARS = 20_000;

export const NATIVE_GET: Record<
  SourceId,
  (documentId: string) => NativeRequest
> = {
  isap: (id) => ({ tool: "isap_tekst", args: { eli: id } }),
  eurlex: (id) => ({ tool: "eurlex_lookup", args: { celex: id } }),
  saos: (id) => ({ tool: "saos_search", args: { sygnatura: id } }),
  cbosa: (id) => ({ tool: "cbosa_pobierz", args: { doc_id: id } }),
  sn: (id) => ({ tool: "sn_pobierz", args: { karta: id } }),
  sp: (id) => ({ tool: "sp_pobierz", args: { url_lub_id: id } }),
  tk: (id) => ({ tool: "tk_pobierz", args: { url: id } }),
  etpcz: (id) => ({ tool: "etpcz_pobierz", args: { url_lub_id: id } }),
  // kio_pobierz takes the numeric id from kio_szukaj; a signature ("KIO 1000/23") is checked instead.
  kio: (id) => (/^\d{1,9}$/u.test(id.trim()) ? { tool: "kio_pobierz", args: { id: id.trim() } } : { tool: "kio_sprawdz_sygnature", args: { sygnatura: id.trim() } }),
  krs: (id) => ({ tool: "krs_lookup", args: { numerKrs: id } }),
  wl: (id) => ({ tool: "wl_sprawdz_nip", args: { nip: id } }),
  ceidg: (id) => ({ tool: "ceidg_szukaj_firmy", args: { nip: id } }),
  nbp: (id) => ({ tool: "nbp_kurs_waluty", args: { kodWaluty: id } }),
  eureka: (id) => ({ tool: "eureka_pobierz", args: { id } }),
  sudop: (id) => ({ tool: "sudop_odbierz_wynik", args: { kolejka_id: id } }),
  uodo: (id) => ({ tool: "uodo_pobierz", args: { urn_lub_sygnatura: id } })
};

const LOCAL_COVERAGE: Record<
  SourceId,
  {
    family: string;
    authority: string;
    role: string;
    fallback: string;
  }
> = {
  isap: {
    family: "polish-legislation",
    authority: "Sejm ELI",
    role: "retrieval",
    fallback: "Native Lex legal-act resolver, temporal freshness gate and verify_legal_reference."
  },
  eurlex: {
    family: "eu-law-and-cjeu",
    authority: "EUR-Lex/CELLAR/CJEU",
    role: "live official retrieval",
    fallback: "Native EUR-Lex/CELLAR official-source verification path."
  },
  saos: {
    family: "case-law",
    authority: "SAOS",
    role: "discovery/support",
    fallback: "Native Lex SAOS discovery for older rulings and common courts (SN only to 2016, TK to 2015, KIO to 2018, no NSA/WSA); recent rulings: web_search + official full-text search. SN citations still require the official SN verifier."
  },
  cbosa: {
    family: "administrative-case-law",
    authority: "CBOSA",
    role: "snapshot 🟨 without promotion",
    fallback: "Native Lex direct-CBOSA adapter; no exact match = OUT_OF_SCOPE, never NOT_FOUND."
  },
  sn: {
    family: "supreme-court-case-law",
    authority: "Sąd Najwyższy (sn.pl snproxy)",
    role: "official retrieval; the decision's card is the source",
    fallback: "Native verify_case_reference (sn.pl card); when sn.pl fails, web_search for leads and SAOS only for SN rulings before 2017."
  },
  sp: {
    family: "common-court-case-law",
    authority: "Portal Orzeczeń Sądów Powszechnych (orzeczenia.ms.gov.pl + portale sądów)",
    role: "official retrieval; the link is the decision itself (/content/$N/{id})",
    fallback: "SAOS (R3, current for common courts) when the portal fails, plus web_search for leads; signature not unique nationally -> court portal resolves AMBIGUOUS."
  },
  tk: {
    family: "constitutional-court-case-law",
    authority: "Trybunał Konstytucyjny (IPO / OTK ZU)",
    role: "official lookup only: IPO case card by signature, OTK ZU search, IPO form; never SAOS",
    fallback: "No hit: open the IPO case card or the OTK ZU search (links in the answer), then tk_pobierz."
  },
  etpcz: {
    family: "echr-case-law",
    authority: "ECHR decisions in the Ministry of Justice database (etpcz.ms.gov.pl)",
    role: "official Polish translations; the link is the decision text (/etpccontent/$N/{id})",
    fallback: "Selected decisions only: no hit is not absence; the full collection is HUDOC (hudoc.echr.coe.int)."
  },
  kio: {
    family: "public-procurement-case-law",
    authority: "KIO / UZP decisions search",
    role: "decisional practice",
    fallback: "Official UZP search (orzeczenia.uzp.gov.pl); no exact match = OUT_OF_SCOPE, Pzp provisions still require ELI verification."
  },
  krs: {
    family: "company-register",
    authority: "KRS Ministry of Justice API",
    role: "registry lookup",
    fallback: "Native official KRS API path used by the entity verification gate."
  },
  wl: {
    family: "vat-register",
    authority: "Wykaz podatników VAT (MF)",
    role: "registry lookup",
    fallback: "Official white-list API at wl-api.mf.gov.pl."
  },
  ceidg: {
    family: "sole-trader-register",
    authority: "CEIDG API v3",
    role: "registry lookup (requires API key)",
    fallback: "Companies are not in CEIDG — use KRS; without a key the source is unavailable, not empty."
  },
  nbp: {
    family: "exchange-rates",
    authority: "NBP table A",
    role: "official data",
    fallback: "Official NBP API."
  },
  eureka: {
    family: "tax-interpretations",
    authority: "EUREKA MF/KIS",
    role: "interpretive practice",
    fallback: "EUREKA web/source lookup; statutory propositions still require ELI verification."
  },
  sudop: {
    family: "state-aid-register",
    authority: "SUDOP (UOKiK)",
    role: "registry lookup",
    fallback: "Official SUDOP search; asynchronous results may need sudop_odbierz_wynik."
  },
  uodo: {
    family: "data-protection-decisions",
    authority: "UODO",
    role: "decisional practice",
    fallback: "Native Lex official UODO API path."
  }
};

export type LegalFederationAuditEvent = {
  tool: string;
  source?: string;
  decision:
    "ALLOW" |
    "BLOCK";
  // Tylko przy BLOCK: POLICY_BLOCKED = odmowa polityki źródeł/prywatności,
  // SOURCE_UNAVAILABLE = źródło nie odpowiedziało (nie jest dowodem braku).
  outcome?:
    "POLICY_BLOCKED" |
    "SOURCE_UNAVAILABLE";
  detail?:
    Record<string, unknown>;
};

const LIST_TOOL =
  "list_federated_legal_sources";
const SEARCH_TOOL =
  "search_federated_legal_sources";
const GET_TOOL =
  "get_federated_legal_document";
const CALL_TOOL =
  "call_federated_legal_source";
const COVERAGE_TOOL =
  "federated_legal_coverage";
const ASSESS_SOURCE_TOOL =
  "assess_legal_source";
const FETCH_AUXILIARY_SOURCE_TOOL =
  "fetch_auxiliary_legal_source";
const WEB_SEARCH_TOOL =
  "web_search";

const LIST_SCHEMA:
  NormalizedToolSchema = {
    type: "function",
    function: {
      name: LIST_TOOL,
      description:
        "List the read-only Polish/EU legal sources served by the Lex Machina MCP connectors (lex-mcp). " +
        "Use without sourceId for the catalog with installation status; provide sourceId to inspect live native tool schemas. " +
        "This is research/discovery only and never replaces Lex Machina citation verification.",
      parameters: {
        type: "object",
        additionalProperties: false,
        properties: {
          sourceId: {
            type: "string",
            enum: SOURCE_ENUM
          },
          group: {
            type: "string",
            enum: [
              "pl",
              "eu"
            ]
          }
        }
      }
    }
  };

const SEARCH_SCHEMA:
  NormalizedToolSchema = {
    type: "function",
    function: {
      name: SEARCH_TOOL,
      description:
        "Search one Lex Machina MCP source. " +
        "Sources: ISAP/ELI, EUR-Lex/CJEU, SAOS (academic aggregator, lowest rank), NSA/WSA (cbosa), SN (sn, card = source), common courts (sp, link = decision), TK (tk), ECHR (etpcz), KIO, KRS, VAT white list (wl), CEIDG, NBP, EUREKA/KIS, SUDOP and UODO. " +
        "Registry sources (krs, wl, ceidg, sudop) take the identifier (KRS number, NIP) as query; nbp takes the currency code. " +
        "Search results are discovery material; fetch the document before relying on its contents.",
      parameters: {
        type: "object",
        additionalProperties: false,
        required: [
          "source"
        ],
        properties: {
          source: {
            type: "string",
            enum: SOURCE_ENUM
          },
          query: {
            type: "string"
          },
          dateFrom: {
            type: "string",
            description:
              "Optional YYYY-MM-DD."
          },
          dateTo: {
            type: "string",
            description:
              "Optional YYYY-MM-DD."
          },
          page: {
            type: "integer",
            minimum: 1
          },
          limit: {
            type: "integer",
            minimum: 1,
            maximum: 100
          },
          extra: {
            type: "object",
            description:
              "Optional source-native filters. Inspect the source schema first when uncertain."
          }
        }
      }
    }
  };

const GET_SCHEMA:
  NormalizedToolSchema = {
    type: "function",
    function: {
      name: GET_TOOL,
      description:
        "Fetch a full legal/research document from one federated source by the identifier returned from search. " +
        "Long documents are paginated. Federation documents remain research evidence; statutory and SN citation hard gates still use Lex Machina verification tools.",
      parameters: {
        type: "object",
        additionalProperties: false,
        required: [
          "source",
          "documentId"
        ],
        properties: {
          source: {
            type: "string",
            enum: SOURCE_ENUM
          },
          documentId: {
            type: "string"
          },
          page: {
            type: "integer",
            minimum: 1,
            description: "Portion number (20 000 characters each) for isap, kio, eureka and uodo; offset takes precedence."
          },
          offset: {
            type: "integer",
            minimum: 0,
            description: "Character offset of the next portion, as the previous portion's _lexPorcja says (isap, kio, eureka, uodo)."
          },
          extra: {
            type: "object"
          }
        }
      }
    }
  };

const CALL_SCHEMA:
  NormalizedToolSchema = {
    type: "function",
    function: {
      name: CALL_TOOL,
      description:
        "Call a source-specific read-only Lex MCP tool, e.g. saos_cytator, krs_reprezentacja, cbosa_sprawdz_sygnature, wl_sprawdz_rachunek or eureka_sprawdz_sygnature. " +
        "The tool name must start with the source id and an underscore. " +
        "Inspect the source schema first. This tool cannot create Lex Machina VERIFIED markers.",
      parameters: {
        type: "object",
        additionalProperties: false,
        required: [
          "source",
          "tool"
        ],
        properties: {
          source: {
            type: "string",
            enum: SOURCE_ENUM
          },
          tool: {
            type: "string"
          },
          arguments: {
            type: "object"
          }
        }
      }
    }
  };

const ASSESS_SOURCE_SCHEMA:
  NormalizedToolSchema = {
    type: "function",
    function: {
      name:
        ASSESS_SOURCE_TOOL,
      description:
        "Classify and assess a public legal/research URL under Lex Machina source hierarchy without fetching it. " +
        "Known R1/R2A/R2B domains are classified deterministically; unknown domains are conservatively R3 until editorial criteria are independently established. " +
        "This tool never creates VERIFIED/SUPPORTED status and never replaces native verification.",
      parameters: {
        type: "object",
        additionalProperties:
          false,
        required: [
          "url"
        ],
        properties: {
          url: {
            type: "string",
            description:
              "Public HTTP(S) source URL to classify."
          },
          claim: {
            type: "string",
            description:
              "Optional exact proposition for which this source is being assessed."
          },

        }
      }
    }
  };

const FETCH_AUXILIARY_SOURCE_SCHEMA:
  NormalizedToolSchema = {
    type: "function",
    function: {
      name:
        FETCH_AUXILIARY_SOURCE_TOOL,
      description:
        "Safely fetch one public R2B/R3 auxiliary legal-research page through Lex Machina's SSRF-protected HTTPS retriever. " +
        "Use only after you have a specific public URL. The runtime classifies the final URL, extracts source-owned publication dates and records a content hash. " +
        "This tool never creates VERIFIED/SUPPORTED status and R2B/R3 can never be the sole legal basis.",
      parameters: {
        type: "object",
        additionalProperties:
          false,
        required: [
          "url"
        ],
        properties: {
          url: {
            type: "string",
            description:
              "Specific public HTTPS URL for an auxiliary legal/research page. Never include case facts, PII tokens or protected document context."
          },
          claim: {
            type: "string",
            description:
              "Optional exact public legal proposition being researched. Do not include client-specific facts."
          }
        }
      }
    }
  };

const WEB_SEARCH_SCHEMA:
  NormalizedToolSchema = {
    type: "function",
    function: {
      name:
        WEB_SEARCH_TOOL,
      description:
        "General internet search (DuckDuckGo, or Brave when BRAVE_SEARCH_API_KEY is set). " +
        "Returns titles, URLs and snippets, each classified R1/R2A/R2B/R3, with leads extracted from them (case signatures with the tool that verifies them, Dz.U. references with ELI, dates of entry into force). Snippets are never evidence, but every result is worth a look: " +
        "for case law, search with an abstract legal phrase (also site:sn.pl, site:orzeczenia.nsa.gov.pl, site:orzeczenia.ms.gov.pl) to find signatures of recent rulings (not in SAOS); results from LEX, Legalis, law portals and news sites are leads to signatures, amendments and dates of entry into force; " +
        "verify every lead at its official source (gradation of sources: R1 > R2A > R2B > R3) before citing; read R2B/R3 pages with fetch_auxiliary_legal_source when needed.",
      parameters: {
        type: "object",
        additionalProperties:
          false,
        required: [
          "query"
        ],
        properties: {
          query: {
            type: "string",
            description:
              "Neutral public search phrase (max 300 chars). Never include case facts, names, PII tokens or document text."
          },
          maxResults: {
            type: "integer",
            minimum: 1,
            maximum: 10,
            description:
              "Number of results, default 5."
          }
        }
      }
    }
  };

const COVERAGE_SCHEMA:
  NormalizedToolSchema = {
    type: "function",
    function: {
      name: COVERAGE_TOOL,
      description:
        "Return Lex MCP connector coverage, installation status and known gaps. Use after an empty search before claiming that a legal source or material does not exist.",
      parameters: {
        type: "object",
        additionalProperties: false,
        properties: {}
      }
    }
  };

function guardOutboundPayload(
  value:
    Record<string, unknown>
): Record<string, unknown> {
  const serialized =
    JSON.stringify(
      value
    );
  if (
    serialized.length >
      20_000
  ) {
    throw new Error(
      "FEDERATED_PAYLOAD_TOO_LARGE"
    );
  }
  if (
    /\[(?:DOCUMENT|CASE KNOWLEDGE|FIRM KNOWLEDGE)\s/i
      .test(
        serialized
      ) ||
    /\[(?:LM)?PII:/i
      .test(
        serialized
      )
  ) {
    throw new Error(
      "FEDERATED_CASE_DATA_FORBIDDEN"
    );
  }
  // Second line: a personal identifier the recognizer missed, in clear text.
  const personal = personalDataIn(value);
  if (personal.length && process.env.LEX_TOOL_BROKER_MODE !== "audit") {
    throw new Error(
      `FEDERATED_PERSONAL_DATA_FORBIDDEN:${personal.join(",")}`
    );
  }
  return value;
}

function sourceFrom(
  input:
    Record<string, unknown>
): SourceId | undefined {
  const raw =
    typeof input.source ===
      "string"
      ? input.source
      : typeof input.sourceId ===
          "string"
        ? input.sourceId
        : undefined;
  if (
    !raw ||
    !SOURCE_IDS.includes(
      raw as SourceId
    )
  ) {
    return undefined;
  }
  return raw as SourceId;
}

function extractToolText(
  value: unknown
): string {
  if (
    !value ||
    typeof value !==
      "object"
  ) {
    return String(
      value ?? ""
    );
  }

  const result =
    value as {
      content?: Array<
        {
          type?: string;
          text?: string;
        }
      >;
      structuredContent?: unknown;
      isError?: boolean;
    };

  const text =
    (result.content ?? [])
      .filter(
        (item) =>
          item.type === "text" &&
          typeof item.text ===
            "string"
      )
      .map(
        (item) =>
          item.text!
      )
      .join("\n");

  if (text) {
    if (
      result.isError
    ) {
      throw new Error(
        text
      );
    }
    return text;
  }

  if (
    result.structuredContent !==
      undefined
  ) {
    const serialized =
      JSON.stringify(
        result.structuredContent
      );
    if (
      result.isError
    ) {
      throw new Error(
        serialized
      );
    }
    return serialized;
  }

  if (
    result.isError
  ) {
    throw new Error(
      "FEDERATED_LEGAL_SOURCE_ERROR"
    );
  }

  return JSON.stringify(
    value
  );
}

/**
 * A document served in portions (isap_tekst, kio_pobierz: tresc with
 * tresc_offset and tresc_dlugosc): which characters the model has seen and
 * how to get the rest - it must not cite what it did not read.
 */
export function portionNote(parsed: Record<string, unknown>): string | null {
  const result = (parsed.result && typeof parsed.result === "object" ? parsed.result : parsed) as Record<string, unknown>;
  const text = result.tresc;
  const offset = result.tresc_offset;
  const total = result.tresc_dlugosc;
  if (typeof text !== "string" || typeof offset !== "number" || typeof total !== "number") return null;
  const end = offset + text.length;
  if (offset === 0 && end >= total) return null;
  const parts = [`Treść porcjowana: znaki ${offset}–${end} z ${total}.`];
  if (offset > 0) parts.push(`Znaków 0–${offset} nie ma w tej porcji.`);
  if (end < total) {
    parts.push(`Brakuje znaków ${end}–${total}: dobierz je wywołaniem get_federated_legal_document z offset=${end} (albo isap_tekst z artykul/szukaj).`);
  }
  parts.push("Nie cytuj ani nie streszczaj fragmentów, których nie widziałeś.");
  return parts.join(" ");
}

export function annotateFederatedLegalContent(
  source:
    string,
  content:
    string
): string {
  const sourcePolicy =
    federatedSourcePolicy(
      source
    );

  try {
    const parsed =
      JSON.parse(
        content
      ) as unknown;

    if (
      parsed &&
      typeof parsed ===
        "object" &&
      !Array.isArray(
        parsed
      )
    ) {
      const portion = portionNote(parsed as Record<string, unknown>);
      return JSON.stringify({
        ...(
          parsed as
            Record<
              string,
              unknown
            >
        ),
        ...(portion ? { _lexPorcja: portion } : {}),
        _lexSourcePolicy:
          sourcePolicy
      });
    }

    return JSON.stringify({
      _lexSourcePolicy:
        sourcePolicy,
      results:
        parsed
    });
  } catch {
    return JSON.stringify({
      _lexSourcePolicy:
        sourcePolicy,
      content
    });
  }
}

class LexMcpClient {
  private client:
    Client | null = null;
  private connecting:
    Promise<Client> | null =
      null;
  private revision = -1;
  private servers = "";

  constructor(
    private readonly connectors:
      LexMcpConnectorStore | undefined,
    private readonly fallback =
      new LegalSourceFallbackStore()
  ) {}

  installed(): SourceId[] {
    return this.connectors?.readyServers() ?? [];
  }

  private async ensureClient():
    Promise<Client> {
    const connectors =
      this.connectors;
    if (!connectors) {
      throw new Error(
        "LEX_MCP_CONNECTORS_NOT_CONFIGURED"
      );
    }
    const servers =
      connectors.readyServers().join(",");
    if (
      this.client &&
      (
        this.revision !==
          connectors.revision ||
        this.servers !==
          servers
      )
    ) {
      await this.close();
    }
    if (this.client) {
      return this.client;
    }
    if (this.connecting) {
      return this.connecting;
    }
    if (!servers) {
      throw new Error(
        "LEX_MCP_NO_SERVERS_INSTALLED"
      );
    }

    this.connecting =
      (async () => {
        const transport =
          new StdioClientTransport({
            command:
              connectors.command,
            // Lista po przecinku = jeden proces z narzędziami wszystkich wybranych serwerów.
            args: [
              connectors.packagePath,
              servers
            ],
            env:
              connectors.serverEnvironment(),
            stderr: "pipe"
          });
        const client =
          new Client({
            name:
              "lex-machina-legal-federation",
            version:
              "0.2.0"
          });
        await client.connect(
          transport
        );
        this.client =
          client;
        this.revision =
          connectors.revision;
        this.servers =
          servers;
        return client;
      })();

    try {
      return await this
        .connecting;
    } catch (error) {
      this.client = null;
      throw error;
    } finally {
      this.connecting =
        null;
    }
  }

  async close():
    Promise<void> {
    const client =
      this.client;
    this.client = null;
    this.connecting = null;
    if (client) {
      try {
        await client.close();
      } catch {
        // Best-effort shutdown.
      }
    }
  }

  async tools(
    source: SourceId
  ): Promise<unknown[]> {
    const client =
      await this.ensureClient();
    const listed =
      await client.listTools();
    return listed.tools
      .filter(
        (tool) =>
          tool.name.startsWith(
            `${source}_`
          )
      )
      .map(
        (tool) => ({
          name: tool.name,
          description: tool.description,
          inputSchema: tool.inputSchema
        })
      );
  }

  async call(
    name: string,
    args:
      Record<string, unknown>
  ): Promise<string> {
    let client: Client;
    try {
      client = await this.ensureClient();
    } catch (error) {
      // The connector does not start: the source's last good answer, dated.
      const copy = withSourceFallback(this.fallback, name, args, null);
      if (copy) return copy;
      throw error;
    }
    try {
      const result =
        await client.callTool(
          {
            name,
            arguments:
              guardOutboundPayload(
                args
              )
          },
          undefined,
          // SDK default is 60 s; SAOS (3 x 45 s), CEIDG (2 x 45 s) and SUDOP
          // (waits up to 50 s for its queue) need longer. Stays under the
          // desktop proxy's 300 s for direct search.
          { timeout: 280_000 }
        );
      return withSourceFallback(
        this.fallback,
        name,
        args,
        extractToolText(
          result
        )
      ) ?? "";
    } catch (error) {
      if (
        error instanceof Error &&
        error.message.startsWith(
          "FEDERATED_"
        )
      ) {
        throw error;
      }
      try {
        await client.close();
      } catch {
        // Best effort: the next call creates a fresh MCP transport.
      }
      this.client = null;
      // The source is down: its last good answer, dated, if there is one.
      const copy = withSourceFallback(this.fallback, name, args, null);
      if (copy) return copy;
      throw error;
    }
  }
}

function withoutUndefined(
  value:
    Record<string, unknown>
): Record<string, unknown> {
  return Object.fromEntries(
    Object.entries(value)
      .filter(
        ([, item]) =>
          item !== undefined
      )
  );
}

function extraFrom(
  input:
    Record<string, unknown>
): Record<string, unknown> {
  const extra =
    input.extra;
  return extra &&
    typeof extra ===
      "object" &&
    !Array.isArray(extra)
    ? extra as Record<string, unknown>
    : {};
}

type AuxiliarySourceFetcher =
  Pick<
    SafeAuxiliarySourceFetcher,
    "fetch"
  >;

export class LegalFederationToolRuntime {
  private readonly client:
    LexMcpClient;

  constructor(
    private readonly auxiliarySourceFetcher:
      AuxiliarySourceFetcher =
        new SafeAuxiliarySourceFetcher(),
    private readonly webSearch:
      WebSearchProvider =
        new PublicWebSearch(),
    connectors?:
      LexMcpConnectorStore
  ) {
    this.client =
      new LexMcpClient(
        connectors
      );
  }

  private assertInstalled(
    source: SourceId
  ): void {
    if (
      !this.client
        .installed()
        .includes(source)
    ) {
      throw new Error(
        source === "ceidg"
          ? "FEDERATED_SOURCE_NOT_INSTALLED:ceidg (klucz API CEIDG: Ustawienia → Konektory MCP)"
          : `FEDERATED_SOURCE_NOT_INSTALLED:${source}`
      );
    }
  }
  private readonly events:
    LegalFederationAuditEvent[] =
      [];

  schemas():
    NormalizedToolSchema[] {
    return [
      LIST_SCHEMA,
      SEARCH_SCHEMA,
      GET_SCHEMA,
      CALL_SCHEMA,
      ASSESS_SOURCE_SCHEMA,
      FETCH_AUXILIARY_SOURCE_SCHEMA,
      WEB_SEARCH_SCHEMA,
      COVERAGE_SCHEMA
    ];
  }

  handles(
    name: string
  ): boolean {
    return [
      LIST_TOOL,
      SEARCH_TOOL,
      GET_TOOL,
      CALL_TOOL,
      ASSESS_SOURCE_TOOL,
      FETCH_AUXILIARY_SOURCE_TOOL,
      WEB_SEARCH_TOOL,
      COVERAGE_TOOL
    ].includes(
      name
    );
  }

  systemPromptAppendix():
    string {
    return [
      "# FEDERATED LEGAL RESEARCH",
      "Lex Machina has optional read-only MCP connectors (lex-mcp, audyt-systemu-v4/mcp-servers): ISAP/ELI, EUR-Lex/CJEU, SAOS (academic aggregator, lowest rank), NSA/WSA (cbosa), SN (sn, card = source), common courts (sp, link = decision), TK (tk), ECHR (etpcz), KIO, KRS, VAT white list (wl), CEIDG, NBP, EUREKA/KIS, SUDOP and UODO. Only sources installed in Settings → MCP connectors are available.",
      "NSA/WSA results from cbosa are a snapshot 🟨 and are never promoted to VERIFIED; no exact match is OUT_OF_SCOPE, not absence of the ruling.",
      "Use list_federated_legal_sources when you need source capabilities or a native schema. Search first, then fetch the actual document before relying on its contents.",
      "This federation is DISCOVERY/RESEARCH ONLY. It never creates a Lex Machina VERIFIED ledger entry and never bypasses Gate I.",
      "Every federated search/get/call result carries _lexSourcePolicy with sourceTier, provenance and verificationAuthority=LEX_NATIVE_ONLY. Preserve that metadata when reasoning about the result.",
      "Use assess_legal_source for classification only. Use fetch_auxiliary_legal_source to retrieve a specific public R2B/R3 page through the SSRF-protected HTTPS channel; the fetched page remains auxiliary evidence.",
      "R2B and R3 material is auxiliary only: it can never create VERIFIED or formal SUPPORTED status and can never be the sole legal basis. Cross-check the proposition against R1/R2A before using it.",
      "Use web_search for general internet discovery (current events, non-legal facts, locating a page) and to find signatures of recent rulings (SN after 2016, TK after 2015, KIO after 2018, last 2-3 years) in secondary sources, where SAOS has no data; secondary sources give only the signature, the thesis and quotes come only from the verified official text. A known signature goes straight to the official registry, not to web_search. Send only neutral public phrases, never case facts or PII tokens. Snippets are not evidence: verify R1/R2A hits with verify_legal_reference / verify_case_* and read R2B/R3 hits with fetch_auxiliary_legal_source before relying on them. Disciplinary case law and professional ethics are not in the MCP connectors or SAOS: rulings of the bar's and the legal advisers' disciplinary courts (WSD Adwokatury „WSD 113/22”, WSD KIRP, sądy dyscyplinarne izb) and of the other professions (Naczelny Sąd Lekarski: nil.org.pl; komornicy: komornik.pl; biegli rewidenci: pibr.org.pl; inżynierowie budownictwa: piib.org.pl; notariusze, pielęgniarki, aptekarze, rzecznicy patentowi: their chambers' sites) are searched with web_search (site:wsd.adwokatura.pl, site:wsd.kirp.pl, site:nil.org.pl and the like) and read with fetch_auxiliary_legal_source on the court's own portal; codes of ethics (Zbiór Zasad Etyki Adwokackiej i Godności Zawodu, Kodeks Etyki Radcy Prawnego) are read the same way, also as PDF, DOC or DOCX files. When sn.pl asks for its human check, a disciplinary ruling of SN (SDI, DSI) found by web_search on another page is a lead (⚠️) until confirmed on sn.pl.",
      "For R3 material, check publication/update date. Missing date or material older than 24 months requires an explicit staleness warning.",
      "For Polish statutory citations and current legal wording, verify_legal_reference remains authoritative. For Sąd Najwyższy signatures/quotes/propositions, use verify_case_reference / verify_case_quote / verify_case_proposition.",
      "SAOS, CBOSA and ISAP connector results can broaden discovery or retrieve source material, but they do not replace the native Lex verification path.",
      "EUREKA interpretations, UODO decisions and other administrative/case materials must be described with their actual legal status; do not present them as generally binding statutory law. EUREKA search is discovery only: before citing an interpretation signature, call verify_interpretation (native Lex verification).",
      "After an empty federated search, call federated_legal_coverage before concluding that material is absent.",
      "Long documents come in 20 000-character portions: _lexPorcja names the characters you saw and the offset of the rest. Fetch the missing part (get_federated_legal_document with offset) before relying on it; never cite or summarise what you did not read.",
      "A business identifier of the case (NIP, REGON, KRS, account number as [PII:...] symbol) may be sent only to the register that answers for it: source krs, wl, ceidg or sudop; Lex puts the value back. Never send PESEL, ID card, e-mail or phone to any source.",
      "Never send case facts, uploaded-document text, secrets, PII tokens or client-specific narrative to the MCP connectors (they call public APIs). Restrict calls to public legal concepts, act/case identifiers, citations and neutral search phrases.",
      "If a federated result conflicts with a native official-source verifier, the native official verification path is authoritative; fail closed until the conflict is resolved.",
      "Do not expose connector implementation details or treat a source_unavailable error as absence of law."
    ].join(
      "\n"
    );
  }

  async close():
    Promise<void> {
    await this.client.close();
  }

  auditEvents():
    LegalFederationAuditEvent[] {
    return this.events.map(
      (event) => ({
        ...event,
        ...(event.detail
          ? {
              detail: {
                ...event.detail
              }
            }
          : {})
      })
    );
  }

  // Karta „Wyszukiwanie": te same bramki co narzędzia modelu (instalacja, zgodność
  // narzędzia ze źródłem, ochrona danych sprawy), ale wywołanie wprost, bez modelu.
  // Bez `tool` zwraca listę narzędzi źródła ze schematami parametrów.
  async direct(
    request: {
      source: string;
      tool?: string;
      arguments?: Record<string, unknown>;
    }
  ): Promise<{
    ok: boolean;
    result: unknown;
  }> {
    // Własny dziennik: zdarzenia karty nie trafiają do audytu żadnej sesji.
    const events: LegalFederationAuditEvent[] = [];
    const [reply] =
      await this.runTools([
        request.tool
          ? {
              id: "direct",
              name: CALL_TOOL,
              input: {
                source:
                  request.source,
                tool:
                  request.tool,
                arguments:
                  request.arguments ??
                  {}
              }
            }
          : {
              id: "direct",
              name: LIST_TOOL,
              input: {
                source:
                  request.source
              }
            }
      ], events);
    let result: unknown;
    try {
      result =
        JSON.parse(
          reply!.content
        );
    } catch {
      result = {
        content:
          reply!.content
      };
    }
    const status =
      result &&
      typeof result ===
        "object"
        ? (result as { status?: unknown }).status
        : undefined;
    return {
      ok:
        status !==
          "SOURCE_UNAVAILABLE" &&
        status !==
          "POLICY_BLOCKED",
      result
    };
  }

  // Instancja jest współdzielona przez sesje: każda sesja przekazuje własny dziennik,
  // inaczej zdarzenia jednej rozmowy trafiałyby do audytu kolejnych.
  async runTools(
    calls:
      NormalizedToolCall[],
    events:
      LegalFederationAuditEvent[] =
        this.events
  ): Promise<
    NormalizedToolResult[]
  > {
    const results:
      NormalizedToolResult[] =
      [];

    // Intentionally sequential: several upstreams publish explicit rate limits.
    for (
      const call
      of calls
    ) {
      const source =
        sourceFrom(
          call.input
        );
      try {
        const content =
          await this.execute(
            call
          );
        events.push({
          tool:
            call.name,
          ...(source
            ? {
                source
              }
            : {}),
          decision:
            "ALLOW"
        });
        results.push({
          tool_use_id:
            call.id,
          content
        });
      } catch (error) {
        const message =
          error instanceof Error
            ? error.message
            : String(
                error
              );
        // Case data or a personal identifier in the arguments: a policy refusal
        // the model must correct, never a source outage.
        const dataForbidden = /(?:CASE|PERSONAL)_DATA_FORBIDDEN/.test(message);
        const policyBlocked =
          dataForbidden ||
          call.name ===
            ASSESS_SOURCE_TOOL ||
          (
            call.name ===
              WEB_SEARCH_TOOL &&
            error instanceof
              WebSearchError &&
            error.code !==
              "WEB_SEARCH_NO_RESULTS"
          ) ||
          (
            call.name ===
              FETCH_AUXILIARY_SOURCE_TOOL &&
            (
              message ===
                "AUX_SOURCE_REQUIRES_R2B_R3" ||
              message ===
                "AUX_SOURCE_CASE_DATA_FORBIDDEN" ||
              (
                error instanceof
                  AuxiliarySourceFetchError &&
                [
                  "AUX_SOURCE_URL_INVALID",
                  "AUX_SOURCE_HOST_FORBIDDEN",
                  "AUX_SOURCE_DNS_PRIVATE"
                ].includes(
                  error.code
                )
              )
            )
          );
        events.push({
          tool:
            call.name,
          ...(source
            ? {
                source
              }
            : {}),
          decision:
            "BLOCK",
          // Próba wysłania danych sprawy do zewnętrznego źródła to zawsze odmowa polityki.
          outcome:
            policyBlocked ||
            /CASE_DATA_FORBIDDEN/.test(
              message
            )
              ? "POLICY_BLOCKED"
              : "SOURCE_UNAVAILABLE",
          detail: {
            error:
              message
          }
        });
        results.push({
          tool_use_id:
            call.id,
          content:
            JSON.stringify({
              status:
                policyBlocked
                  ? "POLICY_BLOCKED"
                  : "SOURCE_UNAVAILABLE",
              error:
                message,
              instruction:
                dataForbidden
                  ? "Lex nie wysyła danych sprawy ani danych osobowych (PESEL, dowód, paszport, e-mail, telefon, symbole [PII:…]) do źródeł zewnętrznych. Zadaj zapytanie ogólne o przepis, orzeczenie lub instytucję, bez danych stron. Numery NIP, REGON i KRS kontrahenta możesz przekazać tylko do rejestru (krs, wl, ceidg, sudop)."
                  : call.name === WEB_SEARCH_TOOL && policyBlocked
                  ? /DISABLED/.test(message)
                    ? "Wyszukiwarka jest wyłączona w ustawieniach aplikacji: brak tropów z sieci. Rejestry urzędowe (verify_case_reference, search_case_law, verify_legal_reference) działają dalej; nie podawaj sygnatur bez weryfikacji."
                    : "Zapytanie do wyszukiwarki odrzucone (puste albo dłuższe niż 300 znaków): podaj krótkie zapytanie ogólne, bez danych sprawy."
                  : call.name === FETCH_AUXILIARY_SOURCE_TOOL && message === "AUX_SOURCE_REQUIRES_R2B_R3"
                  ? "To źródło urzędowe (R1/R2A): nie czytaj go przez fetch_auxiliary_legal_source. Przepis sprawdź verify_legal_reference (ELI), orzeczenie SN verify_case_reference, interpretację verify_interpretation, NSA/WSA search_case_law source=CBOSA."
                  : policyBlocked
                  ? "Source assessment was rejected by Lex source policy. Correct the URL/cross-check evidence; do not treat this as a source outage."
                  : call.name === WEB_SEARCH_TOOL
                  ? "Wyszukiwarka nie zwróciła wyników albo jest chwilowo niedostępna (to nie dowód braku orzeczeń ani przepisów). Zmień zapytanie (krótsze, inne słowa, operator site:) albo użyj rejestrów urzędowych: verify_case_reference, search_case_law, verify_legal_reference."
                  : "Do not infer absence of law from this failure. Use another verified source path or report the source as temporarily unavailable."
            })
        });
      }
    }

    return results;
  }

  private async execute(
    call:
      NormalizedToolCall
  ): Promise<string> {
    // Before any connector is touched: a personal identifier never goes out.
    if (call.name !== LIST_TOOL && call.name !== COVERAGE_TOOL) {
      const personal = personalDataIn(call.input);
      if (personal.length && process.env.LEX_TOOL_BROKER_MODE !== "audit") {
        throw new Error(`FEDERATED_PERSONAL_DATA_FORBIDDEN:${personal.join(",")}`);
      }
    }
    if (
      call.name ===
        LIST_TOOL
    ) {
      const source =
        sourceFrom(
          call.input
        );
      if (source) {
        this.assertInstalled(
          source
        );
        return JSON.stringify({
          status: "OK",
          source,
          tools:
            await this.client.tools(
              source
            )
        });
      }
      const installed =
        new Set(
          this.client.installed()
        );
      return JSON.stringify({
        status: "OK",
        connectorPackage:
          CONNECTOR_PACKAGE,
        sources:
          LEX_MCP_CATALOG.map(
            (server) => ({
              source:
                server.id,
              group:
                server.group,
              label:
                server.label,
              installed:
                installed.has(
                  server.id
                ),
              ...(server.requiresKey
                ? {
                    requiresKey:
                      server.requiresKey
                  }
                : {})
            })
          )
      });
    }

    if (
      call.name ===
        ASSESS_SOURCE_TOOL
    ) {
      const rawUrl =
        typeof call.input
          .url === "string"
          ? call.input.url
              .trim()
          : "";
      let url: URL;
      try {
        url =
          new URL(rawUrl);
      } catch {
        throw new Error(
          "LEGAL_SOURCE_URL_INVALID"
        );
      }
      if (
        (
          url.protocol !==
            "https:" &&
          url.protocol !==
            "http:"
        ) ||
        url.username ||
        url.password
      ) {
        throw new Error(
          "LEGAL_SOURCE_URL_INVALID"
        );
      }

      const knownTier =
        classifyKnownLegalSourceUrl(
          url.toString()
        );
      const tier =
        knownTier ??
        "R3";
      const crossCheckStatus =
        tier === "R2B" ||
        tier === "R3"
          ? "PENDING" as const
          : "NOT_REQUIRED" as const;

      const candidate = {
        ...(typeof call.input
          .claim ===
          "string" &&
        call.input
          .claim
          .trim()
          ? {
              claim:
                call.input
                  .claim
                  .trim()
            }
          : {}),
        url:
          url.toString(),
        tier,
        provenance: {
          sourceUrl:
            url.toString(),
          retrievedVia:
            "WEB_RESEARCH" as const,
          accessMode:
            "UNKNOWN" as const,
          classificationBasis:
            knownTier
              ? "KNOWN_CANONICAL_DOMAIN"
              : "UNKNOWN_DOMAIN_CONSERVATIVE_R3_UNTIL_EDITORIAL_CRITERIA_VERIFIED",
        },
        crossCheckStatus
      };

      return JSON.stringify({
        status: "OK",
        candidate,
        assessment:
          assessLegalSourceCandidate(
            candidate
          ),
        classification:
          knownTier
            ? "KNOWN_DOMAIN"
            : "CONSERVATIVE_R3",
        instruction:
          knownTier
            ? "Preserve the tier and assessment. R2B/R3 remains auxiliary only. A higher-tier cross-check can be confirmed only by the session runtime from a real VerificationLedger record; model input cannot attest it."
            : "Unknown domain was conservatively classified as R3. It may be reconsidered as R2B only after independent evidence of professional editorial board, recognized publisher/brand and systematic updating. A higher-tier cross-check can be confirmed only by the session runtime."
      });
    }

    if (
      call.name ===
        WEB_SEARCH_TOOL
    ) {
      const query =
        assertPublicWebSearchQuery(
          call.input.query
        );
      const requested =
        typeof call.input.maxResults ===
          "number" &&
        Number.isFinite(
          call.input.maxResults
        )
          ? Math.trunc(
              call.input.maxResults
            )
          : 5;
      const response =
        await this.webSearch.search(
          query,
          Math.max(
            1,
            Math.min(
              10,
              requested
            )
          )
        );
      return JSON.stringify({
        status: "OK",
        query,
        provider:
          response.provider,
        results:
          classifyWebSearchHits(
            response.hits
          ),
        _lexSourcePolicy: {
          verificationAuthority:
            "LEX_NATIVE_ONLY",
          verificationEligible:
            false,
          note:
            "Search snippets are discovery only and never create VERIFIED/SUPPORTED status. Cite only URLs returned here, after the nextStep for each result."
        }
      });
    }

    if (
      call.name ===
        FETCH_AUXILIARY_SOURCE_TOOL
    ) {
      const rawUrl =
        typeof call.input
          .url === "string"
          ? call.input.url
              .trim()
          : "";
      const publicClaim =
        typeof call.input
          .claim === "string"
          ? call.input.claim
              .trim()
          : "";

      if (
        /\[(?:DOCUMENT|CASE KNOWLEDGE|FIRM KNOWLEDGE)\s/iu
          .test(
            rawUrl +
              " " +
              publicClaim
          ) ||
        /\[(?:LM)?PII:/iu
          .test(
            rawUrl +
              " " +
              publicClaim
          )
      ) {
        throw new Error(
          "AUX_SOURCE_CASE_DATA_FORBIDDEN"
        );
      }

      const requestedTier =
        classifyKnownLegalSourceUrl(
          rawUrl
        );
      if (
        requestedTier === "R1" ||
        requestedTier === "R2A"
      ) {
        throw new Error(
          "AUX_SOURCE_REQUIRES_R2B_R3"
        );
      }

      const fetched =
        await this
          .auxiliarySourceFetcher
          .fetch(
            rawUrl
          );
      const finalKnownTier =
        classifyKnownLegalSourceUrl(
          fetched.finalUrl
        );
      if (
        finalKnownTier === "R1" ||
        finalKnownTier === "R2A"
      ) {
        throw new Error(
          "AUX_SOURCE_REQUIRES_R2B_R3"
        );
      }
      const tier =
        finalKnownTier ??
        "R3";
      const candidate = {
        ...(publicClaim
          ? {
              claim:
                publicClaim
            }
          : {}),
        url:
          fetched.finalUrl,
        tier,
        provenance: {
          sourceUrl:
            fetched.finalUrl,
          retrievedVia:
            "WEB_RESEARCH" as const,
          accessMode:
            "DIRECT_LIVE" as const,
          classificationBasis:
            finalKnownTier
              ? "KNOWN_CANONICAL_DOMAIN_AFTER_SAFE_FETCH"
              : "UNKNOWN_DOMAIN_CONSERVATIVE_R3_AFTER_SAFE_FETCH",
          ...(fetched
            .publishedAt
            ? {
                publishedAt:
                  fetched
                    .publishedAt
              }
            : {}),
          ...(fetched
            .updatedAt
            ? {
                updatedAt:
                  fetched
                    .updatedAt
              }
            : {})
        },
        crossCheckStatus:
          "PENDING" as const
      };
      const textLimit =
        80_000;
      // LEX/Legalis and other paid services answer with a login or offer page: its text is
      // not the document, only what the search snippet showed can serve as a lead.
      const loginWall =
        fetched.text.length < 6_000 &&
        /zaloguj|logowani|wykup|dostęp\s+(?:płatny|tylko)|subskrypc|abonament|zarejestruj/iu.test(fetched.text.slice(0, 6_000));
      const leads = webSearchLeads(fetched.text.slice(0, textLimit));
      return JSON.stringify({
        status:
          "OK",
        ...(loginWall ? { access: "LOGIN_OR_PAYWALL" } : {}),
        ...(leads.signatures || leads.journals || leads.entryIntoForce ? { leads } : {}),
        classification:
          finalKnownTier
            ? "KNOWN_DOMAIN"
            : "CONSERVATIVE_R3",
        candidate,
        assessment:
          assessLegalSourceCandidate(
            candidate
          ),
        retrieval: {
          requestedUrl:
            fetched.requestedUrl,
          finalUrl:
            fetched.finalUrl,
          fetchedAt:
            fetched.fetchedAt,
          contentType:
            fetched.contentType,
          bytes:
            fetched.bytes,
          sha256:
            fetched.sha256,
          redirectCount:
            fetched
              .redirectCount,
          ...(fetched
            .publishedAt
            ? {
                publishedAt:
                  fetched
                    .publishedAt
              }
            : {}),
          ...(fetched
            .updatedAt
            ? {
                updatedAt:
                  fetched
                    .updatedAt
              }
            : {}),
          text:
            fetched.text
              .slice(
                0,
                textLimit
              ),
          textTruncated:
            fetched.text
              .length >
            textLimit
        },
        instruction:
          (loginWall
            ? "This is a login or paywall page, not the document: do not quote it; use only the leads the search result showed. "
            : "") +
          "This is auxiliary R2B/R3 research material, a lead: verify every signature, Dz.U. reference and date it gives at the official source (leads[].verifyWith, verify_legal_reference / ELI) before citing. Do not create VERIFIED/SUPPORTED from it and do not use it as the sole legal basis. For a legal proposition, obtain a real R1/R2A verification record for the same claim."
      });
    }

    if (
      call.name ===
        COVERAGE_TOOL
    ) {
      const installed =
        new Set(
          this.client.installed()
        );
      return JSON.stringify({
        status:
          "OK",
        connectorPackage:
          CONNECTOR_PACKAGE,
        sources:
          SOURCE_IDS.map(
            (source) => ({
              source,
              ...LOCAL_COVERAGE[
                source
              ],
              installed:
                installed.has(
                  source
                ),
              transport:
                "LEX_MCP_STDIO",
              sourcePolicy:
                federatedSourcePolicy(
                  source
                )
            })
          ),
        policy: {
          verificationAuthority:
            "LEX_NATIVE_ONLY",
          emptySearch:
            "OUT_OF_SCOPE_UNTIL_FALLBACK_CHECKED",
          notInstalled:
            "REPORT_AS_UNAVAILABLE_NEVER_AS_ABSENT",
          conflict:
            "REVERIFY_WITH_OFFICIAL_NATIVE_PATH_AND_FAIL_CLOSED",
          privacy:
            "NO_CASE_FACTS_DOCUMENT_TEXT_OR_PII_TOKENS_TO_EXTERNAL_MCP",
          sourceTierCoverage: {
            tier1:
              "IMPLEMENTED_OFFICIAL_RETRIEVAL_WITH_NATIVE_VERIFICATION",
            tier2A:
              "IMPLEMENTED_OFFICIAL_AND_AUTHORITY_RETRIEVAL_WITH_NATIVE_VERIFICATION_WHERE_SUPPORTED",
            tier2B:
              "SAFE_AUXILIARY_HTTPS_RETRIEVER_AND_RUNTIME_HARD_GATE_IMPLEMENTED",
            tier3:
              "SAFE_AUXILIARY_HTTPS_RETRIEVER_AND_RUNTIME_HARD_GATE_IMPLEMENTED_WITH_CONSERVATIVE_UNKNOWN_DOMAIN_CLASSIFICATION"
          }
        }
      });
    }

    const source =
      sourceFrom(
        call.input
      );
    if (!source) {
      throw new Error(
        "FEDERATED_SOURCE_INVALID"
      );
    }
    this.assertInstalled(
      source
    );

    // A signature of another court (II CSKP 89/26 in CBOSA): where to look instead.
    if (call.name === SEARCH_TOOL || call.name === CALL_TOOL) {
      const text =
        call.name === SEARCH_TOOL
          ? typeof call.input.query === "string" ? call.input.query : ""
          : JSON.stringify(call.input.arguments ?? {});
      const misrouted = misroutedSignature(source, text);
      if (misrouted) return JSON.stringify({ source, ...misrouted });
    }

    if (
      call.name ===
        SEARCH_TOOL
    ) {
      const request =
        NATIVE_SEARCH[source]({
          ...(typeof call.input
            .query === "string"
            ? {
                query:
                  call.input
                    .query
              }
            : {}),
          ...(typeof call.input
            .dateFrom === "string"
            ? {
                dateFrom:
                  call.input
                    .dateFrom
              }
            : {}),
          ...(typeof call.input
            .dateTo === "string"
            ? {
                dateTo:
                  call.input
                    .dateTo
              }
            : {}),
          ...(Number.isInteger(
            call.input.page
          )
            ? {
                page:
                  call.input
                    .page as number
              }
            : {}),
          ...(Number.isInteger(
            call.input.limit
          )
            ? {
                limit:
                  call.input
                    .limit as number
              }
            : {})
        });
      const content =
        await this.client.call(
          request.tool,
          withoutUndefined({
            ...request.args,
            ...extraFrom(
              call.input
            )
          })
        );
      return annotateFederatedLegalContent(
        source,
        content
      );
    }

    if (
      call.name ===
        GET_TOOL
    ) {
      const documentId =
        typeof call.input
          .documentId ===
          "string"
          ? call.input
              .documentId
              .trim()
          : "";
      if (!documentId) {
        throw new Error(
          "FEDERATED_DOCUMENT_ID_REQUIRED"
        );
      }
      const request =
        NATIVE_GET[source](
          documentId
        );
      // Portion of a long document: offset, or page N of 20 000 characters.
      const offset =
        PORTIONED_SOURCES.has(source)
          ? Number.isInteger(call.input.offset) && Number(call.input.offset) >= 0
            ? Number(call.input.offset)
            : Number.isInteger(call.input.page) && Number(call.input.page) > 1
              ? (Number(call.input.page) - 1) * PORTION_CHARS
              : undefined
          : undefined;
      const content =
        await this.client.call(
          request.tool,
          withoutUndefined({
            ...request.args,
            offset,
            ...extraFrom(
              call.input
            )
          })
        );
      return annotateFederatedLegalContent(
        source,
        content
      );
    }

    if (
      call.name ===
        CALL_TOOL
    ) {
      const tool =
        typeof call.input
          .tool ===
          "string"
          ? call.input.tool
              .trim()
          : "";
      if (!tool) {
        throw new Error(
          "FEDERATED_NATIVE_TOOL_REQUIRED"
        );
      }
      if (
        !tool.startsWith(
          `${source}_`
        )
      ) {
        throw new Error(
          "FEDERATED_NATIVE_TOOL_SOURCE_MISMATCH"
        );
      }
      const args =
        call.input.arguments &&
        typeof call.input
          .arguments ===
          "object" &&
        !Array.isArray(
          call.input.arguments
        )
          ? call.input
              .arguments as
              Record<
                string,
                unknown
              >
          : {};
      const content =
        await this.client.call(
          tool,
          args
        );
      return annotateFederatedLegalContent(
        source,
        content
      );
    }

    throw new Error(
      "UNKNOWN_FEDERATED_LEGAL_TOOL"
    );
  }
}

export const FEDERATED_LEGAL_TOOL_NAMES =
  new Set([
    LIST_TOOL,
    SEARCH_TOOL,
    GET_TOOL,
    CALL_TOOL,
    ASSESS_SOURCE_TOOL,
    FETCH_AUXILIARY_SOURCE_TOOL,
    WEB_SEARCH_TOOL,
    COVERAGE_TOOL
  ]);
