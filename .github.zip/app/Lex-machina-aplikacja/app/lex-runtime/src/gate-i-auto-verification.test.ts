import {
  describe,
  expect,
  it
} from "vitest";
import {
  applyAutomaticVerificationMarkers,
  detectHistoricalAsOf,
  lineQuote,
  planAutomaticLegalVerification
} from "./gate-i-auto-verification.js";
import {
  VerificationLedger
} from "./verification-ledger.js";

describe(
  "Gate I automatic statutory verification",
  () => {
    it(
      "plans unambiguous code citations without asking the model for source URLs",
      () => {
        const ledger =
          new VerificationLedger();
        const plan =
          planAutomaticLegalVerification(
            "Podstawą jest art. 5 KC oraz art. 233 KPC.",
            ledger
          );

        expect(plan.calls)
          .toHaveLength(2);
        expect(
          plan.calls.map(
            (call) =>
              call.input.act
          )
        ).toEqual([
          "KC",
          "KPC"
        ]);
        expect(
          plan.calls.every(
            (call) =>
              call.name ===
                "verify_legal_reference"
          )
        ).toBe(true);
      }
    );

    it("verifies an article of an act named in words in that act, not the line's code (RD 121/26)", () => {
      const plan = planAutomaticLegalVerification(
        "Podstawa: art. 95n pkt 1 Prawa o adwokaturze i odpowiednio art. 306 § 1 KPK.",
        new VerificationLedger()
      );
      expect(plan.calls.map((call) => call.input.act)).toEqual(["Prawa o adwokaturze", "KPK"]);
    });

    it(
      "propagates an explicit historical legal-state date into deterministic verification",
      () => {
        const text =
          "Według stanu na 2020-06-01 znaczenie ma art. 5 KC.";
        const plan =
          planAutomaticLegalVerification(
            text,
            new VerificationLedger()
          );

        expect(
          detectHistoricalAsOf(text)
        ).toBe("2020-06-01");
        expect(plan.calls)
          .toHaveLength(1);
        expect(
          plan.calls[0]?.input
        ).toMatchObject({
          act: "KC",
          asOf: "2020-06-01"
        });
      }
    );

    it(
      "rozpoznaje datę stanu prawnego zapisaną słownie i z kropkami",
      () => {
        expect(
          detectHistoricalAsOf("Jaki był stan prawny na 1 maja 2023 r. dla art. 5 KC?")
        ).toBe("2023-05-01");
        expect(
          detectHistoricalAsOf("Brzmienie art. 5 KC na dzień 01.05.2023.")
        ).toBe("2023-05-01");
        expect(
          detectHistoricalAsOf("Według stanu prawnego na 1.5.2023 art. 5 KC.")
        ).toBe("2023-05-01");
        // Nieistniejąca data nie ustawia stanu historycznego.
        expect(
          detectHistoricalAsOf("stan na 31.02.2023")
        ).toBeUndefined();
        // Ta sama data w dwóch zapisach to jeden stan.
        expect(
          detectHistoricalAsOf("stan na 1 maja 2023, czyli na dzień 2023-05-01")
        ).toBe("2023-05-01");
      }
    );

    it(
      "never upgrades an explicit unverified marker to a current-law verification",
      () => {
        const ledger =
          new VerificationLedger();
        ledger.add({
          claim:
            "art. 5 KC",
          kind: "statute",
          status:
            "VERIFIED",
          sourceUrl:
            "https://api.sejm.gov.pl/eli/acts/DU/2026/795/text.html",
          sourceTier: "R1",
          fetchedAt:
            "2026-09-18T12:00:00.000Z",
          verificationMethod:
            "web_fetch",
          temporalMode:
            "CURRENT",
          temporalFreshnessStatus:
            "CURRENT"
        });

        const text =
          "Znaczenie ma art. 5 KC. ⚠️ [NIEWERYFIKOWANE]";
        const plan =
          planAutomaticLegalVerification(
            text,
            ledger,
            "2021-01-01"
          );
        const marked =
          applyAutomaticVerificationMarkers(
            text,
            ledger,
            "2021-01-01"
          );

        expect(plan.calls)
          .toHaveLength(0);
        expect(
          plan.skipped[0]?.reason
        ).toBe(
          "EXPLICIT_UNVERIFIED_MARKER"
        );
        expect(marked.inserted)
          .toBe(0);
        expect(marked.text)
          .not.toContain("✅ [VER:");
      }
    );

    it(
      "does not guess the act for an ambiguous bare article reference",
      () => {
        const plan =
          planAutomaticLegalVerification(
            "Zastosowanie może mieć art. 5.",
            new VerificationLedger()
          );

        expect(plan.calls)
          .toHaveLength(0);
        expect(
          plan.skipped[0]
            ?.reason
        ).toBe(
          "ACT_ALIAS_AMBIGUOUS"
        );
      }
    );

    it(
      "adds runtime verification markers from the ledger to every verified statutory line",
      () => {
        const ledger =
          new VerificationLedger();
        ledger.add({
          claim:
            "art. 5 KC",
          kind:
            "statute",
          status:
            "VERIFIED",
          sourceUrl:
            "https://eli.gov.pl/eli/DU/1964/93/555/ogl",
          sourceTier:
            "R1",
          fetchedAt:
            "2026-09-18T12:00:00.000Z",
          verificationMethod:
            "web_fetch"
        });

        const result =
          applyAutomaticVerificationMarkers(
            "Pierwsza teza: art. 5 KC.\nDruga teza: art. 5 KC.",
            ledger
          );

        expect(result.inserted)
          .toBe(2);
        expect(
          result.text.match(
            /✅ \[VER:/gu
          )
        ).toHaveLength(2);
      }
    );

    it(
      "automatically plans explicit Supreme Court signatures without asking the model for a source URL",
      () => {
        const plan =
          planAutomaticLegalVerification(
            "Sąd Najwyższy, sygn. III CZP 25/11.",
            new VerificationLedger()
          );

        expect(plan.calls)
          .toHaveLength(1);
        expect(plan.calls[0]?.name)
          .toBe(
            "verify_case_reference"
          );
        expect(
          plan.calls[0]?.input
        ).toEqual({
          claim:
            "sygn. III CZP 25/11",
          signature:
            "III CZP 25/11",
          courtFamily: "SN"
        });
      }
    );

    it(
      "reads the court family from a Supreme Court repertory without the court's name",
      () => {
        const plan =
          planAutomaticLegalVerification(
            "Zob. sygn. III CZP 25/11.",
            new VerificationLedger()
          );

        expect(plan.calls[0]?.name)
          .toBe("verify_case_reference");
        expect(plan.calls[0]?.input)
          .toMatchObject({
            signature: "III CZP 25/11",
            courtFamily: "SN"
          });
        // A bare SN signature, no "sygn.": the same lookup.
        expect(
          planAutomaticLegalVerification("Uchwała z 2011 r., III CZP 25/11.", new VerificationLedger()).calls[0]?.input
        ).toMatchObject({ signature: "III CZP 25/11", courtFamily: "SN" });
      }
    );

    it(
      "inserts an unverified marker when runtime verification failed",
      () => {
        const ledger =
          new VerificationLedger();
        ledger.add({
          claim:
            "art. 5 KC",
          kind: "statute",
          status:
            "UNVERIFIED",
          fetchedAt:
            "2026-09-18T12:00:00.000Z"
        });

        const result =
          applyAutomaticVerificationMarkers(
            "Podstawa: art. 5 KC.",
            ledger
          );

        expect(result.inserted)
          .toBe(1);
        expect(result.text)
          .toContain(
            "⚠️ [NIEWERYFIKOWANE]"
          );
      }
    );

    it(
      "plans an SN signature deterministically when the court family is explicit",
      () => {
        const plan =
          planAutomaticLegalVerification(
            "Sąd Najwyższy, sygn. III CZP 25/11, rozpoznawał to zagadnienie.",
            new VerificationLedger()
          );

        expect(plan.calls)
          .toHaveLength(1);
        expect(
          plan.calls[0]?.name
        ).toBe(
          "verify_case_reference"
        );
        expect(
          plan.calls[0]?.input
            .signature
        ).toBe(
          "III CZP 25/11"
        );
        expect(
          plan.calls[0]?.input
            .courtFamily
        ).toBe("SN");
      }
    );

    it(
      "does not guess the court family for a common-court signature",
      () => {
        const plan =
          planAutomaticLegalVerification(
            "Por. sygn. I C 900/26.",
            new VerificationLedger()
          );

        expect(plan.calls)
          .toHaveLength(0);
        expect(
          plan.skipped[0]
            ?.reason
        ).toBe(
          "COURT_FAMILY_AMBIGUOUS"
        );
      }
    );

    it(
      "adds a runtime marker to a verified case signature line",
      () => {
        const ledger =
          new VerificationLedger();
        ledger.add({
          claim:
            "sygn. III CZP 25/11",
          kind: "case",
          status:
            "VERIFIED",
          sourceUrl:
            "https://www.sn.pl/example",
          fetchedAt:
            "2026-09-18T12:00:00.000Z",
          verificationMethod:
            "web_fetch",
          caseScope:
            "FULL_TEXT",
          caseSignature:
            "III CZP 25/11"
        });

        const result =
          applyAutomaticVerificationMarkers(
            "Sąd Najwyższy, sygn. III CZP 25/11.",
            ledger
          );

        expect(result.inserted)
          .toBe(1);
        expect(result.text)
          .toContain(
            "✅ [VER: https://www.sn.pl/example, 2026-09-18]"
          );
      }
    );

    it(
      "does not plan a duplicate verification already present in the ledger",
      () => {
        const ledger =
          new VerificationLedger();
        ledger.add({
          claim:
            "art. 5 KC",
          kind:
            "statute",
          status:
            "UNVERIFIED",
          fetchedAt:
            "2026-09-18T12:00:00.000Z"
        });

        const plan =
          planAutomaticLegalVerification(
            "art. 5 KC",
            ledger
          );

        expect(plan.calls)
          .toHaveLength(0);
        expect(
          plan.skipped[0]
            ?.reason
        ).toBe(
          "ALREADY_IN_LEDGER"
        );
      }
    );
  }
);

describe("Gate I: the wording quoted next to a provision goes to the check", () => {
  it("passes the line's quotation (its longest part around an ellipsis) as the quote", () => {
    const plan = planAutomaticLegalVerification(
      "Zgodnie z art. 52 § 1 pkt 1 KP w brzmieniu: „pracodawca może rozwiązać umowę z powodu zwolnień grupowych bez wypowiedzenia”.",
      new VerificationLedger()
    );
    expect(plan.calls[0]?.input).toMatchObject({ quote: "pracodawca może rozwiązać umowę z powodu zwolnień grupowych bez wypowiedzenia" });
    expect(lineQuote("art. 415 KC: „Kto z winy swej … wyrządził drugiemu szkodę, obowiązany jest do jej naprawienia”")).toBe(
      "wyrządził drugiemu szkodę, obowiązany jest do jej naprawienia"
    );
    expect(lineQuote("art. 415 KC („deliktowa”)")).toBeNull();
    expect(planAutomaticLegalVerification("Podstawą jest art. 5 KC.", new VerificationLedger()).calls[0]?.input).not.toHaveProperty("quote");
  });
});
