import { amountMarkerSpans, markerSpansAfter } from "./amount-references.js";
import { interpretationSignaturesInLine } from "./interpretation-verifier.js";
import { detectLegalReferences, FinalizationGate, namedActRecordForClaim, UNVERIFIED_MARKER_TEXT } from "./finalization-gate.js";
import { DOTTED_ACT_ALTERNATIVES, compactActAbbreviations } from "./legal-act-abbreviations.js";
import { verificationMarker } from "./source-anchor.js";
import {
  VerificationLedger,
  type VerificationRecord
} from "./verification-ledger.js";

// Końcowa kontrola spójności statusów: każdy przepis ma w całej odpowiedzi jeden
// status źródła (✅ [VER: …] albo ⚠️ [NIEWERYFIKOWANE]). Bramka G8 patrzy na wiersz;
// ta bramka porównuje wszystkie wystąpienia przepisu, także w podsumowaniu, i
// sprawdza je z rejestrem weryfikacji. Status źródła nie jest oceną zastosowania
// („potencjalnie”, „może wypełniać znamiona”): niepewność zastosowania nie zmienia ✅.

export type ProvisionSourceStatus =
  | "VERIFIED"
  | "UNVERIFIED"
  | "CONFLICT"
  | "UNMARKED";

export type ProvisionOccurrence = {
  key: string;
  claim: string;
  line: number;
  status: ProvisionSourceStatus;
  applicationHedge: boolean;
};

export type StatusConsistencyFinding = {
  key: string;
  code:
    | "CONFLICTING_STATUS"
    | "STATUS_CONTRADICTS_LEDGER"
    | "STATUS_MIXED_WITH_APPLICATION";
  lines: number[];
  statuses: ProvisionSourceStatus[];
};

export type StatusConsistencyReport = {
  gate: "G39I_STATUS_CONSISTENCY";
  result: "PASS" | "BLOCKED";
  provisions: Array<{
    key: string;
    status: ProvisionSourceStatus;
    lines: number[];
  }>;
  findings: StatusConsistencyFinding[];
  // Znacznik ⚠️ w wierszu bez przepisu: nie da się go przypisać, raportowany bez blokady.
  orphanUnverifiedLines: number[];
};

const ACTS =
  "KC|KPC|KK|KPK|KPA|KP|KRO|KSH|KW|KPW|PZP|KKS|KKW|PPSA|KSCU";
// "art. 110¹ KC" / "art. 110^1 KC" is its own article, not art. 110 (test 500: the superscript was
// dropped and art. 110¹ ⚠️ conflicted with a verified art. 110).
const UNIT =
  "\\d+(?:[⁰¹²³⁴⁵⁶⁷⁸⁹]+|\\^\\d+)?[a-zA-ZąćęłńóśźżĄĆĘŁŃÓŚŹŻ]{0,3}(?:\\s*§\\s*\\d+(?:[⁰¹²³⁴⁵⁶⁷⁸⁹]+|\\^\\d+)?[a-z]?)?(?:\\s+ust\\.?\\s*\\d+(?:[⁰¹²³⁴⁵⁶⁷⁸⁹]+|\\^\\d+)?[a-z]?)?(?:\\s+pkt\\s*\\d+(?:[⁰¹²³⁴⁵⁶⁷⁸⁹]+|\\^\\d+)?[a-z]?)?";
// "art. 233", "art. 233 § 1 KK", "art. 233 i 234 KK", "art. 233, 234 oraz 235 KK", "art. 233–234 KK".
const REFERENCE = new RegExp(
  `(?<!\\p{L})art(?:\\.|ykuł\\p{L}*)?\\s+(${UNIT}(?:\\s*(?:,|i|oraz|lub|albo|a także|–|-)\\s*(?:art\\.?\\s+)?${UNIT})*)(?:\\s+(${DOTTED_ACT_ALTERNATIVES}|${ACTS})(?![\\p{L}]))?`,
  "giu"
);
const ENUMERATION_ITEM = new RegExp(UNIT, "gu");
const RANGE_SEPARATOR = /^\s*[–-]\s*$/u;
const VERIFIED_MARKER = /✅\s*\[VER:[^\]\r\n]*\]/gu;
// 🟨 [KOTWICA-URZĘDOWA: …] to status niezweryfikowany (nie ✅), jak ⚠️.
const UNVERIFIED_MARKER = /⚠️?\s*\[NIEWERYFIKOWANE(?::[^\]\r\n]*)?\]|🟨\s*\[KOTWICA-URZĘDOWA(?::[^\]\r\n]*)?\]/gu;
const APPLICATION_HEDGE =
  /\b(?:potencjaln\p{L}*|ewentualn\p{L}*|prawdopodobn\p{L}*|hipotetyczn\p{L}*|mo(?:że|gą|głoby|głyby)\s+(?:mieć\s+zastosowanie|wypełni\p{L}*|stanowić|wchodzić\s+w\s+grę|znaleźć\s+zastosowanie)|w\s+zależności\s+od\s+okoliczności)/iu;

type Token =
  | {
      type: "reference";
      start: number;
      end: number;
      claim: string;
      article: string;
      act: string | null;
    }
  | {
      type: "marker";
      start: number;
      end: number;
      status: "VERIFIED" | "UNVERIFIED";
      // Right after a Dz.U. address or a case signature: that reference's own marker.
      afterOther?: boolean;
    };

const SUPERSCRIPT_DIGITS: Record<string, string> = { "⁰": "0", "¹": "1", "²": "2", "³": "3", "⁴": "4", "⁵": "5", "⁶": "6", "⁷": "7", "⁸": "8", "⁹": "9" };

function compact(value: string): string {
  return value
    // Before NFKC, which would make "110¹" into "1101".
    .replace(/[⁰¹²³⁴⁵⁶⁷⁸⁹]+/gu, (digits) => `^${[...digits].map((digit) => SUPERSCRIPT_DIGITS[digit]).join("")}`)
    .normalize("NFKC")
    .toLocaleLowerCase("pl")
    .replace(/\s+/gu, " ")
    .replace(/\s*§\s*/gu, " § ")
    .trim();
}

function lineTokens(lineText: string): Token[] {
  const tokens: Token[] = [];
  REFERENCE.lastIndex = 0;
  for (const match of lineText.matchAll(REFERENCE)) {
    const body = match[1] ?? "";
    // "k.k." is KK.
    const act = match[2] ? compactActAbbreviations(match[2]).toLocaleUpperCase("pl") : null;
    const bodyStart = match.index! + match[0].indexOf(body);
    const items = [...body.matchAll(ENUMERATION_ITEM)];
    items.forEach((item, index) => {
      const unit = item[0].trim();
      const previous = items[index - 1];
      const separator = previous
        ? body.slice(previous.index! + previous[0].length, item.index!)
        : "";
      // "art. 233–235" to przedział, nie trzy przepisy: zakres nie jest rozwijany.
      if (previous && RANGE_SEPARATOR.test(separator)) return;
      const start = bodyStart + item.index!;
      // Ostatnia pozycja wyliczenia obejmuje skrót aktu ("234 KK").
      const end =
        index === items.length - 1
          ? match.index! + match[0].length
          : start + item[0].length;
      tokens.push({
        type: "reference",
        start,
        end,
        claim: `art. ${unit}${act ? ` ${act}` : ""}`,
        article: unit.match(/^\d+[a-zA-ZąćęłńóśźżĄĆĘŁŃÓŚŹŻ]*/u)?.[0] ?? unit,
        act
      });
    });
  }
  // ⚠️ tuż za stawką, terminem, karą albo sygnaturą interpretacji należy do niej, nie do przepisu.
  const signatureEnds = interpretationSignaturesInLine(lineText)
    .filter((signature) => lineText.includes(signature))
    .map((signature) => lineText.indexOf(signature) + signature.length);
  const amountMarkers = [...amountMarkerSpans(lineText), ...markerSpansAfter(lineText, signatureEnds)];
  // "zmiana z Dz.U. 2026 poz. 507 ⚠️ …, dla art. 418 …": the ⚠️ is the journal's. Before, a marker
  // ahead of the line's first article was given to that article, so reconciling a verified
  // art. 418 turned the journal's ⚠️ into ✅ (test 500).
  const endsOf = (kinds: string[]) =>
    detectLegalReferences(lineText)
      .filter((reference) => kinds.includes(reference.kind))
      .map((reference) => {
        const written = reference.span ?? reference.claim;
        const at = lineText.indexOf(written);
        return at < 0 ? -1 : at + written.length;
      })
      .filter((end) => end >= 0);
  const otherMarkers = markerSpansAfter(lineText, endsOf(["journal", "case"]));
  // A signature's own marker ("VII P 94/25 ⚠️ [NIEWERYFIKOWANE: z materiałów sprawy]") is no
  // article's, wherever the line's articles stand (RD 121/26: dropped with a verified art. 17 RODO).
  const caseMarkers = markerSpansAfter(lineText, endsOf(["case"]));
  for (const [pattern, status] of [
    [VERIFIED_MARKER, "VERIFIED"],
    [UNVERIFIED_MARKER, "UNVERIFIED"]
  ] as const) {
    pattern.lastIndex = 0;
    for (const match of lineText.matchAll(pattern)) {
      if (status === "UNVERIFIED" && [...amountMarkers, ...caseMarkers].some((span) => span.start === match.index)) continue;
      tokens.push({
        type: "marker",
        start: match.index!,
        end: match.index! + match[0].length,
        status,
        ...(otherMarkers.some((span) => span.start === match.index) ? { afterOther: true } : {})
      });
    }
  }
  return tokens.sort((a, b) => a.start - b.start);
}

/** Powołania artykułów w wierszu, z rozwiniętym wyliczeniem: "art. 233 i 234 KK" -> oba. */
export function statuteClaimsInLine(lineText: string): string[] {
  return [
    ...new Set(
      lineTokens(lineText).flatMap((token) =>
        token.type === "reference" ? [token.claim] : []
      )
    )
  ];
}

type Group = {
  references: Extract<Token, { type: "reference" }>[];
  markers: Extract<Token, { type: "marker" }>[];
};

// Znaczniki należą do przepisów stojących przed nimi od poprzedniego znacznika;
// znacznik na początku wiersza należy do pierwszej grupy przepisów po nim.
function lineGroups(tokens: Token[]): Group[] {
  const groups: Group[] = [];
  let current: Group = { references: [], markers: [] };
  let leading: Group["markers"] = [];
  for (const token of tokens) {
    if (token.type === "reference") {
      if (current.markers.length > 0) {
        groups.push(current);
        current = { references: [], markers: [] };
      }
      current.references.push(token);
      if (leading.length > 0) {
        current.markers.push(...leading);
        leading = [];
      }
      continue;
    }
    if (current.references.length === 0) {
      // Not a marker opening the line: it belongs to the Dz.U. address or signature before it.
      if (!token.afterOther) leading.push(token);
    } else {
      current.markers.push(token);
    }
  }
  if (current.references.length > 0) groups.push(current);
  return groups;
}

function groupStatus(group: Group): ProvisionSourceStatus {
  const verified = group.markers.some((marker) => marker.status === "VERIFIED");
  const unverified = group.markers.some((marker) => marker.status === "UNVERIFIED");
  if (verified && unverified) return "CONFLICT";
  if (verified) return "VERIFIED";
  if (unverified) return "UNVERIFIED";
  return "UNMARKED";
}

type ParsedLine = {
  line: number;
  text: string;
  groups: Group[];
  orphanUnverified: boolean;
};

function parse(text: string): ParsedLine[] {
  return text.split(/\r?\n/u).map((lineText, index) => {
    const tokens = lineTokens(lineText);
    const groups = lineGroups(tokens);
    return {
      line: index + 1,
      text: lineText,
      groups,
      orphanUnverified:
        groups.length === 0 &&
        tokens.some((token) => token.type === "marker" && token.status === "UNVERIFIED")
    };
  });
}

// Przepis bez skrótu aktu ("art. 233") przyjmuje skrót, gdy w odpowiedzi ten numer
// artykułu występuje z dokładnie jednym aktem; inaczej pozostaje osobnym kluczem.
function keyResolver(
  lines: ParsedLine[],
  text: string
): (reference: Group["references"][number], line: number) => string {
  // The act G8 resolved for an act-less article (the only act of the line or the answer).
  const resolvedActs = new Map<string, string>();
  for (const reference of detectLegalReferences(text)) {
    if (reference.kind !== "statute" || !reference.span) continue;
    const act = /\s(\S+)$/u.exec(reference.claim)?.[1];
    if (act) resolvedActs.set(`${reference.line}\u0000${compact(reference.span)}`, act);
  }
  const actsByUnit = new Map<string, Set<string>>();
  for (const line of lines) {
    for (const group of line.groups) {
      for (const reference of group.references) {
        if (!reference.act) continue;
        const unit = compact(reference.claim.replace(/\s+\S+$/u, ""));
        actsByUnit.set(unit, (actsByUnit.get(unit) ?? new Set()).add(reference.act));
      }
    }
  }
  return (reference, line) => {
    if (reference.act) return compact(reference.claim);
    const unit = compact(reference.claim);
    const acts = actsByUnit.get(unit);
    if (acts?.size === 1) return `${unit} ${[...acts][0]!.toLocaleLowerCase("pl")}`;
    const resolved = resolvedActs.get(`${line}\u0000${unit}`);
    return resolved ? `${unit} ${resolved.toLocaleLowerCase("pl")}` : unit;
  };
}

function verifiedRecord(
  ledger: VerificationLedger,
  claims: string[],
  lineText?: string
): VerificationRecord | undefined {
  for (const claim of claims) {
    const record = ledger.latest(claim);
    if (record) {
      return record.status === "VERIFIED" && verificationMarker(record) ? record : undefined;
    }
  }
  // "art. 52 § 3 Prawa o postępowaniu przed sądami administracyjnymi" / "PPSA art. 52 § 3": the act
  // named on the line in words or by acronym (live B02-P04: unresolved, its ✅ was unified to ⚠️).
  const named = lineText ? namedActRecordForClaim(ledger, claims.at(-1)!, lineText) : undefined;
  return named && verificationMarker(named) ? named : undefined;
}

// Najpierw najdokładniejsze powołanie (ze skrótem aktu), potem zapis z odpowiedzi.
function ledgerClaims(reference: Group["references"][number], key: string): string[] {
  return [...new Set([key, reference.claim])];
}

function occurrences(text: string): {
  lines: ParsedLine[];
  items: Array<ProvisionOccurrence & { claims: string[] }>;
} {
  const lines = parse(text);
  const resolve = keyResolver(lines, text);
  const items: Array<ProvisionOccurrence & { claims: string[] }> = [];
  for (const line of lines) {
    const applicationHedge = APPLICATION_HEDGE.test(line.text);
    for (const group of line.groups) {
      const status = groupStatus(group);
      for (const reference of group.references) {
        const key = resolve(reference, line.line);
        items.push({
          key,
          claim: reference.claim,
          line: line.line,
          status,
          applicationHedge,
          claims: ledgerClaims(reference, key)
        });
      }
    }
  }
  return { lines, items };
}

export function evaluateStatusConsistency(
  text: string,
  ledger: VerificationLedger
): StatusConsistencyReport {
  const { lines, items } = occurrences(text);
  const byKey = new Map<string, typeof items>();
  for (const item of items) {
    byKey.set(item.key, [...(byKey.get(item.key) ?? []), item]);
  }

  const provisions: StatusConsistencyReport["provisions"] = [];
  const findings: StatusConsistencyFinding[] = [];
  // A verified provision shown ⚠️ in every place (never ✅): understated, one status in the whole
  // answer. Reported, not blocking — understating the source misleads no one (test 500, C07-001:
  // the repealed art. 1088 KC read from ELI and marked ⚠️ throughout blocked the answer).
  const understated = new Set<string>();
  for (const [key, list] of byKey) {
    const marked = list.filter((item) => item.status !== "UNMARKED");
    const statuses = [...new Set(marked.map((item) => item.status))];
    const lineNumbers = [...new Set(list.map((item) => item.line))];
    const conflict =
      statuses.includes("CONFLICT") ||
      (statuses.includes("VERIFIED") && statuses.includes("UNVERIFIED"));
    provisions.push({
      key,
      status: conflict ? "CONFLICT" : statuses[0] ?? "UNMARKED",
      lines: lineNumbers
    });
    if (conflict) {
      findings.push({
        key,
        code: "CONFLICTING_STATUS",
        lines: [...new Set(marked.map((item) => item.line))],
        statuses
      });
    }
    const contradicted = marked.filter(
      (item) => item.status !== "VERIFIED" && verifiedRecord(ledger, item.claims, lines[item.line - 1]?.text)
    );
    if (contradicted.length > 0 && !conflict && statuses.every((status) => status === "UNVERIFIED")) understated.add(key);
    if (contradicted.length > 0) {
      findings.push({
        key,
        code: "STATUS_CONTRADICTS_LEDGER",
        lines: [...new Set(contradicted.map((item) => item.line))],
        statuses
      });
      const hedged = contradicted.filter((item) => item.applicationHedge);
      if (hedged.length > 0) {
        findings.push({
          key,
          code: "STATUS_MIXED_WITH_APPLICATION",
          lines: [...new Set(hedged.map((item) => item.line))],
          statuses
        });
      }
    }
  }

  return {
    gate: "G39I_STATUS_CONSISTENCY",
    result: findings.some((finding) => !understated.has(finding.key)) ? "BLOCKED" : "PASS",
    provisions,
    findings,
    orphanUnverifiedLines: lines
      .filter((line) => line.orphanUnverified)
      .map((line) => line.line)
  };
}

/**
 * Naprawa według rejestru weryfikacji: przepis, który narzędzie zweryfikowało
 * (VERIFIED), traci w każdym miejscu odpowiedzi znacznik ⚠️ [NIEWERYFIKOWANE] i
 * dostaje ten sam znacznik ✅ [VER: …]. Przepis bez rekordu VERIFIED nie jest
 * zmieniany: sprzeczność zostaje i blokuje odpowiedź.
 */
export function reconcileStatusMarkers(
  text: string,
  ledger: VerificationLedger
): { text: string; repaired: number } {
  const lines = parse(text);
  const resolve = keyResolver(lines, text);
  const ledgerMarkers = new Set(
    ledger
      .all()
      .map((record) => verificationMarker(record))
      .filter((marker): marker is string => Boolean(marker))
  );
  let repaired = 0;
  const output = lines.map((line) => {
    const edits: Array<{ start: number; end: number; insert: string }> = [];
    for (const group of line.groups) {
      const status = groupStatus(group);
      if (status !== "UNVERIFIED" && status !== "CONFLICT") continue;
      const records = group.references.map((reference) =>
        verifiedRecord(ledger, ledgerClaims(reference, resolve(reference, line.line)), line.text)
      );
      if (records.every((record) => !record)) {
        // Nic w grupie nie jest zweryfikowane: ✅ bez rekordu VERIFIED w rejestrze jest
        // zmyślony i znika, ⚠️ zostaje. Prawdziwy ✅ innego przepisu zostaje (blokada).
        if (status !== "CONFLICT") continue;
        for (const marker of group.markers) {
          if (marker.status !== "VERIFIED") continue;
          if (ledgerMarkers.has(line.text.slice(marker.start, marker.end))) continue;
          const start = line.text[marker.start - 1] === " " ? marker.start - 1 : marker.start;
          edits.push({ start, end: marker.end, insert: "" });
          repaired += 1;
        }
        continue;
      }
      const missing = (record: VerificationRecord) => {
        const marker = verificationMarker(record)!;
        return line.text.includes(marker) ? null : marker;
      };
      if (records.every(Boolean)) {
        // Cała grupa zweryfikowana: ⚠️ znika, a w jego miejscu stają brakujące ✅.
        const markers = [
          ...new Set(records.map((record) => missing(record!)).filter(Boolean))
        ] as string[];
        const unverified = group.markers.filter((marker) => marker.status === "UNVERIFIED");
        unverified.forEach((marker, index) => {
          const insert = index === 0 ? markers.join(" ") : "";
          // Usunięcie bez zamiennika zabiera też spację przed znacznikiem.
          const start =
            !insert && line.text[marker.start - 1] === " "
              ? marker.start - 1
              : marker.start;
          edits.push({ start, end: marker.end, insert });
        });
        repaired += unverified.length;
        continue;
      }
      // Grupa mieszana z oboma znacznikami naraz („art. 233 kk i art. 232a KK ✅ … ⚠️ …”):
      // znaczniki po grupie nie mówią, który dotyczy którego przepisu. Każdy przepis
      // dostaje własny znacznik — ✅ z rejestru albo ⚠️ — a wspólne znaczniki znikają.
      if (status === "CONFLICT") {
        for (const marker of group.markers) {
          const start = line.text[marker.start - 1] === " " ? marker.start - 1 : marker.start;
          edits.push({ start, end: marker.end, insert: "" });
        }
        group.references.forEach((reference, index) => {
          const record = records[index];
          edits.push({
            start: reference.end,
            end: reference.end,
            insert: ` ${record ? verificationMarker(record)! : "⚠️ [NIEWERYFIKOWANE]"}`
          });
        });
        repaired += group.markers.length;
        continue;
      }
      // Grupa mieszana: ✅ bezpośrednio po zweryfikowanym przepisie, ⚠️ zostaje przy reszcie.
      // Ten sam ✅ w innym miejscu wiersza (np. dopisany na końcu) nie należy do tej grupy.
      const groupMarkers = new Set(
        group.markers.map((marker) => line.text.slice(marker.start, marker.end))
      );
      group.references.forEach((reference, index) => {
        const record = records[index];
        const marker = record ? verificationMarker(record) : null;
        if (!marker || groupMarkers.has(marker)) return;
        edits.push({ start: reference.end, end: reference.end, insert: ` ${marker}` });
        repaired += 1;
      });
    }
    if (edits.length === 0) return line.text;
    let next = line.text;
    for (const edit of edits.sort((a, b) => b.start - a.start)) {
      next = next.slice(0, edit.start) + edit.insert + next.slice(edit.end);
    }
    return keepOtherReferencesMarked(line.text, next, ledger);
  });
  return { text: repaired > 0 ? output.join("\n") : text, repaired };
}

// "art. 156 § 2 KPA (t.j. Dz.U. 2025 poz. 1691) ✅ … ⚠️": the ⚠️ a verified article loses was
// the journal's too (test 500). A Dz.U. or signature marked before the repair and unmarked
// after it gets its own ⚠️, right after it.
function keepOtherReferencesMarked(before: string, after: string, ledger: VerificationLedger): string {
  const gate = new FinalizationGate();
  const marked = new Set(
    gate.evaluate(before, ledger).findings
      .filter((finding) => finding.reference.kind !== "statute" && finding.status === "UNVERIFIED_MARKED")
      .map((finding) => finding.reference.span ?? finding.reference.claim)
  );
  if (marked.size === 0) return after;
  let next = after;
  for (const finding of gate.evaluate(after, ledger).findings) {
    const written = finding.reference.span ?? finding.reference.claim;
    if (finding.status !== "UNVERIFIED_NOT_MARKED" || !marked.has(written)) continue;
    const at = next.indexOf(written);
    if (at < 0) continue;
    const end = at + written.length;
    next = `${next.slice(0, end)} ${UNVERIFIED_MARKER_TEXT}${next.slice(end)}`;
  }
  return next;
}

/**
 * Znacznik ✅ [VER: …] przy przepisie, którego nie da się odtworzyć z rekordu VERIFIED
 * w rejestrze, jest deklaracją modelu, nie weryfikacją (np. sam link do aktu bez kotwicy
 * albo inna data). Usuwany przed wstawieniem znaczników z rejestru: przepis zweryfikowany
 * dostaje znacznik z rejestru, niezweryfikowany ⚠️ [NIEWERYFIKOWANE]. Wiersz z sygnaturą
 * orzeczenia zostaje bez zmian: zmieniony znacznik orzeczenia nadal blokuje (G22).
 */
export function stripUnbackedVerificationMarkers(
  text: string,
  ledger: VerificationLedger
): { text: string; removed: number } {
  const ledgerMarkers = new Set(
    ledger
      .all()
      .map((record) => verificationMarker(record))
      .filter((marker): marker is string => Boolean(marker))
  );
  const caseLines = new Set(
    detectLegalReferences(text)
      .filter((reference) => reference.kind === "case")
      .map((reference) => reference.line)
  );
  let removed = 0;
  const lines = text.split(/\r?\n/u).map((line, index) =>
    caseLines.has(index + 1)
      ? line
      : line.replace(/ ?✅\s*\[VER:[^\]\r\n]*\]/gu, (match) => {
          if (ledgerMarkers.has(match.trimStart())) return match;
          removed += 1;
          return "";
        })
  );
  return { text: removed > 0 ? lines.join("\n") : text, removed };
}

/**
 * A provision whose occurrences still carry both ✅ and ⚠️ after reconciliation, with no
 * VERIFIED record to settle it: every occurrence is shown ⚠️ [NIEWERYFIKOWANE] (each
 * reference of its group gets its own marker, ✅ from the registry or ⚠️). The answer stays
 * presentable as a draft with the provision marked, instead of the whole turn being blocked.
 */
export function unifyConflictingProvisions(
  text: string,
  ledger: VerificationLedger
): { text: string; unified: string[] } {
  const report = evaluateStatusConsistency(text, ledger);
  const unresolved = new Set(
    report.findings.filter((finding) => finding.code === "CONFLICTING_STATUS").map((finding) => finding.key)
  );
  if (unresolved.size === 0) return { text, unified: [] };
  const lines = parse(text);
  const resolve = keyResolver(lines, text);
  const output = lines.map((line) => {
    const edits: Array<{ start: number; end: number; insert: string }> = [];
    for (const group of line.groups) {
      if (!group.references.some((reference) => unresolved.has(resolve(reference, line.line)))) continue;
      for (const marker of group.markers) {
        const start = line.text[marker.start - 1] === " " ? marker.start - 1 : marker.start;
        edits.push({ start, end: marker.end, insert: "" });
      }
      for (const reference of group.references) {
        const key = resolve(reference, line.line);
        const record = unresolved.has(key) ? undefined : verifiedRecord(ledger, ledgerClaims(reference, key), line.text);
        edits.push({ start: reference.end, end: reference.end, insert: ` ${record ? verificationMarker(record)! : "⚠️ [NIEWERYFIKOWANE]"}` });
      }
    }
    let next = line.text;
    for (const edit of edits.sort((a, b) => b.start - a.start || b.end - a.end)) {
      next = next.slice(0, edit.start) + edit.insert + next.slice(edit.end);
    }
    return next;
  });
  return { text: output.join("\n"), unified: [...unresolved] };
}

// "Zweryfikowano 14/14 pozycji." in an answer with ⚠️ elsewhere (live C12-008, turn 4): the
// count was the model's table, the reader takes it for the whole answer.
const COMPLETE_VERIFICATION_CLAIM =
  /Zweryfikowano\s+(\d+)\s*\/\s*\1(?:\s+pozycj\p{L}*)?|(?:Wszystkie|Wszystkich)\s+(?:powołane\s+)?przepis\p{L}*\s+(?:zostały\s+|są\s+)?(?:zweryfikowan|sprawdzon)\p{L}*|(?:Zweryfikowałem|Sprawdziłem)\s+wszystkie\s+(?:powołane\s+)?przepis\p{L}*/giu;
const ANY_UNVERIFIED_MARKER = /⚠️?\s*\[NIEWERYFIKOWANE|🟨\s*\[KOTWICA-URZĘDOWA/u;

/** A claim that everything was verified gets "(z wyjątkiem pozycji oznaczonych ⚠️)" when ⚠️ is shown. */
export function qualifyCompleteVerificationClaims(text: string): string {
  if (!ANY_UNVERIFIED_MARKER.test(text)) return text;
  return text.replace(COMPLETE_VERIFICATION_CLAIM, (claim, _count, offset: number, whole: string) =>
    /^\s*\(?\s*(?:z\s+wyjątkiem|poza)\b/iu.test(whole.slice(offset + claim.length, offset + claim.length + 20))
      ? claim
      : `${claim} (z wyjątkiem pozycji oznaczonych ⚠️)`
  );
}
