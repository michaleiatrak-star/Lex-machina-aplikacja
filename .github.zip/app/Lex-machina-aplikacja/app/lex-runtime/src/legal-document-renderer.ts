import {
  spawn
} from "node:child_process";
import path from "node:path";
import {
  fileURLToPath
} from "node:url";
import type {
  LegalDocumentAst,
  LegalStyleProfile
} from "./legal-document-ast.js";

export type LegalDocumentFormat =
  | "docx"
  | "odt";

// Whether the firm's template (its letterhead: headers, footers with their images, page
// setup) went into the file; a template that cannot be copied safely is named, not applied.
export type LetterheadReport =
  // body: the template's paragraphs around {{treść}} framed the content; fields: the fields
  // ({{data}}, {{adresat}} ...) filled from the document.
  | { applied: true; headers: number; footers: number; images: number; body?: boolean; fields?: string[] }
  | { applied: false; reason: string };

export type LegalDocumentPackage = {
  data: Buffer;
  text: string;
  replaced?: number;
  template?: LetterheadReport;
};

export type LegalDocumentRendererOptions = {
  python?: string;
  workerPath?: string;
  timeoutMs?: number;
};

function defaultWorkerPath():
  string {
  const here =
    path.dirname(
      fileURLToPath(
        import.meta.url
      )
    );
  return path.resolve(
    here,
    "../../storage/legal_document_worker.py"
  );
}

function letterheadReport(value: unknown): LetterheadReport | undefined {
  if (!value || typeof value !== "object") return undefined;
  const raw = value as Record<string, unknown>;
  if (raw.applied === true) {
    const count = (key: string) => (typeof raw[key] === "number" ? (raw[key] as number) : 0);
    const fields = Array.isArray(raw.fields) ? raw.fields.filter((item): item is string => typeof item === "string").slice(0, 20) : [];
    return {
      applied: true,
      headers: count("headers"),
      footers: count("footers"),
      images: count("images"),
      ...(raw.body === true ? { body: true } : {}),
      ...(fields.length ? { fields } : {})
    };
  }
  return { applied: false, reason: typeof raw.reason === "string" ? raw.reason.slice(0, 120) : "TEMPLATE_NOT_APPLIED" };
}

export class LocalLegalDocumentRenderer {
  private readonly python:
    string;
  private readonly workerPath:
    string;
  private readonly timeoutMs:
    number;

  constructor(
    options:
      LegalDocumentRendererOptions = {}
  ) {
    this.python =
      options.python ??
      process.env
        .LEX_STORAGE_PYTHON ??
      "python3";
    this.workerPath =
      options.workerPath ??
      process.env
        .LEX_LEGAL_DOCUMENT_WORKER ??
      defaultWorkerPath();
    this.timeoutMs =
      options.timeoutMs ??
      60_000;
  }

  async render(
    format:
      LegalDocumentFormat,
    ast:
      LegalDocumentAst,
    // The firm's template file (DOCX): its letterhead frames the generated body.
    template?: Uint8Array
  ): Promise<
    LegalDocumentPackage
  > {
    return await this.call({
      operation:
        "render",
      format,
      ast,
      ...(template ? { templateBase64: Buffer.from(template).toString("base64") } : {})
    });
  }

  async validate(
    format:
      LegalDocumentFormat,
    data:
      Uint8Array
  ): Promise<{
    text: string;
    bytes: number;
    aliases: number;
  }> {
    const result =
      await this.callRaw({
        operation:
          "validate",
        format,
        packageBase64:
          Buffer.from(data)
            .toString(
              "base64"
            )
      });
    if (
      typeof result.text !==
        "string" ||
      typeof result.bytes !==
        "number" ||
      typeof result.aliases !==
        "number"
    ) {
      throw new Error(
        "LEGAL_DOCUMENT_WORKER_RESPONSE_INVALID"
      );
    }
    return {
      text: result.text,
      bytes: result.bytes,
      aliases:
        result.aliases
    };
  }

  async extractStyleProfile(
    format:
      LegalDocumentFormat,
    data:
      Uint8Array
  ): Promise<{
    styleProfile:
      LegalStyleProfile;
    sourceFormat:
      LegalDocumentFormat;
    safe: true;
  }> {
    const result =
      await this.callRaw({
        operation:
          "profile",
        format,
        packageBase64:
          Buffer.from(data)
            .toString(
              "base64"
            )
      });
    if (
      ![
        "lex-classic-clean-v1",
        "lex-light-legal-design-v1",
        "lex-classic-tnr-v1"
      ].includes(
        String(
          result.styleProfile
        )
      ) ||
      result.sourceFormat !==
        format ||
      result.safe !== true
    ) {
      throw new Error(
        "LEGAL_DOCUMENT_PROFILE_INVALID"
      );
    }
    return {
      styleProfile:
        result.styleProfile as
          LegalStyleProfile,
      sourceFormat:
        format,
      safe: true
    };
  }

  async deanonymize(
    format:
      LegalDocumentFormat,
    data:
      Uint8Array,
    replacements:
      Map<string, string>
  ): Promise<
    LegalDocumentPackage
  > {
    return await this.call({
      operation:
        "deanonymize",
      format,
      packageBase64:
        Buffer.from(data)
          .toString(
            "base64"
          ),
      replacements:
        Object.fromEntries(
          replacements
        )
    });
  }

  private async call(
    input:
      Record<string, unknown>
  ): Promise<
    LegalDocumentPackage
  > {
    const result =
      await this.callRaw(
        input
      );
    if (
      typeof result
        .packageBase64 !==
        "string" ||
      typeof result.text !==
        "string" ||
      typeof result.bytes !==
        "number"
    ) {
      throw new Error(
        "LEGAL_DOCUMENT_WORKER_RESPONSE_INVALID"
      );
    }
    const data =
      Buffer.from(
        result.packageBase64,
        "base64"
      );
    if (
      data.byteLength !==
        result.bytes ||
      data.byteLength >
        64 * 1024 * 1024
    ) {
      data.fill(0);
      throw new Error(
        "LEGAL_DOCUMENT_WORKER_SIZE_MISMATCH"
      );
    }
    const template = letterheadReport(result.template);
    return {
      data,
      text:
        result.text,
      ...(typeof result.replaced ===
      "number"
        ? {
            replaced:
              result.replaced
          }
        : {}),
      ...(template ? { template } : {})
    };
  }

  private async callRaw(
    input:
      Record<string, unknown>
  ): Promise<
    Record<string, unknown>
  > {
    const request =
      Buffer.from(
        JSON.stringify(
          input
        ),
        "utf8"
      );
    if (
      request.byteLength >
        128 * 1024 * 1024
    ) {
      request.fill(0);
      throw new Error(
        "LEGAL_DOCUMENT_WORKER_INPUT_TOO_LARGE"
      );
    }

    try {
      return await new Promise(
        (
          resolve,
          reject
        ) => {
          const child =
            spawn(
              this.python,
              [
                this.workerPath
              ],
              {
                stdio: [
                  "pipe",
                  "pipe",
                  "pipe"
                ],
                env: {
                  ...process.env,
                  PYTHONUNBUFFERED:
                    "1"
                }
              }
            );
          const stdout:
            Buffer[] = [];
          let stdoutBytes =
            0;
          let stderr = "";
          let settled =
            false;

          const finish = (
            action:
              () => void
          ): void => {
            if (settled) {
              return;
            }
            settled = true;
            clearTimeout(
              timer
            );
            action();
          };

          const timer =
            setTimeout(
              () => {
                child.kill(
                  "SIGKILL"
                );
                finish(() =>
                  reject(
                    new Error(
                      "LEGAL_DOCUMENT_WORKER_TIMEOUT"
                    )
                  )
                );
              },
              this.timeoutMs
            );

          child.stdout.on(
            "data",
            (
              chunk:
                Buffer
            ) => {
              stdoutBytes +=
                chunk
                  .byteLength;
              if (
                stdoutBytes >
                  128 *
                    1024 *
                    1024
              ) {
                child.kill(
                  "SIGKILL"
                );
                finish(() =>
                  reject(
                    new Error(
                      "LEGAL_DOCUMENT_WORKER_OUTPUT_TOO_LARGE"
                    )
                  )
                );
                return;
              }
              stdout.push(
                Buffer.from(
                  chunk
                )
              );
            }
          );
          child.stderr.on(
            "data",
            (
              chunk:
                Buffer
            ) => {
              stderr +=
                chunk.toString(
                  "utf8"
                );
              if (
                stderr.length >
                  16_000
              ) {
                stderr =
                  stderr.slice(
                    -16_000
                  );
              }
            }
          );
          child.once(
            "error",
            (error) =>
              finish(() =>
                reject(
                  error
                )
              )
          );
          child.once(
            "exit",
            (code) =>
              finish(() => {
                if (
                  code !== 0
                ) {
                  reject(
                    new Error(
                      stderr
                        .trim()
                        .split(
                          "\n"
                        )
                        .pop() ||
                      "LEGAL_DOCUMENT_WORKER_FAILED"
                    )
                  );
                  return;
                }
                try {
                  const parsed =
                    JSON.parse(
                      Buffer.concat(
                        stdout
                      ).toString(
                        "utf8"
                      )
                    );
                  if (
                    !parsed ||
                    typeof parsed !==
                      "object" ||
                    Array.isArray(
                      parsed
                    )
                  ) {
                    throw new Error(
                      "LEGAL_DOCUMENT_WORKER_RESPONSE_INVALID"
                    );
                  }
                  resolve(
                    parsed as
                      Record<
                        string,
                        unknown
                      >
                  );
                } catch (
                  error
                ) {
                  reject(
                    error instanceof
                      Error
                      ? error
                      : new Error(
                          "LEGAL_DOCUMENT_WORKER_RESPONSE_INVALID"
                        )
                  );
                }
              })
          );
          child.stdin.once(
            "error",
            (error) =>
              finish(() =>
                reject(
                  error
                )
              )
          );
          child.stdin.end(
            request
          );
        }
      );
    } finally {
      request.fill(0);
    }
  }
}
