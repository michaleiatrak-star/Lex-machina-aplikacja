import { createHash } from "node:crypto";
import type { ProgressReporter } from "./processing-progress.js";

export type DocumentPageSourceName =
  | "DIGITAL"
  | "OCR"
  | "BLANK";

export type ExtractedDigitalPage = {
  page: number;
  text: string;
  // false: the page draws no image, so OCR has nothing to read.
  hasImages?: boolean;
  // A scan with another program's invisible OCR text over it (iLovePDF, scanner
  // software): its quality is unknown, so the local OCR reads the page again.
  ocrTextLayer?: boolean;
};

export type DocumentSourceExtraction = {
  bytes: number;
  pages: ExtractedDigitalPage[];
};

export interface DocumentPageSource {
  extract(data: Uint8Array): Promise<DocumentSourceExtraction>;
}

// One recognized line: text, recognition score and box on the page image.
export type OcrLine = {
  text: string;
  score?: number | null;
  box?: [number, number, number, number];
  // The line's outline on the page image (same scale as box): a line bent on a fold is no
  // rectangle, the preview frame and the masks follow it.
  poly?: Array<[number, number]>;
  // Read from a coloured stamp's own layer (paddle_worker split_stamp_ink), not from the letter.
  stamp?: boolean;
  // Straightened image of the line (base64 JPEG) for the local vision model; dropped
  // right after that step, never stored.
  crop?: string;
};

// The page as the OCR saw it (JPEG, base64) with the boxes of regions the
// OCR detected but could not read. Never sent anywhere as is: only a copy
// with personal data masked (document-evidence.ts) reaches a model.
export type OcrPageImage = {
  jpeg: string;
  width: number;
  height: number;
  unread: Array<[number, number, number, number]>;
};

export type OcrPageResult = {
  page: number;
  text: string;
  confidence?: number;
  lineCount?: number;
  engine?: string;
  lines?: OcrLine[];
  image?: OcrPageImage;
};

export interface OcrEngine {
  recognizePages(
    data: Uint8Array,
    pages: number[],
    // Called with the number of pages finished so far.
    onPage?: (done: number) => void
  ): Promise<OcrPageResult[]>;
}

export type IngestedPage = {
  page: number;
  text: string;
  source: DocumentPageSourceName;
  confidence?: number;
  lineCount?: number;
  engine?: string;
  lines?: OcrLine[];
  image?: OcrPageImage;
  // Words fixed by the local model after OCR (original kept here).
  corrections?: OcrCorrection[];
  // Text corrected by the user by hand (a poor scan); OCR lines no longer match it.
  editedByUser?: boolean;
  // Lines to check against the scan (handwriting, stamps, doubtful reading).
  review?: OcrReviewLine[];
  // The scan of a page whose text the user corrected by hand: shown next to the text in the
  // preview, never sent (it no longer matches the text, so it cannot be masked).
  scan?: OcrPageImage;
};

export type OcrReviewLine = {
  line: number;
  text: string;
  score?: number;
  reason: "LOW_CONFIDENCE" | "UNKNOWN_WORDS" | "GARBLED" | "STAMP";
};

// Put before a stamp's line in the page text (the same mark as the OCR worker's).
export const STAMP_MARK = "[PIECZĘĆ lub kolorowy tusz]";

/** A line of an OCR page as the page text carries it (a stamp's line marked). */
export function ocrLineText(line: Pick<OcrLine, "text" | "stamp">): string {
  return line.stamp ? `${STAMP_MARK} ${line.text}` : line.text;
}

// Lines of coloured stamps and ink (handwriting in colour) go to the review list
// (ocr-review.ts, reason STAMP), not into the page text: read apart from their own layer they
// are mostly noise a model would take as written (benchmark 2026-10-18: 10 such lines on a
// 7-page scan raised its CER from 2.3% to 5.8%). LEX_OCR_STAMP_TEXT=text keeps them in the text.
export function stampLinesInText(env: NodeJS.ProcessEnv = process.env): boolean {
  return env.LEX_OCR_STAMP_TEXT === "text";
}

/** The text of an OCR page from its lines. */
export function ocrPageText(lines: ReadonlyArray<Pick<OcrLine, "text" | "stamp">>): string {
  const stamps = stampLinesInText();
  return lines.filter((line) => stamps || !line.stamp).map(ocrLineText).join("\n");
}

export type OcrCorrection = {
  line: number;
  from: string;
  to: string;
};

export type DocumentChunk = {
  index: number;
  pageStart: number;
  pageEnd: number;
  text: string;
  sourceChars: number;
};

export type DocumentIngestionResult = {
  complete: true;
  sha256: string;
  bytes: number;
  totalPages: number;
  digitalPages: number;
  ocrPages: number;
  blankPages: number;
  sourceChars: number;
  pages: IngestedPage[];
  chunks: DocumentChunk[];
};

export type DocumentIngestionLimits = {
  maxBytes: number;
  maxPages: number;
  maxTotalChars: number;
  minDigitalCharsPerPage: number;
  maxChunkChars: number;
};

export const DEFAULT_DOCUMENT_INGESTION_LIMITS:
DocumentIngestionLimits = {
  maxBytes: 512 * 1024 * 1024,
  maxPages: 10_000,
  maxTotalChars: 100_000_000,
  minDigitalCharsPerPage: 40,
  maxChunkChars: 24_000
};

export class DocumentIngestionError extends Error {
  constructor(
    message: string,
    readonly code:
      | "DOCUMENT_TOO_LARGE"
      | "DOCUMENT_TOO_MANY_PAGES"
      | "DOCUMENT_TEXT_TOO_LARGE"
      | "OCR_REQUIRED"
      | "OCR_INCOMPLETE"
      | "PAGE_SEQUENCE_INVALID"
      | "CHUNKING_INCOMPLETE"
  ) {
    super(message);
    this.name = "DocumentIngestionError";
  }
}

function assertPageSequence(pages: ExtractedDigitalPage[]): void {
  for (let i = 0; i < pages.length; i += 1) {
    if (pages[i]?.page !== i + 1) {
      throw new DocumentIngestionError(
        "Document page extraction did not account for every page in order.",
        "PAGE_SEQUENCE_INVALID"
      );
    }
  }
}

function splitLosslessly(
  value: string,
  maxChars: number
): string[] {
  if (value.length <= maxChars) return [value];
  const parts: string[] = [];
  for (let offset = 0; offset < value.length; ) {
    let end = Math.min(value.length, offset + maxChars);
    if (end < value.length) {
      // Never inside a token ([PII:PERSON:0001|GEN], [LMPII:...]): split
      // in two, it is neither restored nor recognized as a placeholder.
      const open = value.lastIndexOf("[", end - 1);
      const token = open > offset ? /^\[(?:LMPII|PII):[^\]\s]*\]/.exec(value.slice(open, open + 64)) : null;
      if (token && open + token[0].length > end) end = open;
      // Never between the halves of a surrogate pair.
      else if (/[\uD800-\uDBFF]/.test(value[end - 1] ?? "") && end - 1 > offset) end -= 1;
    }
    parts.push(value.slice(offset, end));
    offset = end;
  }
  return parts;
}

export function chunkDocumentPages(
  pages: IngestedPage[],
  maxChunkChars: number
): DocumentChunk[] {
  if (maxChunkChars < 512) {
    throw new Error("maxChunkChars must be at least 512.");
  }

  const chunks: DocumentChunk[] = [];
  let buffer = "";
  let pageStart = 0;
  let pageEnd = 0;
  let sourceChars = 0;

  const flush = (): void => {
    if (!buffer) return;
    chunks.push({
      index: chunks.length + 1,
      pageStart,
      pageEnd,
      text: buffer,
      sourceChars
    });
    buffer = "";
    pageStart = 0;
    pageEnd = 0;
    sourceChars = 0;
  };

  for (const page of pages) {
    const headerReserve = 96;
    const fragmentLimit = Math.max(
      1,
      maxChunkChars - headerReserve
    );
    const parts = page.text
      ? splitLosslessly(page.text, fragmentLimit)
      : [""];

    for (let index = 0; index < parts.length; index += 1) {
      const part = parts[index] ?? "";
      const header =
        `[STRONA ${page.page}${parts.length > 1
          ? ` · CZĘŚĆ ${index + 1}/${parts.length}`
          : ""} · ${page.source}]\n`;
      const entry = header + part;
      const separator = buffer ? "\n\n" : "";

      if (
        buffer &&
        buffer.length + separator.length + entry.length >
          maxChunkChars
      ) {
        flush();
      }

      if (!buffer) {
        pageStart = page.page;
      }
      pageEnd = page.page;
      buffer += (buffer ? "\n\n" : "") + entry;
      sourceChars += part.length;
    }
  }

  flush();
  return chunks;
}

export class CompleteDocumentIngestor {
  constructor(
    private readonly pageSource: DocumentPageSource,
    private readonly ocr?: OcrEngine,
    private readonly limits: DocumentIngestionLimits =
      DEFAULT_DOCUMENT_INGESTION_LIMITS
  ) {}

  async ingest(
    data: Uint8Array,
    onProgress?: ProgressReporter
  ): Promise<DocumentIngestionResult> {
    if (data.byteLength > this.limits.maxBytes) {
      throw new DocumentIngestionError(
        "Document exceeds the configured byte safety limit.",
        "DOCUMENT_TOO_LARGE"
      );
    }

    const extracted = await this.pageSource.extract(data);
    if (extracted.pages.length > this.limits.maxPages) {
      throw new DocumentIngestionError(
        "Document exceeds the configured page safety limit.",
        "DOCUMENT_TOO_MANY_PAGES"
      );
    }
    assertPageSequence(extracted.pages);

    const ocrCandidates = extracted.pages
      .filter(
        (page) =>
          (page.text.trim().length <
            this.limits.minDigitalCharsPerPage &&
          page.hasImages !== false) ||
          // Re-read only when an engine exists; without one the foreign layer is kept.
          (page.ocrTextLayer === true && this.ocr !== undefined)
      )
      .map((page) => page.page);

    if (ocrCandidates.length > 0 && !this.ocr) {
      throw new DocumentIngestionError(
        `OCR is required for ${ocrCandidates.length} page(s), but no local OCR engine is configured.`,
        "OCR_REQUIRED"
      );
    }

    if (ocrCandidates.length) {
      onProgress?.({ stage: "OCR", done: 0, total: ocrCandidates.length, page: ocrCandidates[0]! });
    }
    const ocrResults = this.ocr && ocrCandidates.length
      ? await this.ocr.recognizePages(
          data,
          ocrCandidates,
          onProgress
            ? (done) =>
                onProgress({
                  stage: "OCR",
                  done,
                  total: ocrCandidates.length,
                  ...(done < ocrCandidates.length ? { page: ocrCandidates[done]! } : {})
                })
            : undefined
        )
      : [];

    const ocrByPage = new Map(
      ocrResults.map((result) => [result.page, result])
    );

    for (const page of ocrCandidates) {
      if (!ocrByPage.has(page)) {
        throw new DocumentIngestionError(
          `OCR did not return an accounted result for page ${page}.`,
          "OCR_INCOMPLETE"
        );
      }
    }

    const pages: IngestedPage[] = extracted.pages.map((page) => {
      const digital = page.text.trim();
      const ocr = ocrByPage.get(page.page);
      const ocrText = ocr?.text.trim() ?? "";

      // A foreign OCR layer gives way to the local engine's reading (line scores, boxes for
      // masking the page image); a real digital layer gives way only to a longer OCR text.
      const preferOcr = page.ocrTextLayer === true && ocrText.length > 0;
      if (ocr && (preferOcr || ocrText.length > digital.length)) {
        return {
          page: page.page,
          text: ocrText,
          source: "OCR" as const,
          ...(ocr.confidence !== undefined
            ? { confidence: ocr.confidence }
            : {}),
          ...(ocr.lineCount !== undefined
            ? { lineCount: ocr.lineCount }
            : {}),
          ...(ocr.engine ? { engine: ocr.engine } : {}),
          ...(ocr.lines ? { lines: ocr.lines } : {}),
          ...(ocr.image ? { image: ocr.image } : {})
        };
      }

      if (digital) {
        return {
          page: page.page,
          text: digital,
          source: "DIGITAL" as const
        };
      }

      return {
        page: page.page,
        text: ocrText,
        source: ocrText ? "OCR" as const : "BLANK" as const,
        ...(ocr?.confidence !== undefined
          ? { confidence: ocr.confidence }
          : {}),
        ...(ocr?.lineCount !== undefined
          ? { lineCount: ocr.lineCount }
          : {}),
        ...(ocr?.engine ? { engine: ocr.engine } : {}),
        ...(ocrText && ocr?.lines ? { lines: ocr.lines } : {}),
        ...(ocrText && ocr?.image ? { image: ocr.image } : {})
      };
    });

    const sourceChars = pages.reduce(
      (sum, page) => sum + page.text.length,
      0
    );
    if (sourceChars > this.limits.maxTotalChars) {
      throw new DocumentIngestionError(
        "Document text exceeds the configured character safety limit.",
        "DOCUMENT_TEXT_TOO_LARGE"
      );
    }

    const chunks = chunkDocumentPages(
      pages,
      this.limits.maxChunkChars
    );
    const chunkSourceChars = chunks.reduce(
      (sum, chunk) => sum + chunk.sourceChars,
      0
    );
    if (chunkSourceChars !== sourceChars) {
      throw new DocumentIngestionError(
        "Chunking did not preserve the complete source character count.",
        "CHUNKING_INCOMPLETE"
      );
    }

    const accountedPages = new Set<number>();
    for (const chunk of chunks) {
      for (
        let page = chunk.pageStart;
        page <= chunk.pageEnd;
        page += 1
      ) {
        accountedPages.add(page);
      }
    }
    if (accountedPages.size !== pages.length) {
      throw new DocumentIngestionError(
        "Chunking did not account for every document page.",
        "CHUNKING_INCOMPLETE"
      );
    }

    return {
      complete: true,
      sha256: createHash("sha256").update(data).digest("hex"),
      bytes: extracted.bytes,
      totalPages: pages.length,
      digitalPages: pages.filter((p) => p.source === "DIGITAL").length,
      ocrPages: pages.filter((p) => p.source === "OCR").length,
      blankPages: pages.filter((p) => p.source === "BLANK").length,
      sourceChars,
      pages,
      chunks
    };
  }
}
