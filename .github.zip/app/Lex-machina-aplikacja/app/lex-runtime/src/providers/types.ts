export type ProviderId = "openai" | "anthropic" | "xai" | "google";

export type ReasoningLevel =
  | "none"
  | "low"
  | "medium"
  | "high"
  | "xhigh"
  | "max";

export type ProviderCapabilities = {
  streaming: boolean;
  tools: boolean;
  reasoning: boolean;
  modelDiscovery: boolean;
};

// A page image sent with a message (masked evidence; models with vision).
export type LlmImage = {
  mediaType: "image/jpeg" | "image/png";
  // base64
  data: string;
};

export type LlmMessage = {
  role: "user" | "assistant";
  content: string;
  images?: LlmImage[];
};

export type NormalizedToolSchema = {
  type: "function";
  function: {
    name: string;
    description: string;
    parameters: Record<string, unknown>;
  };
};

export type NormalizedToolCall = {
  id: string;
  name: string;
  input: Record<string, unknown>;
};

export type NormalizedToolResult = {
  tool_use_id: string;
  content: string;
};

export type StreamCallbacks = {
  onReasoningDelta?: (text: string) => void;
  onReasoningBlockEnd?: () => void;
  onContentDelta?: (text: string) => void;
  onToolCallStart?: (call: NormalizedToolCall) => void;
};

export type ProviderStreamParams = {
  model: string;
  systemPrompt: string;
  messages: LlmMessage[];
  continuityKey?: string;
  // Account sessions (ChatGPT/Claude/Grok CLI): "none" = a fresh host session that
  // neither resumes nor records a thread. For self-contained calls (skill router,
  // document generator) whose prompt already carries the whole context.
  accountContinuity?: "none";
  // Anthropic API prompt cache lifetime of the shared system prefix (systemPromptCachePrefix).
  // "1h" for checkpoint workflows: the next checkpoint of the same matter (often after more
  // than five minutes) reads it from the cache. The rest of the prompt is cached for five
  // minutes (a 1-hour write costs twice the input price).
  promptCacheTtl?: "5m" | "1h";
  // Length of the system prompt's part that is the same for every checkpoint of one
  // workflow (the rest is the checkpoint's own files and state). Anthropic API: the two
  // parts go as separate system blocks with a cache breakpoint after the first, so the
  // next checkpoint reads it from the cache although its own part differs.
  systemPromptCachePrefix?: number;
  // Shorter part of that prefix shared by every question whatever its domain (instructions,
  // catalog, router core): a breakpoint after it too, so a question of another domain reads it
  // from the cache instead of writing the whole prefix again.
  systemPromptSharedPrefix?: number;
  // Same for every request sharing that prefix (a hash of it): OpenAI routes such requests
  // to the same cache (prompt_cache_key), xAI by its conversation header (x-grok-conv-id).
  promptCacheKey?: string;
  tools?: NormalizedToolSchema[];
  // "none": the tools stay defined (the cached prefix of the main call matches) but cannot be
  // called (a correcting round over the main call's prompt).
  toolChoice?: "none";
  maxIterations?: number;
  callbacks?: StreamCallbacks;
  runTools?: (
    calls: NormalizedToolCall[]
  ) => Promise<NormalizedToolResult[]>;
  reasoning?: ReasoningLevel;
  /**
   * Internal Lex local-runtime transport preference. Cloud/account adapters
   * ignore this field. "json" intentionally bypasses SSE for tiny local
   * smoke/conversation requests.
   */
  localTransport?: "stream" | "json";
  localMaxOutputTokens?: number;
  abortSignal?: AbortSignal;
  /**
   * Read-only access to the legal skill corpus for a model CLI that can
   * confine its own file tools to one directory (Claude account session):
   * skills and all their subfolders are read natively in one CLI run, and
   * `tools` are served over MCP. Other adapters ignore it.
   */
  nativeCorpus?: NativeCorpusAccess;
};

export type NativeCorpusAccess = {
  root: string;
  // Relative path of every corpus file the model read (audit).
  onRead?: (relativePath: string) => void;
  // A Read of a corpus file that does not exist (wrong name, version or folder).
  onMissing?: (relativePath: string) => void;
};

export type ProviderStreamResult = {
  fullText: string;
  // Tokens of the whole call, when the adapter can tell (API keys).
  usage?: { inputTokens: number; outputTokens: number; cacheReadTokens?: number; cacheWriteTokens?: number };
};

export interface ProviderAdapter {
  readonly id: ProviderId;
  readonly label: string;
  readonly capabilities: ProviderCapabilities;
  stream(params: ProviderStreamParams): Promise<ProviderStreamResult>;
  listModels?(): Promise<string[]>;
  // True when this model reads the skill corpus with its own confined file tools.
  nativeCorpusAccess?(model: string): boolean;
  // True when images in messages reach this model.
  supportsImages?(model: string): boolean;
}
