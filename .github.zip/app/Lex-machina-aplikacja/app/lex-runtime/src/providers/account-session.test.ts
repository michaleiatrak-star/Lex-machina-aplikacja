import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { afterEach, describe, expect, it } from "vitest";
import {
  accountLoginArgs,
  accountLoginFallbackArgs,
  accountLoginLaunchMode,
  macLoginScript,
  accountSessionModelId,
  accountSessionResumeMode,
  claudeAutomationCredentialMode,
  claudeHeadlessArgs,
  claudeResultReady,
  claudeSubscriptionAuthenticated,
  classifyAccountCliFailureDetail,
  codexExecArgs,
  codexStoredAuthIsChatGpt,
  discoverLatestClaudeSessionId,
  isAccountSessionModel,
  isMissingResumableSessionMessage,
  mergeWindowsCommandPath,
  nativeClaudeExecutable,
  openAiChatGptAuthenticated,
  parseClaudeResult,
  pickResolvedCommand,
  sanitizeAccountCliFailureDetail,
  visibleWindowsLoginLauncher
} from "./account-session.js";

const cleanupRoots: string[] = [];

afterEach(() => {
  delete process.env.LEX_CLAUDE_SESSIONS_ROOT;
  for (
    const root
    of cleanupRoots.splice(0)
  ) {
    fs.rmSync(
      root,
      {
        recursive: true,
        force: true
      }
    );
  }
});

describe("provider account-session transport", () => {
  it("uses isolated pseudo-model ids for each account lane", () => {
    expect(
      accountSessionModelId(
        "openai"
      )
    ).toBe(
      "account/openai/default"
    );
    expect(
      accountSessionModelId(
        "anthropic"
      )
    ).toBe(
      "account/anthropic/default"
    );
    expect(
      accountSessionModelId(
        "xai"
      )
    ).toBe(
      "account/xai/default"
    );
  });


  it("keeps Claude continuity inside Lex while preserving legacy resume for other account lanes", () => {
    expect(accountSessionResumeMode("anthropic")).toBe("LEX_CONTEXT_ONLY");
    expect(accountSessionResumeMode("openai")).toBe("LAST_OR_NEW");
    expect(accountSessionResumeMode("xai")).toBe("LAST_OR_NEW");
  });

  it("pins Codex account execution to a ChatGPT-compatible model and isolated persistent config", () => {
    const args =
      codexExecArgs(
        "C:\\Lex Work",
        "C:\\Lex Work\\last.txt"
      );

    expect(args).not.toContain(
      "--ephemeral"
    );
    expect(args).toContain(
      "gpt-5.6-luna"
    );
    expect(args).toContain(
      "--ignore-user-config"
    );
    expect(args).toContain(
      "--ignore-rules"
    );
    expect(args).toContain(
      "mcp_servers={}"
    );
    expect(args).toContain(
      "read-only"
    );
    expect(
      args.some(
        (value) =>
          value.startsWith(
            "features."
          )
      )
    ).toBe(false);
  });

  it("maps Codex CLI failures to actionable account-session reasons", () => {
    expect(
      classifyAccountCliFailureDetail(
        "The 'gpt-6-astra' model is not supported when using Codex with a ChatGPT account."
      )
    ).toBe(
      "ACCOUNT_SESSION_MODEL_UNSUPPORTED"
    );
    expect(
      classifyAccountCliFailureDetail(
        "HTTP 401 unauthorized; login required"
      )
    ).toBe(
      "ACCOUNT_SESSION_AUTH_EXPIRED"
    );
    expect(
      classifyAccountCliFailureDetail(
        "error: unrecognized option '--legacy-flag'"
      )
    ).toBe(
      "ACCOUNT_SESSION_CLI_INCOMPATIBLE"
    );
  });

  it("uses stdin as the complete Claude headless prompt and keeps tools disabled", () => {
    const args = claudeHeadlessArgs("lex-system");
    expect(args[0]).toBe("-p");
    expect(args[1]).toBe("--output-format");
    expect(args[2]).toBe("stream-json");
    expect(args).toContain("--verbose");
    expect(args).toContain("--restricted");
    expect(args).toContain("--strict-mcp-config");
    expect(args).not.toContain("--mcp-config");
    expect(args).toContain("mcp__*");
    expect(args).toContain("lex-system");
  });

  it("settles on the Claude stream-json result line before the process exits", () => {
    const init =
      '{"type":"system","subtype":"init","session_id":"s-1"}\n';
    expect(claudeResultReady(init)).toBe(false);
    const done =
      init +
      '{"type":"result","subtype":"success","is_error":false,"result":" OK ","session_id":"s-1"}\n';
    expect(claudeResultReady(done)).toBe(true);
    expect(parseClaudeResult(done)).toEqual({
      text: "OK",
      sessionId: "s-1",
      isError: false
    });
  });

  it("keeps the legacy single-object Claude json result readable", () => {
    expect(
      parseClaudeResult(
        '{"result":"OK","session_id":"s-2"}'
      )
    ).toEqual({
      text: "OK",
      sessionId: "s-2",
      isError: false
    });
  });

  it("surfaces Claude error results so a stale resume can fall back", () => {
    const parsed = parseClaudeResult(
      '{"type":"result","subtype":"error_during_execution","is_error":true,"errors":["No conversation found with session ID: x"],"session_id":"x"}\n'
    );
    expect(parsed?.isError).toBe(true);
    expect(
      isMissingResumableSessionMessage(
        parsed?.text ?? ""
      )
    ).toBe(true);
  });

  it("never picks the extensionless npm shim that where.exe lists first on Windows", () => {
    const output = [
      "C:\\Users\\u\\AppData\\Roaming\\npm\\claude",
      "C:\\Users\\u\\AppData\\Roaming\\npm\\claude.cmd",
      ""
    ].join("\r\n");
    expect(pickResolvedCommand(output, "win32")).toBe(
      "C:\\Users\\u\\AppData\\Roaming\\npm\\claude.cmd"
    );
    expect(
      pickResolvedCommand(
        "C:\\x\\claude\r\nC:\\Users\\u\\.local\\bin\\claude.exe\r\n",
        "win32"
      )
    ).toBe("C:\\Users\\u\\.local\\bin\\claude.exe");
    expect(pickResolvedCommand("C:\\x\\claude\r\n", "win32")).toBeNull();
    expect(pickResolvedCommand("/usr/bin/claude\n", "linux")).toBe("/usr/bin/claude");
  });

  it("resolves claude.exe behind an npm global shim", () => {
    const root = fs.mkdtempSync(
      path.join(os.tmpdir(), "lex-claude-global-")
    );
    cleanupRoots.push(root);
    const shim = path.join(root, "claude.cmd");
    fs.writeFileSync(shim, "@echo off\r\n");
    const nativeDir = path.join(
      root,
      "node_modules",
      "@anthropic-ai",
      "claude-code",
      "bin"
    );
    fs.mkdirSync(nativeDir, { recursive: true });
    const native = path.join(nativeDir, "claude.exe");
    fs.writeFileSync(native, Buffer.alloc(2 * 1024 * 1024));
    expect(
      path.resolve(nativeClaudeExecutable(shim, "win32"))
    ).toBe(path.resolve(native));
  });

  it("runs the native claude.exe instead of the npm cmd shim on Windows", () => {
    const root = fs.mkdtempSync(
      path.join(os.tmpdir(), "lex-claude-native-")
    );
    cleanupRoots.push(root);
    const binDir = path.join(root, "node_modules", ".bin");
    const nativeDir = path.join(
      root,
      "node_modules",
      "@anthropic-ai",
      "claude-code",
      "bin"
    );
    fs.mkdirSync(binDir, { recursive: true });
    fs.mkdirSync(nativeDir, { recursive: true });
    const shim = path.join(binDir, "claude.cmd");
    fs.writeFileSync(shim, "@echo off\r\n");
    const native = path.join(nativeDir, "claude.exe");

    fs.writeFileSync(native, "stub");
    expect(nativeClaudeExecutable(shim, "win32")).toBe(shim);

    fs.writeFileSync(native, Buffer.alloc(2 * 1024 * 1024));
    expect(
      path.resolve(nativeClaudeExecutable(shim, "win32"))
    ).toBe(path.resolve(native));
    expect(nativeClaudeExecutable(shim, "linux")).toBe(shim);
  });

  it("classifies common Claude OAuth failures and redacts secrets from diagnostics", () => {
    expect(
      classifyAccountCliFailureDetail(
        "OAuth session expired and could not be refreshed"
      )
    ).toBe("ACCOUNT_SESSION_AUTH_EXPIRED");
    const sanitized = sanitizeAccountCliFailureDetail(
      "Authorization: Bearer abcdefghijklmnopqrstuvwxyz0123456789 token sk-ant-oat01-supersecret"
    );
    expect(sanitized).not.toContain("supersecret");
    expect(sanitized).toContain("[REDACTED_TOKEN]");
  });

  it("uses current interactive login commands for account providers", () => {
    expect(
      accountLoginArgs(
        "openai"
      )
    ).toEqual([
      "login"
    ]);
    expect(
      accountLoginFallbackArgs(
        "openai"
      )
    ).toEqual([
      "login",
      "--device-auth"
    ]);
    expect(
      accountLoginArgs(
        "anthropic"
      )
    ).toEqual([
      "auth",
      "login"
    ]);
    expect(
      accountLoginFallbackArgs(
        "anthropic"
      )
    ).toEqual([
      "auth",
      "login",
      "--claudeai"
    ]);
    expect(
      accountLoginArgs(
        "xai"
      )
    ).toEqual([
      "login"
    ]);
  });

  // Zgłoszenie 2026-10-09 (macOS): Gemini CLI bez okna terminala kończył się przed
  // logowaniem Google; na macOS loguje się w oknie Terminala.
  it("signs in to Gemini in a Terminal window on macOS", async () => {
    expect(accountLoginLaunchMode("google", "darwin")).toBe("VISIBLE_TERMINAL");
    expect(accountLoginLaunchMode("anthropic", "darwin")).toBe("CAPTURED");
    expect(accountLoginLaunchMode("openai", "darwin")).toBe("CAPTURED");
    const script = macLoginScript({
      provider: "google",
      executable: "/Users/o'brien/Library/LexMachina/gemini",
      loginArgs: [],
      exitFile: "/tmp/lex login/exit-code",
      env: { PATH: "/opt/lex/node/bin:/usr/bin", GEMINI_CLI_NO_RELAUNCH: "true", GEMINI_API_KEY: "secret", LEX_DESKTOP_BOOTSTRAP_TOKEN: "token" }
    });
    expect(script).toContain("export PATH='/opt/lex/node/bin:/usr/bin'");
    expect(script).toContain("export GEMINI_CLI_NO_RELAUNCH='true'");
    expect(script).toContain("unset GEMINI_API_KEY");
    expect(script).not.toMatch(/secret|token'/);
    expect(script).toContain("'/Users/o'\\''brien/Library/LexMachina/gemini'");
    expect(script).toContain("> '/tmp/lex login/exit-code'");
    const { spawnSync } = await import("node:child_process");
    expect(spawnSync("/bin/bash", ["-n"], { input: script }).status).toBe(0);
  });

  it("launches Claude subscription OAuth in a visible Windows terminal", () => {
    expect(
      accountLoginLaunchMode(
        "anthropic",
        "win32"
      )
    ).toBe(
      "VISIBLE_TERMINAL"
    );
    expect(
      accountLoginLaunchMode(
        "openai",
        "win32"
      )
    ).toBe(
      "VISIBLE_TERMINAL"
    );
    expect(
      accountLoginLaunchMode(
        "xai",
        "win32"
      )
    ).toBe(
      "VISIBLE_TERMINAL"
    );
    expect(
      accountLoginLaunchMode(
        "anthropic",
        "linux"
      )
    ).toBe(
      "CAPTURED"
    );
  });

  it("merges refreshed Windows PATH entries without losing the running process path", () => {
    expect(
      mergeWindowsCommandPath(
        "C:\\Lex\\Runtime;C:\\Windows\\System32",
        "C:\\Windows\\System32;C:\\Program Files\\Node",
        "C:\\Users\\Tester\\.local\\bin;C:\\Users\\Tester\\AppData\\Roaming\\npm"
      )
    ).toBe(
      "C:\\Lex\\Runtime;C:\\Windows\\System32;C:\\Program Files\\Node;C:\\Users\\Tester\\.local\\bin;C:\\Users\\Tester\\AppData\\Roaming\\npm"
    );
  });

  it("creates a normal visible Windows console for interactive account login", () => {
    const launcher =
      visibleWindowsLoginLauncher(
        "C:\\Users\\Tester\\login.cmd"
      );
    expect(
      launcher
    ).toContain(
      "Start-Process"
    );
    expect(
      launcher
    ).toContain(
      "-WindowStyle Normal"
    );
    expect(
      launcher
    ).toContain(
      "-PassThru -Wait"
    );
  });

  it("falls back to a new host session only for missing-session failures", () => {
    expect(
      isMissingResumableSessionMessage(
        "No saved session found"
      )
    ).toBe(true);
    expect(
      isMissingResumableSessionMessage(
        "conversation not found"
      )
    ).toBe(true);
    expect(
      isMissingResumableSessionMessage(
        "network connection failed"
      )
    ).toBe(false);
  });

  it("distinguishes Claude setup-token and refresh-token automation credentials from interactive login", () => {
    expect(
      claudeAutomationCredentialMode({
        CLAUDE_CODE_OAUTH_TOKEN:
          "oauth-access-token"
      })
    ).toBe(
      "ACCESS_TOKEN"
    );
    expect(
      claudeAutomationCredentialMode({
        CLAUDE_CODE_OAUTH_REFRESH_TOKEN:
          "oauth-refresh-token",
        CLAUDE_CODE_OAUTH_SCOPES:
          "user:profile user:inference user:sessions:claude_code"
      })
    ).toBe(
      "REFRESH_TOKEN"
    );
    expect(
      claudeAutomationCredentialMode({})
    ).toBe(
      "INTERACTIVE"
    );
  });

  it("recognizes persisted ChatGPT auth metadata without reading token values", () => {
    expect(
      codexStoredAuthIsChatGpt(
        JSON.stringify({
          auth_mode:
            "chatgpt",
          tokens: {
            access_token:
              "redacted"
          }
        })
      )
    ).toBe(true);
    expect(
      codexStoredAuthIsChatGpt(
        JSON.stringify({
          auth_mode:
            "api",
          OPENAI_API_KEY:
            "redacted"
        })
      )
    ).toBe(false);
    // Realny kształt auth.json oficjalnego klienta Codex po logowaniu ChatGPT:
    // obiekt `tokens` z OAuth, BEZ pola `auth_mode` (zgł. użytkownika 2026-10-07 —
    // wcześniej rozpoznawane jako niezalogowane mimo udanego loginu w przeglądarce).
    expect(
      codexStoredAuthIsChatGpt(
        JSON.stringify({
          OPENAI_API_KEY: null,
          tokens: {
            id_token: "redacted",
            access_token: "redacted",
            refresh_token: "redacted",
            account_id: "acct_redacted"
          },
          last_refresh: "2026-10-07T17:00:00Z"
        })
      )
    ).toBe(true);
    // Sam klucz API (bez tokenów OAuth) subskrypcją ChatGPT nie jest.
    expect(
      codexStoredAuthIsChatGpt(
        JSON.stringify({
          OPENAI_API_KEY: "sk-redacted",
          tokens: null
        })
      )
    ).toBe(false);
    expect(
      codexStoredAuthIsChatGpt(
        "not-json"
      )
    ).toBe(false);
  });

  it("recognizes ChatGPT auth status without accepting API-key login", () => {
    expect(
      openAiChatGptAuthenticated({
        code: 0,
        stdout:
          "Logged in using ChatGPT",
        stderr: ""
      })
    ).toBe(true);
    expect(
      openAiChatGptAuthenticated({
        code: 0,
        stdout:
          "Signed in with ChatGPT",
        stderr: ""
      })
    ).toBe(true);
    expect(
      openAiChatGptAuthenticated({
        code: 0,
        stdout:
          "Logged in using API key",
        stderr: ""
      })
    ).toBe(false);
  });

  it("trusts the official Claude auth status exit code across status formats", () => {
    expect(
      claudeSubscriptionAuthenticated({
        code: 0,
        stdout: JSON.stringify({
          loggedIn: true,
          authMethod: "oauth_token",
          apiProvider: "firstParty"
        }),
        stderr: ""
      })
    ).toBe(true);

    expect(
      claudeSubscriptionAuthenticated({
        code: 0,
        stdout:
          "Login method: Claude Max account\nOrganization: Test\n",
        stderr: ""
      })
    ).toBe(true);

    expect(
      claudeSubscriptionAuthenticated({
        code: 0,
        stdout:
          "Profile: credentials-file · user_oauth · profile default",
        stderr: ""
      })
    ).toBe(true);

    expect(
      claudeSubscriptionAuthenticated({
        code: 0,
        stdout: JSON.stringify({
          loggedIn: true,
          authMethod: "none",
          apiProvider: "firstParty"
        }),
        stderr: ""
      })
    ).toBe(true);

    expect(
      claudeSubscriptionAuthenticated({
        code: 1,
        stdout: JSON.stringify({
          loggedIn: false
        }),
        stderr: ""
      })
    ).toBe(false);

    expect(
      claudeSubscriptionAuthenticated({
        code: 0,
        stdout:
          "Logged in via Anthropic Console",
        stderr: ""
      })
    ).toBe(true);

    expect(
      claudeSubscriptionAuthenticated({
        code: 0,
        stdout: JSON.stringify({
          loggedIn: true,
          authMethod: "api_key",
          apiProvider: "firstParty"
        }),
        stderr: ""
      })
    ).toBe(true);
  });

  it("discovers the newest Claude Code session id without reading transcript content", async () => {
    const root =
      fs.mkdtempSync(
        path.join(
          os.tmpdir(),
          "lex-claude-sessions-"
        )
      );
    cleanupRoots.push(root);
    process.env.LEX_CLAUDE_SESSIONS_ROOT =
      root;

    const firstProject =
      path.join(root, "project-a");
    const secondProject =
      path.join(root, "project-b");
    fs.mkdirSync(
      firstProject,
      {
        recursive: true
      }
    );
    fs.mkdirSync(
      secondProject,
      {
        recursive: true
      }
    );

    const older =
      "11111111-1111-4111-8111-111111111111";
    const newer =
      "22222222-2222-4222-8222-222222222222";
    const olderPath =
      path.join(
        firstProject,
        older + ".jsonl"
      );
    const newerPath =
      path.join(
        secondProject,
        newer + ".jsonl"
      );
    fs.writeFileSync(
      olderPath,
      "do-not-read"
    );
    fs.writeFileSync(
      newerPath,
      "do-not-read"
    );
    fs.utimesSync(
      olderPath,
      new Date(1_000),
      new Date(1_000)
    );
    fs.utimesSync(
      newerPath,
      new Date(2_000),
      new Date(2_000)
    );

    expect(
      await discoverLatestClaudeSessionId()
    ).toBe(newer);
  });

  it("does not confuse API or local models with account-session models", () => {
    expect(
      isAccountSessionModel(
        "openai",
        "account/openai/default"
      )
    ).toBe(true);
    expect(
      isAccountSessionModel(
        "openai",
        "gpt-5"
      )
    ).toBe(false);
    expect(
      isAccountSessionModel(
        "openai",
        "local/mistral-nemo-12b-q4km"
      )
    ).toBe(false);
    expect(
      isAccountSessionModel(
        "anthropic",
        "account/openai/default"
      )
    ).toBe(false);
  });
});

describe("Claude account plan limit", () => {
  it("is the account's capacity, not an unknown CLI failure (RD 121/26)", async () => {
    const { classifyAccountCliFailureDetail, isTransientRateLimit } = await import("./account-session.js");
    expect(classifyAccountCliFailureDetail("You've hit your 5-hour limit · resets 12:30am (UTC)")).toBe("ACCOUNT_SESSION_CAPACITY");
    expect(classifyAccountCliFailureDetail("You've hit your weekly limit · resets Mon 9am")).toBe("ACCOUNT_SESSION_CAPACITY");
    // Not retried in the turn: it renews hours later.
    expect(isTransientRateLimit(new Error("ACCOUNT_SESSION_CAPACITY:anthropic:1:You've hit your 5-hour limit · resets 12:30am (UTC)"))).toBe(false);
  });
});

describe("Grok ACP failures", () => {
  it("codes a bare rate-limit message and keeps coded errors", async () => {
    const { codedGrokFailure, isTransientRateLimit } = await import("./account-session.js");
    const coded = codedGrokFailure(new Error("Rate limited"));
    expect(coded.message).toBe("ACCOUNT_SESSION_CAPACITY:xai:1:Rate limited");
    expect(isTransientRateLimit(coded)).toBe(true);
    const kept = new Error("ACCOUNT_SESSION_EMPTY_RESPONSE:xai");
    expect(codedGrokFailure(kept)).toBe(kept);
    // A used-up plan quota is not worth waiting for.
    expect(isTransientRateLimit(new Error("ACCOUNT_SESSION_CAPACITY:openai:1:You've hit your usage limit"))).toBe(false);
  });
});
