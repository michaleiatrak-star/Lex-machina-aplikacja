import { reportUsage } from "./usage-meter.js";
import type {
  ProviderAdapter,
  ProviderId,
  ProviderStreamParams,
  ProviderStreamResult
} from "./types.js";

export type ProviderFailureCode =
  | "UNKNOWN_PROVIDER"
  | "TOOLS_UNSUPPORTED"
  | "REASONING_UNSUPPORTED"
  | "ACCOUNT_POLICY"
  | "PROVIDER_ERROR";

export class ProviderGatewayError extends Error {
  constructor(
    readonly code: ProviderFailureCode,
    message: string,
    readonly provider?: ProviderId,
    readonly causeValue?: unknown
  ) {
    super(message);
    this.name = "ProviderGatewayError";
  }
}

export class ProviderRegistry {
  private readonly providers = new Map<ProviderId, ProviderAdapter>();

  register(adapter: ProviderAdapter): void {
    if (this.providers.has(adapter.id)) {
      throw new Error(`Provider already registered: ${adapter.id}`);
    }
    this.providers.set(adapter.id, adapter);
  }

  get(id: ProviderId): ProviderAdapter | undefined {
    return this.providers.get(id);
  }

  list(): ProviderAdapter[] {
    return [...this.providers.values()];
  }
}

/**
 * Server mode: checks an account's plan before each model call (throws with a
 * reason code as message) and records the tokens after it. Without an account
 * scope (desktop, background work) both are no-ops.
 */
export interface ModelCallGuard {
  beforeCall(providerId: ProviderId, model: string): void;
  afterCall(providerId: ProviderId, model: string, usage: ProviderStreamResult["usage"] | null): void;
}

export class ProviderGateway {
  constructor(
    private readonly registry: ProviderRegistry,
    private readonly guard?: ModelCallGuard
  ) {}

  nativeCorpusAccess(providerId: ProviderId, model: string): boolean {
    return this.registry.get(providerId)?.nativeCorpusAccess?.(model) === true;
  }

  supportsImages(providerId: ProviderId, model: string): boolean {
    return this.registry.get(providerId)?.supportsImages?.(model) === true;
  }

  async stream(
    providerId: ProviderId,
    params: ProviderStreamParams
  ): Promise<ProviderStreamResult> {
    const provider = this.registry.get(providerId);
    if (!provider) {
      throw new ProviderGatewayError(
        "UNKNOWN_PROVIDER",
        `Provider is not registered: ${providerId}`,
        providerId
      );
    }

    if (params.tools?.length && !provider.capabilities.tools) {
      throw new ProviderGatewayError(
        "TOOLS_UNSUPPORTED",
        `Provider ${providerId} does not support tool calling.`,
        providerId
      );
    }

    if (
      params.reasoning &&
      params.reasoning !== "none" &&
      !provider.capabilities.reasoning
    ) {
      throw new ProviderGatewayError(
        "REASONING_UNSUPPORTED",
        `Provider ${providerId} does not support reasoning controls.`,
        providerId
      );
    }

    if (this.guard) {
      try {
        this.guard.beforeCall(providerId, params.model);
      } catch (error) {
        throw new ProviderGatewayError(
          "ACCOUNT_POLICY",
          error instanceof Error ? error.message : String(error),
          providerId,
          error
        );
      }
    }

    try {
      const result = await provider.stream(params);
      reportUsage(result.usage ?? null);
      this.guard?.afterCall(providerId, params.model, result.usage ?? null);
      return result;
    } catch (error) {
      if (error instanceof ProviderGatewayError) throw error;
      throw new ProviderGatewayError(
        "PROVIDER_ERROR",
        error instanceof Error ? error.message : String(error),
        providerId,
        error
      );
    }
  }
}
