import fs from "node:fs";
import { flashDomains, fold, parseFlashRouting, type FlashRoute } from "./domain-module-map.js";
import { provisionsForDetection } from "./legal-act-abbreviations.js";
import { criminalMatter } from "./matter-signals.js";
import { laterTurn } from "./skill-sections.js";
import type { LexSkillRegistry } from "./registry.js";
import { requestOf, withoutRoutingMarkers } from "./request-intent.js";
import { latestUserTurn, threadUserText } from "./skill-selection.js";

/**
 * Legal gate at the entry of a chat turn (every provider): a message with no legal
 * signal at all ("jak upiec sernik", "napisz funkcję w Pythonie") is answered in the
 * conversational lane, without the router, legal skills and the mandatory path.
 * Deliberately one-sided: any legal word, intent, routing phrase or legal thread
 * keeps the full legal path. Doubt is legal.
 */

// Stems of folded words (no diacritics) that name a legal matter, an authority or a
// conflict a client brings to a lawyer. Matched at the start of a word.
const LEGAL_STEMS = [
  // "praw" is rights and law, not "prawie" (almost), "prawda", "prawdziwy", "prawidłowy", "prawa ręka".
  "praw(?!d|ie(?![a-z])|ic|idlow|ej (?:rek|stron|nog)|a (?:reka|strona|noga)|o (?:jazdy )?(?:reki|strony))", "prawn", "prawni", "ustaw(?!ic|ien|il|ia[cl]|ion)", "kodeks", "przepis(?!\\s+na\\b)", "paragraf", "artykul", "rozporzadz", "dyrektyw", "konstytuc",
  "sad(?!zic|zi\\b|zil|zon|zen|zaw|ownik\\b)", "sedzi", "wyrok", "postanowieni", "pozew", "pozw", "apelac", "zazaleni", "skarg", "odwola", "sprzeciw", "kasac",
  "rozpraw", "proces", "pelnomocni", "adwokat", "radc", "notariu", "komorni", "mediac", "biegl", "swiad", "dowod",
  "umow", "kontrakt", "aneks", "regulamin", "ugod", "wypowiedz", "kara", "kary", "karn", "grzywn", "mandat", "odszkodowa",
  "zadoscuczyn", "roszczen", "dlug(?!o\\b|osc|ie\\b|ich\\b|im\\b|iego|iej|a\\b)", "dluz", "wierzyc", "zaplat", "faktur", "windyk", "egzekuc", "zajeci", "zajal",
  "spadk", "spadek", "testament", "zachow", "dziedzicz", "rozwod", "alimen", "opiek", "wladz", "separac", "malzen",
  "najem", "najm", "wynajm", "wynajem", "czynsz", "kaucj", "lokator", "eksmis", "wlasciciel", "wlasnos", "nieruchomos", "dzialk", "dzialc", "bez (?:mojej|jego|jej|naszej) wiedzy",
  "sasiad", "pracodaw", "pracowni", "zwolni", "urlop", "wynagrodz", "zus", "krus", "emerytur", "rent", "zasil", "swiadcze",
  "urzad", "urzedni", "decyzj", "organ", "gmin", "wojewod", "starost", "burmistrz", "wojt", "(?<!obligacj\\w* )skarbow", "podat", "vat", "pit", "cit",
  "polic(?!z)", "prokurat", "przestep", "wykrocz", "oszu", "krad", "pobi", "grozi", "nek", "zglos", "zawiadom",
  "reklamac", "rekojm", "gwarancj", "zwrot", "odstap", "konsument", "ubezpiecz", "polis", "kredyt", "pozyczk", "zablokow",
  "rodo", "dane osobow", "wizerun", "autorsk", "licencj", "patent", "znak towar", "zezwoleni", "pozwoleni", "koncesj",
  "spolk", "wspolni", "upadlos", "restruktur", "zarzad", "udzial", "rejestr", "krs", "ceidg", "przetarg", "zamowieni publ",
  "obywatel", "paszport", "melduj", "zamelduj", "wymelduj", "pobyt", "wiz", "cudzoziem", "uchodz",
  "lekarz", "szpital", "pacjent", "dokumentacj", "szkod", "wypad", "uszkodz", "zalal", "zalew", "zniszczy", "pogryz",
  "termin", "przedawni", "pismo", "pisma", "wniosek", "wezwani", "uchwal", "nakaz", "zakaz", "obowiaz", "uprawnie",
  "legaln", "nielegaln", "wolno", "dozwolon", "przysluguj", "nalez mi", "naleza mi", "nalezy mi", "odpowiedzialn",
  "szef", "kierowni", "firma nie", "nie placi", "nie zaplacil", "nie oddaj", "nie odda", "oddac pieniadz", "ukradl", "zabral",
  "nie pozwal", "widyw", "kontakt(?:y|ow|ami)? z dzie", "zostawil", "wyprowadzil", "nie chce oddac", "nie chce zaplac",
  "bez (?:mojej |jego |jej |ich |naszej )?zgod", "odmow", "opodatk", "odlicz", "ulg", "wierzytel", "syndyk", "orzeczeni",
  "opublikow", "publikac", "wymeldow", "zameldow", "(?:moich|moje|twoich|klientow|pracownikow) dan", "dan(?:e|ych) (?:osob|klient|pracown)",
  "korupc", "sankcj", "audyt", "complian", "dzierzaw", "doplat", "refundac", "etykiet", "wycofan", "mobilizac", "sluzb", "taryf",
  "traktat", "pomoc publiczn", "wyklucz", "ksieg", "nadzor", "kontrol", "sprostowan", "fiskus", "wad(?:a|y|e|liw)", "intercyz",
  "rozdzielnos", "ubezwlasnowol", "ojcostw", "wspolwlasnos", "konwencj", "konsul", "dyskrymin", "wywiez", "uprowadz", "przyjeci",
  "dopuszcz", "kara?t[ay] (?:polaka|pobytu)", "licencj", "certyfik", "iso", "aml", "dora", "nis2", "ai act",
  "akt(?:a|ach|ami|om)\\b", "dokument", "spraw(?:a|y|ie|e|ach|om|ami)\\b", "klient", "rozprawa", "protokol",
  // Matters told without a legal word (benchmark 2026-10-08, scenarios-5000): a gift,
  // a petition, a brand, whistleblowing, a carrier's liability, ESG, an internal inquiry.
  "darowizn", "zglasz", "podpis", "nieprawidlowos", "zastrzec", "zastrzez", "esg", "csrd", "antykorupc", "dochodzeni",
  "przewozn", "odpowiada za", "ukrad", "nazw\\w* (?:dla )?(?:mojej |naszej )?(?:marki|firmy|sklepu|produktu)", "praktyk\\w* lekarsk", "zalozyc (?:firm|spolk|fundacj|stowarzysz|dzialalnos|praktyk)",
  "polityk\\w* prywatnosc", "klauzul\\w* informacyjn", "statut", "fundacj", "stowarzyszeni",
  "usun\\w* (?:moje |moj )?(?:zdjec|zdjeci|wpis|komentarz|dane)\\w* z (?:internet|sieci|portal|forum|google|facebook|serwis|strony)",
];
const LEGAL_LEXICON = new RegExp(`(?<![a-z0-9])(?:${LEGAL_STEMS.join("|")})`, "u");

// Questions about rights and duties, whatever the topic.
const LEGAL_INTENT =
  /(?<![a-z])(?:czy (?:(?:cos|jakos|w ogole|tu|tutaj|teraz|wtedy|nadal|jeszcze) )*(?:moge|mozna|musze|trzeba|wolno|mam prawo|grozi|jestem zobowiazan|to legalne|to zgodne|da sie)|co (?:(?:mi|w tej sytuacji|teraz) )?grozi|cos (?:moge|mozna|da sie)|co (?:(?:moge|mam|mozna|powinienem|powinnam|nalezy) )(?:z tym )?(?:zrobic|robic)|od czego zaczac|jakie mam (?:prawa|szanse|opcje|mozliwosci)|kto (?:placi|odpowiada|ponosi|zaplaci)|ile (?:mam czasu|mam dni)|do kogo (?:sie )?(?:zwrocic|zglosic|isc)|gdzie (?:sie )?(?:zglosic|zwrocic|to zglosic|zlozyc)|jak (?:to )?(?:zalatwic|rozwiazac|sie bronic|sie odwolac|zaskarzyc|dochodzic|odzyskac (?:pieniadz|kaucj|dlug|nalezn|zaplat|wklad|depozyt|prawo|samoch|mieszk)|zglosic|wypowiedziec|rozwiazac umowe))/u;

// One everyday word of a domain's routing row ("pies", "student", "zamówienie",
// "fotowoltaika") names a topic, not yet a matter: alone it does not make the
// message legal. Any second signal (a legal word, an intent) does.
const TOPIC_ONLY = new Set([
  "dług", "sąd", "student", "uczeń", "szkoła", "uczelnia", "matura", "zamówienie", "pies", "zwierzę", "sport", "energia", "transport",
  "środowisko", "żywność", "rolnik", "rolnictwo", "hodowla", "budowa", "apteka", "fotowoltaika", "studnia", "geodeta", "zabytek",
  "prasa", "redakcja", "narzędzia", "kalkulator", "strategia", "spam", "cookies", "newsletter", "wojsko", "odpady", "farmacja",
  "lekarz rodzinny", "IP", "za granicą", "Konwencja", "dyrektywa", "uchwała", "wynagrodzenie", "urlop", "emerytura", "recepta"
]);

// Words that name a legal matter in any context. In a message whose topic is plainly not
// legal (code, a recipe, a novel, a game, physics, a garden), the everyday words of the
// lexicon above ("prawo Newtona", "proces", "sąd" of apple trees, "wyrok" in a song,
// "dowód" in maths, "świadek" in a novel) are no evidence; one of these, a citation or
// a question about rights is (benchmark series 3, 2026-10-10: 26.4% of non-legal
// messages answered without the legal path).
const STRONG_LEGAL_STEMS = [
  "prawn", "prawnik", "ustaw(?!ic|ien|il|ia[cl]|ion|i[eć]|ia\\b|iaj)", "rozporzadz", "konstytuc", "kodeks\\w* (?:karn|cywiln|prac|rodzin|wykroczen|spolek|postepowani)", "pozew", "pozw(?!ol)", "apelac",
  "zazaleni", "kasac", "pelnomocni", "adwokat", "radc\\w* prawn", "notariu", "notarial", "komorni", "odszkodowa", "zadoscuczyn", "roszczen", "wierzyc", "windyk",
  "spadk", "testament", "zachowek", "zachowku", "rozwod", "alimen", "eksmis", "kaucj", "zus", "krus", "urzad", "urzedni", "wojewod", "starost", "skarbow", "podat",
  "vat", "prokurat", "przestep", "wykrocz", "oszust", "oszuk", "reklamac", "rekojm", "konsument", "rodo", "dane osobow", "wizerun", "praw\\w* autorsk", "patent",
  "znak\\w* towarow", "zezwoleni", "pozwoleni\\w* (?:na budow|wodnopraw)", "koncesj", "upadlos", "krs", "ceidg", "przetarg", "cudzoziem", "przedawni", "wezwani\\w* do zaplat",
  "nielegaln", "przysluguj", "opodatk", "wierzytel", "syndyk", "korupc", "sankcj", "intercyz", "ubezwlasnowol", "ojcostw", "dyskrymin", "grzywn", "mobbing",
  "pracodaw", "wypowiedzeni\\w* umow", "umow\\w* (?:o prac|najm|zleceni|o dzielo|sprzedazy|kupna|pozyczk|darowizn|licencyjn)", "nieruchomos", "dzialk", "ksieg\\w* wieczyst",
  "spolk", "zamowieni\\w* publiczn", "decyzj\\w* (?:administracyjn|urzedu|organu|wojewody|starosty|zus)", "mandat\\w* (?:karn|za)", "policj", "zatrzyma\\w* przez", "areszt", "oskarz",
  "sad\\w* (?:rejonow|okregow|apelacyjn|najwyzsz|administracyjn|pracy|rodzinn|powszechn)", "w sadzie", "do sadu", "przed sadem", "sprawa sadow", "wsa", "nsa", "uodo", "uokik", "kio",
  "plan\\w* miejscow", "gmin", "oplat", "przepis\\w* (?:tu )?obowiazuj", "antykorupc", "pogryz", "ugryz", "baner", "zgod", "petycj", "formaln", "samowol",
  "tablic\\w* budowy", "przybudow", "opakowani", "plagiat", "prac\\w* dyplomow", "dyscyplinar", "ukaral", "w reklamie", "fundusz\\w* (?:europejsk|unijn)", "rolnicz\\w* handl", "ochron\\w* (?:prawn|przed)", "mam ochron", "uporczyw", "nekan",
  "przedsiebiorc", "zazadal", "zadal\\w* zwrotu", "niejawn", "wspolnik", "zabezpiecz\\w* (?:te |tych )?dowod", "nie wyplac", "inspekc"
];
const STRONG_LEGAL = new RegExp(`(?<![a-z0-9])(?:${STRONG_LEGAL_STEMS.join("|")})`, "u");
const RIGHTS_QUESTION =
  /(?<![a-z])(?:co (?:moge|mozemy|mozna) (?:z tym |w tej sytuacji )?zrobic|czy (?:moge|mozemy) w ogole|mam prawo|ma prawo|maja prawo|jakie mam prawa|co (?:mi|nam|mu|jej|im) grozi|czy (?:to )?(?:jest )?(?:legaln|zgodn\w* z prawem|zgodn\w* z przepisami)|czy wolno|kto (?:odpowiada|ponosi|zaplaci)|do kogo (?:sie )?(?:zwrocic|zglosic)|bez (?:mojej |jego |jej |naszej )?zgody)/u;
// The topic of a message that is plainly not a legal matter.
// Fiction and games: a crime in the plot is no criminal matter.
const FICTION = /(?<![a-z])(?:powiesc\w*|powiesci|opowiadani\w*|bohater\w*|scen\w* (?:procesu|w|z)|rozdzial\w*|gracz\w*|grze\b|rpg|piosenk\w*|refren\w*|kryminal\w*|zabaw\w* w sad)/u;
const NONLEGAL_TOPIC =
  /(?<![a-z])(?:python\w*|javascript|typescript|bash\w*|skrypt\w*|excel\w*|arkusz\w* kalkul|github\w*|repo\b|pypi|npm|package\.json|pyproject|docker\w*|kubernetes|request\w*|promise|foreach|petl\w*|kod\w* (?:w|pythona|programu)|program\w* (?:w|czasem)|raspberry|gpio|wordpress|wtyczk\w*|scheduler\w*|modul\w* (?:w|pdf)|merge|powiesc\w*|powiesci|opowiadani\w*|bohater\w*|scen\w* (?:procesu|w|z)|rozdzial\w*|gracz\w*|grze\b|gry (?:planszow|komputer)|planszow\w*|rpg|rzuty? kosc\w*|piosenk\w*|refren\w*|rym\w*|wiersz\w*|teatr\w*|aktorsk\w*|zuch\w*|harcer\w*|przepis\w* na (?!podstaw)|sernik\w*|piekarnik\w*|ugotowa\w*|rosol\w*|jogurt\w*|pizz\w*|drozdz\w*|fermentac\w*|newton\w*|archimedes\w*|coulomb\w*|fizyk\w*|dynamiki|matematyczn\w*|pierwiast\w*|liczb\w* pierwsz\w*|niewymiern\w*|indukcj\w*|elastycznosc\w*|popytu|trener\w*|zawodnik\w*|druzyn\w*|spalon\w*|ligi\b|treningow\w*|plywa\w*|roslin\w*|jablon\w*|pomidor\w*|szklarni\w*|fikus\w*|wkretark\w*|poziomic\w*|zawias\w*|syfon\w*|placu manewrow\w*|parkowani\w* rownoleg\w*|zabaw\w* w sad|repozytori\w* (?:na )?git\w*|egzamin\w* praktyczn\w*|smut\w*|psychoterapi\w*|etf|fundusz\w* indeksow\w*|nocleg\w*|szlak\w*|lewad\w*|warcab\w*|chorze\b|wiedzmin\w*|szach\w*|unity|javie|dysk\w* ssd|linux\w*|gitlab\w*|kanban\w*|scrum\w*|retrospektyw\w*|termodynamik\w*|ohma|jadlospis\w*|refluks\w*|behawiorys\w*|debat\w*|gr\w* slow|kawiarni\w*|ishikaw\w*|amortyzator\w*|wahacz\w*|sprzegl\w*|kursant\w*)/u;

// Citations: an article or a section, a case number, a Dz.U. reference.
const CITATION = /\bart\.?\s*\d|§\s*\d|\bsygn\.?|\bdz\.?\s?u\.?|\b[ivx]+\s+[a-z]{1,4}\s+\d+\/\d{2}\b/iu;

function hasLegalSignal(text: string, flash: FlashRoute[]): boolean {
  if (!text.trim()) return false;
  const folded = fold(provisionsForDetection(text));
  if (NONLEGAL_TOPIC.test(folded)) {
    return CITATION.test(text) || STRONG_LEGAL.test(folded) || RIGHTS_QUESTION.test(folded) || (!FICTION.test(folded) && criminalMatter(text));
  }
  return (
    CITATION.test(text) ||
    LEGAL_LEXICON.test(folded) ||
    LEGAL_INTENT.test(folded) ||
    criminalMatter(text) ||
    flashDomains(flash, text).some((row) => row.matched.some((phrase) => !TOPIC_ONLY.has(phrase)))
  );
}

// A general request: a question or an instruction ("jak upiec", "ile to jest", "co to
// jest", "napisz wiersz", "przetłumacz"), after an optional greeting. A bare statement
// ("Komitet audytu w jednostce zainteresowania publicznego") describes a matter and
// stays legal.
const OPENING = /^(?:(?:hej|hejka|czesc|witam|witaj|dzien dobry|dobry wieczor|siema|halo)[\s,!.]*)?(?:(?:mam (?:takie )?pytanie|pytanie|prosba)\s*[:,-]?\s*)?/u;
const GENERAL_REQUEST =
  /^(?:jak|jaki|jaka|jakie|jakiego|jakim|ile|rozpisz|kto|kim|komu|kiedy|gdzie|skad|dokad|dlaczego|czemu|po co|co|czym|czy|ktory|ktora|ktore|napisz|wymysl|przetlumacz|policz|oblicz|rozwiaz|przelicz|podaj|polec|zaproponuj|opowiedz|stresc|wyjasnij|wytlumacz|uloz|zagrajmy|popraw|wymien|opisz|zrob|stworz|narysuj|zaplanuj|pomoz|daj|powiedz|wskaz|porownaj|polecisz|polecasz|podpowiesz|podpowiedz|doradz|doradzisz|podziel|pomnoz|dodaj|odejmij|naucz|pokaz|wymysl|masz|w co|plan|cwiczenia|przepis na)\b/u;

/** True only for a general request with no legal signal, in a thread with none either. */
export function isNonLegalMessage(query: string, flash: FlashRoute[]): boolean {
  // Routing markers pasted into a message ("#prawo #pozew", "[[legal=true]]", "KROK0A")
  // do not make a recipe legal; the matter decides.
  const latest = withoutRoutingMarkers(latestUserTurn(query)).replace(/#[\p{L}_]+|\[\[[^\]]*\]\]/gu, " ");
  // A question opening the message, or the closing request of a story ("Mam psa, który
  // tyje. ... Ułóż mi plan diety.") (benchmark 2026-10-10, 1000 kazusów).
  const opening = (text: string) => GENERAL_REQUEST.test(fold(text.trim()).replace(OPENING, ""));
  const lastSentence = latest.trim().split(/(?<=[.!?])\s+/u).pop() ?? "";
  if (!opening(latest) && !opening(requestOf(latest)) && !(NONLEGAL_TOPIC.test(fold(latest)) && opening(lastSentence))) return false;
  if (hasLegalSignal(latest, flash)) return false;
  // A follow-up in a legal thread ("tak, w maju") belongs to that matter.
  if (laterTurn(query) && hasLegalSignal(threadUserText(query), flash)) return false;
  return true;
}

let flashCache: { file: string; mtimeMs: number; rows: FlashRoute[] } | null = null;

/** prawo-polskie-v2 "Routing błyskawiczny" of the registry, re-read after a skill update. */
export function registryFlashRoutes(registry: LexSkillRegistry): FlashRoute[] {
  const file = registry.get("prawo-polskie-v2")?.skillFile;
  if (!file) return [];
  try {
    const mtimeMs = fs.statSync(file).mtimeMs;
    if (flashCache?.file === file && flashCache.mtimeMs === mtimeMs) return flashCache.rows;
    flashCache = { file, mtimeMs, rows: parseFlashRouting(fs.readFileSync(file, "utf8")) };
    return flashCache.rows;
  } catch {
    return [];
  }
}

// A correction of a fact in a running matter ("to ta sama firma, tylko błąd OCR", "chodziło o
// 2024", "nie Kowalski, tylko Kowalska"): no new task, no question.
const CORRECTION =
  /(?<![\p{L}])(?:to (?:jest )?(?:ta sama|ten sam|to samo|te same)|b[łl][ąa]d (?:ocr|w nazwie|w nazwisku|w dacie|w kwocie|pisowni|odczytu)|liter[óo]wk|pomy[łl]k|chodzi[łl]o (?:mi )?o|poprawka *:|korekta *:|powinno by[ćc]|ma by[ćc] |w[łl]a[śs]ciwie (?:to )?(?:jest|by[łl])|nie \S+,? (?:tylko|lecz|ale) )/iu;
const TASK =
  /(?<![\p{L}])(?:przygotuj|napisz|sporz[ąa]d[źz]|przeanalizuj|analizuj|sprawd[źz]|zr[óo]b|wygeneruj|generuj|kontynuuj|dalej|nast[ęe]pny|dokończ|popraw (?:pismo|umow|dokument|tekst)|oce[ńn]|zbadaj|wyja[śs]nij|policz|oblicz|stw[óo]rz|dodaj|usu[ńn])/iu;

/**
 * The latest message only corrects a fact of the conversation (not the first message, at
 * most 400 characters, no question, no request for work): it is acknowledged and kept in the
 * case's register without a legal turn (2 minutes and ~120k tokens of instructions before).
 */
export function isFactCorrection(query: string): boolean {
  const latest = latestUserTurn(query).trim();
  return laterTurn(query) && latest.length > 0 && latest.length <= 400 && !latest.includes("?") && CORRECTION.test(latest) && !TASK.test(latest);
}
