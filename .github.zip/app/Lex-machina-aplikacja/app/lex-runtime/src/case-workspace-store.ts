import { validCaseCourt, type CaseCourt } from "./courts/case-court.js";
import { validateProcessPleadingDraft, type ProcessPleadingDraft } from "./process-pleading-draft.js";
import { type AnswerCorrection, validAnswerCorrections } from "./answer-corrections.js";
import { validThreadEvidence, type ThreadEvidence } from "./thread-evidence.js";
import { validThreadSummary, type ThreadSummary } from "./thread-summary.js";
import { validCaseChronology, type CaseChronology } from "./case-chronology.js";
import { validCaseOverview, type CaseOverview } from "./case-overview.js";
import { validCaseWork, type CaseWorkItem } from "./case-work.js";
import { validLongDocument, type LongDocumentState } from "./long-document.js";
import { validAnswerDocument, type AnswerDocument } from "./answer-document.js";
import {
  createCipheriv,
  createDecipheriv,
  hkdfSync,
  randomBytes
} from "node:crypto";
import {
  mkdir,
  readFile,
  rename,
  rm,
  writeFile
} from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import {
  validateProcessPleadingState,
  type ProcessPleadingState
} from "./process-pleading-state.js";
import {
  validateCourtAnalysisState,
  type CourtAnalysisState
} from "./court-analysis-state.js";
import {
  validateChronologyState,
  type ChronologyState
} from "./chronology-state.js";
import {
  validateContractAnalysisState,
  type ContractAnalysisState
} from "./contract-analysis-state.js";
import {
  validateOrderedCaseWorkflowState,
  type OrderedCaseWorkflowId,
  type OrderedCaseWorkflowState
} from "./ordered-case-workflow-state.js";

export type WorkspaceFolder = {
  folderId: string;
  parentId: string | null;
  name: string;
  createdAt: string;
};

export type WorkspaceDocumentCitation = {
  citationId: string;
  marker: string;
  label: string;
  caseId?: string;
  documentId: string;
  chunkIndex: number;
  pageStart: number;
  pageEnd: number;
  contextText: string;
  quote?: string;
  highlightStart?: number;
  highlightEnd?: number;
};

export type WorkspaceThreadMessage = {
  messageId: string;
  role: "user" | "assistant" | "system";
  content: string;
  createdAt: string;
  meta?: string;
  documentCitations?: WorkspaceDocumentCitation[];
  restorations?: WorkspaceRestoration[];
  // A document generated in this message (chat card: download, preview, deanonymize).
  generatedDocument?: WorkspaceGeneratedDocument;
  // Widgets shown with show_widget, re-rendered when the thread is reopened.
  widgets?: WorkspaceWidget[];
  // Lista „Źródła i weryfikacja”, źródła pomocnicze, ścieżka obowiązkowa i
  // następny krok: zapisywane, żeby nie znikały po powrocie do wątku.
  evidence?: Record<string, unknown>[];
  auxiliarySources?: Record<string, unknown>[];
  mandatoryPath?: Record<string, unknown>;
  // Pages of the case's documents read for this answer (document-coverage.ts).
  documentCoverage?: Array<{ documentId: string; title?: string; totalPages: number; pages: Array<[number, number]>; status: "FULL" | "PARTIAL" }>;
  documentAnalysis?: boolean;
  // The answer is itself a letter kept for its file (answer-document.ts): its session.
  answerDocument?: { sessionId: string };
  // What the application's correcting rounds removed from the answer (answer-corrections.ts).
  corrections?: AnswerCorrection[];
  pipelineNext?: { skill: string; reason: string; choices?: Array<{
    skill: string;
    kind: "DOCUMENT" | "ANALYSIS" | "CONTINUE";
    reason: string;
    own?: true;
    steps?: { done: number; total: number; skipped: Array<{ checkpoint: string; reason?: string }>; open: string[] };
    longDocumentId?: string;
  }> };
};

export type WorkspaceWidget = {
  title: string;
  kind: "html" | "jsx";
  code: string;
  source?: string;
};

export type WorkspaceGeneratedDocument = {
  artifactId: string;
  filename: string;
  format: "docx" | "odt";
  // true: the file carries alias symbols and needs machine deanonymization.
  tokenized: boolean;
  // Letter workflows: a draft after a cycle, the finished document at the end.
  stage?: "DRAFT" | "FINAL";
};

/** A value restored into an assistant message (see privacy/restoration-report). */
export type WorkspaceRestoration = {
  start: number;
  end: number;
  token: string;
  kind: string;
  case?: string;
  source: string;
  confidence: number;
  status: string;
  canonical?: string;
  gender?: "m1" | "f";
  caseMissing?: boolean;
  agreement?: string;
};

export type CaseMemory = {
  evidence?: ThreadEvidence;
  summary?: ThreadSummary;
  // The case's timeline from its last chronology (case-chronology.ts).
  chronology?: CaseChronology;
  // The case summary made on the user's request (case-overview.ts).
  overview?: CaseOverview;
  // Work done and open in the case (case-work.ts).
  work?: CaseWorkItem[];
  // A long letter written in parts: its plan and the parts written so far (long-document.ts).
  longDocument?: LongDocumentState;
  // The court of the case: from its documents or the first letter (courts/case-court.ts).
  court?: CaseCourt;
  // The last answer that is itself a letter, with its session's trail: its file (answer-document.ts).
  answerDocument?: AnswerDocument;
};

export type CaseWorkspaceIndex = {
  schemaVersion: 1;
  caseId: string;
  updatedAt: string;
  folders: WorkspaceFolder[];
  itemLocations: Record<string, string | null>;
  thread: {
    messages: WorkspaceThreadMessage[];
  };
  // Pamięć sprawy: dowody z poprzednich odpowiedzi i streszczenie starszej części wątku.
  memory?: CaseMemory;
  workflows?: {
    processPleading?: ProcessPleadingState;
    // The pleading text between the pipeline's stages (process-pleading-draft.ts).
    processPleadingDraft?: ProcessPleadingDraft;
    courtAnalysis?: CourtAnalysisState;
    chronology?: ChronologyState;
    contractAnalysis?: ContractAnalysisState;
    orderedCase?: Partial<
      Record<
        OrderedCaseWorkflowId,
        OrderedCaseWorkflowState
      >
    >;
  };
};

type EncryptedWorkspaceEnvelope = {
  schemaVersion: 1;
  keyVersion: number;
  nonce: string;
  tag: string;
  ciphertext: string;
};

export type CaseWorkspaceStoreOptions = {
  rootDir?: string;
  maxIndexBytes?: number;
  maxMessages?: number;
};

const CASE_ID = /^case_[a-f0-9]{32}$/;
const FOLDER_ID = /^folder_[a-f0-9]{32}$/;
const ITEM_ID = /^(?:upload|template)_[a-f0-9]{32}$/;
const DOCUMENT_ID = /^[a-z][a-z0-9-]*_[a-f0-9]{16,64}$/;
const MESSAGE_ID = /^[a-z][a-z0-9-]*_[a-f0-9]{16,64}$/;
const ARTIFACT_ID = /^artifact_[a-f0-9]{32}$/;

function defaultRootDir(): string {
  return path.resolve(
    process.env.LEX_DATA_DIR ??
      path.join(os.homedir(), ".lex-machina", "data")
  );
}

function cleanFolderName(value: string): string {
  const name = value
    .normalize("NFKC")
    .replace(/[\x00-\x1f\x7f]/g, "")
    .trim();
  if (
    !name ||
    name === "." ||
    name === ".." ||
    name.includes("/") ||
    name.includes("\\") ||
    name.length > 120
  ) {
    throw new Error("WORKSPACE_FOLDER_NAME_INVALID");
  }
  return name;
}

function safeMessage(input: WorkspaceThreadMessage): WorkspaceThreadMessage {
  if (
    !MESSAGE_ID.test(input.messageId) ||
    !["user", "assistant", "system"].includes(input.role) ||
    typeof input.content !== "string" ||
    input.content.length > 80_000 ||
    !input.content.trim() ||
    typeof input.createdAt !== "string" ||
    input.createdAt.length > 64 ||
    (input.meta !== undefined &&
      (typeof input.meta !== "string" || input.meta.length > 8_000))
  ) {
    throw new Error("WORKSPACE_THREAD_MESSAGE_INVALID");
  }

  const citations = (input.documentCitations ?? []).slice(0, 64).map((citation) => {
    if (
      typeof citation.citationId !== "string" ||
      citation.citationId.length > 96 ||
      typeof citation.marker !== "string" ||
      citation.marker.length > 160 ||
      typeof citation.label !== "string" ||
      citation.label.length > 160 ||
      !DOCUMENT_ID.test(citation.documentId) ||
      !Number.isInteger(citation.chunkIndex) ||
      citation.chunkIndex < 0 ||
      !Number.isInteger(citation.pageStart) ||
      citation.pageStart < 1 ||
      !Number.isInteger(citation.pageEnd) ||
      citation.pageEnd < citation.pageStart ||
      typeof citation.contextText !== "string" ||
      citation.contextText.length > 40_000 ||
      (citation.caseId !== undefined && !CASE_ID.test(citation.caseId)) ||
      (citation.quote !== undefined && citation.quote.length > 4_000) ||
      (citation.highlightStart !== undefined &&
        (!Number.isInteger(citation.highlightStart) || citation.highlightStart < 0)) ||
      (citation.highlightEnd !== undefined &&
        (!Number.isInteger(citation.highlightEnd) ||
          citation.highlightEnd < 0 ||
          citation.highlightEnd > citation.contextText.length)) ||
      (citation.highlightStart !== undefined &&
        citation.highlightEnd !== undefined &&
        citation.highlightEnd < citation.highlightStart)
    ) {
      throw new Error("WORKSPACE_DOCUMENT_CITATION_INVALID");
    }
    return { ...citation };
  });

  const restorations = (input.restorations ?? []).slice(0, 2_000).map((item) => {
    if (
      !Number.isInteger(item.start) ||
      !Number.isInteger(item.end) ||
      item.start < 0 ||
      item.end < item.start ||
      item.end > input.content.length ||
      typeof item.token !== "string" ||
      !/^\[PII:[A-Z_]+:\d{4}\]$/.test(item.token) ||
      typeof item.kind !== "string" ||
      !/^[A-Z_]{1,32}$/.test(item.kind) ||
      (item.case !== undefined && !/^[A-Z]{2,4}$/.test(item.case)) ||
      typeof item.source !== "string" ||
      item.source.length > 64 ||
      typeof item.confidence !== "number" ||
      !(item.confidence >= 0 && item.confidence <= 1) ||
      typeof item.status !== "string" ||
      item.status.length > 32 ||
      (item.canonical !== undefined &&
        (typeof item.canonical !== "string" || item.canonical.length > 200)) ||
      (item.gender !== undefined && item.gender !== "m1" && item.gender !== "f") ||
      (item.caseMissing !== undefined && typeof item.caseMissing !== "boolean") ||
      (item.agreement !== undefined && (typeof item.agreement !== "string" || item.agreement.length > 200))
    ) {
      throw new Error("WORKSPACE_RESTORATION_INVALID");
    }
    return {
      start: item.start,
      end: item.end,
      token: item.token,
      kind: item.kind,
      ...(item.case ? { case: item.case } : {}),
      source: item.source,
      confidence: item.confidence,
      status: item.status,
      ...(item.canonical ? { canonical: item.canonical } : {}),
      ...(item.gender ? { gender: item.gender } : {}),
      ...(item.caseMissing ? { caseMissing: true } : {}),
      ...(item.agreement ? { agreement: item.agreement } : {})
    };
  });

  const widgets = (input.widgets ?? []).slice(0, 3).map((widget) => {
    if (
      !widget ||
      typeof widget.title !== "string" ||
      widget.title.length > 200 ||
      (widget.kind !== "html" && widget.kind !== "jsx") ||
      typeof widget.code !== "string" ||
      !widget.code.trim() ||
      widget.code.length > 300_000 ||
      (widget.source !== undefined && (typeof widget.source !== "string" || widget.source.length > 300))
    ) {
      throw new Error("WORKSPACE_THREAD_MESSAGE_INVALID");
    }
    return {
      title: widget.title,
      kind: widget.kind,
      code: widget.code,
      ...(widget.source ? { source: widget.source } : {})
    };
  });
  const generated = input.generatedDocument;
  if (
    generated !== undefined &&
    (
      typeof generated !== "object" ||
      generated === null ||
      !ARTIFACT_ID.test(String(generated.artifactId)) ||
      typeof generated.filename !== "string" ||
      !generated.filename.trim() ||
      generated.filename.length > 200 ||
      !["docx", "odt"].includes(generated.format) ||
      typeof generated.tokenized !== "boolean" ||
      (generated.stage !== undefined && !["DRAFT", "FINAL"].includes(generated.stage))
    )
  ) {
    throw new Error("WORKSPACE_GENERATED_DOCUMENT_INVALID");
  }

  const evidence = plainRecords(input.evidence, 300, 600_000);
  const auxiliarySources = plainRecords(input.auxiliarySources, 100, 300_000);
  const mandatoryPath = plainRecords(input.mandatoryPath === undefined ? undefined : [input.mandatoryPath], 1, 200_000)?.[0];
  const next = input.pipelineNext;
  const validChoice = (choice: unknown) => {
    const item = choice as { skill?: unknown; kind?: unknown; reason?: unknown; own?: unknown; steps?: unknown; longDocumentId?: unknown } | null;
    const steps = item?.steps as { done?: unknown; total?: unknown; skipped?: unknown; open?: unknown } | undefined;
    const validSteps =
      steps === undefined ||
      (typeof steps === "object" && steps !== null &&
        Number.isInteger(steps.done) && Number.isInteger(steps.total) && (steps.total as number) <= 100 &&
        Array.isArray(steps.open) && steps.open.length <= 100 && steps.open.every((value) => typeof value === "string" && value.length <= 100) &&
        Array.isArray(steps.skipped) && steps.skipped.length <= 100 &&
        steps.skipped.every((entry: { checkpoint?: unknown; reason?: unknown }) =>
          typeof entry?.checkpoint === "string" && entry.checkpoint.length <= 100 && (entry.reason === undefined || (typeof entry.reason === "string" && entry.reason.length <= 300))));
    return (
      typeof item === "object" && item !== null &&
      typeof item.skill === "string" && item.skill.length <= 200 &&
      (item.kind === "DOCUMENT" || item.kind === "ANALYSIS" || item.kind === "CONTINUE") &&
      (item.own === undefined || item.own === true) &&
      (item.longDocumentId === undefined || (typeof item.longDocumentId === "string" && /^[0-9a-f-]{36}$/u.test(item.longDocumentId))) &&
      validSteps &&
      typeof item.reason === "string" && item.reason.length <= 2_000
    );
  };
  if (
    next !== undefined &&
    (typeof next !== "object" || next === null ||
      typeof next.skill !== "string" || next.skill.length > 200 ||
      typeof next.reason !== "string" || next.reason.length > 2_000 ||
      (next.choices !== undefined && (!Array.isArray(next.choices) || next.choices.length > 5 || !next.choices.every(validChoice))))
  ) {
    throw new Error("WORKSPACE_THREAD_MESSAGE_INVALID");
  }

  const coverage = input.documentCoverage;
  if (
    coverage !== undefined &&
    (!Array.isArray(coverage) ||
      coverage.length > 50 ||
      !coverage.every(
        (entry) =>
          typeof entry === "object" && entry !== null &&
          /^doc_[a-f0-9]{24}$/.test(String(entry.documentId)) &&
          (entry.title === undefined || (typeof entry.title === "string" && entry.title.length <= 300)) &&
          Number.isInteger(entry.totalPages) && entry.totalPages >= 1 && entry.totalPages <= 100_000 &&
          (entry.status === "FULL" || entry.status === "PARTIAL") &&
          Array.isArray(entry.pages) && entry.pages.length <= 500 &&
          entry.pages.every((range) => Array.isArray(range) && range.length === 2 && range.every((page) => Number.isInteger(page) && page >= 1))
      ))
  ) {
    throw new Error("WORKSPACE_THREAD_MESSAGE_INVALID");
  }
  if (input.documentAnalysis !== undefined && typeof input.documentAnalysis !== "boolean") {
    throw new Error("WORKSPACE_THREAD_MESSAGE_INVALID");
  }
  if (
    input.answerDocument !== undefined &&
    (typeof input.answerDocument !== "object" || typeof input.answerDocument?.sessionId !== "string" || input.answerDocument.sessionId.length > 200)
  ) {
    throw new Error("WORKSPACE_THREAD_MESSAGE_INVALID");
  }
  if (input.corrections !== undefined && !validAnswerCorrections(input.corrections)) {
    throw new Error("WORKSPACE_THREAD_MESSAGE_INVALID");
  }

  const {
    restorations: _dropped,
    generatedDocument: _generated,
    evidence: _evidence,
    auxiliarySources: _auxiliary,
    mandatoryPath: _path,
    pipelineNext: _next,
    documentCoverage: _coverage,
    documentAnalysis: _analysis,
    answerDocument: _answerDocument,
    corrections: _corrections,
    ...rest
  } = input;
  return {
    ...rest,
    ...(coverage?.length
      ? {
          documentCoverage: coverage.map((entry) => ({
            documentId: entry.documentId,
            ...(entry.title ? { title: entry.title } : {}),
            totalPages: entry.totalPages,
            pages: entry.pages.map(([start, end]) => [start, end] as [number, number]),
            status: entry.status
          }))
        }
      : {}),
    ...(input.documentAnalysis ? { documentAnalysis: true } : {}),
    ...(input.answerDocument ? { answerDocument: { sessionId: input.answerDocument.sessionId } } : {}),
    ...(input.corrections?.length
      ? { corrections: input.corrections.map((item) => ({ round: item.round, findings: [...item.findings], removed: [...item.removed] })) }
      : {}),
    ...(evidence?.length ? { evidence } : {}),
    ...(auxiliarySources?.length ? { auxiliarySources } : {}),
    ...(mandatoryPath ? { mandatoryPath } : {}),
    ...(next
      ? {
          pipelineNext: {
            skill: next.skill,
            reason: next.reason,
            ...(next.choices?.length
              ? {
                  choices: next.choices.map((choice) => ({
                    skill: choice.skill,
                    kind: choice.kind,
                    reason: choice.reason,
                    ...(choice.own ? { own: true as const } : {}),
                    ...(choice.steps ? { steps: structuredClone(choice.steps) } : {})
                  }))
                }
              : {})
          }
        }
      : {}),
    ...(generated
      ? {
          generatedDocument: {
            artifactId: generated.artifactId,
            filename: generated.filename,
            format: generated.format,
            tokenized: generated.tokenized,
            ...(generated.stage ? { stage: generated.stage } : {})
          }
        }
      : {}),
    ...(citations.length > 0 ? { documentCitations: citations } : {}),
    ...(restorations.length > 0 ? { restorations } : {}),
    ...(widgets.length > 0 ? { widgets } : {})
  };
}

// Tablica zwykłych obiektów JSON z limitem liczby i rozmiaru (dane widoku, nie logika).
function plainRecords(
  value: unknown,
  maxItems: number,
  maxBytes: number
): Record<string, unknown>[] | undefined {
  if (value === undefined) return undefined;
  if (
    !Array.isArray(value) ||
    value.length > maxItems ||
    value.some((item) => !item || typeof item !== "object" || Array.isArray(item))
  ) {
    throw new Error("WORKSPACE_THREAD_MESSAGE_INVALID");
  }
  const json = JSON.stringify(value);
  if (json.length > maxBytes) throw new Error("WORKSPACE_THREAD_MESSAGE_INVALID");
  return JSON.parse(json) as Record<string, unknown>[];
}

export class EncryptedCaseWorkspaceStore {
  readonly rootDir: string;
  private readonly maxIndexBytes: number;
  private readonly maxMessages: number;

  constructor(options: CaseWorkspaceStoreOptions = {}) {
    this.rootDir = path.resolve(options.rootDir ?? defaultRootDir());
    this.maxIndexBytes = options.maxIndexBytes ?? 12 * 1024 * 1024;
    this.maxMessages = options.maxMessages ?? 250;
  }

  private workspaceFile(caseId: string): string {
    if (!CASE_ID.test(caseId)) {
      throw new Error("INVALID_CASE_ID");
    }
    const target = path.resolve(
      this.rootDir,
      "cases",
      caseId,
      "secure",
      "workspace",
      "index.lmw1"
    );
    const base = path.resolve(this.rootDir, "cases", caseId) + path.sep;
    if (!target.startsWith(base)) {
      throw new Error("CASE_PATH_ESCAPE");
    }
    return target;
  }

  private deriveKey(caseDataKey: Buffer, caseId: string): Buffer {
    if (caseDataKey.byteLength !== 32 || !CASE_ID.test(caseId)) {
      throw new Error("INVALID_CASE_DATA_KEY");
    }
    return Buffer.from(
      hkdfSync(
        "sha256",
        caseDataKey,
        Buffer.from(caseId, "utf8"),
        Buffer.from("lex/case-workspace-index/v1", "utf8"),
        32
      )
    );
  }

  private empty(caseId: string): CaseWorkspaceIndex {
    return {
      schemaVersion: 1,
      caseId,
      updatedAt: new Date().toISOString(),
      folders: [],
      itemLocations: {},
      thread: { messages: [] },
      workflows: {}
    };
  }

  private validateIndex(index: CaseWorkspaceIndex, caseId: string): void {
    if (
      index.schemaVersion !== 1 ||
      index.caseId !== caseId ||
      !Array.isArray(index.folders) ||
      !index.itemLocations ||
      typeof index.itemLocations !== "object" ||
      !Array.isArray(index.thread?.messages)
    ) {
      throw new Error("WORKSPACE_INDEX_INVALID");
    }

    const folders = new Set<string>();
    for (const folder of index.folders) {
      if (
        !FOLDER_ID.test(folder.folderId) ||
        folders.has(folder.folderId) ||
        (folder.parentId !== null && !FOLDER_ID.test(folder.parentId))
      ) {
        throw new Error("WORKSPACE_INDEX_INVALID");
      }
      cleanFolderName(folder.name);
      folders.add(folder.folderId);
    }
    for (const folder of index.folders) {
      if (folder.parentId !== null && !folders.has(folder.parentId)) {
        throw new Error("WORKSPACE_INDEX_INVALID");
      }
    }
    for (const [itemId, folderId] of Object.entries(index.itemLocations)) {
      if (
        !ITEM_ID.test(itemId) ||
        (folderId !== null && !folders.has(folderId))
      ) {
        throw new Error("WORKSPACE_INDEX_INVALID");
      }
    }
    if (index.thread.messages.length > this.maxMessages) {
      throw new Error("WORKSPACE_INDEX_INVALID");
    }
    index.thread.messages.forEach(safeMessage);

    if (index.workflows !== undefined) {
      if (
        !index.workflows ||
        typeof index.workflows !== "object" ||
        Array.isArray(index.workflows)
      ) {
        throw new Error("WORKSPACE_INDEX_INVALID");
      }
      if (index.workflows.processPleading) {
        const workflow =
          validateProcessPleadingState(
            index.workflows.processPleading
          );
        if (workflow.caseId !== caseId) {
          throw new Error("WORKSPACE_INDEX_INVALID");
        }
      }
      if (index.workflows.processPleadingDraft) {
        const draft = validateProcessPleadingDraft(index.workflows.processPleadingDraft);
        if (draft.caseId !== caseId) {
          throw new Error("WORKSPACE_INDEX_INVALID");
        }
      }
      if (index.workflows.courtAnalysis) {
        const workflow =
          validateCourtAnalysisState(
            index.workflows.courtAnalysis
          );
        if (workflow.caseId !== caseId) {
          throw new Error("WORKSPACE_INDEX_INVALID");
        }
      }
      if (index.workflows.chronology) {
        const workflow =
          validateChronologyState(
            index.workflows.chronology
          );
        if (workflow.caseId !== caseId) {
          throw new Error("WORKSPACE_INDEX_INVALID");
        }
      }
      if (index.workflows.contractAnalysis) {
        const workflow =
          validateContractAnalysisState(
            index.workflows.contractAnalysis
          );
        if (workflow.caseId !== caseId) {
          throw new Error("WORKSPACE_INDEX_INVALID");
        }
      }
      if (index.workflows.orderedCase) {
        if (
          typeof index.workflows
            .orderedCase !== "object" ||
          Array.isArray(
            index.workflows
              .orderedCase
          )
        ) {
          throw new Error(
            "WORKSPACE_INDEX_INVALID"
          );
        }
        for (
          const [
            workflowId,
            rawState
          ]
          of Object.entries(
            index.workflows
              .orderedCase
          )
        ) {
          if (!rawState) continue;
          if (
            ![
              "EVIDENCE_ANALYSIS_V1",
              "WITNESS_QUESTIONING_V1"
            ].includes(
              workflowId
            )
          ) {
            throw new Error(
              "WORKSPACE_INDEX_INVALID"
            );
          }
          const workflow =
            validateOrderedCaseWorkflowState(
              rawState as
                OrderedCaseWorkflowState
            );
          if (
            workflow.caseId !==
              caseId ||
            workflow.workflowId !==
              workflowId
          ) {
            throw new Error(
              "WORKSPACE_INDEX_INVALID"
            );
          }
        }
      }
    }
  }

  private async read(
    caseId: string,
    caseDataKey: Buffer,
    keyVersion: number
  ): Promise<CaseWorkspaceIndex> {
    const target = this.workspaceFile(caseId);
    let encoded: string;
    try {
      encoded = await readFile(target, "utf8");
    } catch (error) {
      if (error instanceof Error && "code" in error && error.code === "ENOENT") {
        return this.empty(caseId);
      }
      throw error;
    }
    if (Buffer.byteLength(encoded, "utf8") > this.maxIndexBytes * 2) {
      throw new Error("WORKSPACE_INDEX_TOO_LARGE");
    }

    const envelope = JSON.parse(encoded) as EncryptedWorkspaceEnvelope;
    if (
      envelope.schemaVersion !== 1 ||
      envelope.keyVersion !== keyVersion ||
      typeof envelope.nonce !== "string" ||
      typeof envelope.tag !== "string" ||
      typeof envelope.ciphertext !== "string"
    ) {
      throw new Error("WORKSPACE_ENVELOPE_INVALID");
    }

    const nonce = Buffer.from(envelope.nonce, "base64url");
    const tag = Buffer.from(envelope.tag, "base64url");
    const ciphertext = Buffer.from(envelope.ciphertext, "base64url");
    if (nonce.length !== 12 || tag.length !== 16 || ciphertext.length > this.maxIndexBytes) {
      throw new Error("WORKSPACE_ENVELOPE_INVALID");
    }

    const key = this.deriveKey(caseDataKey, caseId);
    try {
      const decipher = createDecipheriv("aes-256-gcm", key, nonce);
      decipher.setAAD(
        Buffer.from(`LMW1:${caseId}:${keyVersion}`, "utf8")
      );
      decipher.setAuthTag(tag);
      const plain = Buffer.concat([
        decipher.update(ciphertext),
        decipher.final()
      ]);
      if (plain.length > this.maxIndexBytes) {
        plain.fill(0);
        throw new Error("WORKSPACE_INDEX_TOO_LARGE");
      }
      try {
        const index = JSON.parse(plain.toString("utf8")) as CaseWorkspaceIndex;
        this.validateIndex(index, caseId);
        return index;
      } finally {
        plain.fill(0);
      }
    } catch (error) {
      if (
        error instanceof Error &&
        ["WORKSPACE_INDEX_INVALID", "WORKSPACE_INDEX_TOO_LARGE"].includes(error.message)
      ) {
        throw error;
      }
      throw new Error("WORKSPACE_DECRYPT_FAILED");
    } finally {
      key.fill(0);
      nonce.fill(0);
      tag.fill(0);
      ciphertext.fill(0);
    }
  }

  private async write(
    index: CaseWorkspaceIndex,
    caseDataKey: Buffer,
    keyVersion: number
  ): Promise<void> {
    this.validateIndex(index, index.caseId);
    index.updatedAt = new Date().toISOString();
    const plain = Buffer.from(JSON.stringify(index), "utf8");
    if (plain.length > this.maxIndexBytes) {
      plain.fill(0);
      throw new Error("WORKSPACE_INDEX_TOO_LARGE");
    }
    const nonce = randomBytes(12);
    const key = this.deriveKey(caseDataKey, index.caseId);
    try {
      const cipher = createCipheriv("aes-256-gcm", key, nonce);
      cipher.setAAD(
        Buffer.from(`LMW1:${index.caseId}:${keyVersion}`, "utf8")
      );
      const ciphertext = Buffer.concat([
        cipher.update(plain),
        cipher.final()
      ]);
      const envelope: EncryptedWorkspaceEnvelope = {
        schemaVersion: 1,
        keyVersion,
        nonce: nonce.toString("base64url"),
        tag: cipher.getAuthTag().toString("base64url"),
        ciphertext: ciphertext.toString("base64url")
      };
      const target = this.workspaceFile(index.caseId);
      await mkdir(path.dirname(target), { recursive: true, mode: 0o700 });
      const partial = target + ".partial";
      await rm(partial, { force: true });
      await writeFile(partial, JSON.stringify(envelope), {
        encoding: "utf8",
        flag: "wx",
        mode: 0o600
      });
      await rename(partial, target);
      ciphertext.fill(0);
    } finally {
      plain.fill(0);
      nonce.fill(0);
      key.fill(0);
    }
  }

  async listWorkspace(args: {
    caseId: string;
    caseDataKey: Buffer;
    keyVersion: number;
    itemIds: readonly string[];
  }): Promise<CaseWorkspaceIndex> {
    const index = await this.read(args.caseId, args.caseDataKey, args.keyVersion);
    const validItems = new Set(args.itemIds.filter((item) => ITEM_ID.test(item)));
    let changed = false;

    for (const itemId of validItems) {
      if (!(itemId in index.itemLocations)) {
        index.itemLocations[itemId] = null;
        changed = true;
      }
    }
    for (const itemId of Object.keys(index.itemLocations)) {
      if (!validItems.has(itemId)) {
        delete index.itemLocations[itemId];
        changed = true;
      }
    }
    if (changed) {
      await this.write(index, args.caseDataKey, args.keyVersion);
    }
    return index;
  }

  async createFolder(args: {
    caseId: string;
    caseDataKey: Buffer;
    keyVersion: number;
    name: string;
    parentId?: string | null;
  }): Promise<WorkspaceFolder> {
    const index = await this.read(args.caseId, args.caseDataKey, args.keyVersion);
    const parentId = args.parentId ?? null;
    if (parentId !== null && !index.folders.some((item) => item.folderId === parentId)) {
      throw new Error("WORKSPACE_PARENT_FOLDER_NOT_FOUND");
    }
    const folder: WorkspaceFolder = {
      folderId: "folder_" + randomBytes(16).toString("hex"),
      parentId,
      name: cleanFolderName(args.name),
      createdAt: new Date().toISOString()
    };
    index.folders.push(folder);
    await this.write(index, args.caseDataKey, args.keyVersion);
    return folder;
  }

  async deleteFolder(args: {
    caseId: string;
    caseDataKey: Buffer;
    keyVersion: number;
    folderId: string;
  }): Promise<void> {
    if (!FOLDER_ID.test(args.folderId)) {
      throw new Error("WORKSPACE_FOLDER_ID_INVALID");
    }
    const index = await this.read(args.caseId, args.caseDataKey, args.keyVersion);
    if (!index.folders.some((item) => item.folderId === args.folderId)) {
      throw new Error("WORKSPACE_FOLDER_NOT_FOUND");
    }
    if (
      index.folders.some((item) => item.parentId === args.folderId) ||
      Object.values(index.itemLocations).some((folderId) => folderId === args.folderId)
    ) {
      throw new Error("WORKSPACE_FOLDER_NOT_EMPTY");
    }
    index.folders = index.folders.filter((item) => item.folderId !== args.folderId);
    await this.write(index, args.caseDataKey, args.keyVersion);
  }

  async moveItem(args: {
    caseId: string;
    caseDataKey: Buffer;
    keyVersion: number;
    itemId: string;
    folderId: string | null;
    knownItemIds: readonly string[];
  }): Promise<void> {
    if (!ITEM_ID.test(args.itemId) || !args.knownItemIds.includes(args.itemId)) {
      throw new Error("WORKSPACE_ITEM_NOT_FOUND");
    }
    const index = await this.read(args.caseId, args.caseDataKey, args.keyVersion);
    if (
      args.folderId !== null &&
      !index.folders.some((item) => item.folderId === args.folderId)
    ) {
      throw new Error("WORKSPACE_FOLDER_NOT_FOUND");
    }
    index.itemLocations[args.itemId] = args.folderId;
    await this.write(index, args.caseDataKey, args.keyVersion);
  }

  async forgetItem(args: {
    caseId: string;
    caseDataKey: Buffer;
    keyVersion: number;
    itemId: string;
  }): Promise<void> {
    const index = await this.read(args.caseId, args.caseDataKey, args.keyVersion);
    if (args.itemId in index.itemLocations) {
      delete index.itemLocations[args.itemId];
      await this.write(index, args.caseDataKey, args.keyVersion);
    }
  }

  async loadThread(args: {
    caseId: string;
    caseDataKey: Buffer;
    keyVersion: number;
  }): Promise<WorkspaceThreadMessage[]> {
    const index = await this.read(args.caseId, args.caseDataKey, args.keyVersion);
    return index.thread.messages.map((item) => ({
      ...item,
      ...(item.documentCitations
        ? { documentCitations: item.documentCitations.map((citation) => ({ ...citation })) }
        : {}),
      ...(item.restorations
        ? { restorations: item.restorations.map((restoration) => ({ ...restoration })) }
        : {}),
      ...(item.widgets ? { widgets: item.widgets.map((widget) => ({ ...widget })) } : {}),
      ...(item.evidence ? { evidence: structuredClone(item.evidence) } : {}),
      ...(item.auxiliarySources ? { auxiliarySources: structuredClone(item.auxiliarySources) } : {}),
      ...(item.mandatoryPath ? { mandatoryPath: structuredClone(item.mandatoryPath) } : {}),
      ...(item.pipelineNext ? { pipelineNext: structuredClone(item.pipelineNext) } : {}),
      ...(item.documentCoverage ? { documentCoverage: structuredClone(item.documentCoverage) } : {}),
      ...(item.documentAnalysis ? { documentAnalysis: true } : {}),
      ...(item.answerDocument ? { answerDocument: { sessionId: item.answerDocument.sessionId } } : {}),
      ...(item.corrections ? { corrections: structuredClone(item.corrections) } : {})
    }));
  }

  async appendThreadMessage(args: {
    caseId: string;
    caseDataKey: Buffer;
    keyVersion: number;
    message: WorkspaceThreadMessage;
  }): Promise<WorkspaceThreadMessage> {
    const index = await this.read(args.caseId, args.caseDataKey, args.keyVersion);
    const message = safeMessage(args.message);
    const existing = index.thread.messages.findIndex(
      (item) => item.messageId === message.messageId
    );
    if (existing >= 0) {
      // A corrected message keeps its place in the thread.
      index.thread.messages[existing] = message;
    } else {
      index.thread.messages = [...index.thread.messages, message].slice(-this.maxMessages);
    }
    await this.write(index, args.caseDataKey, args.keyVersion);
    return message;
  }

  async getProcessPleadingState(args: {
    caseId: string;
    caseDataKey: Buffer;
    keyVersion: number;
  }): Promise<ProcessPleadingState | null> {
    const index = await this.read(
      args.caseId,
      args.caseDataKey,
      args.keyVersion
    );
    const state =
      index.workflows?.processPleading;
    return state
      ? validateProcessPleadingState(state)
      : null;
  }

  async saveProcessPleadingState(args: {
    caseId: string;
    caseDataKey: Buffer;
    keyVersion: number;
    state: ProcessPleadingState;
    expectedRevision?: number;
  }): Promise<ProcessPleadingState> {
    const state =
      validateProcessPleadingState(
        args.state
      );
    if (state.caseId !== args.caseId) {
      throw new Error(
        "PROCESS_PLEADING_CASE_ID_MISMATCH"
      );
    }
    const index = await this.read(
      args.caseId,
      args.caseDataKey,
      args.keyVersion
    );
    const current =
      index.workflows?.processPleading;
    if (
      args.expectedRevision !==
        undefined &&
      (
        !current ||
        current.revision !==
          args.expectedRevision
      )
    ) {
      throw new Error(
        "PROCESS_PLEADING_STATE_CONFLICT"
      );
    }
    index.workflows ??= {};
    index.workflows.processPleading =
      state;
    await this.write(
      index,
      args.caseDataKey,
      args.keyVersion
    );
    return validateProcessPleadingState(
      state
    );
  }

  async clearProcessPleadingState(args: {
    caseId: string;
    caseDataKey: Buffer;
    keyVersion: number;
    expectedRevision?: number;
  }): Promise<boolean> {
    const index = await this.read(
      args.caseId,
      args.caseDataKey,
      args.keyVersion
    );
    const workflows =
      index.workflows;
    const current =
      workflows?.processPleading;
    if (!workflows || !current) {
      return false;
    }
    if (
      args.expectedRevision !==
        undefined &&
      current.revision !==
        args.expectedRevision
    ) {
      throw new Error(
        "PROCESS_PLEADING_STATE_CONFLICT"
      );
    }
    delete workflows.processPleading;
    // A new pipeline starts without the previous pleading's text.
    delete workflows.processPleadingDraft;
    await this.write(
      index,
      args.caseDataKey,
      args.keyVersion
    );
    return true;
  }

  async getProcessPleadingDraft(args: {
    caseId: string;
    caseDataKey: Buffer;
    keyVersion: number;
  }): Promise<ProcessPleadingDraft | null> {
    const index = await this.read(args.caseId, args.caseDataKey, args.keyVersion);
    const draft = index.workflows?.processPleadingDraft;
    return draft ? validateProcessPleadingDraft(draft) : null;
  }

  async saveProcessPleadingDraft(args: {
    caseId: string;
    caseDataKey: Buffer;
    keyVersion: number;
    draft: ProcessPleadingDraft;
    // Revision of the draft the change was made on (0: none yet).
    expectedRevision: number;
  }): Promise<ProcessPleadingDraft> {
    const draft = validateProcessPleadingDraft(args.draft);
    if (draft.caseId !== args.caseId) throw new Error("PROCESS_PLEADING_DRAFT_INVALID");
    const index = await this.read(args.caseId, args.caseDataKey, args.keyVersion);
    if ((index.workflows?.processPleadingDraft?.revision ?? 0) !== args.expectedRevision) {
      throw new Error("PROCESS_PLEADING_DRAFT_CONFLICT");
    }
    index.workflows ??= {};
    index.workflows.processPleadingDraft = draft;
    await this.write(index, args.caseDataKey, args.keyVersion);
    return validateProcessPleadingDraft(draft);
  }

  async getCourtAnalysisState(args: {
    caseId: string;
    caseDataKey: Buffer;
    keyVersion: number;
  }): Promise<CourtAnalysisState | null> {
    const index = await this.read(
      args.caseId,
      args.caseDataKey,
      args.keyVersion
    );
    const state =
      index.workflows?.courtAnalysis;
    return state
      ? validateCourtAnalysisState(
          state
        )
      : null;
  }

  async saveCourtAnalysisState(args: {
    caseId: string;
    caseDataKey: Buffer;
    keyVersion: number;
    state: CourtAnalysisState;
    expectedRevision?: number;
  }): Promise<CourtAnalysisState> {
    const state =
      validateCourtAnalysisState(
        args.state
      );
    if (
      state.caseId !==
        args.caseId
    ) {
      throw new Error(
        "COURT_ANALYSIS_CASE_ID_MISMATCH"
      );
    }

    const index =
      await this.read(
        args.caseId,
        args.caseDataKey,
        args.keyVersion
      );
    const current =
      index.workflows?.courtAnalysis;
    if (
      args.expectedRevision !==
        undefined &&
      (
        !current ||
        current.revision !==
          args.expectedRevision
      )
    ) {
      throw new Error(
        "COURT_ANALYSIS_STATE_CONFLICT"
      );
    }

    index.workflows ??= {};
    index.workflows.courtAnalysis =
      state;
    await this.write(
      index,
      args.caseDataKey,
      args.keyVersion
    );
    return validateCourtAnalysisState(
      state
    );
  }

  async clearCourtAnalysisState(args: {
    caseId: string;
    caseDataKey: Buffer;
    keyVersion: number;
    expectedRevision?: number;
  }): Promise<boolean> {
    const index =
      await this.read(
        args.caseId,
        args.caseDataKey,
        args.keyVersion
      );
    const workflows =
      index.workflows;
    const current =
      workflows?.courtAnalysis;
    if (!workflows || !current) {
      return false;
    }
    if (
      args.expectedRevision !==
        undefined &&
      current.revision !==
        args.expectedRevision
    ) {
      throw new Error(
        "COURT_ANALYSIS_STATE_CONFLICT"
      );
    }

    delete workflows.courtAnalysis;
    await this.write(
      index,
      args.caseDataKey,
      args.keyVersion
    );
    return true;
  }

  async getCaseMemory(args: {
    caseId: string;
    caseDataKey: Buffer;
    keyVersion: number;
  }): Promise<CaseMemory & { threadMessages: WorkspaceThreadMessage[] }> {
    const index = await this.read(args.caseId, args.caseDataKey, args.keyVersion);
    const evidence = validThreadEvidence(index.memory?.evidence);
    const summary = validThreadSummary(index.memory?.summary);
    const chronology = validCaseChronology(index.memory?.chronology);
    const overview = validCaseOverview(index.memory?.overview);
    const work = validCaseWork(index.memory?.work);
    const longDocument = validLongDocument(index.memory?.longDocument);
    const court = validCaseCourt(index.memory?.court);
    const answerDocument = validAnswerDocument(index.memory?.answerDocument);
    return {
      ...(court ? { court } : {}),
      ...(answerDocument ? { answerDocument } : {}),
      ...(work?.length ? { work } : {}),
      ...(longDocument ? { longDocument } : {}),
      ...(evidence ? { evidence } : {}),
      ...(summary ? { summary } : {}),
      ...(chronology ? { chronology } : {}),
      ...(overview ? { overview } : {}),
      threadMessages: index.thread.messages.map((message) => ({ ...message }))
    };
  }

  /** Replaces the given parts of the memory; null removes a part. */
  async saveCaseMemory(args: {
    caseId: string;
    caseDataKey: Buffer;
    keyVersion: number;
    evidence?: ThreadEvidence | null;
    summary?: ThreadSummary | null;
    chronology?: CaseChronology | null;
    overview?: CaseOverview | null;
    work?: CaseWorkItem[] | null;
    longDocument?: LongDocumentState | null;
    court?: CaseCourt | null;
    answerDocument?: AnswerDocument | null;
  }): Promise<CaseMemory> {
    const index = await this.read(args.caseId, args.caseDataKey, args.keyVersion);
    const memory: CaseMemory = { ...(index.memory ?? {}) };
    if (args.evidence !== undefined) {
      const evidence = args.evidence === null ? null : validThreadEvidence(args.evidence);
      if (args.evidence !== null && !evidence) throw new Error("CASE_MEMORY_EVIDENCE_INVALID");
      if (evidence) memory.evidence = evidence;
      else delete memory.evidence;
    }
    if (args.summary !== undefined) {
      const summary = args.summary === null ? null : validThreadSummary(args.summary);
      if (args.summary !== null && !summary) throw new Error("CASE_MEMORY_SUMMARY_INVALID");
      if (summary) memory.summary = summary;
      else delete memory.summary;
    }
    if (args.chronology !== undefined) {
      const chronology = args.chronology === null ? null : validCaseChronology(args.chronology);
      if (args.chronology !== null && !chronology) throw new Error("CASE_MEMORY_CHRONOLOGY_INVALID");
      if (chronology) memory.chronology = chronology;
      else delete memory.chronology;
    }
    if (args.overview !== undefined) {
      const overview = args.overview === null ? null : validCaseOverview(args.overview);
      if (args.overview !== null && !overview) throw new Error("CASE_MEMORY_OVERVIEW_INVALID");
      if (overview) memory.overview = overview;
      else delete memory.overview;
    }
    if (args.work !== undefined) {
      const work = args.work === null ? null : validCaseWork(args.work);
      if (args.work !== null && !work) throw new Error("CASE_MEMORY_WORK_INVALID");
      if (work?.length) memory.work = work;
      else delete memory.work;
    }
    if (args.longDocument !== undefined) {
      const longDocument = args.longDocument === null ? null : validLongDocument(args.longDocument);
      if (args.longDocument !== null && !longDocument) throw new Error("CASE_MEMORY_LONG_DOCUMENT_INVALID");
      if (longDocument) memory.longDocument = longDocument;
      else delete memory.longDocument;
    }
    if (args.court !== undefined) {
      const court = args.court === null ? null : validCaseCourt(args.court);
      if (args.court !== null && !court) throw new Error("CASE_MEMORY_COURT_INVALID");
      if (court) memory.court = court;
      else delete memory.court;
    }
    if (args.answerDocument !== undefined) {
      const answerDocument = args.answerDocument === null ? null : validAnswerDocument(args.answerDocument);
      if (args.answerDocument !== null && !answerDocument) throw new Error("CASE_MEMORY_ANSWER_DOCUMENT_INVALID");
      if (answerDocument) memory.answerDocument = answerDocument;
      else delete memory.answerDocument;
    }
    index.memory = memory;
    await this.write(index, args.caseDataKey, args.keyVersion);
    return memory;
  }

  async getChronologyState(args: {
    caseId: string;
    caseDataKey: Buffer;
    keyVersion: number;
  }): Promise<ChronologyState | null> {
    const index = await this.read(
      args.caseId,
      args.caseDataKey,
      args.keyVersion
    );
    const state =
      index.workflows?.chronology;
    return state
      ? validateChronologyState(state)
      : null;
  }

  async saveChronologyState(args: {
    caseId: string;
    caseDataKey: Buffer;
    keyVersion: number;
    state: ChronologyState;
    expectedRevision?: number;
  }): Promise<ChronologyState> {
    const state =
      validateChronologyState(
        args.state
      );
    if (state.caseId !== args.caseId) {
      throw new Error(
        "CHRONOLOGY_CASE_ID_MISMATCH"
      );
    }

    const index = await this.read(
      args.caseId,
      args.caseDataKey,
      args.keyVersion
    );
    const current =
      index.workflows?.chronology;
    if (
      args.expectedRevision !== undefined &&
      (
        !current ||
        current.revision !==
          args.expectedRevision
      )
    ) {
      throw new Error(
        "CHRONOLOGY_STATE_CONFLICT"
      );
    }

    index.workflows ??= {};
    index.workflows.chronology =
      state;
    await this.write(
      index,
      args.caseDataKey,
      args.keyVersion
    );
    return validateChronologyState(
      state
    );
  }

  async clearChronologyState(args: {
    caseId: string;
    caseDataKey: Buffer;
    keyVersion: number;
    expectedRevision?: number;
  }): Promise<boolean> {
    const index = await this.read(
      args.caseId,
      args.caseDataKey,
      args.keyVersion
    );
    const workflows =
      index.workflows;
    const current =
      workflows?.chronology;
    if (!workflows || !current) {
      return false;
    }
    if (
      args.expectedRevision !== undefined &&
      current.revision !==
        args.expectedRevision
    ) {
      throw new Error(
        "CHRONOLOGY_STATE_CONFLICT"
      );
    }

    delete workflows.chronology;
    await this.write(
      index,
      args.caseDataKey,
      args.keyVersion
    );
    return true;
  }

  async getContractAnalysisState(args: {
    caseId: string;
    caseDataKey: Buffer;
    keyVersion: number;
  }): Promise<ContractAnalysisState | null> {
    const index = await this.read(
      args.caseId,
      args.caseDataKey,
      args.keyVersion
    );
    const state =
      index.workflows?.contractAnalysis;
    return state
      ? validateContractAnalysisState(
          state
        )
      : null;
  }

  async saveContractAnalysisState(args: {
    caseId: string;
    caseDataKey: Buffer;
    keyVersion: number;
    state: ContractAnalysisState;
    expectedRevision?: number;
  }): Promise<ContractAnalysisState> {
    const state =
      validateContractAnalysisState(
        args.state
      );
    if (
      state.caseId !==
        args.caseId
    ) {
      throw new Error(
        "CONTRACT_CASE_ID_MISMATCH"
      );
    }

    const index = await this.read(
      args.caseId,
      args.caseDataKey,
      args.keyVersion
    );
    const current =
      index.workflows
        ?.contractAnalysis;
    if (
      args.expectedRevision !==
        undefined &&
      (
        !current ||
        current.revision !==
          args.expectedRevision
      )
    ) {
      throw new Error(
        "CONTRACT_STATE_CONFLICT"
      );
    }

    index.workflows ??= {};
    index.workflows.contractAnalysis =
      state;
    await this.write(
      index,
      args.caseDataKey,
      args.keyVersion
    );
    return validateContractAnalysisState(
      state
    );
  }

  async clearContractAnalysisState(args: {
    caseId: string;
    caseDataKey: Buffer;
    keyVersion: number;
    expectedRevision?: number;
  }): Promise<boolean> {
    const index = await this.read(
      args.caseId,
      args.caseDataKey,
      args.keyVersion
    );
    const workflows =
      index.workflows;
    const current =
      workflows?.contractAnalysis;
    if (
      !workflows ||
      !current
    ) {
      return false;
    }
    if (
      args.expectedRevision !==
        undefined &&
      current.revision !==
        args.expectedRevision
    ) {
      throw new Error(
        "CONTRACT_STATE_CONFLICT"
      );
    }

    delete workflows
      .contractAnalysis;
    await this.write(
      index,
      args.caseDataKey,
      args.keyVersion
    );
    return true;
  }

  async getOrderedCaseWorkflowState(args: {
    caseId: string;
    workflowId:
      OrderedCaseWorkflowId;
    caseDataKey: Buffer;
    keyVersion: number;
  }): Promise<OrderedCaseWorkflowState | null> {
    const index = await this.read(
      args.caseId,
      args.caseDataKey,
      args.keyVersion
    );
    const state =
      index.workflows
        ?.orderedCase
        ?.[args.workflowId];
    return state
      ? validateOrderedCaseWorkflowState(
          state
        )
      : null;
  }

  async saveOrderedCaseWorkflowState(args: {
    caseId: string;
    workflowId:
      OrderedCaseWorkflowId;
    caseDataKey: Buffer;
    keyVersion: number;
    state:
      OrderedCaseWorkflowState;
    expectedRevision?: number;
  }): Promise<OrderedCaseWorkflowState> {
    const state =
      validateOrderedCaseWorkflowState(
        args.state
      );
    if (
      state.caseId !== args.caseId ||
      state.workflowId !==
        args.workflowId
    ) {
      throw new Error(
        "ORDERED_WORKFLOW_CASE_OR_ID_MISMATCH"
      );
    }

    const index = await this.read(
      args.caseId,
      args.caseDataKey,
      args.keyVersion
    );
    const current =
      index.workflows
        ?.orderedCase
        ?.[args.workflowId];

    if (
      args.expectedRevision !==
        undefined &&
      (
        !current ||
        current.revision !==
          args.expectedRevision
      )
    ) {
      throw new Error(
        "ORDERED_WORKFLOW_STATE_CONFLICT"
      );
    }

    index.workflows ??= {};
    index.workflows.orderedCase ??= {};
    index.workflows
      .orderedCase[
        args.workflowId
      ] = state;

    await this.write(
      index,
      args.caseDataKey,
      args.keyVersion
    );
    return validateOrderedCaseWorkflowState(
      state
    );
  }

  async clearOrderedCaseWorkflowState(args: {
    caseId: string;
    workflowId:
      OrderedCaseWorkflowId;
    caseDataKey: Buffer;
    keyVersion: number;
    expectedRevision?: number;
  }): Promise<boolean> {
    const index = await this.read(
      args.caseId,
      args.caseDataKey,
      args.keyVersion
    );
    const workflows =
      index.workflows
        ?.orderedCase;
    const current =
      workflows?.[
        args.workflowId
      ];
    if (!workflows || !current) {
      return false;
    }
    if (
      args.expectedRevision !==
        undefined &&
      current.revision !==
        args.expectedRevision
    ) {
      throw new Error(
        "ORDERED_WORKFLOW_STATE_CONFLICT"
      );
    }

    delete workflows[
      args.workflowId
    ];
    await this.write(
      index,
      args.caseDataKey,
      args.keyVersion
    );
    return true;
  }

  async rekeyCaseWorkspace(args: {
    caseId: string;
    oldCaseDataKey: Buffer;
    oldKeyVersion: number;
    newCaseDataKey: Buffer;
    newKeyVersion: number;
  }): Promise<boolean> {
    const target = this.workspaceFile(args.caseId);
    try {
      await readFile(target);
    } catch (error) {
      if (error instanceof Error && "code" in error && error.code === "ENOENT") {
        return false;
      }
      throw error;
    }
    const index = await this.read(
      args.caseId,
      args.oldCaseDataKey,
      args.oldKeyVersion
    );
    await this.write(index, args.newCaseDataKey, args.newKeyVersion);
    return true;
  }
}
