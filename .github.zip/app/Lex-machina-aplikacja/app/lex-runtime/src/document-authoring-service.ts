import {
  createHash
} from "node:crypto";
import type {
  DeanonymizationTargetState
} from "./auth/reauthorization.js";
import type {
  SecureCaseArtifactStore,
  StoredCaseArtifact
} from "./case-artifact-store.js";
import {
  buildGenerationAliases,
  resolveGenerationAliases,
  applyRestorationOverrides,
  describeGenerationAliases,
  renderRestorationPreview,
  type DocumentRestoration,
  type RestorationPreview,
  type GenerationAliasManifest
} from "./generation-aliases.js";
import {
  legalDocumentPlainText,
  validateLegalDocumentAst,
  type LegalDocumentAst
} from "./legal-document-ast.js";
import {
  LocalLegalDocumentRenderer,
  type LegalDocumentFormat
} from "./legal-document-renderer.js";
import type { LetterheadReport } from "./legal-document-renderer.js";
import type {
  DocumentGenerationStateStore
} from "./document-generation-state.js";
import {
  privacyVaultDeanonymizationKeyBinding,
  type EncryptedPrivacyVaultStore
} from "./privacy/vault-store.js";
import type {
  DocumentGenerationValidationContext
} from "./document-generation-validation.js";
import {
  rebuildGenerationExportState,
  validateLocalHybridDocument
} from "./document-generation-validation.js";
import {
  ExportGate,
  type ExportGateReport
} from "./export-gate.js";
import { CASE_MATERIAL_MARKER_TEXT, FinalizationGate, markUnverifiedReferences, type FinalizationReport } from "./finalization-gate.js";
import { astTextLines } from "./ast-text-lines.js";
import { stripAstVerificationMarkers } from "./verification-markers.js";
import { documentCompletenessWarnings } from "./document-completeness.js";

export type BlockedReference = {
  claim: string;
  status: string;
  line: number;
};

/**
 * Export refused: the gate's reasons and the references behind them, so the
 * user sees which provisions and judgments block the file. `draftAvailable`:
 * only unverified (not blocked) references - a draft naming them may be saved.
 */
export class ExportGateBlockedError extends Error {
  constructor(
    code: string,
    readonly reasons: string[],
    readonly references: BlockedReference[],
    readonly draftAvailable: boolean
  ) {
    super(`${code}:${reasons.join(",")}`);
    this.name = "ExportGateBlockedError";
  }
}

function blockedReferences(finalization: FinalizationReport | undefined): BlockedReference[] {
  if (!finalization) return [];
  return [
    ...finalization.findings
      .filter((finding) => finding.status !== "VERIFIED")
      .map((finding) => ({ claim: finding.reference.claim, status: finding.status, line: finding.reference.line })),
    ...finalization.caseQuoteFindings
      .filter((finding) => finding.status !== "VERIFIED")
      .map((finding) => ({ claim: finding.lineText.trim().slice(0, 160), status: finding.status, line: finding.line })),
    ...finalization.caseSupportFindings
      .filter((finding) => finding.status !== "SUPPORTED")
      .map((finding) => ({ claim: finding.lineText.trim().slice(0, 160), status: finding.status, line: finding.line }))
  ];
}

function exportBlocked(code: string, report: ExportGateReport): ExportGateBlockedError {
  return new ExportGateBlockedError(
    code,
    report.reasons,
    blockedReferences(report.finalization),
    report.reasons.length === 1 && report.reasons[0] === "UNVERIFIED_REFERENCE_REQUIRES_HUMAN_DECISION"
  );
}

/**
 * A signature the case's materials name (VIII W 633/25 in RD 121/26) written in the file
 * without its marker: marked "z materiałów sprawy" as in the chat, so it is an unverified
 * reference the user may accept in a draft, not a blocking judgment of unknown origin.
 */
function markCaseMaterialSignatures(markedText: string, context: DocumentGenerationValidationContext): string {
  const ledger = rebuildGenerationExportState(context).ledger;
  const caseReferences = new Set(ledger.caseReferences());
  if (caseReferences.size === 0) return markedText;
  const report = new FinalizationGate().evaluate(markedText, ledger);
  const cases = { ...report, findings: report.findings.filter((finding) => finding.reference.kind === "case") };
  return markUnverifiedReferences(markedText, cases, caseReferences);
}

/**
 * The user's choice "save it as a draft" (W3-WERYFIKACJA, wybór b): the
 * references G8 finds unverified, named at the top of the file. Null when
 * nothing is unverified or something blocks outright.
 */
function unverifiedDraft(
  markedText: string,
  context: DocumentGenerationValidationContext
): { claims: string[]; ast: (ast: LegalDocumentAst) => LegalDocumentAst } | null {
  // The document's text nodes as lines (ast-text-lines.ts): a provision's act and marker are its own.
  const report = new FinalizationGate().evaluate(astTextLines(markedText)?.text ?? markedText, rebuildGenerationExportState(context).ledger);
  // The session that wrote the file named its unverified references; the file text may have
  // lost their markers, the heading never loses them.
  const fromSession = context.acceptedUnverifiedSource?.claims ?? [];
  if (report.result !== "DEGRADED" && !fromSession.length) return null;
  const claims = [
    ...new Set([
      ...fromSession,
      ...(report.result === "DEGRADED"
        ? report.findings
            .filter((finding) => finding.status === "UNVERIFIED_MARKED" && finding.reference.kind !== "amount")
            // A signature of the case's materials is marked as such, not unverified in a source.
            .filter((finding) => !finding.reference.lineText.includes(CASE_MATERIAL_MARKER_TEXT))
            .map((finding) => finding.reference.claim)
        : [])
    ])
  ];
  return {
    claims,
    ast: (ast) => ({
      ...ast,
      blocks: [
        {
          type: "paragraph",
          content: [{
            type: "text",
            text: claims.length
              ? `PROJEKT – NIE SKŁADAĆ BEZ WERYFIKACJI. Powołania niezweryfikowane w źródle: ${claims.join("; ")}.`
              : "PROJEKT – NIE SKŁADAĆ BEZ WERYFIKACJI."
          }]
        },
        ...ast.blocks
      ]
    })
  };
}

export type TokenizedDocumentResult = {
  // The firm's template (letterhead) applied to the file, or why not.
  letterhead?: LetterheadReport;
  artifact:
    StoredCaseArtifact;
  format:
    LegalDocumentFormat;
  tokenizedSha256:
    string;
  vaultGeneration:
    number;
  aliases:
    GenerationAliasManifest;
  aliasesUsed:
    string[];
  text:
    string;
  deanonymizationKeyBound:
    true;
  // Not reasons to refuse: what the user should check (fields, title, signature).
  warnings: string[];
};

export type FinalDocumentResult = {
  artifact:
    StoredCaseArtifact;
  format:
    LegalDocumentFormat;
  sha256: string;
  text: string;
  replacements: number;
  deanonymizationBasis:
    "PRIVACY_VAULT_KEY";
  keyBindingVerified:
    boolean;
  restorations?: DocumentRestoration[];
};

export type ReadyDocumentResult = {
  artifact:
    StoredCaseArtifact;
  format:
    LegalDocumentFormat;
  sha256: string;
  text: string;
  warnings: string[];
  // The firm's template (letterhead) applied to the file, or why not.
  letterhead?: LetterheadReport;
};

export class LocalDocumentAuthoringService {
  constructor(
    private readonly vaults:
      Partial<Pick<EncryptedPrivacyVaultStore, "sharedMembers">> &
      Pick<
        EncryptedPrivacyVaultStore,
        | "loadDocumentVault"
        | "getGeneration"
      >,
    private readonly artifacts:
      Pick<
        SecureCaseArtifactStore,
        | "saveArtifact"
        | "readArtifact"
      >,
    private readonly states:
      Pick<
        DocumentGenerationStateStore,
        | "saveTokenized"
        | "readState"
        | "loadAliases"
        | "loadValidationContext"
        | "markFinalized"
      >,
    private readonly renderer =
      new LocalLegalDocumentRenderer()
  ) {}

  async aliasManifest(args: {
    caseId: string;
    sourceDocumentIds:
      string[];
    caseDataKey:
      Buffer;
    keyVersion:
      number;
  }): Promise<
    GenerationAliasManifest
  > {
    const unique =
      [
        ...new Set(
          args
            .sourceDocumentIds
        )
      ];
    if (
      unique.length > 99 ||
      unique.some(
        (documentId) =>
          !/^doc_[a-f0-9]{24}$/
            .test(
              documentId
            )
      )
    ) {
      throw new Error(
        "GENERATION_SOURCE_DOCUMENTS_INVALID"
      );
    }

    const sharedMembers =
      this.vaults.sharedMembers
        ? await this.vaults.sharedMembers({
            caseId: args.caseId,
            caseDataKey: args.caseDataKey,
            keyVersion: args.keyVersion
          })
        : new Set<string>();
    const documents =
      [];
    for (
      const documentId
      of unique
    ) {
      documents.push({
        documentId,
        shared: sharedMembers.has(documentId),
        vault:
          await this.vaults
            .loadDocumentVault({
              caseId:
                args.caseId,
              documentId,
              caseDataKey:
                args.caseDataKey,
              keyVersion:
                args.keyVersion
            })
      });
    }
    return buildGenerationAliases(
      documents
    );
  }

  async createTokenized(args: {
    // The firm's template file (DOCX): its letterhead frames the generated body.
    template?: Uint8Array;
    caseId: string;
    createdByUserId:
      string;
    format:
      LegalDocumentFormat;
    ast: unknown;
    sourceDocumentIds:
      string[];
    caseDataKey:
      Buffer;
    keyVersion:
      number;
    // Pipeline status of a pleading (draft files stay tokenized for good).
    processDocumentStatus?: "DRAFT" | "FINAL";
    // The user saves a draft with its unverified references named.
    acceptUnverified?: boolean;
    validationContext:
      DocumentGenerationValidationContext;
    filename?: string;
  }): Promise<
    TokenizedDocumentResult
  > {
    const aliases =
      await this.aliasManifest({
        caseId:
          args.caseId,
        sourceDocumentIds:
          args
            .sourceDocumentIds,
        caseDataKey:
          args.caseDataKey,
        keyVersion:
          args.keyVersion
      });
    const validated =
      validateLegalDocumentAst(
        args.ast,
        aliases.entries
      );
    // STRIP-VER-GATE: the file carries the provisions, not their markers.
    const draft =
      args.acceptUnverified
        ? unverifiedDraft(legalDocumentPlainText(validated.ast), args.validationContext)
        : null;
    const stripped =
      stripAstVerificationMarkers(
        validated.ast
      ).ast;
    const documentAst = draft ? draft.ast(stripped) : stripped;

    const rendered =
      await this.renderer
        .render(
          args.format,
          documentAst,
          args.template
        );
    try {
      const validation =
        await this.renderer
          .validate(
            args.format,
            rendered.data
          );
      const astText =
        legalDocumentPlainText(
          documentAst
        );
      // Which check failed, named: an empty document, the file's text not what was rendered,
      // or a privacy symbol of the document missing from the file.
      const flat = (value: string) => value.replace(/\s+/g, " ").trim();
      // A reference in a grammatical case is written "[LMPII:D00:PERSON:0003|GEN]" (pii_ref_text in
      // the worker): the symbol is in the file with or without its case.
      const inFile = (alias: string) =>
        new RegExp(`${alias.slice(0, -1).replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}(?:\\|[A-Z]+)?\\]`).test(validation.text);
      const missingAliases = validated.aliasesUsed.filter((alias) => !inFile(alias));
      const failure = !astText
        ? "EMPTY_DOCUMENT"
        : flat(validation.text) !== flat(rendered.text)
          ? "RENDERED_TEXT_MISMATCH"
          : missingAliases.length
            ? `ALIAS_MISSING:${missingAliases.slice(0, 5).join(",")}`
            : null;
      if (failure) {
        throw new Error(
          `TOKENIZED_DOCUMENT_VALIDATION_FAILED:${failure}`
        );
      }

      // HYBRID-VAL before the .docx, as for a ready document; the privacy tokens are this
      // file's purpose (they are replaced and checked again on deanonymization).
      const hybridReasons =
        validateLocalHybridDocument(
          validation.text,
          args.validationContext
        ).reasons.filter(
          (reason) =>
            reason !== "PRIVACY_TOKEN_REMAINS"
        );
      if (hybridReasons.length) {
        throw new Error(
          "TOKENIZED_DOCUMENT_HYBRID_BLOCKED:" +
          hybridReasons.join(",")
        );
      }

      const tokenizedSha256 =
        createHash("sha256")
          .update(
            rendered.data
          )
          .digest("hex");
      const vaultGeneration =
        await this.vaults
          .getGeneration({
            caseId:
              args.caseId,
            caseDataKey:
              args.caseDataKey,
            keyVersion:
              args.keyVersion
          });
      if (
        vaultGeneration < 1
      ) {
        throw new Error(
          "GENERATION_VAULT_EMPTY"
        );
      }

      const ext =
        args.format;
      const artifact =
        await this.artifacts
          .saveArtifact({
            caseId:
              args.caseId,
            filename:
              args.filename ??
              `document-tokenized.${ext}`,
            mediaType:
              args.format ===
                "docx"
                ? "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                : "application/vnd.oasis.opendocument.text",
            data:
              rendered.data,
            caseDataKey:
              args.caseDataKey,
            keyVersion:
              args.keyVersion,
            sensitivity:
              "PROTECTED",
            createdByUserId:
              args
                .createdByUserId
          });

      await this.states
        .saveTokenized({
          state: {
            schemaVersion: 1,
            caseId:
              args.caseId,
            artifactId:
              artifact
                .artifactId,
            format:
              args.format,
            state:
              "TOKENIZED_VALIDATED",
            tokenizedSha256,
            vaultGeneration,
            caseKeyVersion:
              args.keyVersion,
            deanonymizationKeyBinding:
              privacyVaultDeanonymizationKeyBinding({
                caseId:
                  args.caseId,
                caseDataKey:
                  args.caseDataKey,
                keyVersion:
                  args.keyVersion
              }),
            ...(validated.ast.documentType ===
              "pleading"
              ? {
                  workflowRequirement:
                    "PROCESS_PLEADING_FINAL" as const
                }
              : {}),
            ...(args.processDocumentStatus ? { processDocumentStatus: args.processDocumentStatus } : {}),
            ...(draft ? { unverifiedAccepted: draft.claims } : {}),
            createdAt:
              new Date()
                .toISOString()
          },
          aliases,
          validation:
            args.validationContext,
          caseDataKey:
            args.caseDataKey
        });

      return {
        artifact,
        format:
          args.format,
        tokenizedSha256,
        vaultGeneration,
        aliases,
        aliasesUsed:
          validated
            .aliasesUsed,
        text:
          rendered.text,
        deanonymizationKeyBound:
          true,
        warnings:
          documentCompletenessWarnings(documentAst, rendered.text),
        ...(rendered.template ? { letterhead: rendered.template } : {})
      };
    } finally {
      rendered.data.fill(0);
    }
  }

  async createReady(args: {
    // The firm's template file (DOCX): its letterhead frames the generated body.
    template?: Uint8Array;
    caseId: string;
    createdByUserId:
      string;
    format:
      LegalDocumentFormat;
    ast: unknown;
    caseDataKey:
      Buffer;
    keyVersion:
      number;
    validationContext:
      DocumentGenerationValidationContext;
    filename?: string;
    // The user saves a draft with its unverified references named.
    acceptUnverified?: boolean;
  }): Promise<
    ReadyDocumentResult
  > {
    const validated =
      validateLegalDocumentAst(
        args.ast,
        []
      );
    if (
      validated
        .aliasesUsed
        .length > 0
    ) {
      throw new Error(
        "READY_DOCUMENT_PII_ALIAS_FORBIDDEN"
      );
    }

    // G8 reads the markers; the court gets the document without them.
    const markedText =
      markCaseMaterialSignatures(
        legalDocumentPlainText(
          validated.ast
        ),
        args.validationContext
      );
    const draft =
      args.acceptUnverified
        ? unverifiedDraft(markedText, args.validationContext)
        : null;
    const stripped =
      stripAstVerificationMarkers(
        validated.ast
      ).ast;
    const documentAst = draft ? draft.ast(stripped) : stripped;
    const rendered =
      await this.renderer
        .render(
          args.format,
          documentAst,
          args.template
        );
    try {
      const validation =
        await this.renderer
          .validate(
            args.format,
            rendered.data
          );
      const astText =
        legalDocumentPlainText(
          documentAst
        );
      if (
        validation.aliases !==
          0 ||
        validation.text
          .replace(/\s+/g, " ")
          .trim() !==
        rendered.text
          .replace(/\s+/g, " ")
          .trim() ||
        !astText
      ) {
        throw new Error(
          "READY_DOCUMENT_VALIDATION_FAILED"
        );
      }

      const hybrid =
        validateLocalHybridDocument(
          validation.text,
          args.validationContext
        );
      if (
        hybrid.result !==
          "PASS"
      ) {
        throw new Error(
          "READY_DOCUMENT_HYBRID_BLOCKED:" +
          hybrid.reasons
            .join(",")
        );
      }

      const exportState =
        rebuildGenerationExportState(
          args.validationContext
        );
      const exportReport =
        new ExportGate()
          .evaluate({
            documentContent:
              rendered.data,
            documentText:
              validation.text,
            markedText,
            ...(draft ? { acceptUnverified: true } : {}),
            documentKind:
              args.format,
            documentSkill:
              args.validationContext
                .primarySkill,
            ledger:
              exportState.ledger,
            audit:
              exportState.audit,
            hybridValidation:
              "PASS"
          });
      if (
        exportReport.result !==
          "PASS" ||
        !exportReport
          .documentHash
      ) {
        throw exportBlocked(
          "READY_DOCUMENT_EXPORT_GATE_BLOCKED",
          exportReport
        );
      }

      const sha256 =
        createHash("sha256")
          .update(
            rendered.data
          )
          .digest("hex");
      if (
        sha256 !==
          exportReport
            .documentHash
      ) {
        throw new Error(
          "READY_DOCUMENT_EXPORT_HASH_MISMATCH"
        );
      }

      const artifact =
        await this.artifacts
          .saveArtifact({
            caseId:
              args.caseId,
            filename:
              args.filename ??
              `LexMachina-document.${args.format}`,
            mediaType:
              args.format ===
                "docx"
                ? "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                : "application/vnd.oasis.opendocument.text",
            data:
              rendered.data,
            caseDataKey:
              args.caseDataKey,
            keyVersion:
              args.keyVersion,
            sensitivity:
              "PROTECTED",
            createdByUserId:
              args
                .createdByUserId
          });

      return {
        artifact,
        format:
          args.format,
        sha256,
        text:
          validation.text,
        warnings:
          documentCompletenessWarnings(documentAst, validation.text),
        ...(rendered.template ? { letterhead: rendered.template } : {})
      };
    } finally {
      rendered.data.fill(0);
    }
  }

  /**
   * Checks key binding, vault generation and the tokenized hash, then resolves
   * every alias used in the document with its source and confidence.
   */
  private async restorationInputs(
    args: {
      target:
        DeanonymizationTargetState;
      caseDataKey:
        Buffer;
      keyVersion:
        number;
    }
  ) {
    if (
      args.target
        .caseKeyVersion !==
        args.keyVersion
    ) {
      throw new Error(
        "GENERATION_CASE_KEY_CHANGED"
      );
    }
    if (
      !args.target
        .deanonymizationKeyBinding
    ) {
      throw new Error(
        "GENERATION_DEANONYMIZATION_KEY_BINDING_MISSING"
      );
    }

    const currentKeyBinding =
      privacyVaultDeanonymizationKeyBinding({
        caseId:
          args.target
            .caseId,
        caseDataKey:
          args.caseDataKey,
        keyVersion:
          args.keyVersion
      });
    const keyBindingVerified =
      currentKeyBinding ===
        args.target
          .deanonymizationKeyBinding;
    if (
      !keyBindingVerified
    ) {
      throw new Error(
        "GENERATION_DEANONYMIZATION_KEY_CHANGED"
      );
    }

    const currentGeneration =
      await this.vaults
        .getGeneration({
          caseId:
            args.target
              .caseId,
          caseDataKey:
            args.caseDataKey,
          keyVersion:
            args.keyVersion
        });
    if (
      currentGeneration !==
        args.target
          .vaultGeneration
    ) {
      throw new Error(
        "GENERATION_VAULT_CHANGED"
      );
    }

    const validationContext =
      await this.states
        .loadValidationContext({
          caseId:
            args.target
              .caseId,
          artifactId:
            args.target
              .artifactId,
          caseDataKey:
            args.caseDataKey,
          keyVersion:
            args.keyVersion
        });

    const aliases =
      await this.states
        .loadAliases({
          caseId:
            args.target
              .caseId,
          artifactId:
            args.target
              .artifactId,
          caseDataKey:
            args.caseDataKey,
          keyVersion:
            args.keyVersion
        });
    const vaults =
      new Map();
    for (
      const documentId
      of [
        ...new Set(
          aliases.entries
            .map(
              (entry) =>
                entry.documentId
            )
        )
      ]
    ) {
      vaults.set(
        documentId,
        await this.vaults
          .loadDocumentVault({
            caseId:
              args.target
                .caseId,
            documentId,
            caseDataKey:
              args.caseDataKey,
            keyVersion:
              args.keyVersion
          })
      );
    }
    const replacements =
      resolveGenerationAliases(
        aliases,
        vaults
      );

    const tokenized =
      await this.artifacts
        .readArtifact({
          caseId:
            args.target
              .caseId,
          artifactId:
            args.target
              .artifactId,
          caseDataKey:
            args.caseDataKey,
          keyVersion:
            args.keyVersion,
          maxBytes:
            64 * 1024 *
            1024
        });
    try {
      const hash =
        createHash("sha256")
          .update(
            tokenized
          )
          .digest("hex");
      if (
        hash !==
          args.target
            .tokenizedSha256
      ) {
        throw new Error(
          "GENERATION_TOKENIZED_HASH_CHANGED"
        );
      }

      const tokenizedText =
        (
          await this.renderer
            .validate(
              args.target
                .artifactFormat,
              tokenized
            )
        ).text;
      const restorations =
        describeGenerationAliases(
          tokenizedText,
          aliases,
          vaults
        );
      return {
        validationContext,
        replacements,
        tokenized,
        tokenizedText,
        keyBindingVerified,
        restorations
      };
    } catch (error) {
      tokenized.fill(0);
      throw error;
    }
  }

  /** Restored text with every restored value marked, for review before finalizing. */
  async previewDeanonymization(
    args: {
      target:
        DeanonymizationTargetState;
      caseDataKey:
        Buffer;
      keyVersion:
        number;
    }
  ): Promise<RestorationPreview> {
    const inputs =
      await this.restorationInputs(args);
    inputs.tokenized.fill(0);
    return renderRestorationPreview(
      inputs.tokenizedText,
      inputs.restorations
    );
  }

  async deanonymizeConsumed(
    args: {
      target:
        DeanonymizationTargetState;
      createdByUserId:
        string;
      caseDataKey:
        Buffer;
      keyVersion:
        number;
      filename?: string;
      // Corrections from the review step, keyed by alias (with |CASE).
      overrides?: Record<string, string>;
    }
  ): Promise<
    FinalDocumentResult
  > {
    const {
      validationContext,
      replacements,
      tokenized,
      restorations,
      keyBindingVerified
    } = await this.restorationInputs(args);
    try {
      applyRestorationOverrides(
        replacements,
        restorations,
        args.overrides
      );
      const finalPackage =
        await this.renderer
          .deanonymize(
            args.target
              .artifactFormat,
            tokenized,
            replacements
          );
      try {
        const validation =
          await this.renderer
            .validate(
              args.target
                .artifactFormat,
              finalPackage
                .data
            );
        if (
          validation.aliases !==
            0 ||
          /\[(?:LMPII|PII):[^\]]+\]/
            .test(
              validation.text
            )
        ) {
          throw new Error(
            "FINAL_DOCUMENT_TOKEN_RESIDUE"
          );
        }
        const hybrid =
          validateLocalHybridDocument(
            validation.text,
            validationContext
          );
        if (
          hybrid.result !==
            "PASS"
        ) {
          throw new Error(
            "FINAL_DOCUMENT_HYBRID_BLOCKED:" +
            hybrid.reasons
              .join(",")
          );
        }

        const exportState =
          rebuildGenerationExportState(
            validationContext
          );
        // A draft saved with its unverified references named stays one.
        const stored =
          await this.states.readState(
            args.target.caseId,
            args.target.artifactId
          );
        const exportReport =
          new ExportGate()
            .evaluate({
              ...(stored?.unverifiedAccepted?.length ? { acceptUnverified: true } : {}),
              documentContent:
                finalPackage
                  .data,
              documentText:
                validation.text,
              documentKind:
                args.target
                  .artifactFormat,
              documentSkill:
                validationContext
                  .primarySkill,
              ledger:
                exportState
                  .ledger,
              audit:
                exportState
                  .audit,
              hybridValidation:
                "PASS"
            });
        if (
          exportReport.result !==
            "PASS" ||
          !exportReport
            .documentHash
        ) {
          throw exportBlocked(
            "FINAL_DOCUMENT_EXPORT_GATE_BLOCKED",
            exportReport
          );
        }

        const sha256 =
          createHash("sha256")
            .update(
              finalPackage
                .data
            )
            .digest("hex");
        if (
          sha256 !==
            exportReport
              .documentHash
        ) {
          throw new Error(
            "FINAL_DOCUMENT_EXPORT_HASH_MISMATCH"
          );
        }

        const format =
          args.target
            .artifactFormat;
        const artifact =
          await this.artifacts
            .saveArtifact({
              caseId:
                args.target
                  .caseId,
              filename:
                args.filename ??
                `document-final.${format}`,
              mediaType:
                format ===
                  "docx"
                  ? "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                  : "application/vnd.oasis.opendocument.text",
              data:
                finalPackage
                  .data,
              caseDataKey:
                args.caseDataKey,
              keyVersion:
                args.keyVersion,
              sensitivity:
                "CLEAR_PII",
              createdByUserId:
                args
                  .createdByUserId,
              sourceArtifactId:
                args.target
                  .artifactId
            });

        await this.states
          .markFinalized({
            caseId:
              args.target
                .caseId,
            artifactId:
              args.target
                .artifactId,
            finalArtifactId:
              artifact
                .artifactId,
            finalSha256:
              sha256
          });

        return {
          artifact,
          format,
          sha256,
          text:
            validation.text,
          replacements:
            finalPackage
              .replaced ?? 0,
          deanonymizationBasis:
            "PRIVACY_VAULT_KEY",
          keyBindingVerified,
          restorations:
            restorations.map(
              (item) =>
                args.overrides?.[item.alias] !== undefined
                  ? { ...item, text: replacements.get(item.alias)!, source: "manual", confidence: 1, status: "ok" as const }
                  : item
            )
        };
      } finally {
        finalPackage
          .data.fill(0);
      }
    } finally {
      tokenized.fill(0);
    }
  }
}
