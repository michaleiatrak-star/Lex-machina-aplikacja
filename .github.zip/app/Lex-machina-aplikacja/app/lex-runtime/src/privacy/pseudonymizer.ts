import { surnameMentions } from "./surname-propagation.js";
import { samePerson } from "./person-identity.js";
import { degradedRecognizers } from "./gazetteer-ner.js";
import { detectPeselNames } from "./pesel-names.js";
import { detectStreetAddresses } from "./street-addresses.js";
import { detectFirmNames, type FirmSpan } from "./firm-names.js";
import { genericWords, personPart } from "./generic-words.js";
import { detectIdentifiers } from "./identifiers.js";
import { findNameApproximately } from "./fuzzy-names.js";
import type { RegistryFormsProvider } from "./registry-enrichment.js";
import {
  PERSON_CASES,
  type PersonCase,
  type PersonEntity,
  type PersonMorphology
} from "./person-morphology.js";

export type PiiKind =
  | "PESEL"
  | "NIP"
  | "REGON"
  | "IBAN"
  | "EMAIL"
  | "PHONE"
  | "PERSON"
  | "ADDRESS"
  | "ID_CARD"
  | "PASSPORT"
  | "KRS"
  | "LAND_REGISTRY"
  | "BIRTH_DATE"
  | "VEHICLE_PLATE"
  | "BAR_NUMBER"
  | "PAYMENT_CARD"
  | "CUSTOM";

export type PiiSpan = {
  start: number;
  end: number;
  kind: PiiKind;
  value: string;
  confidence?: number;
  source?: "AUTO" | "USER";
  label?: string;
  // A person match a local model should confirm from its sentence.
  ambiguous?: boolean;
  // The local model read it as no person (its answer, e.g. "słowo pospolite"). Still masked:
  // the user unmasks it with one click.
  aiNotPerson?: string;
  // A loose match the user should confirm (a register's masked or OCR-distorted name).
  uncertain?: string;
};

export type PrivacyDirectiveAction =
  | "PSEUDONYMIZE"
  | "KEEP"
  | "LABEL";

export type ManualPrivacyDirective = {
  start: number;
  end: number;
  action: PrivacyDirectiveAction;
  // "FIRM": the user's mark of a firm name - a PERSON token with the firm's identity
  // (declined as a name, its legal form left in the text), as found firms get.
  kind?: PiiKind | "FIRM";
  label?: string;
};

export interface NamedEntityRecognizer {
  recognize(text: string): Promise<PiiSpan[]>;
}

export type PseudonymizationFinding = {
  token: string;
  kind: PiiKind;
  // A firm's name: from a public register (VAT white list, KRS, CEIDG) or from the text
  // (legal form, business prefix, the user's "Firma" mark).
  firm?: "REGISTRY" | "TEXT";
  start: number;
  end: number;
  source: "AUTO" | "USER";
  label?: string;
  // A known person's surname where the word may also be a common noun (sentence start,
  // capitals): masked, for the user to confirm (surname-propagation.ts).
  uncertain?: string;
};

export type PrivacyAnnotation = {
  start: number;
  end: number;
  label: string;
};

export type PseudonymizationVaultToken = {
  token: string;
  kind: PiiKind;
  value: string;
  createdAt: string;
  // PERSON: canonical identity and the inflected forms used on restore.
  entity?: PersonEntity;
};

/** [PII:PERSON:0001] or, with the grammatical case a model asked for, [PII:PERSON:0001|INS]. */
export const PII_TOKEN_WITH_CASE =
  /\[PII:([A-Z_]+):(\d{4})(?:\|([A-Z]{2,4}))?\]/g;

function isShouting(text: string): boolean {
  return text === text.toLocaleUpperCase("pl") && /\p{L}{2}/u.test(text);
}

function titleCase(text: string): string {
  return text
    .toLocaleLowerCase("pl")
    .replace(/(^|[\s\-'’])(\p{L})/gu, (_match, lead: string, letter: string) => lead + letter.toLocaleUpperCase("pl"));
}

/**
 * A name read from an all-caps heading ("JAN KOWALSKI") is restored in normal
 * spelling inside sentences; abbreviations of addresses (ul., al.) stay lower.
 */
function calmEntity(entity: PersonEntity): PersonEntity {
  if (!isShouting(entity.canonical)) return entity;
  const calm = (text: string) =>
    titleCase(text).replace(/\b(Ul|Al|Pl|Os|Ulica|Ulicy|Ulicę|Ulicą|Ulico|Aleja|Alei|Aleję|Aleją|Alejo|Plac|Placu|Placem|Osiedle|Osiedla|Osiedlu|Osiedlem)\b/gu, (word) =>
      word.toLocaleLowerCase("pl")
    );
  return {
    ...entity,
    canonical: calm(entity.canonical),
    forms: Object.fromEntries(
      Object.entries(entity.forms).map(([key, form]) => [key, { ...form, text: calm(form.text) }])
    ) as PersonEntity["forms"]
  };
}

// Persons and addresses with a paradigm: one token per canonical entity.
const ENTITY_KINDS = new Set<PiiKind>(["PERSON", "ADDRESS"]);
// Numbers that identify a person or a firm wherever they appear (no context word needed).
const IDENTIFIER_KINDS = new Set<PiiKind>(["PESEL", "NIP", "REGON", "KRS", "IBAN", "ID_CARD", "PASSPORT", "PAYMENT_CARD", "EMAIL", "PHONE", "BAR_NUMBER", "LAND_REGISTRY"]);

function personEntityKey(entity: PersonEntity, kind: PiiKind = "PERSON"): string {
  return `${kind}\u0000entity\u0000${entity.canonical.toLocaleLowerCase("pl")}\u0000${entity.gender}\u0000${entity.type ?? ""}${entity.number ?? ""}`;
}

// A firm named after a person has its own token, never the person's.
function valueKey(kind: PiiKind, value: string, entity?: PersonEntity): string {
  return entity?.type === "organization" ? `${kind}\u0000org\u0000${value}` : `${kind}\u0000${value}`;
}

// Words after which a surname names several persons ("państwo Kowalscy").
const GROUP_WORDS = new Set([
  "państwo", "państwa", "państwu", "państwem", "małżonkowie", "małżonków", "małżonkom", "małżonkami",
  "małżonkach", "rodzeństwo", "rodzeństwa", "rodzeństwu", "rodzeństwem", "rodzina", "rodziny", "rodzinie",
  "rodzinę", "rodziną", "powodowie", "pozwani", "powódki", "pozwane", "wnioskodawcy", "uczestnicy",
  "dłużnicy", "wierzyciele", "spadkobiercy", "najemcy", "oskarżeni", "obwinieni", "skarżący", "oboje", "obaj", "obie"
]);

// "PHU Jan Kowalski", "pod firmą Jan Nowak", "Kancelaria Adwokacka Jan Kowalski".
const FIRM_BEFORE =
  /(?:\b(?:P\.?P\.?H\.?U\.?|P\.?H\.?U\.?|F\.?H\.?U\.?|F\.?P\.?H\.?U\.?|Firma|Przedsiębiorstwo|Zakład|Kancelaria|Biuro|Studio|Sklep|Warsztat|Hurtownia|Gabinet|Pracownia|Agencja)(?:\s+(?:\p{Lu}[\p{L}-]*|[\p{L}]+\.)){0,2}|\bpod\s+(?:firmą|nazwą))\s*[„"»]?\s*$/u;
// "Nowak sp. z o.o.", "Kowalski i Wspólnicy sp.k.", "Jan Nowak Transport".
const LEGAL_FORM =
  /(sp\.\s?z\s?o\.\s?o\.|spółk[aiąę]\s+z\s+ograniczoną\s+odpowiedzialnością|spółk[aiąę]\s+(?:akcyjn|komandytow|jawn|partnersk|cywiln)\p{L}*|S\.\s?A\.|sp\.\s?k\.(?:\s?a\.)?|sp\.\s?j\.|sp\.\s?p\.|s\.\s?c\.|S\.K\.A\.|P\.S\.A\.)/iu;
const FIRM_AFTER =
  /^\s*(?:i\s+(?:Wspólnicy|Partnerzy|Syn|Synowie|S-ka)\b|&|(?:Usługi|Transport|Handel|Budownictwo|Consulting|Group|Trade|Service|Serwis|Invest|Development|Logistics|Holding|Media|Design|Auto|Bud|Tech|Soft|Med|Eko)\b|,?\s*(?:[Ss][Pp]\.|[Ss][Pp][Óó][Łł][Kk]|S\.\s?A\.|[Ss]\.\s?[Cc]\.|S\.K\.A\.|P\.S\.A\.))/u;

/** The firm around a person-name mention, if the name is part of a firm name. */
export function firmContext(text: string, start: number, end: number): { legalForm?: string } | null {
  const before = text.slice(Math.max(0, start - 60), start).split(/[\n.;:!?](?=\s)/).pop() ?? "";
  // To the end of the sentence: "PHU Jan Kowalski. Umowę zawarła X sp.k." is not one firm.
  const lineAfter = (text.slice(end, end + 80).split("\n")[0] ?? "").split(/(?<=[.!?])\s+(?=\p{Lu})/u)[0] ?? "";
  if (!FIRM_BEFORE.test(before) && !FIRM_AFTER.test(lineAfter)) return null;
  const legal = LEGAL_FORM.exec(lineAfter.slice(0, 60));
  return legal ? { legalForm: legal[1]!.replace(/\s+/g, " ") } : {};
}

const STREET_MARK = /(?:^|\s)(?:ul\.|ulica|ulicy|al\.|aleja|alei|pl\.|plac|placu|os\.|osiedle|osiedlu)(?:\s|$)/iu;
// The name of a court, prosecutor's office, police unit or other office runs up to the town:
// "Prokuratura Rejonowa Katowice-Zachód w Katowicach", "Komisariat Policji VII w Katowicach".
const INSTITUTION_BEFORE =
  /(?:\b(?:Sąd|Sądu|Sądem|Sądzie|Prokuratur|Komisariat|Komend|Urząd|Urzęd|Izb|Starostw|Komornik|Kuratori|Inspektorat|Oddział|Policji)\p{L}*)[^.;:\n]{0,70}$/u;

// The address block of a court or an office ("Sąd Rejonowy w Zielonej Górze⏎I Wydział
// Cywilny⏎Pl. Słowiański 2⏎65-069 Zielona Góra"): a public institution's address is no personal
// data and the reader needs it (user report 2026-11-06: the court's postal code was masked).
const INSTITUTION_LINE =
  /^\s*(?:\*\*)?(?:Sąd|Sądu|Prokuratur|Komisariat|Komend|Urząd|Urzędu|Izb[ay]|Starostw|Komornik|Kancelaria\s+Komornika|Kuratori|Inspektorat|Zakład\s+Ubezpieczeń|ZUS|Krajowa\s+Izba|Naczelny\s+Sąd|Wojewódzki\s+Sąd|Samorządowe\s+Kolegium|Ministerstw|Minister|Wojewoda|Prezydent\s+Miasta|Burmistrz|Wójt|Starosta|Marszałek)\p{L}*/u;
// Lines that stay inside such a block: the division, the address, the contact data.
const INSTITUTION_BLOCK_LINE =
  /^\s*(?:[IVXLC]+\s+)?(?:Wydział|Oddział|Biuro|Sekretariat|Zespół|Departament|Delegatura|Filia)(?!\p{L})|^\s*(?:ul\.|ulica|al\.|aleja|pl\.|plac|os\.)\s|^\s*\d{2}-\d{3}\s|^\s*(?:tel|fax|e-?mail|www)\b|^\s*\p{Lu}[\p{L} -]{1,40},\s*(?:dnia\s*)?\d{1,2}[.\s]/iu;
// (the last: the letter's place and date set between the court's lines in an OCR read)

/** An address in the address block of a court or a public office, not a person's or a firm's. */
export function institutionAddress(text: string, start: number, value = ""): boolean {
  const lineStart = text.lastIndexOf("\n", start - 1) + 1;
  const ownLine = text.slice(lineStart, start);
  // On the institution's own line: its street or postal address in the same sentence
  // ("Komornik Sądowy przy SR w Toruniu, ul. Grudziądzka 45"), never a town further on.
  const sentence = ownLine.split(/[.!?]\s+(?=\p{Lu})/u).at(-1) ?? "";
  if (/\d/u.test(value) && INSTITUTION_LINE.test(sentence) && !LEGAL_FORM_WORDS.test(sentence)) return true;
  if (ownLine.trim() && !INSTITUTION_BLOCK_LINE.test(ownLine)) return false;
  const previous = text.slice(Math.max(0, lineStart - 400), Math.max(0, lineStart - 1)).split("\n").reverse();
  for (const line of previous.slice(0, 5)) {
    if (!line.trim()) return false;
    if (INSTITUTION_LINE.test(line) && !LEGAL_FORM_WORDS.test(line)) return true;
    if (!INSTITUTION_BLOCK_LINE.test(line)) return false;
  }
  return false;
}
// A housing community is named after its building ("Wspólnota Mieszkaniowa Piłsudskiego 45",
// "Wspólnota Mieszkaniowa Nieruchomości przy ul. Lipowej 7"): the party's name, not a person or a
// home address (user report 2026-11-06: the plaintiff masked, the analysis found no other party).
// A housing cooperative too, with or without a number ("Spółdzielnia Mieszkaniowa Piłsudskiego 45",
// "Spółdzielnia Mieszkaniowa „Przyszłość”").
const HOUSING_COMMUNITY =
  /(?:Wsp[óo]lnot|Sp[óo]łdzielni)\p{L}*\s+Mieszkaniow\p{L}*(?:\s+Lokatorsko-Własnościow\p{L}*)?\s+(?:(?:Nieruchomo\p{L}*|Budynku)\s+)?(?:(?:przy|nr)\s+)?(?:(?:ul\.|ulicy|al\.|alei|pl\.|placu|os\.|osiedla)\s*)?(?:[„"]?\p{Lu}[\p{L}.-]*[”"]?(?:\s+|$)){1,4}(?:\d{1,4}[A-Za-z]?(?:\s*[/-]\s*\d{1,4}[A-Za-z]?)?)?/gu;

export function housingCommunityNames(text: string): Array<{ start: number; end: number }> {
  return [...text.matchAll(HOUSING_COMMUNITY)].map((match) => ({ start: match.index!, end: match.index! + match[0].length }));
}
const LEGAL_FORM_WORDS = /\bsp\.\s*z\s*o\.\s*o\.|\bspółk\p{L}*|\bS\.A\.|\bsp\.\s*k\./iu;

/** A town inside an institution's name: before it the institution, or it starts "Katowice-Zachód". */
export function institutionTown(text: string, start: number, end: number): boolean {
  if (/^-\p{Lu}/u.test(text.slice(end, end + 2))) return true;
  return INSTITUTION_BEFORE.test(text.slice(Math.max(0, start - 90), start));
}

export function organizationEntity(value: string, legalForm?: string): PersonEntity {
  const form = { text: value, source: "frozen", confidence: 1 };
  return {
    canonical: value,
    gender: "n",
    genderAlternatives: [],
    status: "ok",
    forms: { NOM: form, GEN: form, DAT: form, ACC: form, INS: form, LOC: form, VOC: form },
    warnings: ["ORGANIZATION"],
    type: "organization",
    ...(legalForm ? { legalForm } : {})
  };
}

export type RestoredToken = {
  token: string;
  requestedCase: PersonCase | null;
  text: string;
  kind: PiiKind;
  source: string;
  confidence: number;
  // ok, invalid_case (unknown case suffix, nominative used), no_forms, unknown_token
  status: "ok" | "invalid_case" | "no_forms" | "unknown_token";
};

export type PseudonymizationVaultSnapshot = {
  counters:
    Partial<Record<PiiKind, number>>;
  tokens:
    PseudonymizationVaultToken[];
};

export type PseudonymizationResult = {
  text: string;
  findings: PseudonymizationFinding[];
  annotations: PrivacyAnnotation[];
  keptRanges: Array<{
    start: number;
    end: number;
  }>;
  counts: Partial<Record<PiiKind, number>>;
};

const PRIORITY: Record<PiiKind, number> = {
  PESEL: 100,
  PAYMENT_CARD: 99,
  ID_CARD: 98,
  PASSPORT: 97,
  LAND_REGISTRY: 96,
  NIP: 95,
  REGON: 90,
  IBAN: 85,
  EMAIL: 80,
  PHONE: 70,
  // A structural address wins over a name inside it ("ul. Jana Kowalskiego 5").
  ADDRESS: 65,
  PERSON: 60,
  BIRTH_DATE: 54,
  VEHICLE_PLATE: 53,
  BAR_NUMBER: 53,
  KRS: 52,
  CUSTOM: 50
};

function overlaps(
  a: { start: number; end: number },
  b: { start: number; end: number }
): boolean {
  return a.start < b.end && a.end > b.start;
}

function nonOverlapping(spans: PiiSpan[]): PiiSpan[] {
  const sorted = [...spans].sort((a, b) =>
    a.start - b.start ||
    (a.source === "USER" ? -1 : 1) -
      (b.source === "USER" ? -1 : 1) ||
    PRIORITY[b.kind] - PRIORITY[a.kind] ||
    (b.end - b.start) - (a.end - a.start)
  );
  const accepted: PiiSpan[] = [];

  for (const candidate of sorted) {
    if (
      candidate.start < 0 ||
      candidate.end <= candidate.start
    ) {
      continue;
    }
    if (!accepted.some((current) => overlaps(candidate, current))) {
      accepted.push(candidate);
    }
  }

  return accepted.sort((a, b) => a.start - b.start);
}

function normalizeDirectives(
  text: string,
  directives: ManualPrivacyDirective[]
): ManualPrivacyDirective[] {
  const normalized = directives.map((directive) => {
    if (
      !Number.isInteger(directive.start) ||
      !Number.isInteger(directive.end) ||
      directive.start < 0 ||
      directive.end <= directive.start ||
      directive.end > text.length
    ) {
      throw new Error("INVALID_PRIVACY_DIRECTIVE_RANGE");
    }

    const label = directive.label?.trim();
    if (
      directive.action === "LABEL" &&
      (!label || label.length > 120)
    ) {
      throw new Error("INVALID_PRIVACY_DIRECTIVE_LABEL");
    }

    return {
      ...directive,
      ...(label ? { label } : {})
    };
  }).sort((a, b) => a.start - b.start || a.end - b.end);

  for (let index = 1; index < normalized.length; index += 1) {
    if (overlaps(normalized[index - 1]!, normalized[index]!)) {
      throw new Error("OVERLAPPING_PRIVACY_DIRECTIVES");
    }
  }

  return normalized;
}

// SGJP gives some surnames two declensions (Stępień: Stępnia and Stępienia) and the
// nominative alone does not tell which one a person uses. A later mention written in
// the other one ("Wojciecha Stępnia") is the document's evidence: its forms replace the
// generated ones in the dependent cases; the nominative stays as written.
function documentVariant(current: PersonEntity, incoming: PersonEntity, surface: string): PersonEntity | null {
  if (current.type === "organization" || incoming.type === "organization" || isShouting(surface)) return null;
  const same = (a: string, b: string) => a.toLocaleLowerCase("pl") === b.toLocaleLowerCase("pl");
  if ((current.number ?? "") !== (incoming.number ?? "") || current.gender !== incoming.gender) return null;
  if (!same(current.forms.NOM.text, incoming.forms.NOM.text)) return null;
  if (Object.values(current.forms).some((form) => same(form.text, surface))) return null;
  if (!Object.values(incoming.forms).some((form) => same(form.text, surface))) return null;
  return { ...current, forms: { ...incoming.forms, NOM: current.forms.NOM } };
}

export class PseudonymizationVault {
  private readonly tokenToValue =
    new Map<string, string>();
  private readonly keyToToken =
    new Map<string, string>();
  private readonly counters =
    new Map<PiiKind, number>();
  private readonly tokenMetadata =
    new Map<
      string,
      {
        kind: PiiKind;
        createdAt: string;
      }
    >();
  private readonly tokenEntities =
    new Map<string, PersonEntity>();
  // Every surface mapped to a token in this session (for entity merging).
  // Readings of a person merged into its token (mergePerson).
  private readonly personReadings = new Set<PersonEntity>();
  private readonly tokenSurfaces =
    new Map<string, Set<string>>();

  constructor(
    snapshot?:
      PseudonymizationVaultSnapshot
  ) {
    if (snapshot) {
      this.hydrate(snapshot);
    }
  }

  private hydrate(
    snapshot:
      PseudonymizationVaultSnapshot
  ): void {
    for (
      const [
        kind,
        rawCount
      ] of Object.entries(
        snapshot.counters
      ) as Array<
        [PiiKind, number]
      >
    ) {
      if (
        !Number.isInteger(
          rawCount
        ) ||
        rawCount < 0
      ) {
        throw new Error(
          "INVALID_PRIVACY_VAULT_COUNTER"
        );
      }
      this.counters.set(
        kind,
        rawCount
      );
    }

    for (
      const item
      of snapshot.tokens
    ) {
      const match =
        /^\[PII:([A-Z_]+):(\d{4})\]$/
          .exec(item.token);
      if (
        !match ||
        match[1] !== item.kind ||
        typeof item.value !==
          "string" ||
        typeof item.createdAt !==
          "string" ||
        !Number.isFinite(
          Date.parse(
            item.createdAt
          )
        ) ||
        this.tokenToValue.has(
          item.token
        )
      ) {
        throw new Error(
          "INVALID_PRIVACY_VAULT_TOKEN"
        );
      }

      const key = valueKey(item.kind, item.value, item.entity);
      if (
        this.keyToToken.has(key)
      ) {
        throw new Error(
          "DUPLICATE_PRIVACY_VAULT_VALUE"
        );
      }

      const sequence =
        Number(match[2]);
      const counter =
        this.counters.get(
          item.kind
        ) ?? 0;
      if (
        sequence > counter
      ) {
        this.counters.set(
          item.kind,
          sequence
        );
      }

      this.keyToToken.set(
        key,
        item.token
      );
      this.tokenToValue.set(
        item.token,
        item.value
      );
      // As in getOrCreate: a key read from disk merges entities by surface too.
      this.tokenSurfaces.set(item.token, new Set([item.value]));
      this.tokenMetadata.set(
        item.token,
        {
          kind: item.kind,
          createdAt:
            item.createdAt
        }
      );
      if (item.entity) {
        this.tokenEntities.set(
          item.token,
          item.entity
        );
        this.keyToToken.set(
          personEntityKey(item.entity, item.kind),
          item.token
        );
      }
    }
  }

  getOrCreate(
    kind: PiiKind,
    value: string,
    entity?: PersonEntity
  ): string {
    const key = valueKey(kind, value, entity);
    const existing =
      this.keyToToken.get(key);
    if (existing) {
      return existing;
    }
    // One person, one token: "Jana Kowalskiego" and "Janem Kowalskim" are the
    // same Jan Kowalski.
    const entityKey =
      ENTITY_KINDS.has(kind) && entity
        ? personEntityKey(entity, kind)
        : null;
    const sameEntity =
      entityKey
        ? this.keyToToken.get(entityKey) ?? this.overlappingEntityToken(kind, entity!, value)
        : undefined;
    if (sameEntity) {
      this.keyToToken.set(
        key,
        sameEntity
      );
      if (entityKey) this.keyToToken.set(entityKey, sameEntity);
      // The document's own nominative decides the paradigm: "Martyna Jurga"
      // wins over "Martyna Jurda" read from "Martynie Jurdze".
      this.tokenSurfaces.get(sameEntity)?.add(value);
      const current = this.tokenEntities.get(sameEntity);
      const nominative =
        entity &&
        current &&
        value.toLocaleLowerCase("pl") === entity.canonical.toLocaleLowerCase("pl") &&
        current.canonical.toLocaleLowerCase("pl") !== entity.canonical.toLocaleLowerCase("pl") &&
        this.keyToToken.get(valueKey(kind, current.canonical, current)) !== sameEntity;
      // An unambiguous reading replaces an ambiguous one, and a normally
      // written name replaces one read from an all-caps heading.
      const clearer = entity && current && current.status !== "ok" && entity.status === "ok";
      const calmer = entity && current && isShouting(current.canonical) && !isShouting(entity.canonical);
      if (entity && (nominative || clearer || calmer)) {
        this.tokenEntities.set(sameEntity, calmEntity(entity));
      } else if (entity && current) {
        const variant = documentVariant(current, entity, value);
        if (variant) this.tokenEntities.set(sameEntity, variant);
      }
      return sameEntity;
    }

    // "JAN KOWALSKI" from a heading, without a paradigm: the same person as a
    // known "Jan Kowalski" (one token, restored in normal spelling).
    if (ENTITY_KINDS.has(kind) && !entity && isShouting(value)) {
      const upper = value.toLocaleUpperCase("pl");
      for (const [token, known] of this.tokenToValue) {
        if (this.tokenMetadata.get(token)?.kind !== kind || this.tokenEntities.get(token)?.type === "organization") continue;
        if (known.toLocaleUpperCase("pl") === upper) {
          this.keyToToken.set(key, token);
          this.tokenSurfaces.get(token)?.add(value);
          return token;
        }
      }
    }

    const next =
      (
        this.counters.get(
          kind
        ) ?? 0
      ) + 1;
    this.counters.set(
      kind,
      next
    );
    const token =
      `[PII:${kind}:${String(
        next
      ).padStart(4, "0")}]`;
    this.keyToToken.set(
      key,
      token
    );
    this.tokenToValue.set(
      token,
      value
    );
    this.tokenSurfaces.set(token, new Set([value]));
    this.tokenMetadata.set(
      token,
      {
        kind,
        createdAt:
          new Date()
            .toISOString()
      }
    );
    if (entity && entityKey) {
      this.tokenEntities.set(
        token,
        calmEntity(entity)
      );
      this.keyToToken.set(
        entityKey,
        token
      );
    }
    return token;
  }

  /**
   * Two analyses of one person can reach different lemmas (Malek from
   * "Daniel Malek", Malc from "Danielem Malkiem"); when two paradigms share at
   * a case form they are the same entity.
   */
  private overlappingEntityToken(
    kind: PiiKind,
    entity: PersonEntity,
    value: string
  ): string | undefined {
    const lower = (text: string) => text.toLocaleLowerCase("pl");
    const forms = new Set(Object.values(entity.forms).map((form) => lower(form.text)));
    if (entity.type === "organization") return undefined;
    for (const [token, other] of this.tokenEntities) {
      if (this.tokenMetadata.get(token)?.kind !== kind) continue;
      // A firm, or one person against a family: never the same entity.
      if (other.type === "organization" || (other.number ?? "sg") !== (entity.number ?? "sg")) continue;
      const otherForms = new Set(Object.values(other.forms).map((form) => lower(form.text)));
      // The mention is one of the forms of a known entity, or a known mention
      // is one of this entity's forms - whatever gender either analysis chose
      // for an ambiguous form ("Martynie Jurdze").
      if (otherForms.has(lower(value))) return token;
      const surfaces = this.tokenSurfaces.get(token);
      if (surfaces && [...surfaces].some((surface) => forms.has(lower(surface)))) return token;
      if (other.gender === entity.gender && [...otherForms].some((text) => forms.has(text))) return token;
    }
    return undefined;
  }

  entity(
    token: string
  ): PersonEntity | undefined {
    return this.tokenEntities.get(
      token
    );
  }

  /**
   * Value for a token in a model's output. A person token with a case
   * ([PII:PERSON:0001|INS]) gets that inflected form; a bare person token gets
   * the nominative. Other kinds return the stored value.
   */
  restore(
    token: string,
    requestedCase: string | null
  ): RestoredToken {
    const value =
      this.tokenToValue.get(
        token
      );
    const metadata =
      this.tokenMetadata.get(
        token
      );
    if (value === undefined || !metadata) {
      throw new Error(
        `Unknown pseudonymization token: ${token}`
      );
    }
    const entity =
      this.tokenEntities.get(
        token
      );
    const validCase =
      requestedCase &&
      (PERSON_CASES as readonly string[]).includes(
        requestedCase
      )
        ? requestedCase as PersonCase
        : null;
    if (!entity) {
      return {
        token,
        requestedCase: validCase,
        text: value,
        kind: metadata.kind,
        source: "stored",
        confidence: 1,
        status:
          metadata.kind === "PERSON" && requestedCase
            ? "no_forms"
            : "ok"
      };
    }
    const form =
      entity.forms[
        validCase ?? "NOM"
      ];
    return {
      token,
      requestedCase: validCase,
      text: form.text,
      kind: metadata.kind,
      source: form.source,
      confidence: form.confidence,
      status:
        requestedCase && !validCase
          ? "invalid_case"
          : "ok"
    };
  }

  /**
   * Every known written form of every person in this vault: the surfaces
   * found so far and, with the morphology engine, all seven cases.
   */
  /** Drops a token and everything that maps to it (the user un-anonymized it). */
  remove(token: string): boolean {
    if (!this.tokenToValue.has(token)) return false;
    this.tokenToValue.delete(token);
    this.tokenMetadata.delete(token);
    this.tokenEntities.delete(token);
    this.tokenSurfaces.delete(token);
    for (const [key, value] of [...this.keyToToken]) {
      if (value === token) this.keyToToken.delete(key);
    }
    return true;
  }

  /**
   * Case forms corrected by the user: each given form becomes a manual,
   * certain form; the nominative also becomes the entity's canonical name.
   */
  updateForms(token: string, forms: Partial<Record<PersonCase, string>>): PersonEntity {
    const entity = this.tokenEntities.get(token);
    if (!entity) throw new Error("PRIVACY_KEY_ENTITY_NOT_FOUND");
    const next: PersonEntity = {
      ...entity,
      forms: { ...entity.forms },
      warnings: [...entity.warnings]
    };
    for (const personCase of PERSON_CASES) {
      const text = forms[personCase]?.trim();
      if (!text) continue;
      next.forms[personCase] = { text, source: "manual", confidence: 1 };
    }
    next.canonical = next.forms.NOM.text;
    next.status = "ok";
    this.tokenEntities.set(token, next);
    this.keyToToken.set(`${this.tokenMetadata.get(token)!.kind}\u0000${next.canonical}`, token);
    return next;
  }

  /**
   * Replaces a person token's entity after the user set what it is (a man,
   * a woman, several persons, a firm): the token and its surfaces stay, the
   * keys follow the new kind of entity.
   */
  setEntity(token: string, next: PersonEntity): void {
    const kind = this.tokenMetadata.get(token)?.kind;
    const current = this.tokenEntities.get(token);
    if (kind !== "PERSON" || !current) throw new Error("PRIVACY_KEY_ENTITY_NOT_FOUND");
    const wasFirm = current.type === "organization";
    const isFirm = next.type === "organization";
    for (const [key, value] of [...this.keyToToken]) {
      if (value !== token) continue;
      if (key.startsWith(`${kind}\u0000entity\u0000`)) {
        this.keyToToken.delete(key);
      } else if (wasFirm !== isFirm) {
        const surface = wasFirm ? key.slice(`${kind}\u0000org\u0000`.length) : key.slice(`${kind}\u0000`.length);
        const moved = valueKey(kind, surface, next);
        const other = this.keyToToken.get(moved);
        if (other && other !== token) throw new Error("PRIVACY_KEY_CONFLICT");
        this.keyToToken.delete(key);
        this.keyToToken.set(moved, token);
      }
    }
    const entityKey = personEntityKey(next, kind);
    const other = this.keyToToken.get(entityKey);
    if (other && other !== token) throw new Error("PRIVACY_KEY_CONFLICT");
    this.keyToToken.set(entityKey, token);
    this.tokenEntities.set(token, next);
  }

  knownEntityForms(): Array<{ text: string; kind: PiiKind; entity?: PersonEntity }> {
    const forms = new Map<string, { kind: PiiKind; entity?: PersonEntity }>();
    for (const [token, value] of this.tokenToValue) {
      const kind = this.tokenMetadata.get(token)?.kind;
      if (!kind || !ENTITY_KINDS.has(kind)) continue;
      const stored = this.tokenEntities.get(token);
      // A firm's name also protects other mentions, but they are read afresh
      // (the same words may be the owner's name).
      const entity = stored?.type === "organization" ? undefined : stored;
      if (!forms.has(value)) forms.set(value, entity ? { kind, entity } : { kind });
      if (entity) {
        for (const form of Object.values(entity.forms)) {
          if (!forms.has(form.text)) forms.set(form.text, { kind, entity });
        }
      }
    }
    return [...forms]
      .filter(([text]) => text.trim().length >= 4)
      .map(([text, item]) => ({ text, ...item }));
  }

  /** Firms already protected (another page): their names, the register's spelling first. */
  knownOrganizationNames(): Array<{ name: string; canonical: string; legalForm?: string }> {
    const names = new Map<string, { canonical: string; legalForm?: string }>();
    for (const [token, value] of this.tokenToValue) {
      const entity = this.tokenEntities.get(token);
      if (entity?.type !== "organization") continue;
      for (const name of [entity.canonical, value]) {
        if (/\p{Lu}/u.test(name) && name.replace(/\s+/gu, " ").trim().length >= 6 && !names.has(name)) {
          names.set(name, { canonical: entity.canonical, ...(entity.legalForm ? { legalForm: entity.legalForm } : {}) });
        }
      }
    }
    return [...names].map(([name, item]) => ({ name, ...item }));
  }

  /**
   * Another reading of a known person (samePerson): its key leads to the person's token, and a
   * clearer reading (a normal spelling, an unambiguous paradigm) becomes the person's paradigm,
   * so the answer restores "Michał Wiatrak", not the OCR's "MICHAL WIATRAK". False when the
   * person has no token yet.
   */
  mergePerson(known: PersonEntity, reading: PersonEntity): boolean {
    const token = [...this.tokenEntities].find(([, entity]) => entity === known)?.[0] ?? this.keyToToken.get(personEntityKey(known, "PERSON"));
    if (!token) return false;
    this.keyToToken.set(personEntityKey(reading, "PERSON"), token);
    this.personReadings.add(reading);
    // Never a reading with fewer words ("MICHAŁWIATRAK" read without its space).
    const current = this.tokenEntities.get(token) ?? known;
    const wordCount = (entity: PersonEntity) => entity.canonical.split(/\s+/u).filter(Boolean).length;
    const fuller = wordCount(reading) >= Math.max(2, wordCount(current));
    const clearer = current.status !== "ok" && reading.status === "ok";
    const calmer = isShouting(current.canonical) && !isShouting(reading.canonical);
    if (fuller && (clearer || calmer)) this.tokenEntities.set(token, calmEntity(reading));
    return true;
  }

  /** Persons already protected (another page of the document). */
  knownPersons(): PersonEntity[] {
    // Every reading merged into a person, so a later mention matches any of them.
    const persons = new Set<PersonEntity>([...this.personReadings]);
    for (const token of this.tokenToValue.keys()) {
      const entity = this.tokenEntities.get(token);
      if (entity && entity.type !== "organization" && this.tokenMetadata.get(token)?.kind === "PERSON") persons.add(entity);
    }
    return [...persons];
  }

  /** Identifiers already protected (another page of the document): their values by kind. */
  knownIdentifierValues(): Array<{ kind: PiiKind; value: string }> {
    const known: Array<{ kind: PiiKind; value: string }> = [];
    for (const [token, value] of this.tokenToValue) {
      const kind = this.tokenMetadata.get(token)?.kind;
      if (kind && IDENTIFIER_KINDS.has(kind)) known.push({ kind, value });
    }
    return known;
  }

  hasToken(
    token: string
  ): boolean {
    return this.tokenToValue
      .has(token);
  }

  resolveToken(
    token: string
  ): string {
    const value =
      this.tokenToValue.get(
        token
      );
    if (value === undefined) {
      throw new Error(
        `Unknown pseudonymization token: ${token}`
      );
    }
    return value;
  }

  snapshot():
    PseudonymizationVaultSnapshot {
    const counters:
      Partial<
        Record<PiiKind, number>
      > = {};
    for (
      const [kind, count]
      of this.counters
    ) {
      counters[kind] = count;
    }

    const tokens =
      [...this.tokenToValue
        .entries()]
        .map(
          ([token, value]) => {
            const metadata =
              this.tokenMetadata
                .get(token);
            if (!metadata) {
              throw new Error(
                "PRIVACY_VAULT_METADATA_MISSING"
              );
            }
            const entity =
              this.tokenEntities.get(
                token
              );
            return {
              token,
              kind:
                metadata.kind,
              value,
              createdAt:
                metadata.createdAt,
              ...(entity
                ? { entity }
                : {})
            };
          }
        )
        .sort((a, b) =>
          a.token.localeCompare(
            b.token,
            "en"
          )
        );

    return {
      counters,
      tokens
    };
  }

  deanonymize(
    text: string
  ): string {
    return text.replace(
      PII_TOKEN_WITH_CASE,
      (_match, kind: string, sequence: string, requestedCase?: string) =>
        this.restore(
          `[PII:${kind}:${sequence}]`,
          requestedCase ?? null
        ).text
    );
  }

  get size(): number {
    return this.tokenToValue
      .size;
  }
}

/** A line naming a role or an office ("Radców Prawnych", "Kancelaria Adwokatów"), not a person. */
function roleHeading(line: string): boolean {
  const first = /\p{L}+/u.exec(line)?.[0]?.toLowerCase();
  const words = genericWords();
  return Boolean(first && (words.personOnlyTriggers.has(first) || words.institutions.has(first)));
}

export class LocalPolishPseudonymizer {
  constructor(
    private readonly vault: PseudonymizationVault,
    private readonly namedEntities?: NamedEntityRecognizer,
    private readonly morphology?: PersonMorphology,
    // Firm name, address and representatives from the VAT white list and KRS for a NIP/KRS in the text.
    private readonly registry?: RegistryFormsProvider
  ) {}

  async pseudonymize(
    text: string,
    directives: ManualPrivacyDirective[] = []
  ): Promise<PseudonymizationResult> {
    const manual = normalizeDirectives(text, directives);
    const keep = manual.filter(
      (item) => item.action === "KEEP"
    );
    const labelDirectives = manual.filter(
      (item) => item.action === "LABEL"
    );
    const annotations: PrivacyAnnotation[] =
      labelDirectives.map((item) => ({
        start: item.start,
        end: item.end,
        label: item.label!
      }));

    const manualPseudonyms: PiiSpan[] = manual
      .filter(
        (item) => item.action === "PSEUDONYMIZE"
      )
      .map((item) => ({
        start: item.start,
        end: item.end,
        kind: item.kind === "FIRM" ? "PERSON" as const : item.kind ?? "CUSTOM",
        value: text.slice(item.start, item.end),
        source: "USER" as const,
        ...(item.label ? { label: item.label } : {})
      }));

    const autoSpans: PiiSpan[] = detectIdentifiers(text);
    // Street addresses by structure, also when the local gazetteer worker is unavailable.
    autoSpans.push(...detectStreetAddresses(text));
    // Private firms ([FIRMA]): a name before a legal form or after a business prefix,
    // and its later mentions; one organization token per name.
    const firms = detectFirmNames(text);
    autoSpans.push(...firms);

    // Register data of firms named by NIP/KRS: their names, addresses and people are
    // protected even where no legal form or prefix marks them ("umowę z Transkomem").
    const registryFirms = new Map<string, string | undefined>();
    // A firm's name as OCR damaged it -> the register's name: one firm, one token
    // ("Human Park Giobal" is "Human Park Global", not a second company).
    const registryCanonical = new Map<string, { name: string; note: string }>();
    let registered: Awaited<ReturnType<RegistryFormsProvider["forms"]>> = [];
    try {
      registered = this.registry ? await this.registry.forms(text) : [];
    } catch (error) {
      process.stderr.write(`REGISTRY_ENRICHMENT_DEGRADED:${error instanceof Error ? error.message : String(error)}\n`);
    }
    for (const form of registered) {
      // A bank account of the firm from the white list: also as OCR damaged it (a digit or two
      // misread, "O" for 0, "l" for 1), masked and marked: the register names whose account it is.
      if (form.kind === "IBAN") {
        const digits = form.text.replace(/\D/gu, "");
        for (const match of text.matchAll(/(?<![\p{L}\p{N}])(?:PL\s?)?[\dOolI|]{2}(?:[ \u00a0-]?[\dOolI|]{4}){6}(?![\p{L}\p{N}])/gu)) {
          const read = match[0].replace(/^PL\s?/u, "").replace(/[Oo]/gu, "0").replace(/[lI|]/gu, "1").replace(/\D/gu, "");
          let differ = read.length === digits.length ? 0 : Infinity;
          for (let index = 0; index < read.length && differ <= 2; index += 1) if (read[index] !== digits[index]) differ += 1;
          if (differ > 2) continue;
          autoSpans.push({
            start: match.index!, end: match.index! + match[0].length, kind: "IBAN", value: match[0], confidence: differ ? 0.9 : 1, source: "AUTO",
            ...(differ ? { uncertain: `odczyt zniekształcony przez OCR, ${form.uncertain ?? "rachunek z białej listy VAT"}` } : {})
          });
        }
        continue;
      }
      // The firm's KRS and REGON: the same digits anywhere; one digit off only after the label.
      if (form.kind === "KRS" || form.kind === "REGON") {
        for (const match of text.matchAll(/(?<![\p{L}\p{N}])\d(?:[ \u00a0-]?\d){8,13}(?![\p{L}\p{N}])/gu)) {
          const read = match[0].replace(/\D/gu, "");
          if (read.length !== form.text.length) continue;
          let differ = 0;
          for (let index = 0; index < read.length && differ <= 1; index += 1) if (read[index] !== form.text[index]) differ += 1;
          const labelled = new RegExp(`\\b${form.kind}\\s*(?:nr\\.?|numer)?\\s*:?\\s*$`, "u").test(text.slice(Math.max(0, match.index! - 20), match.index!));
          if (differ > 1 || (differ === 1 && !labelled)) continue;
          autoSpans.push({
            start: match.index!, end: match.index! + match[0].length, kind: form.kind, value: match[0], confidence: differ ? 0.9 : 1, source: "AUTO",
            ...(differ ? { uncertain: `${form.kind} różni się od rejestru o jedną cyfrę (literówka lub błąd OCR); ${form.uncertain}` } : {})
          });
        }
        continue;
      }
      // Any letter case and spacing ("UL. DŁUGA 5", "Długa  5", "DŁUGA 5"): the same letters with
      // the register's house number do not appear by chance. A firm's name in any case too,
      // but not written all in small letters (a common phrase, not the name).
      const escaped = form.pattern ?? form.text.replace(/[.*+?^${}()|[\]\\]/g, "\\$&").replace(/\s+/gu, "\\s+");
      const anyCase = !form.pattern && (form.kind === "ADDRESS" || Boolean(form.organization));
      for (const match of text.matchAll(new RegExp(`(?<![\\p{L}\\p{N}])${escaped}(?![\\p{L}\\p{N}])`, anyCase ? "giu" : "gu"))) {
        if (form.organization && match[0] !== form.text && match[0] === match[0].toLocaleLowerCase("pl")) continue;
        autoSpans.push({
          start: match.index!, end: match.index! + match[0].length, kind: form.kind, value: match[0], confidence: 1, source: "AUTO",
          ...(form.uncertain ? { uncertain: form.uncertain } : {})
        });
        if (form.organization) registryFirms.set(match[0], form.organization.legalForm);
      }
      // The same name or address as OCR damaged it ("uman Park Global", "Michal Wiatrak",
      // "Pukowca l5"): the whole of it within a letter or two, masked and marked for the user to
      // confirm. An address only with its own numbers: "Pukowca 16" is another building.
      if (form.pattern || (form.kind !== "PERSON" && form.kind !== "ADDRESS")) continue;
      const numbers = (value: string) => value.replace(/[Oo](?=[\d\s,/-]|$)|(?<=\d)[Oo]/gu, "0").replace(/[lI|](?=\d|$)|(?<=\d)[lI|]/gu, "1").replace(/\D/gu, "");
      for (const match of findNameApproximately(text, form.text)) {
        if (match.exact) continue;
        if (form.kind === "ADDRESS" && numbers(match.value) !== numbers(form.text)) continue;
        autoSpans.push({
          start: match.start, end: match.end, kind: form.kind, value: match.value, confidence: 0.9, source: "AUTO",
          uncertain: `odczyt zniekształcony przez OCR, w rejestrze: ${form.text}`
        });
        if (form.organization) {
          registryFirms.set(match.value, form.organization.legalForm);
          // The whole name wins over a fragment of it ("Park Global").
          const known = registryCanonical.get(match.value);
          if (!known || known.name.length < form.text.length) {
            registryCanonical.set(match.value, { name: form.text, note: `odczyt zniekształcony przez OCR, w rejestrze: ${form.text}` });
          }
        }
      }
    }

    // A person found once is protected everywhere: mentions the recognizer
    // missed (another page, another case form) are matched by known forms.
    const propagatedEntities =
      new Map<string, PersonEntity>();
    // Also the all-caps spelling of a known form ("POWÓD: JAN KOWALSKI" in a heading).
    const knownForms = this.vault.knownEntityForms().flatMap((form) => {
      const shouted = form.text.toLocaleUpperCase("pl");
      return shouted === form.text ? [form] : [form, { ...form, text: shouted }];
    });
    for (const form of knownForms) {
      const escaped = form.text.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      // A town alone (no street, no number) masked where it was someone's address is not
      // carried into a court's, office's or police unit's name ("Sąd Rejonowy Katowice-Zachód
      // w Katowicach"): that is no personal data and the analysis needs the court.
      const town = form.kind === "ADDRESS" && !/\d/u.test(form.text) && !STREET_MARK.test(form.text);
      for (const match of text.matchAll(
        new RegExp(`(?<![\\p{L}\\p{N}])${escaped}(?![\\p{L}\\p{N}])`, "gu")
      )) {
        if (town && institutionTown(text, match.index!, match.index! + match[0].length)) continue;
        autoSpans.push({
          start: match.index!,
          end: match.index! + match[0].length,
          kind: form.kind,
          value: match[0],
          confidence: 1,
          source: "AUTO"
        });
        if (form.entity) propagatedEntities.set(`${form.kind}\u0000${match[0]}`, form.entity);
      }
    }

    // A number the register names with a note (one digit off its REGON, an account read with
    // errors) keeps the note: the same span found by its label alone carries none.
    for (const noted of autoSpans.filter((span) => span.uncertain && (span.kind === "REGON" || span.kind === "KRS" || span.kind === "IBAN"))) {
      for (let index = autoSpans.length - 1; index >= 0; index -= 1) {
        const other = autoSpans[index]!;
        if (other !== noted && !other.uncertain && other.start === noted.start && other.end === noted.end) autoSpans.splice(index, 1);
      }
    }
    // A firm protected on another page (its NIP and register data were there): its name here
    // too, as the same firm; a recognized span running past it is cut off below.
    for (const { name, canonical, legalForm } of this.vault.knownOrganizationNames()) {
      const escaped = name.trim().replace(/[.*+?^${}()|[\]\\]/g, "\\$&").replace(/\s+/gu, "\\s+");
      for (const match of text.matchAll(new RegExp(`(?<![\\p{L}\\p{N}])${escaped}(?![\\p{L}\\p{N}])`, "giu"))) {
        if (match[0] === match[0].toLocaleLowerCase("pl")) continue;
        autoSpans.push({ start: match.index!, end: match.index! + match[0].length, kind: "PERSON", value: match[0], confidence: 1, source: "AUTO" });
        if (!registryFirms.has(match[0])) registryFirms.set(match[0], legalForm);
        // The firm's own name: one token whatever the case it is written in (no note).
        if (!registryCanonical.has(match[0])) registryCanonical.set(match[0], { name: canonical, note: "" });
      }
    }
    // An identifier protected on another page (a KRS after its label on page 2, alone on
    // page 3): the same digits in any grouping, the same text for the others.
    for (const { kind, value } of this.vault.knownIdentifierValues()) {
      const digits = value.replace(/\D/gu, "");
      const pattern =
        digits.length >= 6 && !/\p{L}{2}/u.test(value.replace(/^PL/u, ""))
          ? digits.split("").join("[ \\u00a0-]?")
          : value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      for (const match of text.matchAll(new RegExp(`(?<![\\p{L}\\p{N}])(?:PL\\s?)?${pattern}(?![\\p{L}\\p{N}])`, "gu"))) {
        autoSpans.push({ start: match.index!, end: match.index! + match[0].length, kind, value: match[0], confidence: 1, source: "AUTO" });
      }
    }
    // A postal code of a protected address also where it stands apart ("w Katowicach 40-847
    // przy ul. ..."): it narrows the address down.
    const codes = new Set(
      [...autoSpans.filter((span) => span.kind === "ADDRESS").map((span) => span.value), ...this.vault.knownEntityForms().filter((form) => form.kind === "ADDRESS").map((form) => form.text)]
        .flatMap((value) => value.match(/\b\d{2}-\d{3}\b/gu) ?? [])
    );
    for (const code of codes) {
      for (const match of text.matchAll(new RegExp(`(?<![\\p{N}-])${code}(?![\\p{N}-])`, "gu"))) {
        autoSpans.push({ start: match.index!, end: match.index! + match[0].length, kind: "ADDRESS", value: match[0], confidence: 0.9, source: "AUTO" });
      }
    }

    if (this.namedEntities) {
      const named =
        await this.namedEntities.recognize(text);
      for (const recognized of named) {
        // A name never runs over a line: "Paweł Kania⏎os. Kosmonautów 86/9" (a heading
        // and the address under it) is the name; the address is found on its own.
        const lineEnd = recognized.kind === "PERSON" ? recognized.value.indexOf("\n") : -1;
        // A role heading on the first line ("Radców Prawnych⏎Nowak Lis"): the name is below.
        const heading = lineEnd > 0 && roleHeading(recognized.value.slice(0, lineEnd));
        const below = heading ? recognized.value.slice(lineEnd + 1).split("\n")[0]!.trim() : "";
        // A given name at the end of a line and the surname opening the next ("Adwokata
        // Andrzeja⏎Ciecierskiego z Kancelarii"): one name; an address below is no part of it.
        const wrapped =
          lineEnd > 0 &&
          !heading &&
          /^\p{Lu}\p{Ll}+$/u.test(recognized.value.slice(0, lineEnd).trim()) &&
          /^\p{Lu}\p{Ll}+(?:-\p{Lu}\p{Ll}+)?$/u.test(recognized.value.slice(lineEnd + 1).trim()) &&
          !STREET_MARK.test(` ${recognized.value.slice(lineEnd + 1)} `);
        const found =
          heading
            ? { ...recognized, start: recognized.start + recognized.value.indexOf(below, lineEnd + 1), value: below }
            : lineEnd > 0 && !wrapped
              ? { ...recognized, end: recognized.start + lineEnd, value: recognized.value.slice(0, lineEnd).trimEnd() }
              : recognized;
        if (lineEnd > 0) found.end = found.start + found.value.length;
        if (!found.value) continue;
        if (found.kind === "PERSON") {
          // "Sz. P.", "Szan. Pani": a form of address, not a name.
          if (/^(?:Sz(?:an)?\.?\s*P(?:\.|an|ani|aństwo)?|P\.|Pan|Pani|Państwo)\.?$/u.test(found.value.trim())) continue;
          // "Katowice, dnia 4 czerwca", "Katowice, 01.01.2023": the place of a letter's date line.
          const after = text.slice(found.end, found.end + 24);
          const lineStart = found.start === 0 || text[found.start - 1] === "\n";
          if (lineStart && !/\s/u.test(found.value) && /^\s*,\s*(?:dnia\s+)?\d/u.test(after)) continue;
          // The name of a firm from the register is the register's span: a recognized span that
          // runs past it takes words of the sentence with it ("Pomiędzy Human Park Global").
          const firm = autoSpans.find(
            (span) => registryFirms.has(span.value) && span.start < found.end && found.start < span.end && (found.start !== span.start || found.end !== span.end)
          );
          if (firm) continue;
        }
        // A double surname the recognizer cut at the hyphen ("Nicole Brzezińska" of "Nicole Brzezińska-Król").
        if (found.kind === "PERSON") {
          const rest = /^-\p{Lu}\p{Ll}+/u.exec(text.slice(found.end, found.end + 40));
          if (rest) {
            found.end += rest[0].length;
            found.value = text.slice(found.start, found.end);
          }
        }
        // "Bank", "Rada Gminy": an institution; "Najemca Jan Kowalski": the name only.
        const span = found.kind === "PERSON" ? personPart(text, found) : found;
        if (
          span &&
          text.slice(
            span.start,
            span.end
          ) === span.value
        ) {
          autoSpans.push({
            ...span,
            source: "AUTO"
          });
        }
      }
    }

    // The gazetteer is down (Morfeusz not started): names from the PESEL registers instead,
    // so a given name with a surname is not left in clear (pesel-names.ts).
    if (degradedRecognizers().some((item) => item.name.startsWith("Morfeusz"))) {
      for (const span of detectPeselNames(text)) {
        if (!autoSpans.some((other) => other.kind === "PERSON" && other.start < span.end && span.start < other.end)) autoSpans.push(span);
      }
    }

    // A maiden name after "z d." / "z domu" ("Anna Nowak z d. Kot"): a person, whatever the word.
    for (const match of text.matchAll(/(?<![\p{L}])z\s*(?:d\.|domu)\s+(\p{Lu}[\p{L}'’]+(?:-\p{Lu}[\p{L}'’]+)?)/gu)) {
      const start = match.index! + match[0].length - match[1]!.length;
      autoSpans.push({ start, end: start + match[1]!.length, kind: "PERSON", value: match[1]!, confidence: 0.95, source: "AUTO" });
    }

    // A firm name read after a prefix may run into its owner's name ("P.H.U. Marex Marek
    // Nowak"): the firm ends where a recognized person starts; the person keeps its own token.
    // A name before a legal form is the firm whole: "Ciecierski Rak Spółka Komandytowa" keeps
    // "Ciecierski Rak" as one element, though both words are also surnames.
    for (const firm of firms) {
      if (firm.legalForm) continue;
      const owner = autoSpans
        .filter((span) => span.kind === "PERSON" && !firms.includes(span) && span.start > firm.start && span.start < firm.end && span.end >= firm.end)
        .sort((a, b) => a.start - b.start)[0];
      if (!owner) continue;
      const value = text.slice(firm.start, owner.start).trimEnd();
      firm.end = firm.start + value.length;
      firm.value = value;
    }
    for (let index = autoSpans.length - 1; index >= 0; index -= 1) {
      const span = autoSpans[index]!;
      if (firms.includes(span as (typeof firms)[number]) && !/\p{L}{2}/u.test(span.value)) autoSpans.splice(index, 1);
    }

    // A firm read before its legal form may take the words before its name ("Pomiędzy Human
    // Park Global Sp. z o.o.", "(dalej „Rozporządzenie”) Human Park Sp. z o.o."): a name the
    // register or another page gave that ends the span is the firm.
    for (const firm of firms) {
      const known = autoSpans
        .filter((span) => span !== firm && registryFirms.has(span.value) && span.end === firm.end && span.start > firm.start)
        .sort((a, b) => a.start - b.start)[0];
      if (!known) continue;
      firm.start = known.start;
      firm.value = known.value;
    }

    // The bare surname of a person recognized in this text, written with a capital inside a
    // sentence ("spotkał się z Lis", "Lis" also being a common noun the recognizer skips).
    const surnames = new Set(
      autoSpans
        .filter((span) => span.kind === "PERSON" && /\s/u.test(span.value) && !isShouting(span.value))
        .map((span) => span.value.split(/\s+/u).at(-1)!)
        .filter((surname) => /^\p{Lu}\p{Ll}{2,}(?:-\p{Lu}\p{Ll}+)?$/u.test(surname))
    );
    for (const surname of surnames) {
      for (const match of text.matchAll(new RegExp(`(?<![\\p{L}\\p{N}.-])${surname}(?![\\p{L}\\p{N}-])`, "gu"))) {
        const before = text.slice(Math.max(0, match.index! - 3), match.index!);
        if (/(?:^|[.!?]\s*|\n\s*)$/u.test(before) && !/\p{L}\s$/u.test(before)) continue;
        autoSpans.push({ start: match.index!, end: match.index! + match[0].length, kind: "PERSON", value: match[0], confidence: 0.9, source: "AUTO" });
      }
    }

    // A name recognized in the text also protects its all-caps spelling in the same text
    // ("NICOLE BARAN" in a heading above "Nicole Baran"): NER misses names in capitals.
    for (const found of [...autoSpans]) {
      if (found.kind !== "PERSON" || !/\s/u.test(found.value) || isShouting(found.value)) continue;
      const shouted = found.value.toLocaleUpperCase("pl");
      const escaped = shouted.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      for (const match of text.matchAll(new RegExp(`(?<![\\p{L}\\p{N}])${escaped}(?![\\p{L}\\p{N}])`, "gu"))) {
        autoSpans.push({ start: match.index!, end: match.index! + match[0].length, kind: "PERSON", value: match[0], confidence: 1, source: "AUTO" });
      }
    }

    const communities = housingCommunityNames(text);
    const autoAllowed = autoSpans.filter(
      (span) =>
        !(span.kind === "ADDRESS" && institutionAddress(text, span.start, span.value)) &&
        !((span.kind === "ADDRESS" || span.kind === "PERSON") && communities.some((name) => span.start >= name.start && span.end <= name.end)) &&
        !keep.some((item) => overlaps(span, item)) &&
        !labelDirectives.some(
          (item) => overlaps(span, item)
        ) &&
        !manualPseudonyms.some(
          (item) => overlaps(span, item)
        )
    );

    const findings = nonOverlapping([
      ...manualPseudonyms,
      ...autoAllowed
    ]);
    let output = text;
    const publicFindings: PseudonymizationFinding[] = [];

    // Canonical identity and paradigm of every person mention. Without the
    // morphology engine tokens fall back to exact-surface identity.
    // Canonical identity and paradigm of every person and address mention,
    // keyed by kind and surface. Without the morphology engine tokens fall back
    // to exact-surface identity.
    const entities =
      new Map<string, PersonEntity>(propagatedEntities);
    // An inflected mention ("z Transkomem") shares the firm's canonical name and so its token.
    for (const firm of firms) entities.set(`PERSON\u0000${firm.value}`, organizationEntity(firm.canonical ?? firm.value, firm.legalForm));
    for (const [value, legalForm] of registryFirms) {
      const canonical = registryCanonical.get(value)?.name;
      if (canonical || !entities.has(`PERSON\u0000${value}`)) entities.set(`PERSON\u0000${value}`, organizationEntity(canonical ?? value, legalForm));
    }
    // The user's "Firma" marks: the firm's identity, with the legal form written next to it.
    for (const item of manual) {
      if (item.action !== "PSEUDONYMIZE" || item.kind !== "FIRM") continue;
      const value = text.slice(item.start, item.end);
      entities.set(`PERSON\u0000${value}`, organizationEntity(value, firmContext(text, item.start, item.end)?.legalForm));
    }
    // Surfaces written after "państwo", "małżonkowie", a plural role...: a family.
    const plural = new Set(
      findings
        .filter((finding) => finding.kind === "PERSON")
        .filter((finding) => {
          const previous = /([\p{L}]+)\s*$/u.exec(text.slice(Math.max(0, finding.start - 30), finding.start));
          return previous && GROUP_WORDS.has(previous[1]!.toLocaleLowerCase("pl"));
        })
        .map((finding) => finding.value)
    );
    const analyse = async (
      kind: PiiKind,
      run: ((surfaces: string[]) => Promise<Array<PersonEntity | null>>) | undefined
    ) => {
      if (!run) return;
      const surfaces = [
        ...new Set(
          findings
            .filter((finding) => finding.kind === kind)
            .map((finding) => finding.value)
            .filter((value) => !entities.has(`${kind}\u0000${value}`))
        )
      ];
      if (surfaces.length === 0) return;
      try {
        const analysed = await run(surfaces);
        surfaces.forEach((surface, index) => {
          const entity = analysed[index];
          if (entity) entities.set(`${kind}\u0000${surface}`, entity);
        });
      } catch (error) {
        process.stderr.write(
          `${kind}_MORPHOLOGY_DEGRADED:${error instanceof Error ? error.message : String(error)}\n`
        );
      }
    };
    if (this.morphology) {
      const morphology = this.morphology;
      await analyse("PERSON", (surfaces) =>
        morphology.analyze(surfaces, surfaces.map((surface) => (plural.has(surface) ? { numberHint: "pl" as const } : undefined)))
      );
      await analyse(
        "ADDRESS",
        morphology.analyzeAddresses
          ? (surfaces) => morphology.analyzeAddresses!(surfaces)
          : undefined
      );
    }

    // A known person by surname alone or surname first ("Nowakowi", "Pan Wilk", "WILK JAN"):
    // the full name's token, so the model sees one person (surname-propagation.ts).
    {
      // Persons only: an address's last word ("40-847 Katowice") or a firm's ("Human Park") is
      // no surname, and a person sharing it would be read as ambiguous.
      // Also persons named in full only on another page ("Park Juneyoung" here, "Juneyoung Park" there).
      const known = [
        ...new Set([
          ...[...entities].filter(([key, entity]) => key.startsWith("PERSON\u0000") && entity.type !== "organization").map(([, entity]) => entity),
          ...this.vault.knownEntityForms().filter((form) => form.kind === "PERSON" && form.entity && form.entity.type !== "organization").map((form) => form.entity!)
        ])
      ];
      const singleWordPerson = (item: PiiSpan) => item.kind === "PERSON" && !/\s/u.test(item.value.trim());
      const blocked = (start: number, end: number) =>
        [...keep, ...labelDirectives, ...findings.filter((item) => !singleWordPerson(item))].some((item) => overlaps({ start, end }, item));
      for (const mention of surnameMentions(text, known, blocked)) {
        const same = findings.find((item) => item.kind === "PERSON" && item.start === mention.start && item.end === mention.end);
        // A longer mention ("Nowak Piotr") takes the place of a lone surname found inside it,
        // which would leave the given name in clear text under another token.
        const inside = findings.filter(
          (item) => item !== same && singleWordPerson(item) && item.source !== "USER" && item.start >= mention.start && item.end <= mention.end
        );
        for (const item of inside) findings.splice(findings.indexOf(item), 1);
        if (!same && findings.some((item) => overlaps(mention, item))) continue;
        if (!same) {
          findings.push({
            start: mention.start,
            end: mention.end,
            kind: "PERSON",
            value: mention.value,
            confidence: 0.9,
            source: "AUTO",
            ...(mention.ambiguous ? { ambiguous: true } : {})
          });
        }
        entities.set(`PERSON\u0000${mention.value}`, mention.entity);
      }
    }

    // Per mention: a firm named after a person, a family the recognizer
    // missed ("małżonkowie Kowalscy") and given names that share the next
    // person's surname ("Piotrowi i Marii Nowakom"). New mentions are added
    // only when the dictionary confirms them.
    const byFinding = new Map<PiiSpan, PersonEntity>();
    // A sole trader's firm named after the person ("pod firmą Jan Nowak Usługi Remontowe"): the
    // name is the person named outside the firm too ("Powód Jan Nowak"), one token for both.
    const namedAlone = new Set(
      findings
        .filter((finding) => finding.kind === "PERSON" && !firmContext(text, finding.start, finding.end))
        .map((finding) => finding.value)
    );
    for (const finding of findings) {
      if (finding.kind !== "PERSON" || finding.source === "USER") continue;
      const firm = firmContext(text, finding.start, finding.end);
      if (firm && !firm.legalForm && namedAlone.has(finding.value)) continue;
      if (firm) {
        const canonical = registryCanonical.get(finding.value)?.name ?? (finding as FirmSpan).canonical ?? finding.value;
        byFinding.set(finding, organizationEntity(canonical, firm.legalForm));
      }
    }
    if (this.morphology) {
      const morphology = this.morphology;
      const taken = (start: number, end: number) =>
        [...keep, ...labelDirectives, ...findings].some((item) => overlaps({ start, end }, item));
      const analyseSafely = async (surfaces: string[], hints?: Array<{ numberHint: "pl" } | undefined>) => {
        try {
          return await morphology.analyze(surfaces, hints);
        } catch (error) {
          process.stderr.write(`PERSON_MORPHOLOGY_DEGRADED:${error instanceof Error ? error.message : String(error)}\n`);
          return surfaces.map(() => null);
        }
      };

      const families: PiiSpan[] = [];
      for (const match of text.matchAll(/(?<![\p{L}])(\p{L}+)\s+(\p{Lu}\p{Ll}+(?:-\p{Lu}\p{Ll}+)?)(?![\p{L}])/gu)) {
        if (!GROUP_WORDS.has(match[1]!.toLocaleLowerCase("pl"))) continue;
        const start = match.index! + match[0].length - match[2]!.length;
        const end = start + match[2]!.length;
        if (!taken(start, end)) families.push({ start, end, kind: "PERSON", value: match[2]!, confidence: 0.9, source: "AUTO" });
      }
      if (families.length) {
        const analysed = await analyseSafely(families.map((span) => span.value), families.map(() => ({ numberHint: "pl" as const })));
        families.forEach((span, position) => {
          const entity = analysed[position];
          if (entity?.number !== "pl" || taken(span.start, span.end)) return;
          findings.push(span);
          entities.set(`PERSON\u0000${span.value}`, entity);
        });
      }

      const shared: Array<{ span: PiiSpan; surface: string; added: boolean }> = [];
      for (const finding of [...findings]) {
        const entity = entities.get(`PERSON\u0000${finding.value}`);
        if (finding.kind !== "PERSON" || byFinding.has(finding) || !entity?.warnings.includes("SHARED_SURNAME")) continue;
        const surname = finding.value.split(/\s+/).pop()!;
        let cursor = finding.start;
        for (let step = 0; step < 5; step += 1) {
          const before = text.slice(Math.max(0, cursor - 60), cursor);
          const match = /(?<![\p{L}])(\p{Lu}\p{Ll}+)\s*(?:,|\bi\b|\boraz\b)\s*$/u.exec(before);
          if (!match) break;
          const start = cursor - before.length + match.index;
          const end = start + match[1]!.length;
          const existing = findings.find((item) => item.start === start && item.end === end && item.kind === "PERSON");
          if (!existing && taken(start, end)) break;
          shared.push({
            span: existing ?? { start, end, kind: "PERSON", value: match[1]!, confidence: 0.9, source: "AUTO" },
            surface: `${match[1]} ${surname}`,
            added: !existing
          });
          cursor = start;
        }
      }
      if (shared.length) {
        const analysed = await analyseSafely(shared.map((item) => item.surface));
        shared.forEach((item, position) => {
          const entity = analysed[position];
          // Only a name SGJP knows as a given name gets the shared surname.
          if (!entity?.warnings.includes("SHARED_SURNAME")) return;
          if (item.added) {
            if (taken(item.span.start, item.span.end)) return;
            findings.push(item.span);
          }
          byFinding.set(item.span, entity);
        });
      }
      findings.sort((a, b) => a.start - b.start);
    }

    // One person, one token: a mention the morphology read as another person ("MICHAL
    // WIATRAK" without its mark, "MICHAŁWIATRAK" without the space, "Michałem Wiatrak" with
    // the surname not inflected, "Junreyoung Park" with a letter misread) is the person known
    // from this document (person-identity.ts).
    {
      const known = [
        ...new Set([
          ...this.vault.knownPersons(),
          ...[...entities].filter(([key, entity]) => key.startsWith("PERSON\u0000") && entity.type !== "organization").map(([, entity]) => entity)
        ])
      ];
      for (const finding of findings) {
        if (finding.kind !== "PERSON" || finding.source === "USER") continue;
        const own = byFinding.get(finding) ?? entities.get(`PERSON\u0000${finding.value}`);
        if (own?.type === "organization") continue;
        const same = samePerson(finding.value, own, known);
        if (!same) continue;
        // The mention's own reading joins the person's token; the clearer one becomes its paradigm.
        byFinding.set(finding, own && this.vault.mergePerson(same.entity, own) ? own : same.entity);
        if (same.uncertain && !finding.uncertain) finding.uncertain = same.uncertain;
      }
    }

    for (
      let index = findings.length - 1;
      index >= 0;
      index -= 1
    ) {
      const finding = findings[index]!;
      const token = this.vault.getOrCreate(
        finding.kind,
        finding.value,
        byFinding.get(finding) ?? entities.get(`${finding.kind}\u0000${finding.value}`)
      );
      output =
        output.slice(0, finding.start) +
        token +
        output.slice(finding.end);
      const entity = byFinding.get(finding) ?? entities.get(`${finding.kind}\u0000${finding.value}`);
      publicFindings.push({
        token,
        kind: finding.kind,
        ...(entity?.type === "organization" ? { firm: registryFirms.has(finding.value) ? "REGISTRY" as const : "TEXT" as const } : {}),
        start: finding.start,
        end: finding.end,
        source: finding.source ?? "AUTO",
        ...(finding.label
          ? { label: finding.label }
          : {}),
        ...(finding.uncertain && finding.source !== "USER"
          ? { uncertain: finding.uncertain }
          // Kept when the firm rule, not the register, gave the span.
          : registryCanonical.get(finding.value)?.note && finding.source !== "USER"
            ? { uncertain: registryCanonical.get(finding.value)!.note }
          : finding.ambiguous && finding.kind === "PERSON" && finding.source !== "USER" && entity
            ? { uncertain: `nazwisko osoby ${entity.canonical} czy słowo pospolite?` }
            : {})
      });
    }

    publicFindings.reverse();
    const counts: Partial<Record<PiiKind, number>> = {};
    for (const finding of publicFindings) {
      counts[finding.kind] =
        (counts[finding.kind] ?? 0) + 1;
    }

    return {
      text: output,
      findings: publicFindings,
      annotations,
      keptRanges: keep.map((item) => ({
        start: item.start,
        end: item.end
      })),
      counts
    };
  }

  deanonymize(text: string): string {
    return this.vault.deanonymize(text);
  }
}

/**
 * Leak test of the outgoing text (as in a pre-send tightness check): a value the
 * pseudonymizer replaced must not survive anywhere else in the protected text
 * (a second occurrence the recognizer missed). Every remaining occurrence is
 * replaced by the same token, so the answer still restores it. Values shorter
 * than 3 characters are skipped (they also occur inside ordinary words).
 */
export function sealResidualValues(
  original: string,
  protectedText: string,
  findings: ReadonlyArray<Pick<PseudonymizationFinding, "start" | "end" | "token">>
): { text: string; sealed: number } {
  const byValue = new Map<string, string>();
  for (const finding of findings) {
    const value = original.slice(finding.start, finding.end).trim();
    if (value.length >= 3 && !byValue.has(value)) byValue.set(value, finding.token);
  }
  let text = protectedText;
  let sealed = 0;
  // Longest values first: "Jan Kowalski" before "Kowalski".
  for (const [value, token] of [...byValue.entries()].sort((a, b) => b[0].length - a[0].length)) {
    const escaped = value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const pattern = new RegExp(`(?<![\\p{L}\\p{N}])${escaped}(?![\\p{L}\\p{N}])`, "gu");
    text = text.replace(pattern, () => {
      sealed += 1;
      return token;
    });
  }
  return { text, sealed };
}
