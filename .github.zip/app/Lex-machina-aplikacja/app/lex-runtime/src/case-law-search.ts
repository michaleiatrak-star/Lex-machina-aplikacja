import { supremeCourtSearch, type SupremeCourtSearchFilters } from "./case-law-verifier.js";
export type CaseLawSearchFetch = (
  input: string | URL,
  init?: RequestInit
) => Promise<Response>;

export type CaseLawSearchSource =
  | "SAOS"
  | "CBOSA"
  | "SN";

export type CaseLawSearchRequest = {
  source: CaseLawSearchSource;
  query: string;
  limit?: number;
  // SN only: the other fields of the sn.pl search form.
  sn?: Omit<SupremeCourtSearchFilters, "tresc" | "strona" | "rozmiar_strony">;
  // SAOS only: court type (SUPREME, COMMON, ...) and form (SENTENCE = wyrok, DECISION, RESOLUTION).
  saos?: { courtType?: string; judgmentType?: string };
};

export type CaseLawSearchCandidate = {
  source: CaseLawSearchSource;
  id: string;
  caseNumbers: string[];
  judgmentDate?: string;
  court?: string;
  courtType?: string;
  sourceUrl: string;
  contentScope: "DISCOVERY";
};

export type CaseLawSearchResult = {
  source: CaseLawSearchSource;
  status:
    | "FOUND"
    | "NOT_FOUND"
    | "OUT_OF_SCOPE";
  query: string;
  candidates: CaseLawSearchCandidate[];
  total?: number;
  reason?: string;
};

export const CASE_LAW_SEARCH_HOSTS = [
  "saos.org.pl",
  "www.saos.org.pl",
  "orzeczenia.nsa.gov.pl",
  "sn.pl"
] as const;

const SAOS_ENDPOINT =
  "https://www.saos.org.pl/api/search/judgments";
const CBOSA_QUERY =
  "https://orzeczenia.nsa.gov.pl/cbo/query";
const CBOSA_SEARCH =
  "https://orzeczenia.nsa.gov.pl/cbo/search";
const CBOSA_SEARCH_GET =
  "https://orzeczenia.nsa.gov.pl/cbo/search";

const REQUEST_TIMEOUT_MS = 60_000;
const MAX_RESULTS = 10;
const CBOSA_PAGE_SIZE = 10;
const MAX_CBOSA_REDIRECTS = 3;
const MAX_CBOSA_TRANSPORT_ATTEMPTS = 3;

const USER_AGENT =
  "Lex-Machina/0.1 (+local legal research runtime)";
const CBOSA_USER_AGENT =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36";

function clampLimit(
  value: number | undefined
): number {
  if (
    value === undefined ||
    !Number.isFinite(value)
  ) {
    return 5;
  }
  return Math.max(
    1,
    Math.min(
      MAX_RESULTS,
      Math.trunc(value)
    )
  );
}

function object(
  value: unknown
): Record<string, unknown> | null {
  return (
    value &&
    typeof value === "object" &&
    !Array.isArray(value)
  )
    ? value as Record<string, unknown>
    : null;
}

function array(
  value: unknown
): unknown[] {
  return Array.isArray(value)
    ? value
    : [];
}

function text(
  value: unknown
): string | undefined {
  return typeof value === "string" &&
    value.trim()
    ? value.trim()
    : undefined;
}

function decodeHtml(
  value: string
): string {
  return value
    .replace(/&nbsp;|&#160;/giu, " ")
    .replace(/&amp;/giu, "&")
    .replace(/&quot;/giu, '"')
    .replace(/&#39;|&apos;/giu, "'")
    .replace(/&lt;/giu, "<")
    .replace(/&gt;/giu, ">")
    .replace(/<[^>]+>/gu, " ")
    .replace(/\s+/gu, " ")
    .trim();
}

function saosCourt(
  item: Record<string, unknown>
): string | undefined {
  const division =
    object(item.division);
  const court =
    object(division?.court);
  const courtName =
    text(court?.name);
  if (courtName) {
    return courtName;
  }

  const chamber =
    object(array(item.chambers)[0]);
  return text(chamber?.name);
}

function saosCaseNumbers(
  item: Record<string, unknown>
): string[] {
  return array(item.courtCases)
    .map(object)
    .map((entry) =>
      text(entry?.caseNumber)
    )
    .filter(
      (value): value is string =>
        Boolean(value)
    );
}

function saosCandidate(
  raw: unknown
): CaseLawSearchCandidate | null {
  const item = object(raw);
  if (!item) return null;

  const idValue = item.id;
  const id =
    (
      typeof idValue === "number" ||
      typeof idValue === "string"
    )
      ? String(idValue)
      : "";

  if (!id) return null;

  const judgmentDate =
    text(item.judgmentDate);
  const courtType =
    text(item.courtType);
  const court =
    saosCourt(item);

  return {
    source: "SAOS",
    id,
    caseNumbers:
      saosCaseNumbers(item),
    ...(judgmentDate
      ? { judgmentDate }
      : {}),
    ...(court
      ? { court }
      : {}),
    ...(courtType
      ? { courtType }
      : {}),
    sourceUrl:
      `https://www.saos.org.pl/judgments/${encodeURIComponent(id)}`,
    contentScope:
      "DISCOVERY"
  };
}

function saosTotal(
  payload: Record<string, unknown>
): number | undefined {
  const info = object(payload.info);
  const value =
    info?.totalResults ??
    info?.total ??
    payload.totalResults ??
    payload.total;

  return typeof value === "number" &&
    Number.isFinite(value)
    ? value
    : undefined;
}

function cookiesFrom(
  response: Response
): string[] {
  const headers =
    response.headers as Headers & {
      getSetCookie?: () => string[];
    };

  const values =
    headers.getSetCookie?.() ??
    (
      response.headers.get(
        "set-cookie"
      )
        ? [
            response.headers.get(
              "set-cookie"
            )!
          ]
        : []
    );

  return values
    .map((value) =>
      value.split(";", 1)[0]?.trim()
    )
    .filter(
      (value): value is string =>
        Boolean(value)
    );
}

function mergeCookies(
  current: string[],
  incoming: string[]
): string[] {
  const byName =
    new Map<string, string>();

  for (const cookie of [
    ...current,
    ...incoming
  ]) {
    const name =
      cookie.split("=", 1)[0]?.trim();
    if (name) {
      byName.set(name, cookie);
    }
  }

  return [...byName.values()];
}

function sleep(
  milliseconds: number
): Promise<void> {
  return new Promise(
    (resolve) =>
      setTimeout(
        resolve,
        milliseconds
      )
  );
}

async function fetchCbosa(
  fetcher: CaseLawSearchFetch,
  input: string,
  init: RequestInit,
  cookies: string[]
): Promise<{
  response: Response;
  cookies: string[];
}> {
  let url = input;
  let method =
    (init.method ?? "GET")
      .toUpperCase();
  let body = init.body;
  let jar = [...cookies];

  for (
    let redirect = 0;
    redirect <= MAX_CBOSA_REDIRECTS;
    redirect += 1
  ) {
    const {
      body: _initBody,
      ...initWithoutBody
    } = init;
    const requestInit:
      RequestInit = {
        ...initWithoutBody,
        method,
        redirect: "manual",
        headers: {
          "User-Agent":
            CBOSA_USER_AGENT,
          Accept:
            "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
          "Accept-Language":
            "pl-PL,pl;q=0.9,en;q=0.7",
          "Upgrade-Insecure-Requests":
            "1",
          ...(init.headers ?? {}),
          ...(jar.length
            ? {
                Cookie:
                  jar.join("; ")
              }
            : {})
        }
      };

    if (
      method !== "GET" &&
      method !== "HEAD" &&
      body !== undefined &&
      body !== null
    ) {
      requestInit.body = body;
    }

    let response:
      Response | undefined;
    let lastError:
      unknown;

    for (
      let attempt = 1;
      attempt <=
        MAX_CBOSA_TRANSPORT_ATTEMPTS;
      attempt += 1
    ) {
      try {
        response =
          await fetcher(
            url,
            {
              ...requestInit,
              signal:
                AbortSignal.timeout(
                  REQUEST_TIMEOUT_MS
                )
            }
          );
        // CBOSA answers 503 under load: one more attempt after a pause, like a transport error.
        if (response.status === 503 && attempt < MAX_CBOSA_TRANSPORT_ATTEMPTS) {
          await sleep(500 * 2 ** (attempt - 1));
          continue;
        }
        break;
      } catch (error) {
        lastError = error;
        if (
          attempt >=
          MAX_CBOSA_TRANSPORT_ATTEMPTS
        ) {
          throw lastError;
        }
        await sleep(
          500 *
          2 ** (attempt - 1)
        );
      }
    }

    if (!response) {
      throw lastError ??
        new Error(
          "CBOSA_TRANSPORT_FAILED"
        );
    }

    jar = mergeCookies(
      jar,
      cookiesFrom(response)
    );

    if (
      response.status >= 300 &&
      response.status < 400
    ) {
      const location =
        response.headers.get(
          "location"
        );
      if (!location) {
        throw new Error(
          "CBOSA_REDIRECT_WITHOUT_LOCATION"
        );
      }

      const next =
        new URL(location, url);
      if (
        next.protocol !== "https:" ||
        next.hostname.toLowerCase() !==
          "orzeczenia.nsa.gov.pl"
      ) {
        throw new Error(
          "CBOSA_REDIRECT_HOST_DENIED"
        );
      }

      url = next.toString();
      if (
        response.status === 303 ||
        (
          response.status === 302 &&
          method === "POST"
        )
      ) {
        method = "GET";
        body = undefined;
      }
      continue;
    }

    return {
      response,
      cookies: jar
    };
  }

  throw new Error(
    "CBOSA_REDIRECT_LIMIT_EXCEEDED"
  );
}

function cbosaTotal(
  html: string
): number | undefined {
  const normalized =
    decodeHtml(html);
  const match =
    normalized.match(
      /Znaleziono\s+(\d+)\s+orzecze(?:ń|nia|nie)/iu
    );
  return match?.[1]
    ? Number(match[1])
    : undefined;
}

function cbosaDocIds(
  html: string
): string[] {
  const ids: string[] = [];
  const seen = new Set<string>();
  const regex =
    /href\s*=\s*["']\/doc\/([A-Z0-9]{10})\/?["']/giu;

  for (
    const match of html.matchAll(regex)
  ) {
    const id =
      match[1]?.toUpperCase();
    if (
      id &&
      !seen.has(id)
    ) {
      seen.add(id);
      ids.push(id);
    }
  }

  return ids;
}

function cbosaCaseNumber(
  html: string
): string[] {
  const titleMatch =
    html.match(
      /<title\b[^>]*>([\s\S]*?)<\/title>/iu
    );
  const title =
    titleMatch?.[1]
      ? decodeHtml(titleMatch[1])
      : "";

  const match =
    title.match(
      /^(.+?)\s+-\s+(?:Wyrok|Postanowienie|Uchwała)\b/iu
    );

  return match?.[1]?.trim()
    ? [match[1].trim()]
    : [];
}

function cbosaField(
  html: string,
  label: string
): string | undefined {
  const escaped =
    label.replace(
      /[.*+?^${}()|[\]\\]/g,
      "\\$&"
    );
  const pattern =
    new RegExp(
      `<td[^>]*class=["'][^"']*lista-label[^"']*["'][^>]*>\\s*${escaped}\\s*<\\/td>[\\s\\S]{0,500}?<td[^>]*class=["'][^"']*info-list-value[^"']*["'][^>]*>([\\s\\S]*?)<\\/td>`,
      "iu"
    );
  const value =
    html.match(pattern)?.[1];
  return value
    ? decodeHtml(value)
    : undefined;
}

function cbosaCandidate(
  id: string,
  html: string
): CaseLawSearchCandidate {
  const judgmentDate =
    cbosaField(
      html,
      "Data orzeczenia"
    );
  const court =
    cbosaField(
      html,
      "Sąd"
    );

  return {
    source: "CBOSA",
    id,
    caseNumbers:
      cbosaCaseNumber(html),
    ...(judgmentDate
      ? { judgmentDate }
      : {}),
    ...(court
      ? { court }
      : {}),
    courtType:
      "ADMINISTRATIVE",
    sourceUrl:
      `https://orzeczenia.nsa.gov.pl/doc/${id}`,
    contentScope:
      "DISCOVERY"
  };
}

export function caseLawSearchEntryUrl(
  source: CaseLawSearchSource
): string {
  return source === "SAOS"
    ? SAOS_ENDPOINT
    : source === "SN"
      ? "https://sn.pl/index.php"
      : CBOSA_SEARCH;
}

export class CaseLawSearchService {
  constructor(
    private readonly fetcher:
      CaseLawSearchFetch =
        globalThis.fetch.bind(
          globalThis
        )
  ) {}

  async search(
    request: CaseLawSearchRequest
  ): Promise<CaseLawSearchResult> {
    const query =
      request.query
        .normalize("NFKC")
        .replace(/\s+/gu, " ")
        .trim();
    const limit =
      clampLimit(request.limit);

    if (request.source === "SN") {
      return await this.searchSn(query, limit, request.sn ?? {});
    }

    if (
      query.length < 2 ||
      query.length > 500
    ) {
      return {
        source: request.source,
        status:
          "OUT_OF_SCOPE",
        query,
        candidates: [],
        reason:
          "INVALID_SEARCH_QUERY"
      };
    }

    return request.source === "SAOS"
      ? await this.searchSaos(
          query,
          limit,
          request.saos ?? {}
        )
      : await this.searchCbosa(
          query,
          limit
        );
  }

  // sn.pl search form: text of the decision and its reasons plus the other
  // fields. Hits are checked against the asked signature, form and dates.
  private async searchSn(
    query: string,
    limit: number,
    filters: NonNullable<CaseLawSearchRequest["sn"]>
  ): Promise<CaseLawSearchResult> {
    const hasFilter = Object.values(filters).some((value) => typeof value === "string" && value.trim());
    if ((query.length < 2 && !hasFilter) || query.length > 500) {
      return { source: "SN", status: "OUT_OF_SCOPE", query, candidates: [], reason: "INVALID_SEARCH_QUERY" };
    }
    let hits;
    try {
      hits = await supremeCourtSearch(
        { ...(query.length >= 2 ? { tresc: query } : {}), ...filters, strona: 1, rozmiar_strony: Math.max(10, limit) },
        this.fetcher
      );
    } catch (error) {
      return {
        source: "SN",
        status: "OUT_OF_SCOPE",
        query,
        candidates: [],
        reason: error instanceof Error && /^SN_/.test(error.message) ? error.message : "SN_SEARCH_TRANSPORT_FAILED"
      };
    }
    const same = (a: string, b: string) => a.replace(/[.\s]+/g, " ").trim().toUpperCase() === b.replace(/[.\s]+/g, " ").trim().toUpperCase();
    const matching = hits.filter(
      (hit) =>
        (!filters.sygnatura || same(hit.signature, filters.sygnatura)) &&
        (!filters.forma_orzeczenia || !hit.form || same(hit.form, filters.forma_orzeczenia)) &&
        (!filters.data_wydania_od || !hit.date || hit.date >= filters.data_wydania_od) &&
        (!filters.data_wydania_do || !hit.date || hit.date <= filters.data_wydania_do)
    );
    const candidates: CaseLawSearchCandidate[] = matching.slice(0, limit).map((hit) => ({
      source: "SN",
      id: hit.id,
      caseNumbers: [hit.signature],
      ...(hit.date ? { judgmentDate: hit.date } : {}),
      court: "Sąd Najwyższy",
      ...(hit.form ? { courtType: hit.form } : {}),
      sourceUrl: hit.cardUrl,
      contentScope: "DISCOVERY"
    }));
    return {
      source: "SN",
      status: candidates.length ? "FOUND" : "NOT_FOUND",
      query,
      candidates,
      total: matching.length,
      ...(hits.length > matching.length ? { reason: `REJECTED_${hits.length - matching.length}_NOT_MATCHING_FILTERS` } : {})
    };
  }

  private async searchSaos(
    query: string,
    limit: number,
    filters: NonNullable<CaseLawSearchRequest["saos"]> = {}
  ): Promise<CaseLawSearchResult> {
    const url =
      new URL(SAOS_ENDPOINT);
    url.searchParams.set(
      "all",
      query
    );
    if (filters.courtType) url.searchParams.set("courtType", filters.courtType);
    if (filters.judgmentType) url.searchParams.set("judgmentTypes", filters.judgmentType);
    url.searchParams.set(
      "pageSize",
      String(
        Math.max(10, limit)
      )
    );
    url.searchParams.set(
      "pageNumber",
      "0"
    );
    url.searchParams.set(
      "sortingField",
      "JUDGMENT_DATE"
    );
    url.searchParams.set(
      "sortingDirection",
      "DESC"
    );

    let response: Response;
    try {
      response =
        await this.fetcher(
          url,
          {
            method: "GET",
            redirect: "error",
            signal:
              AbortSignal.timeout(
                REQUEST_TIMEOUT_MS
              ),
            headers: {
              Accept:
                "application/json",
              "User-Agent":
                USER_AGENT
            }
          }
        );
    } catch {
      return {
        source: "SAOS",
        status:
          "OUT_OF_SCOPE",
        query,
        candidates: [],
        reason:
          "SAOS_TRANSPORT_FAILED"
      };
    }

    if (!response.ok) {
      return {
        source: "SAOS",
        status:
          "OUT_OF_SCOPE",
        query,
        candidates: [],
        reason:
          "SAOS_HTTP_" +
          response.status
      };
    }

    const contentType =
      response.headers
        .get(
          "content-type"
        )
        ?.toLowerCase() ??
      "";
    if (
      !contentType.includes(
        "application/json"
      )
    ) {
      return {
        source: "SAOS",
        status:
          "OUT_OF_SCOPE",
        query,
        candidates: [],
        reason:
          "SAOS_NON_JSON_RESPONSE"
      };
    }

    let payload: unknown;
    try {
      payload =
        await response.json();
    } catch {
      return {
        source: "SAOS",
        status:
          "OUT_OF_SCOPE",
        query,
        candidates: [],
        reason:
          "SAOS_JSON_DRIFT"
      };
    }

    const root =
      object(payload);
    if (!root) {
      return {
        source: "SAOS",
        status:
          "OUT_OF_SCOPE",
        query,
        candidates: [],
        reason:
          "SAOS_SCHEMA_DRIFT"
      };
    }

    const candidates =
      array(root.items)
        .map(saosCandidate)
        .filter(
          (
            item
          ): item is CaseLawSearchCandidate =>
            Boolean(item)
        )
        .slice(0, limit);

    const total =
      saosTotal(root);

    return {
      source: "SAOS",
      status:
        candidates.length
          ? "FOUND"
          : "NOT_FOUND",
      query,
      candidates,
      ...(total !== undefined
        ? { total }
        : {})
    };
  }

  private async searchCbosa(
    query: string,
    limit: number
  ): Promise<CaseLawSearchResult> {
    const form =
      new URLSearchParams({
        wszystkieSlowa:
          query,
        wystepowanie:
          "gdziekolwiek",
        odmiana:
          "on",
        sygnatura:
          "",
        sad:
          "dowolny",
        rodzaj:
          "dowolny",
        symbole:
          "",
        odDaty:
          "",
        doDaty:
          "",
        sedziowie:
          "",
        funkcja:
          "",
        submit:
          "Szukaj"
      });

    let first:
      | {
          response:
            Response;
          cookies:
            string[];
        }
      | undefined;

    let warmupCookies:
      string[] = [];

    try {
      const warmup =
        await fetchCbosa(
          this.fetcher,
          CBOSA_QUERY,
          {
            method: "GET"
          },
          []
        );

      if (warmup.response.ok) {
        warmupCookies =
          warmup.cookies;
      }
    } catch {
      // Continue to the same-host search fallback below.
    }

    try {
      first =
        await fetchCbosa(
          this.fetcher,
          CBOSA_SEARCH,
          {
            method: "POST",
            headers: {
              "Content-Type":
                "application/x-www-form-urlencoded",
              Origin:
                "https://orzeczenia.nsa.gov.pl",
              Referer:
                CBOSA_QUERY
            },
            body:
              form.toString()
          },
          warmupCookies
        );
    } catch {
      try {
        const fallbackUrl =
          new URL(
            CBOSA_SEARCH_GET
          );
        for (
          const [key, value]
          of form.entries()
        ) {
          fallbackUrl
            .searchParams
            .set(
              key,
              value
            );
        }

        first =
          await fetchCbosa(
            this.fetcher,
            fallbackUrl.toString(),
            {
              method:
                "GET",
              headers: {
                Referer:
                  CBOSA_QUERY
              }
            },
            warmupCookies
          );
      } catch {
        return {
          source: "CBOSA",
          status:
            "OUT_OF_SCOPE",
          query,
          candidates: [],
          reason:
            "CBOSA_TRANSPORT_FAILED"
        };
      }
    }

    if (!first.response.ok) {
      return {
        source: "CBOSA",
        status:
          "OUT_OF_SCOPE",
        query,
        candidates: [],
        reason:
          "CBOSA_HTTP_" +
          first.response.status
      };
    }

    const firstHtml =
      await first.response.text();

    const total =
      cbosaTotal(firstHtml);
    if (total === undefined) {
      return {
        source: "CBOSA",
        status:
          "OUT_OF_SCOPE",
        query,
        candidates: [],
        reason:
          "CBOSA_RESULT_COUNT_DRIFT"
      };
    }

    // NSA/WSA (CBOSA) policy: no hits is OUT_OF_SCOPE, never evidence that
    // no judgment exists.
    if (total === 0) {
      return {
        source: "CBOSA",
        status:
          "OUT_OF_SCOPE",
        query,
        candidates: [],
        total: 0,
        reason:
          "CBOSA_NO_HITS"
      };
    }

    const ids: string[] = [];
    const seen =
      new Set<string>();
    const collect =
      (html: string) => {
        for (
          const id
          of cbosaDocIds(html)
        ) {
          if (!seen.has(id)) {
            seen.add(id);
            ids.push(id);
          }
        }
      };

    collect(firstHtml);

    const needed =
      Math.min(
        total,
        limit
      );
    let page = 2;

    while (
      ids.length < needed
    ) {
      if (
        page > 25 ||
        (
          page - 1
        ) * CBOSA_PAGE_SIZE >
          total + CBOSA_PAGE_SIZE
      ) {
        return {
          source:
            "CBOSA",
          status:
            "OUT_OF_SCOPE",
          query,
          candidates: [],
          total,
          reason:
            "CBOSA_PAGINATION_LIMIT"
        };
      }

      let next:
        | {
            response:
              Response;
            cookies:
              string[];
          }
        | undefined;
      try {
        next =
          await fetchCbosa(
            this.fetcher,
            `https://orzeczenia.nsa.gov.pl/cbo/find?p=${page}`,
            {
              method:
                "GET"
            },
            first.cookies
          );
      } catch {
        return {
          source:
            "CBOSA",
          status:
            "OUT_OF_SCOPE",
          query,
          candidates: [],
          total,
          reason:
            "CBOSA_PAGINATION_TRANSPORT_FAILED"
        };
      }

      if (!next.response.ok) {
        return {
          source:
            "CBOSA",
          status:
            "OUT_OF_SCOPE",
          query,
          candidates: [],
          total,
          reason:
            "CBOSA_PAGINATION_HTTP_" +
            next.response.status
        };
      }

      const html =
        await next.response.text();
      const before =
        ids.length;
      collect(html);
      if (
        ids.length === before
      ) {
        return {
          source:
            "CBOSA",
          status:
            "OUT_OF_SCOPE",
          query,
          candidates: [],
          total,
          reason:
            "CBOSA_PAGINATION_STALLED"
        };
      }
      page += 1;
    }

    if (!ids.length) {
      return {
        source: "CBOSA",
        status:
          "OUT_OF_SCOPE",
        query,
        candidates: [],
        total,
        reason:
          "CBOSA_RESULT_LINK_DRIFT"
      };
    }

    const candidates:
      CaseLawSearchCandidate[] = [];
    const skipped: string[] = [];

    for (
      const id
      of ids.slice(0, needed)
    ) {
      let document:
        | {
            response:
              Response;
            cookies:
              string[];
          }
        | undefined;
      try {
        document =
          await fetchCbosa(
            this.fetcher,
            `https://orzeczenia.nsa.gov.pl/doc/${id}`,
            {
              method:
                "GET"
            },
            first.cookies
          );
      } catch {
        // One document that cannot be read drops that document, not the whole search.
        skipped.push("CBOSA_DOCUMENT_TRANSPORT_FAILED");
        continue;
      }

      if (!document.response.ok) {
        skipped.push("CBOSA_DOCUMENT_HTTP_" + document.response.status);
        continue;
      }

      const html =
        await document.response.text();
      const caseNumbers =
        cbosaCaseNumber(html);
      if (!caseNumbers.length) {
        skipped.push("CBOSA_DOCUMENT_SCHEMA_DRIFT");
        continue;
      }

      candidates.push(
        cbosaCandidate(
          id,
          html
        )
      );
    }

    return {
      source: "CBOSA",
      status:
        candidates.length
          ? "FOUND"
          : "OUT_OF_SCOPE",
      query,
      candidates,
      total,
      ...(candidates.length
        ? {}
        : {
            reason:
              skipped[0] ?? "CBOSA_NO_HITS"
          })
    };
  }
}
