import { EML_MEDIA_TYPE, RTF_MEDIA_TYPE } from "./office-document-extractor.js";
import { isRecordingMediaType, transcriptPages, type RecordingMediaType, type RecordingTranscriber } from "./transcription.js";
import { alignProtected, protectedPageText, type DocxAnonymizationPlan } from "./docx-anonymize.js";
import { detectHealthData } from "./privacy/health-data.js";
import type {
  PersonMorphology
} from "./privacy/person-morphology.js";
import { degradedRecognizers } from "./privacy/gazetteer-ner.js";
import { normalizeOcrPage } from "./ocr-correction.js";
import { documentWork } from "./document-work.js";
import { restoreOcrSpacing } from "./ocr-spacing.js";
import { markOcrReview } from "./ocr-review.js";
import { correctWithVision, enoughMemoryForVision, withoutLineCrops, type ReadLine } from "./ocr-vision.js";
import {
  maskBoxes,
  protectedValues,
  wantsImage,
  type EvidenceImage,
  type EvidencePolicy,
  type PageImageMasker
} from "./document-evidence.js";
import {
  createHash
} from "node:crypto";
import type {
  CompleteDocumentIngestor,
  DocumentIngestionResult,
  IngestedPage,
  OcrCorrection,
  OcrReviewLine
} from "./document-ingestion.js";
import {
  chunkDocumentPages
} from "./document-ingestion.js";
import type {
  CompleteImageIngestor,
  SupportedImageMediaType
} from "./image-ingestion.js";
import {
  LocalPolishPseudonymizer,
  organizationEntity,
  PseudonymizationVault,
  type PseudonymizationVaultSnapshot,
  type ManualPrivacyDirective,
  type NamedEntityRecognizer,
  type PiiSpan,
  type PiiKind
} from "./privacy/pseudonymizer.js";
import {
  privacyRecognizerFor
} from "./privacy/local-llm-ner.js";
import type {
  EncryptedPrivacyVaultStore
} from "./privacy/vault-store.js";
import type {
  SecureCaseDocumentStore
} from "./case-document-store.js";
import type { ProgressReporter } from "./processing-progress.js";
import { restoreWithReport } from "./privacy/restoration-report.js";
import {
  genderOf,
  partyGroups,
  placeholderGrammar,
  placeholderKeyPrompt,
  type PlaceholderGrammar
} from "./privacy/token-legend.js";
import { genericWords } from "./privacy/generic-words.js";
import type { RegistryFormsProvider } from "./privacy/registry-enrichment.js";
import {
  PERSON_CASES,
  type PersonCase,
  type PersonEntity
} from "./privacy/person-morphology.js";
import {
  DOCX_MEDIA_TYPE,
  ODT_MEDIA_TYPE,
  type OfficeDocumentTextExtractor,
  type OfficeDocumentMediaType
} from "./office-document-extractor.js";
import {
  XLSX_MEDIA_TYPE,
  XLSM_MEDIA_TYPE,
  CSV_MEDIA_TYPE,
  TSV_MEDIA_TYPE,
  type SpreadsheetTextExtractor,
  type SpreadsheetMediaType
} from "./spreadsheet-extractor.js";

/** The scan of a page for the preview next to its text, with the box of every OCR line. */
export type PageScan = {
  page: number;
  mediaType: "image/jpeg";
  data: string;
  width: number;
  height: number;
  // Empty after a hand correction: the lines no longer match the text.
  // Indexed like the OCR lines (review and correction entries point at them).
  lines: Array<{ text: string; box: [number, number, number, number] | null; poly?: Array<[number, number]> }>;
};

export type DocumentSecurityContext = {
  caseId: string;
  caseDataKey?: Buffer;
  keyVersion?: number;
  // Stage and page counts for the case view's progress bar.
  onProgress?: ProgressReporter;
  // "z lokalnym AI": the running local model checks every page for
  // personal data.
  localAi?: boolean;
  // OCR correction (model-free cleanup and the local vision model): true = on (also without
  // localAi, for "Tylko OCR z korektą AI"), false = off; unset = on with localAi.
  ocrFix?: boolean;
  // false: only read the document (OCR); personal data is detected later by detect().
  detect?: boolean;
  // OCR of a file added to the case, before the user's decision: yields to the user's work.
  background?: boolean;
  // A recording transcribed again with this many speakers (0 = estimated): the stored reading
  // is not reused.
  speakers?: number;
  // Background OCR runs outside the case lock (a confirmation in the same case does not wait
  // for it); only saving its result takes the lock and the case key, through this callback.
  storeUnderLock?: <T>(save: (key: { caseDataKey: Buffer; keyVersion: number }) => Promise<T>) => Promise<T>;
};

/**
 * OCR correction (vision model): on for "z AI" anonymization unless switched off (undo),
 * and on its own for "Tylko OCR z korektą AI".
 */
export function shouldCorrectOcr(
  security?: Pick<DocumentSecurityContext, "localAi" | "ocrFix">
): boolean {
  return (
    security?.ocrFix === true ||
    (security?.localAi === true && security.ocrFix !== false)
  );
}

function normalizedOcr(source: DocumentIngestionResult, maxChunkChars: number): DocumentIngestionResult {
  const pages = source.pages.map(normalizeOcrPage);
  if (pages.every((page, index) => page === source.pages[index])) return source;
  return {
    ...source,
    pages,
    sourceChars: pages.reduce((sum, page) => sum + page.text.length, 0),
    chunks: chunkDocumentPages(pages, maxChunkChars)
  };
}

function hasLineCrops(source: DocumentIngestionResult): boolean {
  return source.pages.some((page) => page.source === "OCR" && page.lines?.some((line) => line.crop));
}

function withoutCrops(source: DocumentIngestionResult): DocumentIngestionResult {
  const pages = source.pages.map(withoutLineCrops);
  return pages.every((page, index) => page === source.pages[index]) ? source : { ...source, pages };
}

/** UTF-8 (BOM stripped), else Windows-1250 as used by older Polish files. */
export function decodePlainText(data: Uint8Array): string {
  try {
    return new TextDecoder("utf-8", { fatal: true, ignoreBOM: false }).decode(data);
  } catch {
    return new TextDecoder("windows-1250").decode(data);
  }
}

export type SupportedDocumentMediaType =
  | "application/pdf"
  | SupportedImageMediaType
  | "text/plain"
  | "text/markdown"
  | typeof DOCX_MEDIA_TYPE
  | typeof ODT_MEDIA_TYPE
  | typeof XLSX_MEDIA_TYPE
  | typeof XLSM_MEDIA_TYPE
  | typeof CSV_MEDIA_TYPE
  | typeof TSV_MEDIA_TYPE
  | typeof EML_MEDIA_TYPE
  | typeof RTF_MEDIA_TYPE
  | RecordingMediaType;

export type PublicDocumentChunk = {
  index: number;
  pageStart: number;
  pageEnd: number;
  text: string;
};

export type DocumentChunkSelection = {
  documentId: string;
  chunkIndices: number[];
};

export type ResolvedDocumentAttachment = {
  documentId: string;
  chunks: PublicDocumentChunk[];
  totalChars: number;
  // Kind and gender of the person/address placeholders in the chunks.
  grammar?: PlaceholderGrammar[];
  // Page count of the whole document, so a model knows where it is.
  totalPages?: number;
  // Scanned pages of the selected chunks, personal data masked (evidence).
  images?: EvidenceImage[];
};

export type AnonymizedVersion = {
  documentId: string;
  totalPages: number;
  chunks: PublicDocumentChunk[];
  highlighted: HighlightedChunk[];
  entries: PrivacyKeyEntry[];
  // Legend and key for an external model (kinds, gender, parties - no values).
  modelKey: string | null;
  // See PublicDocumentIngestion.privacy.reviewed.
  reviewed?: boolean;
};

/**
 * The legend and key a model needs to answer with this document's symbols:
 * kinds, gender, number and parties of several persons. Never a value.
 */
export function modelKeyFor(
  texts: string[],
  vault: PseudonymizationVault
): string | null {
  const roles = genericWords().partyRoles;
  return placeholderKeyPrompt(
    placeholderGrammar(texts.join("\n"), vault),
    partyGroups(texts, (word) => roles.has(word))
  );
}

function escapeRegExp(value: string): string {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

/** Replaces whole-word surfaces (longest first) outside existing tokens. */
export function replaceOutsideTokens(
  text: string,
  surfaces: string[],
  token: string
): { text: string; count: number } {
  const ordered = [...surfaces].sort((a, b) => b.length - a.length).map(escapeRegExp);
  if (!ordered.length) return { text, count: 0 };
  const pattern = new RegExp(`(?<![\\p{L}\\p{N}])(?:${ordered.join("|")})(?![\\p{L}\\p{N}])`, "giu");
  let count = 0;
  const parts = text.split(/(\[(?:LMPII:D\d{2}|PII):[A-Z_]+:\d{4}(?:\|[A-Z]{2,4})?\])/);
  const out = parts.map((part, index) =>
    index % 2 === 1
      ? part
      : part.replace(pattern, () => {
          count += 1;
          return token;
        })
  );
  return { text: out.join(""), count };
}

export type HighlightedChunk = {
  index: number;
  pageStart: number;
  pageEnd: number;
  // The original wording, with every anonymized span marked.
  text: string;
  marks: Array<{ start: number; end: number; token: string; kind: string }>;
};

const PROTECTED_PART = /(\[PII:[A-Z_]+:\d{4}(?:\|[A-Z]{2,4})?\])/;
const PAGE_HEADER = /^\[STRONA [^\]\n]+\]\n?/gm;
// One page corrected by hand; a scanned page is a few thousand characters.
const MAX_EDITED_PAGE_CHARS = 200_000;

/**
 * Lines the anonymized text up with the source to show the original words
 * (in their original case) where each token stands. A token takes the
 * longest of its known forms found at that point; otherwise the text up to
 * where the next literal part continues in the source.
 */
export function highlightProtected(
  protectedText: string,
  source: string,
  surfaces: (token: string) => string[],
  fallback: (token: string) => string
): { text: string; marks: HighlightedChunk["marks"] } {
  const parts = protectedText.split(PROTECTED_PART);
  const lower = source.toLocaleLowerCase("pl");
  let cursor = 0;
  let text = "";
  const marks: HighlightedChunk["marks"] = [];
  for (let index = 0; index < parts.length; index += 1) {
    const part = parts[index]!;
    if (index % 2 === 0) {
      text += part;
      const literal = part.replace(PAGE_HEADER, "");
      if (literal) {
        const found = source.indexOf(literal, cursor);
        if (found >= 0 && found - cursor < 4000) cursor = found + literal.length;
      }
      continue;
    }
    const token = part.replace(/\|[A-Z]{2,4}\]$/, "]");
    const kind = /^\[PII:([A-Z_]+):/.exec(token)![1]!;
    let original = "";
    for (const surface of [...surfaces(token)].sort((a, b) => b.length - a.length)) {
      if (surface && lower.startsWith(surface.toLocaleLowerCase("pl"), cursor)) {
        original = source.slice(cursor, cursor + surface.length);
        break;
      }
    }
    if (!original) {
      const anchor = (parts[index + 1] ?? "").replace(PAGE_HEADER, "").slice(0, 24);
      const found = anchor ? source.indexOf(anchor, cursor) : -1;
      if (found > cursor && found - cursor <= 300) original = source.slice(cursor, found);
    }
    // Not found in the source (e.g. text changed since): the stored value.
    const shown = original || fallback(token);
    cursor += original.length;
    text += shown;
    marks.push({ start: text.length - shown.length, end: text.length, token, kind });
  }
  return { text, marks };
}

/** One row of a document's anonymization key, shown locally only. */
export type PrivacyKeyEntry = {
  token: string;
  kind: string;
  value: string;
  // Case forms used when restoring (persons and addresses).
  forms?: Array<{ case: string; text: string }>;
  gender?: "m" | "f" | "unknown";
  // Person tokens: one person, several persons named together, or a firm.
  entity?: "person" | "group" | "organization";
  legalForm?: string;
  occurrences: number;
};

// What the user may set for a person token in the key.
export type KeyGrammar = "m" | "f" | "group-m" | "group-f" | "organization";

export type PagePrivacyDirective =
  ManualPrivacyDirective & {
    page: number;
  };

export type PublicPrivacySuggestion = {
  page: number;
  start: number;
  end: number;
  kind: PiiKind;
  // A firm's name, found in a public register (VAT white list, KRS) or in the text.
  firm?: "REGISTRY" | "TEXT";
  // The local model's answer that this is no person ("słowo pospolite"); masked until the user unmasks it.
  aiNotPerson?: string;
  // Masked as a known person's surname, but the word may be a common noun: the user decides.
  uncertain?: string;
};

export type PublicPrivacyAnnotation = {
  page: number;
  start: number;
  end: number;
  label: string;
};

export type PublicDocumentReview = {
  documentId: string;
  mediaType: SupportedDocumentMediaType;
  complete: true;
  totalPages: number;
  pages: Array<{
    page: number;
    text: string;
    source: IngestedPage["source"];
    confidence?: number;
    engine?: string;
    // OCR words fixed: spaces restored, and by the local model (from → to).
    corrections?: OcrCorrection[];
    // Lines to check against the scan (handwriting, stamps, doubtful reading).
    review?: OcrReviewLine[];
    // The user corrected this page's text by hand.
    editedByUser?: boolean;
  }>;
  suggestions: PublicPrivacySuggestion[];
  // Local recognizers down during the detection: what they find may be missing above.
  recognizerWarnings?: Array<{ name: string; reason: string }>;
  // Health data (art. 9 RODO), not masked by default: the user masks them or not (privacy/health-data.ts).
  healthData?: Array<{ page: number; start: number; end: number }>;
};

export type PublicDocumentIngestion = {
  documentId: string;
  mediaType: SupportedDocumentMediaType;
  complete: true;
  totalPages: number;
  digitalPages: number;
  ocrPages: number;
  blankPages: number;
  sourceChars: number;
  pseudonymizedChars: number;
  chunks: PublicDocumentChunk[];
  privacy: {
    findings: number;
    counts: Partial<Record<PiiKind, number>>;
    manualPseudonymizations: number;
    keptRanges: number;
    annotations: PublicPrivacyAnnotation[];
    reversibleLocally: true;
    // The user saw the preview (doubtful OCR lines, local AI hints) and confirmed it. false: not
    // yet, and the document never reaches a model outside the computer. Absent: processed
    // before the preview was required.
    reviewed?: boolean;
  };
};

export interface DocumentService {
  ingestPdf(
    data: Uint8Array,
    security?: DocumentSecurityContext
  ): Promise<PublicDocumentIngestion>;
  ingestImage(
    data: Uint8Array,
    mediaType: SupportedImageMediaType,
    security?: DocumentSecurityContext
  ): Promise<PublicDocumentIngestion>;
  review(
    data: Uint8Array,
    mediaType: SupportedDocumentMediaType,
    security?: DocumentSecurityContext
  ): Promise<PublicDocumentReview>;
  finalizeReview(
    documentId: string,
    directives: PagePrivacyDirective[],
    security?: DocumentSecurityContext,
    reviewed?: boolean
  ): Promise<PublicDocumentIngestion>;
  markReviewed?(documentId: string, security: DocumentSecurityContext): Promise<AnonymizedVersion>;
  detect?(documentId: string, security?: DocumentSecurityContext): Promise<PublicDocumentReview>;
  correct?(documentId: string, security?: DocumentSecurityContext): Promise<PublicDocumentReview>;
  pageScan?(documentId: string, pageNumber: number, security?: DocumentSecurityContext): Promise<PageScan | null>;
  editPage?(
    documentId: string,
    pageNumber: number,
    text: string,
    security?: DocumentSecurityContext
  ): Promise<{ page: PublicDocumentReview["pages"][number]; suggestions: PublicPrivacySuggestion[] }>;
  resolveProtectedChunks(
    selection: DocumentChunkSelection,
    options?: { images?: EvidencePolicy; remote?: boolean }
  ): Promise<ResolvedDocumentAttachment>;
  restoreDocument?(args: {
    caseId: string;
    documentId: string;
    caseDataKey: Buffer;
    keyVersion: number;
  }): Promise<PublicDocumentIngestion>;
  deanonymize?(
    documentId: string,
    text: string
  ): string;
  privacyKey?(documentId: string): PrivacyKeyEntry[];
  restoreText?(documentId: string, text: string): { text: string; count: number; unresolved: string[] };
  usesSharedKey?(documentId: string): boolean;
  joinSharedKey?(
    documentId: string,
    security: DocumentSecurityContext
  ): Promise<AnonymizedVersion & { remapped: number }>;
  sharedKeyState?(args: {
    caseId: string;
    caseDataKey: Buffer;
    keyVersion: number;
  }): Promise<{ snapshot: PseudonymizationVaultSnapshot; members: Set<string> } | null>;
  anonymizedVersion?(documentId: string): AnonymizedVersion;
  anonymizedDocxPlan?(documentId: string): DocxAnonymizationPlan;
  addProtection?(
    documentId: string,
    text: string,
    kind: PiiKind,
    security: DocumentSecurityContext
  ): Promise<AnonymizedVersion & { token: string; replaced: number }>;
  removeProtection?(
    documentId: string,
    token: string,
    security: DocumentSecurityContext
  ): Promise<AnonymizedVersion & { restored: number }>;
  editProtectedText?(
    documentId: string,
    chunkIndex: number,
    text: string,
    security: DocumentSecurityContext
  ): Promise<AnonymizedVersion>;
  updateKeyGrammar?(
    documentId: string,
    token: string,
    grammar: KeyGrammar,
    security: DocumentSecurityContext
  ): Promise<AnonymizedVersion>;
  updateKeyForms?(
    documentId: string,
    token: string,
    forms: Partial<Record<PersonCase, string>>,
    security: DocumentSecurityContext
  ): Promise<AnonymizedVersion>;
}

type PrivateDocumentRecord = {
  mediaType: SupportedDocumentMediaType;
  caseId?: string;
  vault: PseudonymizationVault;
  source: DocumentIngestionResult;
  protectedChunks?: PublicDocumentChunk[];
  // The stored anonymized version, kept whole so edits can be saved back.
  protectedIngestion?: PublicDocumentIngestion;
  // Uses the case's shared key (one symbol per entity across the case).
  sharedKey?: boolean;
  // "z lokalnym AI": the local model's findings per page text, from the
  // review, so saving the document does not run the model a second time.
  localAi?: boolean;
  aiFindings?: Map<string, PiiSpan[]>;
  // Read without the vision model: the OCR with its line images, before the doubtful lines
  // were marked, kept in memory only until the user's choice (correct()) or confirmation.
  visionPending?: DocumentIngestionResult;
};

/**
 * Tekst w postaci NFC ("ó" jako jeden znak, nie "o" + znak łączący, jak w
 * tekście z macOS lub z części PDF-ów): bez tego znane wartości z klucza,
 * słownik i granice słów nie trafiają w zapis rozłożony.
 */
export function nfcIngestion(source: DocumentIngestionResult): DocumentIngestionResult {
  const nfc = (text: string) => text.normalize("NFC");
  const changed = (text: string) => nfc(text) !== text;
  if (
    !source.pages.some((page) => changed(page.text) || page.lines?.some((line) => changed(line.text))) &&
    !source.chunks.some((chunk) => changed(chunk.text))
  ) {
    return source;
  }
  return {
    ...source,
    pages: source.pages.map((page) => ({
      ...page,
      text: nfc(page.text),
      ...(page.lines ? { lines: page.lines.map((line) => ({ ...line, text: nfc(line.text) })) } : {})
    })),
    chunks: source.chunks.map((chunk) => ({ ...chunk, text: nfc(chunk.text) }))
  };
}

function withAiMemory(
  recognizer: NamedEntityRecognizer,
  memory: Map<string, PiiSpan[]> | undefined
): NamedEntityRecognizer {
  return memory ? rememberingRecognizer(recognizer, memory) : recognizer;
}

/** The recognizer, also collecting the matches the local model read as no person in `text`. */
function collectingAiHints(inner: NamedEntityRecognizer, text: string, hints: PiiSpan[]): NamedEntityRecognizer {
  return {
    recognize: async (input: string) => {
      const found = await inner.recognize(input);
      if (input === text) hints.push(...found.filter((span) => span.aiNotPerson));
      return found;
    }
  };
}

function suggestionOf(
  page: number,
  finding: { start: number; end: number; kind: PiiKind; firm?: "REGISTRY" | "TEXT"; uncertain?: string },
  hints: PiiSpan[]
): PublicPrivacySuggestion {
  const hint = hints.find((span) => span.start < finding.end && span.end > finding.start);
  return {
    page,
    start: finding.start,
    end: finding.end,
    kind: finding.kind,
    ...(finding.firm ? { firm: finding.firm } : {}),
    ...(hint ? { aiNotPerson: hint.aiNotPerson } : {}),
    ...(finding.uncertain && !hint ? { uncertain: finding.uncertain } : {})
  };
}

/** Reuses the local-AI findings of a page already checked during the review. */
function rememberingRecognizer(
  inner: NamedEntityRecognizer,
  memory: Map<string, PiiSpan[]>
): NamedEntityRecognizer {
  return {
    recognize: async (text: string) => {
      const known = memory.get(text);
      if (known) return known.map((span) => ({ ...span }));
      const found = await inner.recognize(text);
      memory.set(text, found.map((span) => ({ ...span })));
      return found;
    }
  };
}

export class LocalPrivateDocumentService
implements DocumentService {
  private readonly documents =
    new Map<string, PrivateDocumentRecord>();
  private readonly detecting =
    new Map<string, Promise<PublicDocumentReview>>();

  constructor(
    private readonly pdfIngestor: CompleteDocumentIngestor,
    private readonly namedEntities: NamedEntityRecognizer,
    private readonly maxChunkChars = 24_000,
    private readonly imageIngestor?: CompleteImageIngestor,
    private readonly privacyVaultStore?: Pick<
      EncryptedPrivacyVaultStore,
      "loadDocumentVault" |
      "saveDocumentVault"
    > &
      Partial<Pick<EncryptedPrivacyVaultStore, "withSharedVault" | "sharedMembers" | "sharedState">>,
    private readonly secureDocumentStore?: Pick<
      SecureCaseDocumentStore,
      | "saveSource"
      | "saveProtected"
      | "loadSource"
      | "loadProtected"
    >,
    private readonly officeExtractor?:
      OfficeDocumentTextExtractor,
    private readonly spreadsheetExtractor?:
      SpreadsheetTextExtractor,
    // One token per person and inflected restore ([PII:PERSON:0001|GEN]).
    private readonly personMorphology?:
      PersonMorphology,
    // Masks personal data on scanned pages sent to a model as evidence.
    private readonly pageMasker?: PageImageMasker,
    // Firm name, address and representatives from the VAT white list and KRS for a NIP/KRS in the document.
    private readonly registryForms?: RegistryFormsProvider,
    // The local vision model for doubtful OCR lines, when installed (null otherwise).
    private readonly visionReader?: () => { readLine: ReadLine; stop(): void; modelBytes: number } | null,
    // The vision step: text models (Bielik) are stopped so the vision model has the memory.
    private readonly stopTextModels?: () => Promise<void>,
    // "z lokalnym AI": the text model is started right before the detection of personal data.
    private readonly startTextModels?: () => Promise<void>,
    // Recordings (audio, video): the local speech-to-text model writes the text.
    private readonly transcriber?: RecordingTranscriber,
    // The vision step holds the local text model exclusively (LocalModelRuntime.withExclusiveModel).
    private readonly exclusiveTextModels?: <T>(fn: () => Promise<T>, fallback: () => T) => Promise<T>
  ) {}

  /**
   * A recording as a document: one page per 10 minutes, each line with the time it starts.
   * The pages are DIGITAL text (no scan to compare), so the privacy review works as for a letter.
   */
  private async transcribe(data: Uint8Array, mediaType: RecordingMediaType, onProgress?: ProgressReporter, speakers?: number): Promise<DocumentIngestionResult> {
    if (!this.transcriber) throw new Error("TRANSCRIPTION_UNAVAILABLE");
    if (!this.transcriber.available()) throw new Error("TRANSCRIPTION_MODEL_MISSING");
    onProgress?.({ stage: "TRANSCRIPTION", done: 0, total: 0 });
    const transcript = await this.transcriber.transcribe(
      data,
      mediaType,
      (done, total) => onProgress?.({ stage: "TRANSCRIPTION", done, total }),
      ...(speakers !== undefined ? [{ speakers }] : [])
    );
    const pages: IngestedPage[] = transcriptPages(transcript).map((page) => ({
      page: page.page,
      text: page.text,
      source: page.text.trim() ? ("DIGITAL" as const) : ("BLANK" as const)
    }));
    const sourceChars = pages.reduce((sum, page) => sum + page.text.length, 0);
    return {
      complete: true,
      sha256: createHash("sha256").update(data).digest("hex"),
      bytes: data.byteLength,
      totalPages: pages.length,
      digitalPages: pages.filter((page) => page.source === "DIGITAL").length,
      ocrPages: 0,
      blankPages: pages.filter((page) => page.source === "BLANK").length,
      sourceChars,
      pages,
      chunks: chunkDocumentPages(pages, this.maxChunkChars)
    };
  }

  private digitalTextResult(
    data: Uint8Array,
    text: string
  ): DocumentIngestionResult {
    if (
      data.byteLength >
        64 * 1024 * 1024 ||
      text.length >
        100_000_000
    ) {
      throw new Error(
        "DOCUMENT_TEXT_LIMIT_EXCEEDED"
      );
    }
    const page = {
      page: 1,
      text,
      source:
        text.trim()
          ? "DIGITAL" as const
          : "BLANK" as const
    };
    const pages:
      IngestedPage[] = [
        page
      ];
    return {
      complete: true,
      sha256:
        createHash("sha256")
          .update(data)
          .digest("hex"),
      bytes:
        data.byteLength,
      totalPages: 1,
      digitalPages:
        page.source ===
          "DIGITAL"
          ? 1
          : 0,
      ocrPages: 0,
      blankPages:
        page.source ===
          "BLANK"
          ? 1
          : 0,
      sourceChars:
        text.length,
      pages,
      chunks:
        chunkDocumentPages(
          pages,
          this.maxChunkChars
        )
    };
  }

  private async extract(
    data: Uint8Array,
    mediaType: SupportedDocumentMediaType,
    onProgress?: ProgressReporter,
    speakers?: number
  ): Promise<DocumentIngestionResult> {
    if (mediaType === "application/pdf") {
      return this.pdfIngestor.ingest(data, onProgress);
    }
    if (isRecordingMediaType(mediaType)) {
      return this.transcribe(data, mediaType, onProgress, speakers);
    }
    if (
      mediaType ===
        "text/plain" ||
      mediaType ===
        "text/markdown"
    ) {
      return this.digitalTextResult(
        data,
        decodePlainText(data)
      );
    }
    if (
      mediaType ===
        XLSX_MEDIA_TYPE ||
      mediaType ===
        XLSM_MEDIA_TYPE ||
      mediaType ===
        CSV_MEDIA_TYPE ||
      mediaType ===
        TSV_MEDIA_TYPE
    ) {
      if (!this.spreadsheetExtractor) {
        throw new Error(
          "SPREADSHEET_EXTRACTOR_UNAVAILABLE"
        );
      }
      return this.digitalTextResult(
        data,
        await this.spreadsheetExtractor
          .extract(
            data,
            mediaType as
              SpreadsheetMediaType
          )
      );
    }
    if (
      mediaType ===
        DOCX_MEDIA_TYPE ||
      mediaType ===
        ODT_MEDIA_TYPE ||
      mediaType === EML_MEDIA_TYPE ||
      mediaType === RTF_MEDIA_TYPE
    ) {
      if (!this.officeExtractor) {
        throw new Error(
          "OFFICE_DOCUMENT_EXTRACTOR_UNAVAILABLE"
        );
      }
      return this.digitalTextResult(
        data,
        await this.officeExtractor
          .extract(
            data,
            mediaType as
              OfficeDocumentMediaType
          )
      );
    }
    if (!this.imageIngestor) {
      throw new Error("IMAGE_OCR_UNAVAILABLE");
    }
    onProgress?.({ stage: "OCR", done: 0, total: 1, page: 1 });
    const image = await this.imageIngestor.ingest(
      data,
      mediaType
    );
    onProgress?.({ stage: "OCR", done: 1, total: 1 });
    return image;
  }

  async review(
    data: Uint8Array,
    mediaType: SupportedDocumentMediaType,
    security?: DocumentSecurityContext
  ): Promise<PublicDocumentReview> {
    return security?.background
      ? documentWork.background(() => this.reviewNow(data, mediaType, security))
      : this.reviewNow(data, mediaType, security);
  }

  /**
   * The reading stored for this exact file in this case (the document id comes from the file's
   * SHA-256), or null. Not used when the vision model was asked to correct the OCR now.
   */
  private async storedReading(
    data: Uint8Array,
    security?: DocumentSecurityContext
  ): Promise<{ documentId: string; source: DocumentIngestionResult } | null> {
    if (!this.secureDocumentStore || !security?.caseId || shouldCorrectOcr(security)) return null;
    const sha256 = createHash("sha256").update(data).digest("hex");
    const documentId = `doc_${sha256.slice(0, 24)}`;
    const load = (caseDataKey: Buffer, keyVersion: number) =>
      this.secureDocumentStore!.loadSource({ caseId: security.caseId!, documentId, caseDataKey, keyVersion });
    try {
      let stored: { source: DocumentIngestionResult } | undefined;
      if (security.caseDataKey && Number.isInteger(security.keyVersion)) {
        stored = await load(security.caseDataKey, security.keyVersion!);
      } else if (security.storeUnderLock) {
        await security.storeUnderLock(async ({ caseDataKey, keyVersion }) => {
          stored = await load(caseDataKey, keyVersion);
        });
      }
      return stored && stored.source.sha256 === sha256 && stored.source.complete ? { documentId, source: stored.source } : null;
    } catch {
      // Not read before (or unreadable): read it now.
      return null;
    }
  }

  private async reviewNow(
    data: Uint8Array,
    mediaType: SupportedDocumentMediaType,
    security?: DocumentSecurityContext
  ): Promise<PublicDocumentReview> {
    const onProgress = security?.onProgress;
    onProgress?.({ stage: "READING" });
    // The same file read before in this case (a retry, the file added again, a password typed
    // after the first attempt): its stored reading is used, no second OCR or transcription.
    const cached = security?.speakers !== undefined ? null : await this.storedReading(data, security);
    if (cached) {
      const vault = new PseudonymizationVault();
      this.documents.set(cached.documentId, {
        mediaType,
        ...(security?.localAi ? { localAi: true, aiFindings: new Map<string, PiiSpan[]>() } : {}),
        ...(security?.caseId ? { caseId: security.caseId } : {}),
        vault,
        source: cached.source
      });
      if (security?.detect === false) return this.publicReview(cached.documentId, mediaType, cached.source, []);
      return this.detectSuggestions(cached.documentId, mediaType, cached.source, security);
    }
    const extracted = nfcIngestion(await this.extract(
      data,
      mediaType,
      onProgress,
      security?.speakers
    ));
    const spaced = await this.restoreSpacing(extracted);
    // Model-free cleanup on every OCR page (ligatures, look-alike letters, misread amounts;
    // each change kept in page.corrections), then, when asked for, the vision model on the
    // doubtful lines. Line images live only for that step; never kept with the document.
    const cleaned = normalizedOcr(spaced, this.maxChunkChars);
    const correctNow = shouldCorrectOcr(security);
    // Read now, decided later: the vision model may still be chosen (correct()).
    const visionPending = !correctNow && security?.detect === false && hasLineCrops(cleaned) ? cleaned : undefined;
    // The vision step stops the text model: in a background read it waits for the user's work.
    const read = withoutCrops(
      correctNow
        ? security?.background
          ? await documentWork.foreground(() => this.readWithVision(cleaned, onProgress))
          : await this.readWithVision(cleaned, onProgress)
        : cleaned
    );
    // Lines to check against the scan, marked after the corrections (which rebuild the text).
    const source = await this.markReview(read);
    const documentId =
      `doc_${source.sha256.slice(0, 24)}`;

    const persistentDocument =
      Boolean(
        this.secureDocumentStore &&
        security?.caseId
      );
    if (persistentDocument && security?.storeUnderLock) {
      await security.storeUnderLock(async ({ caseDataKey, keyVersion }) =>
        this.secureDocumentStore!.saveSource({ caseId: security.caseId, documentId, mediaType, source, caseDataKey, keyVersion })
      );
    } else if (persistentDocument) {
      if (
        !security?.caseDataKey ||
        !Number.isInteger(
          security.keyVersion
        ) ||
        (security.keyVersion ?? 0) <
          1
      ) {
        throw new Error(
          "DOCUMENT_STORAGE_CONTEXT_REQUIRED"
        );
      }
      await this
        .secureDocumentStore!
        .saveSource({
          caseId:
            security.caseId,
          documentId,
          mediaType,
          source,
          caseDataKey:
            security.caseDataKey,
          keyVersion:
            security.keyVersion!
        });
    }

    const vault = new PseudonymizationVault();
    this.documents.set(documentId, {
      mediaType,
      ...(security?.localAi ? { localAi: true, aiFindings: new Map<string, PiiSpan[]>() } : {}),
      ...(security?.caseId
        ? {
            caseId:
              security.caseId
          }
        : {}),
      vault,
      source,
      ...(visionPending ? { visionPending } : {})
    });

    // Several files: the OCR of all of them first (text models stopped for the vision
    // model), then the detection of personal data (text model started once).
    if (security?.detect === false) return this.publicReview(documentId, mediaType, source, []);
    return this.detectSuggestions(documentId, mediaType, source, security);
  }

  /**
   * Personal data in a document already read (review with detect: false). With "z lokalnym
   * AI" the text model is started first.
   */
  async detect(documentId: string, security?: DocumentSecurityContext): Promise<PublicDocumentReview> {
    const record = this.documents.get(documentId);
    if (!record) throw new Error("UNKNOWN_LOCAL_DOCUMENT");
    if (record.caseId && security?.caseId !== record.caseId) throw new Error("DOCUMENT_CASE_MISMATCH");
    if (security?.localAi && !record.aiFindings) {
      record.localAi = true;
      record.aiFindings = new Map<string, PiiSpan[]>();
    }
    // A retry after a dropped connection joins the check still running (or waiting for its
    // turn) for this document (the local model keeps working after the client is gone)
    // instead of starting a second one.
    const key = `${documentId}:${security?.localAi ? "ai" : "rules"}`;
    const running = this.detecting.get(key);
    if (running) return running;
    const run = documentWork
      .foreground(() => this.detectSuggestions(documentId, record.mediaType, record.source, security))
      .finally(() => this.detecting.delete(key));
    this.detecting.set(key, run);
    return run;
  }

  /**
   * The vision model's correction of a document read in the background, chosen by the user
   * afterwards ("z korektą AI"): the doubtful lines read again, then marked for the preview.
   * Without line images kept (no vision model when it was read, or already corrected) the
   * document stays as read.
   */
  async correct(documentId: string, security?: DocumentSecurityContext): Promise<PublicDocumentReview> {
    return documentWork.foreground(async () => {
      const record = this.documents.get(documentId);
      if (!record) throw new Error("UNKNOWN_LOCAL_DOCUMENT");
      if (record.caseId && security?.caseId !== record.caseId) throw new Error("DOCUMENT_CASE_MISMATCH");
      const pending = record.visionPending;
      if (!pending) return this.publicReview(documentId, record.mediaType, record.source, []);
      const corrected = await this.markReview(withoutCrops(await this.readWithVision(pending, security?.onProgress)));
      // A page the user already corrected by hand keeps the user's text.
      const pages = corrected.pages.map((page) => record.source.pages.find((item) => item.page === page.page && item.editedByUser) ?? page);
      const source: DocumentIngestionResult = {
        ...corrected,
        pages,
        sourceChars: pages.reduce((sum, page) => sum + page.text.length, 0),
        chunks: chunkDocumentPages(pages, this.maxChunkChars)
      };
      if (this.secureDocumentStore && record.caseId) {
        if (!security?.caseDataKey || !Number.isInteger(security.keyVersion) || (security.keyVersion ?? 0) < 1) {
          throw new Error("DOCUMENT_STORAGE_CONTEXT_REQUIRED");
        }
        await this.secureDocumentStore.saveSource({
          caseId: record.caseId,
          documentId,
          mediaType: record.mediaType,
          source,
          caseDataKey: security.caseDataKey,
          keyVersion: security.keyVersion!
        });
      }
      record.source = source;
      delete record.visionPending;
      return this.publicReview(documentId, record.mediaType, source, []);
    });
  }

  private async detectSuggestions(
    documentId: string,
    mediaType: SupportedDocumentMediaType,
    source: DocumentIngestionResult,
    security?: DocumentSecurityContext
  ): Promise<PublicDocumentReview> {
    const onProgress = security?.onProgress;
    if (security?.localAi && this.startTextModels) {
      onProgress?.({ stage: "AI_CHECK", done: 0, total: 0, item: "uruchamianie modelu lokalnego do anonimizacji" });
      await this.startTextModels();
    }
    const suggestionVault =
      new PseudonymizationVault();
    const suggestions: PublicPrivacySuggestion[] = [];

    // Jak przy zatwierdzeniu: przy kilku stronach pierwszy przebieg zbiera osoby i firmy
    // ze wszystkich stron, żeby propozycja na s. 1 obejmowała też nazwę znalezioną na s. 3.
    const passes = source.pages.length > 1 ? 2 : 1;
    for (let pass = 1; pass <= passes; pass += 1)
    for (const [index, page] of source.pages.entries()) {
      onProgress?.({ stage: "DETECTING", done: index, total: source.pages.length, page: page.page });
      const hints: PiiSpan[] = [];
      const preview =
        await new LocalPolishPseudonymizer(
          suggestionVault,
          collectingAiHints(withAiMemory(privacyRecognizerFor(
            this.namedEntities,
            page.source === "OCR",
            security?.localAi
              ? {
                  onCheck: (item, done, total) =>
                    onProgress?.({ stage: "AI_CHECK", done, total, item: `s. ${page.page}: ${item}`.slice(0, 160) })
                }
              : undefined
          ), this.documents.get(documentId)?.aiFindings), page.text, hints),
          this.personMorphology,
          this.registryForms
        ).pseudonymize(
          page.text
        );
      if (pass < passes) continue;
      for (const finding of preview.findings) {
        suggestions.push(suggestionOf(page.page, finding, hints));
      }
    }

    const down = degradedRecognizers();
    const health = source.pages.flatMap((page) =>
      detectHealthData(page.text)
        .filter((item) => !suggestions.some((suggestion) => suggestion.page === page.page && suggestion.start < item.end && item.start < suggestion.end))
        .map((item) => ({ page: page.page, start: item.start, end: item.end }))
    );
    return {
      ...this.publicReview(documentId, mediaType, source, suggestions),
      ...(down.length ? { recognizerWarnings: down } : {}),
      ...(health.length ? { healthData: health } : {})
    };
  }

  private publicReview(
    documentId: string,
    mediaType: SupportedDocumentMediaType,
    source: DocumentIngestionResult,
    suggestions: PublicPrivacySuggestion[]
  ): PublicDocumentReview {
    return {
      documentId,
      mediaType,
      complete: true,
      totalPages: source.totalPages,
      pages: source.pages.map((page) => ({
        page: page.page,
        text: page.text,
        source: page.source,
        ...(page.confidence !== undefined
          ? { confidence: page.confidence }
          : {}),
        ...(page.engine
          ? { engine: page.engine }
          : {}),
        ...(page.corrections?.length
          ? { corrections: page.corrections }
          : {}),
        ...(page.review?.length
          ? { review: page.review }
          : {})
      })),
      suggestions
    };
  }

  /**
   * The user's own correction of a page's text (a poor scan the OCR got wrong). The page
   * text of the document is replaced (also in the case's encrypted store) and personal
   * data on that page detected again; the review's earlier offsets for it no longer hold.
   */
  /**
   * The page as scanned, for the user's own view next to the text (local only, nothing goes
   * to a model). A case document not open in this session is read from the case store.
   */
  async pageScan(documentId: string, pageNumber: number, security?: DocumentSecurityContext): Promise<PageScan | null> {
    const record = this.documents.get(documentId);
    let pages: IngestedPage[];
    if (record) {
      if (record.caseId && security?.caseId !== record.caseId) throw new Error("DOCUMENT_VAULT_CONTEXT_REQUIRED");
      pages = record.source.pages;
    } else {
      if (!this.secureDocumentStore || !security?.caseDataKey || !Number.isInteger(security.keyVersion)) {
        throw new Error("UNKNOWN_LOCAL_DOCUMENT");
      }
      const stored = await this.secureDocumentStore.loadSource({
        caseId: security.caseId,
        documentId,
        caseDataKey: security.caseDataKey,
        keyVersion: security.keyVersion!
      });
      pages = stored.source.pages;
    }
    const page = pages.find((item) => item.page === pageNumber);
    if (!page) throw new Error("INVALID_DOCUMENT_PAGE");
    const image = page.image ?? page.scan;
    if (!image) return null;
    return {
      page: page.page,
      mediaType: "image/jpeg",
      data: image.jpeg,
      width: image.width,
      height: image.height,
      lines: page.editedByUser
        ? []
        : (page.lines ?? []).map((line) => ({ text: line.text, box: line.box ?? null, ...(line.poly ? { poly: line.poly } : {}) }))
    };
  }

  async editPage(
    documentId: string,
    pageNumber: number,
    text: string,
    security?: DocumentSecurityContext
  ): Promise<{ page: PublicDocumentReview["pages"][number]; suggestions: PublicPrivacySuggestion[] }> {
    return documentWork.foreground(() => this.editPageNow(documentId, pageNumber, text, security));
  }

  private async editPageNow(
    documentId: string,
    pageNumber: number,
    text: string,
    security?: DocumentSecurityContext
  ): Promise<{ page: PublicDocumentReview["pages"][number]; suggestions: PublicPrivacySuggestion[] }> {
    const record = this.documents.get(documentId);
    if (!record) throw new Error("UNKNOWN_LOCAL_DOCUMENT");
    // Dokument sprawy edytuje tylko ktoś z dostępem do TEJ sprawy (i jej kluczem): inaczej
    // dostęp do własnej sprawy wystarczałby, by nadpisać źródło dokumentu cudzej sprawy.
    if (record.caseId && security?.caseId !== record.caseId) {
      throw new Error("DOCUMENT_VAULT_CONTEXT_REQUIRED");
    }
    const index = record.source.pages.findIndex((item) => item.page === pageNumber);
    if (index < 0) throw new Error("INVALID_DOCUMENT_PAGE");
    const clean = text.replace(/\u0000/g, "").replace(/\r\n?/g, "\n");
    if (clean.length > MAX_EDITED_PAGE_CHARS) throw new Error("DOCUMENT_PAGE_TEXT_TOO_LONG");
    // The page image goes with the OCR lines: masking needs the line boxes, and a hand-edited
    // text no longer matches the image, so the image could only be sent unmasked.
    const { lines: _lines, corrections: _corrections, image, ...previous } = record.source.pages[index]!;
    const scan = image ?? previous.scan;
    const page: IngestedPage = { ...previous, text: clean, editedByUser: true, ...(scan ? { scan } : {}) };
    const pages = record.source.pages.map((item, at) => (at === index ? page : item));
    const source: DocumentIngestionResult = {
      ...record.source,
      pages,
      sourceChars: pages.reduce((sum, item) => sum + item.text.length, 0),
      chunks: chunkDocumentPages(pages, this.maxChunkChars)
    };
    if (this.secureDocumentStore && record.caseId) {
      if (!security?.caseDataKey || !Number.isInteger(security.keyVersion) || (security.keyVersion ?? 0) < 1) {
        throw new Error("DOCUMENT_STORAGE_CONTEXT_REQUIRED");
      }
      await this.secureDocumentStore.saveSource({
        caseId: record.caseId,
        documentId,
        mediaType: record.mediaType,
        source,
        caseDataKey: security.caseDataKey,
        keyVersion: security.keyVersion!
      });
    }
    record.source = source;
    const hints: PiiSpan[] = [];
    const preview = await new LocalPolishPseudonymizer(
      new PseudonymizationVault(),
      collectingAiHints(withAiMemory(privacyRecognizerFor(this.namedEntities, page.source === "OCR"), record.aiFindings), clean, hints),
      this.personMorphology,
      this.registryForms
    ).pseudonymize(clean);
    return {
      page: {
        page: page.page,
        text: page.text,
        source: page.source,
        ...(page.confidence !== undefined ? { confidence: page.confidence } : {}),
        ...(page.engine ? { engine: page.engine } : {}),
        editedByUser: true
      },
      suggestions: preview.findings.map((finding) => suggestionOf(page.page, finding, hints))
    };
  }

  /** OCR pages through the local model's correction (original words kept). */
  /** Spaces PaddleOCR dropped ("ul.Pukowca15", "ipodlega"), without a model, on every OCR page. */
  private async restoreSpacing(source: DocumentIngestionResult): Promise<DocumentIngestionResult> {
    const morphology = this.personMorphology;
    if (!morphology?.knownWords || !source.pages.some((page) => page.source === "OCR" && page.lines?.length)) {
      return source;
    }
    const known = (words: string[]) => morphology.knownWords!(words);
    let pages: IngestedPage[];
    try {
      pages = await Promise.all(source.pages.map((page) => restoreOcrSpacing(page, known)));
    } catch (error) {
      process.stderr.write(`OCR_SPACING_DEGRADED:${error instanceof Error ? error.message : String(error)}\n`);
      return source;
    }
    if (pages.every((page, index) => page === source.pages[index])) return source;
    return {
      ...source,
      pages,
      sourceChars: pages.reduce((sum, page) => sum + page.text.length, 0),
      chunks: chunkDocumentPages(pages, this.maxChunkChars)
    };
  }

  /** Doubtful OCR lines read again by the local vision model, through the arbiter (ocr-vision.ts). */
  private async readWithVision(
    source: DocumentIngestionResult,
    onProgress?: ProgressReporter
  ): Promise<DocumentIngestionResult> {
    const morphology = this.personMorphology;
    if (!morphology?.knownWords || !source.pages.some((page) => page.source === "OCR" && page.lines?.some((line) => line.crop))) {
      return source;
    }
    if (!this.visionReader) return source;
    const visionReader = this.visionReader;
    const run = async (): Promise<DocumentIngestionResult> => {
      // The text model is started again only for the detection of personal data.
      if (this.stopTextModels) {
        try {
          await this.stopTextModels();
        } catch (error) {
          process.stderr.write(`TEXT_MODEL_STOP_FAILED:${error instanceof Error ? error.message : String(error)}\n`);
        }
      }
      const session = visionReader();
      if (!session) return source;
      if (!enoughMemoryForVision(session.modelBytes)) {
        process.stderr.write("VISION_OCR_SKIPPED:LOW_MEMORY\n");
        onProgress?.({ stage: "AI_CHECK", done: 0, total: 0, item: "model wizyjny pominięty: za mało wolnej pamięci" });
        return source;
      }
      let pages: IngestedPage[];
      try {
        pages = await correctWithVision(
          source.pages,
          session.readLine,
          (words) => morphology.knownWords!(words),
          (done, total) => onProgress?.({ stage: "AI_CHECK", done, total, item: "odczyt wątpliwych linii OCR (model wizyjny)" })
        );
      } catch (error) {
        process.stderr.write(`VISION_OCR_DEGRADED:${error instanceof Error ? error.message : String(error)}\n`);
        return source;
      } finally {
        session.stop();
      }
      if (pages.every((page, index) => page === source.pages[index])) return source;
      return {
        ...source,
        pages,
        sourceChars: pages.reduce((sum, page) => sum + page.text.length, 0),
        chunks: chunkDocumentPages(pages, this.maxChunkChars)
      };
    };
    // Held exclusively: running chat answers on the local model end first, new ones wait for
    // the vision step instead of losing the model in the middle of an answer.
    return this.exclusiveTextModels
      ? this.exclusiveTextModels(run, () => {
          process.stderr.write("VISION_OCR_SKIPPED:CHAT_ANSWER_RUNNING\n");
          return source;
        })
      : run();
  }

  /** Lines to check against the scan (handwriting, stamps): marked in the text and listed. */
  private async markReview(source: DocumentIngestionResult): Promise<DocumentIngestionResult> {
    const morphology = this.personMorphology;
    if (!morphology?.knownWords || !source.pages.some((page) => page.source === "OCR" && page.lines?.length)) {
      return source;
    }
    const known = (words: string[]) => morphology.knownWords!(words);
    let pages: IngestedPage[];
    try {
      pages = await Promise.all(source.pages.map((page) => markOcrReview(page, known)));
    } catch (error) {
      process.stderr.write(`OCR_REVIEW_DEGRADED:${error instanceof Error ? error.message : String(error)}\n`);
      return source;
    }
    if (pages.every((page, index) => page === source.pages[index])) return source;
    return {
      ...source,
      pages,
      sourceChars: pages.reduce((sum, page) => sum + page.text.length, 0),
      chunks: chunkDocumentPages(pages, this.maxChunkChars)
    };
  }

  async finalizeReview(
    documentId: string,
    directives: PagePrivacyDirective[],
    security?: DocumentSecurityContext,
    // Confirmed by the user in the preview (see privacy.reviewed).
    reviewed = false
  ): Promise<PublicDocumentIngestion> {
    return documentWork.foreground(() => this.finalizeReviewNow(documentId, directives, security, reviewed));
  }

  private async finalizeReviewNow(
    documentId: string,
    directives: PagePrivacyDirective[],
    security?: DocumentSecurityContext,
    reviewed = false
  ): Promise<PublicDocumentIngestion> {
    const record = this.documents.get(documentId);
    if (!record) {
      throw new Error("UNKNOWN_LOCAL_DOCUMENT");
    }
    // Confirmed as read: the line images are no longer needed.
    delete record.visionPending;
    // "z lokalnym AI": the vision step of another document may have stopped the text model.
    if (record.localAi && this.startTextModels) await this.startTextModels();

    for (const directive of directives) {
      if (
        !Number.isInteger(directive.page) ||
        directive.page < 1 ||
        directive.page > record.source.totalPages
      ) {
        throw new Error("INVALID_PRIVACY_DIRECTIVE_PAGE");
      }
    }

    const persistentVault =
      Boolean(
        this.privacyVaultStore &&
        record.caseId
      );

    if (persistentVault) {
      if (
        !security ||
        security.caseId !==
          record.caseId ||
        !security.caseDataKey ||
        !Number.isInteger(
          security.keyVersion
        ) ||
        (security.keyVersion ?? 0) <
          1
      ) {
        throw new Error(
          "DOCUMENT_VAULT_CONTEXT_REQUIRED"
        );
      }
    }

    const pages: IngestedPage[] = [];
    const counts: Partial<Record<PiiKind, number>> = {};
    const annotations: PublicPrivacyAnnotation[] = [];
    let findings = 0;
    let manualPseudonymizations = 0;
    let keptRanges = 0;

    const onProgress = security?.onProgress;
    // Wyniki rozpoznawania osób per strona: drugi przebieg ich nie liczy od nowa.
    const pageMemory = record.source.pages.map(() => new Map<string, PiiSpan[]>());
    const protectPage = (pageIndex: number, page: IngestedPage, pageDirectives: ManualPrivacyDirective[]) =>
      new LocalPolishPseudonymizer(
        record.vault,
        rememberingRecognizer(
          withAiMemory(privacyRecognizerFor(
            this.namedEntities,
            page.source === "OCR",
            record.localAi
              ? {
                  onCheck: (item, done, total) =>
                    onProgress?.({ stage: "AI_CHECK", done, total, item: `s. ${page.page}: ${item}`.slice(0, 160) })
                }
              : undefined
          ), record.aiFindings),
          pageMemory[pageIndex]!
        ),
        this.personMorphology,
        this.registryForms
      ).pseudonymize(page.text, pageDirectives);
    const directivesFor = (page: IngestedPage): ManualPrivacyDirective[] =>
      directives
        .filter((directive) => directive.page === page.page)
        .map(({ page: _page, ...directive }) => directive);
    const pseudonymizePages = async (): Promise<void> => {
    const multiPage = record.source.pages.length > 1;
    if (multiPage) {
      // Pierwszy przebieg zbiera do klucza osoby ze wszystkich stron, żeby
      // osoba rozpoznana dopiero na s. 3 była chroniona także na s. 1.
      for (const [pageIndex, page] of record.source.pages.entries()) {
        onProgress?.({ stage: "PSEUDONYMIZING", done: pageIndex, total: record.source.pages.length, page: page.page });
        await protectPage(pageIndex, page, directivesFor(page));
      }
    }
    for (const [pageIndex, page] of record.source.pages.entries()) {
      if (!multiPage) {
        onProgress?.({ stage: "PSEUDONYMIZING", done: pageIndex, total: record.source.pages.length, page: page.page });
      }
      const pageDirectives = directivesFor(page);

      const protectedPage = await protectPage(pageIndex, page, pageDirectives);
      findings += protectedPage.findings.length;
      manualPseudonymizations +=
        protectedPage.findings.filter(
          (item) => item.source === "USER"
        ).length;
      keptRanges +=
        protectedPage.keptRanges.length;

      for (
        const [kind, count] of Object.entries(
          protectedPage.counts
        ) as Array<[PiiKind, number]>
      ) {
        counts[kind] = (counts[kind] ?? 0) + count;
      }
      for (
        const annotation of
          protectedPage.annotations
      ) {
        annotations.push({
          page: page.page,
          ...annotation
        });
      }

      pages.push({
        ...page,
        text: protectedPage.text
      });
    }
    };

    // One key per case: the document is pseudonymized with the case's
    // shared key under the case lock, so a person keeps one symbol in all of
    // the case's documents. Without a store that supports it (tests, older
    // setups) the document keeps its own key.
    const sharedStore =
      persistentVault && this.privacyVaultStore!.withSharedVault
        ? this.privacyVaultStore!
        : undefined;
    if (sharedStore) {
      await sharedStore.withSharedVault!(
        { caseId: record.caseId!, caseDataKey: security!.caseDataKey!, keyVersion: security!.keyVersion! },
        documentId,
        async (vault) => {
          record.vault = vault;
          await pseudonymizePages();
        }
      );
      record.sharedKey = true;
    } else {
      if (persistentVault) {
        record.vault = await this.privacyVaultStore!.loadDocumentVault({
          caseId: record.caseId!,
          documentId,
          caseDataKey: security!.caseDataKey!,
          keyVersion: security!.keyVersion!
        });
      }
      await pseudonymizePages();
    }

    const chunks = chunkDocumentPages(
      pages,
      this.maxChunkChars
    );
    const pseudonymizedChars = pages.reduce(
      (sum, page) => sum + page.text.length,
      0
    );
    const publicChunks = chunks.map((chunk) => ({
      index: chunk.index,
      pageStart: chunk.pageStart,
      pageEnd: chunk.pageEnd,
      text: chunk.text
    }));
    record.protectedChunks = publicChunks;

    onProgress?.({ stage: "SAVING" });
    if (
      !sharedStore &&
      persistentVault &&
      security?.caseDataKey &&
      security.keyVersion &&
      record.caseId
    ) {
      await this
        .privacyVaultStore!
        .saveDocumentVault({
          caseId:
            record.caseId,
          documentId,
          vault:
            record.vault,
          caseDataKey:
            security.caseDataKey,
          keyVersion:
            security.keyVersion
        });
    }

    const result:
      PublicDocumentIngestion = {
        documentId,
        mediaType:
          record.mediaType,
        complete: true,
        totalPages:
          record.source.totalPages,
        digitalPages:
          record.source.digitalPages,
        ocrPages:
          record.source.ocrPages,
        blankPages:
          record.source.blankPages,
        sourceChars:
          record.source.sourceChars,
        pseudonymizedChars,
        chunks:
          publicChunks.map(
            (chunk) => ({
              ...chunk
            })
          ),
        privacy: {
          findings,
          counts,
          manualPseudonymizations,
          keptRanges,
          annotations,
          reversibleLocally: true,
          reviewed
        }
      };

    record.protectedIngestion = result;
    if (
      this.secureDocumentStore &&
      record.caseId
    ) {
      if (
        !security ||
        security.caseId !==
          record.caseId ||
        !security.caseDataKey ||
        !Number.isInteger(
          security.keyVersion
        ) ||
        (security.keyVersion ?? 0) <
          1
      ) {
        throw new Error(
          "DOCUMENT_STORAGE_CONTEXT_REQUIRED"
        );
      }
      await this
        .secureDocumentStore
        .saveProtected({
          caseId:
            record.caseId,
          documentId,
          ingestion:
            result,
          caseDataKey:
            security.caseDataKey,
          keyVersion:
            security.keyVersion!
        });
    }

    return result;
  }

  async ingestPdf(
    data: Uint8Array,
    security?: DocumentSecurityContext
  ): Promise<PublicDocumentIngestion> {
    const review = await this.review(
      data,
      "application/pdf",
      security
    );
    return this.finalizeReview(
      review.documentId,
      [],
      security
    );
  }

  async ingestImage(
    data: Uint8Array,
    mediaType: SupportedImageMediaType,
    security?: DocumentSecurityContext
  ): Promise<PublicDocumentIngestion> {
    const review = await this.review(
      data,
      mediaType,
      security
    );
    return this.finalizeReview(
      review.documentId,
      [],
      security
    );
  }

  async resolveProtectedChunks(
    selection: DocumentChunkSelection,
    // remote: for a model outside the computer, which never gets a document the user has not reviewed.
    options: { images?: EvidencePolicy; remote?: boolean } = {}
  ): Promise<ResolvedDocumentAttachment> {
    const record =
      this.documents.get(selection.documentId);
    if (!record) {
      throw new Error("UNKNOWN_LOCAL_DOCUMENT");
    }
    if (!record.protectedChunks) {
      throw new Error("DOCUMENT_NOT_FINALIZED");
    }
    if (options.remote && record.protectedIngestion?.privacy.reviewed === false) {
      throw new Error("DOCUMENT_NOT_REVIEWED");
    }

    const unique = [
      ...new Set(selection.chunkIndices)
    ].sort((a, b) => a - b);

    if (
      unique.length === 0 ||
      unique.length > 32 ||
      unique.some(
        (index) =>
          !Number.isInteger(index) ||
          index < 1
      )
    ) {
      throw new Error(
        "INVALID_DOCUMENT_CHUNK_SELECTION"
      );
    }

    const byIndex = new Map(
      record.protectedChunks.map(
        (chunk) => [chunk.index, chunk]
      )
    );
    const chunks = unique.map((index) => {
      const chunk = byIndex.get(index);
      if (!chunk) {
        throw new Error(
          "UNKNOWN_DOCUMENT_CHUNK"
        );
      }
      return { ...chunk };
    });

    const totalChars = chunks.reduce(
      (sum, chunk) => sum + chunk.text.length,
      0
    );
    if (totalChars > 160_000) {
      throw new Error(
        "DOCUMENT_ATTACHMENT_CONTEXT_TOO_LARGE"
      );
    }

    const images = options.images
      ? await this.evidenceImages(record, chunks, options.images)
      : [];
    return {
      documentId: selection.documentId,
      chunks,
      totalChars,
      grammar: placeholderGrammar(
        chunks.map((chunk) => chunk.text).join("\n"),
        record.vault
      ),
      totalPages: record.source.totalPages,
      ...(images.length ? { images } : {})
    };
  }

  /**
   * Pages of the chunks as images (photos by default, text pages on request),
   * with everything the
   * document's current key hides painted black (so key edits apply), plus
   * unreadable regions and badly read lines. A page that cannot be aligned
   * or masked is not sent.
   */
  private async evidenceImages(
    record: PrivateDocumentRecord,
    chunks: PublicDocumentChunk[],
    policy: EvidencePolicy
  ): Promise<EvidenceImage[]> {
    if (!this.pageMasker) return [];
    const wanted = new Set(chunks.flatMap((chunk) =>
      Array.from({ length: chunk.pageEnd - chunk.pageStart + 1 }, (_, offset) => chunk.pageStart + offset)
    ));
    const values = protectedValues(record.vault.snapshot().tokens);
    const images: EvidenceImage[] = [];
    for (const page of record.source.pages) {
      if (!wanted.has(page.page) || !page.image || !wantsImage(page, record.mediaType, policy)) continue;
      const boxes = maskBoxes(page, values);
      if (!boxes) continue;
      try {
        images.push({
          page: page.page,
          mediaType: "image/jpeg",
          data: await this.pageMasker.mask(page.image.jpeg, boxes),
          masked: boxes.length
        });
      } catch (error) {
        process.stderr.write(`EVIDENCE_IMAGE_SKIPPED:${error instanceof Error ? error.message : String(error)}\n`);
      }
    }
    return images;
  }

  async restoreDocument(args: {
    caseId: string;
    documentId: string;
    caseDataKey: Buffer;
    keyVersion: number;
  }): Promise<
    PublicDocumentIngestion
  > {
    if (
      !this.secureDocumentStore
    ) {
      throw new Error(
        "DOCUMENT_STORAGE_UNAVAILABLE"
      );
    }

    const source =
      await this
        .secureDocumentStore
        .loadSource(args);
    const protectedResult =
      await this
        .secureDocumentStore
        .loadProtected(args);

    if (
      protectedResult.mediaType !==
        source.mediaType
    ) {
      throw new Error(
        "DOCUMENT_STORAGE_MEDIA_TYPE_MISMATCH"
      );
    }

    let vault =
      new PseudonymizationVault();
    if (
      this.privacyVaultStore
    ) {
      vault =
        await this
          .privacyVaultStore
          .loadDocumentVault({
            caseId:
              args.caseId,
            documentId:
              args.documentId,
            caseDataKey:
              args.caseDataKey,
            keyVersion:
              args.keyVersion
          });
    }

    const sharedKey =
      Boolean(
        this.privacyVaultStore?.sharedMembers &&
        (await this.privacyVaultStore.sharedMembers({
          caseId: args.caseId,
          caseDataKey: args.caseDataKey,
          keyVersion: args.keyVersion
        })).has(args.documentId)
      );

    this.documents.set(
      args.documentId,
      {
        mediaType:
          source.mediaType,
        caseId:
          args.caseId,
        vault,
        sharedKey,
        source:
          nfcIngestion(source.source),
        protectedIngestion:
          protectedResult,
        protectedChunks:
          protectedResult
            .chunks
            .map(
              (chunk) => ({
                ...chunk
              })
            )
      }
    );
    return protectedResult;
  }

  deanonymize(
    documentId: string,
    text: string
  ): string {
    const record = this.documents.get(documentId);
    if (!record) {
      throw new Error("Unknown local document.");
    }
    return record.vault.deanonymize(text);
  }

  /**
   * The document's anonymization key: every token, the value it hides and
   * its case forms, with how often it occurs in the protected text. Needs
   * the document restored (restoreDocument) with the case key first.
   */
  privacyKey(documentId: string): PrivacyKeyEntry[] {
    const record = this.documents.get(documentId);
    if (!record || !record.protectedChunks) {
      throw new Error("UNKNOWN_LOCAL_DOCUMENT");
    }
    const counts = new Map<string, number>();
    for (const chunk of record.protectedChunks) {
      for (const match of chunk.text.matchAll(/\[PII:([A-Z_]+):(\d{4})(?:\|[A-Z]{2,4})?\]/g)) {
        const token = `[PII:${match[1]}:${match[2]}]`;
        counts.set(token, (counts.get(token) ?? 0) + 1);
      }
    }
    return record.vault
      .snapshot()
      .tokens.sort((a, b) => a.token.localeCompare(b.token, "en"))
      .map((item) => {
        const entity = item.entity;
        const forms = entity
          ? PERSON_CASES.map((personCase) => ({ case: personCase, text: entity.forms[personCase].text }))
          : undefined;
        return {
          token: item.token,
          kind: item.kind,
          value: entity?.canonical ?? item.value,
          ...(forms ? { forms } : {}),
          ...(item.kind === "PERSON" ? { gender: genderOf(record.vault, item.token) } : {}),
          ...(item.kind === "PERSON" && entity
            ? {
                entity: entity.type === "organization" ? "organization" as const : entity.number === "pl" ? "group" as const : "person" as const,
                ...(entity.legalForm ? { legalForm: entity.legalForm } : {})
              }
            : {}),
          occurrences: counts.get(item.token) ?? 0
        };
      })
      // A shared key also holds the case's other documents' entries.
      .filter((entry) => !record.sharedKey || entry.occurrences > 0);
  }

  private editableRecord(documentId: string): PrivateDocumentRecord & {
    protectedIngestion: PublicDocumentIngestion;
  } {
    const record = this.documents.get(documentId);
    if (!record || !record.protectedIngestion) {
      throw new Error("UNKNOWN_LOCAL_DOCUMENT");
    }
    return record as PrivateDocumentRecord & { protectedIngestion: PublicDocumentIngestion };
  }

  /** The case's shared key, to give chat the same symbols as the documents. */
  async sharedKeyState(args: {
    caseId: string;
    caseDataKey: Buffer;
    keyVersion: number;
  }): Promise<{ snapshot: PseudonymizationVaultSnapshot; members: Set<string> } | null> {
    return (await this.privacyVaultStore?.sharedState?.(args)) ?? null;
  }

  /** Whether a restored document uses the case's shared key. */
  usesSharedKey(documentId: string): boolean {
    return Boolean(this.documents.get(documentId)?.sharedKey);
  }

  /** Values of this document's key put back into any text (a file with its placeholders). */
  restoreText(documentId: string, text: string): { text: string; count: number; unresolved: string[] } {
    const record = this.documents.get(documentId);
    if (!record) throw new Error("UNKNOWN_LOCAL_DOCUMENT");
    const result = restoreWithReport(text, record.vault);
    return { text: result.text, count: result.restorations.length, unresolved: result.unresolved };
  }

  /** The anonymized version as stored: chunks with tokens, and its key. */
  anonymizedVersion(documentId: string): AnonymizedVersion {
    const record = this.editableRecord(documentId);
    const vault = record.vault;
    const surfaces = (token: string): string[] => {
      const entity = vault.entity(token);
      const value = vault.hasToken(token) ? vault.restore(token, null).text : "";
      return [
        ...new Set([
          value,
          ...(entity ? PERSON_CASES.map((personCase) => entity.forms[personCase].text) : [])
        ])
      ].filter(Boolean);
    };
    const fallback = (token: string): string =>
      vault.hasToken(token) ? vault.restore(token, "NOM").text : token;
    const chunks = record.protectedIngestion.chunks;
    return {
      documentId,
      totalPages: record.source.totalPages,
      chunks: chunks.map((chunk) => ({ ...chunk })),
      highlighted: chunks.map((chunk) => {
        const source = record.source.pages
          .filter((page) => page.page >= chunk.pageStart && page.page <= chunk.pageEnd)
          .map((page) => page.text)
          .join("\n");
        return {
          index: chunk.index,
          pageStart: chunk.pageStart,
          pageEnd: chunk.pageEnd,
          ...highlightProtected(chunk.text, source, surfaces, fallback)
        };
      }),
      entries: this.privacyKey(documentId),
      modelKey: modelKeyFor(chunks.map((chunk) => chunk.text), vault),
      ...(record.protectedIngestion.privacy.reviewed !== undefined ? { reviewed: record.protectedIngestion.privacy.reviewed } : {})
    };
  }

  /** What the anonymized .docx needs: the read text, the anonymized one, where each token stands, the key's values. */
  anonymizedDocxPlan(documentId: string): DocxAnonymizationPlan {
    const record = this.editableRecord(documentId);
    if (record.source.pages.length !== 1) throw new Error("DOCX_ANONYMIZED_UNSUPPORTED");
    const vault = record.vault;
    const surfaces = (token: string): string[] => {
      const entity = vault.entity(token);
      const value = vault.hasToken(token) ? vault.restore(token, null).text : "";
      return [...new Set([value, ...(entity ? PERSON_CASES.map((personCase) => entity.forms[personCase].text) : [])])].filter(Boolean);
    };
    const source = record.source.pages[0]!.text;
    const expected = protectedPageText(record.protectedIngestion.chunks);
    return {
      source,
      expected,
      replacements: alignProtected(source, expected, surfaces),
      values: vault.snapshot().tokens.flatMap((item) => surfaces(item.token).map((value): [string, string] => [value, item.token]))
    };
  }

  /** The user's confirmation of the anonymized version after its preview. */
  async markReviewed(documentId: string, security: DocumentSecurityContext): Promise<AnonymizedVersion> {
    const record = this.editableRecord(documentId);
    record.protectedIngestion = {
      ...record.protectedIngestion,
      privacy: { ...record.protectedIngestion.privacy, reviewed: true }
    };
    await this.persistEdit(documentId, record, security, false);
    return this.anonymizedVersion(documentId);
  }

  /**
   * Anonymizes one more value everywhere in the anonymized version: a person
   * or address in every case form, anything else verbatim. The version and
   * the key are saved together.
   */
  async addProtection(
    documentId: string,
    text: string,
    kind: PiiKind,
    security: DocumentSecurityContext
  ): Promise<AnonymizedVersion & { token: string; replaced: number }> {
    const record = this.editableRecord(documentId);
    const value = text.replace(/\s+/g, " ").trim();
    if (value.length < 2 || value.length > 300 || /\[|\]/.test(value)) {
      throw new Error("PRIVACY_EDIT_TEXT_INVALID");
    }
    let entity: PersonEntity | null | undefined;
    if (kind === "PERSON" && this.personMorphology) {
      [entity] = await this.personMorphology.analyze([value]);
    } else if (kind === "ADDRESS" && this.personMorphology?.analyzeAddresses) {
      [entity] = await this.personMorphology.analyzeAddresses([value]);
    }
    const { token, replaced } = await this.withKey(documentId, record, security, (vault) => {
      const known = new Set(vault.snapshot().tokens.map((item) => item.token));
      const token = vault.getOrCreate(kind, value, entity ?? undefined);
      const stored = vault.entity(token);
      const surfaces = [
        ...new Set([
          value,
          ...(stored ? PERSON_CASES.map((personCase) => stored.forms[personCase].text) : [])
        ])
      ].filter((surface) => surface.trim().length >= 2);
      let replaced = 0;
      const chunks = record.protectedIngestion.chunks.map((chunk) => {
        const result = replaceOutsideTokens(chunk.text, surfaces, token);
        replaced += result.count;
        return { ...chunk, text: result.text };
      });
      if (replaced === 0) {
        // Nothing matched: do not keep a new token that stands for nothing.
        if (!known.has(token)) vault.remove(token);
        throw new Error("PRIVACY_EDIT_TEXT_NOT_FOUND");
      }
      const privacy = record.protectedIngestion.privacy;
      this.replaceProtected(record, chunks, {
        ...privacy,
        findings: privacy.findings + replaced,
        manualPseudonymizations: privacy.manualPseudonymizations + replaced,
        counts: { ...privacy.counts, [kind]: (privacy.counts[kind] ?? 0) + replaced }
      });
      return { token, replaced };
    });
    return { ...this.anonymizedVersion(documentId), token, replaced };
  }

  /**
   * The user's correction of one fragment of the anonymized version (an OCR error, a
   * value the detection missed and the user rewrote by hand). Every symbol in the new
   * text must be one of this document's key: a symbol cannot be invented or mistyped,
   * since the model would then see a value nobody can restore.
   */
  async editProtectedText(
    documentId: string,
    chunkIndex: number,
    text: string,
    security: DocumentSecurityContext
  ): Promise<AnonymizedVersion> {
    const record = this.editableRecord(documentId);
    if (text.length > 200_000 || !text.trim()) throw new Error("PRIVACY_EDIT_TEXT_INVALID");
    if (!record.protectedIngestion.chunks.some((chunk) => chunk.index === chunkIndex)) {
      throw new Error("PRIVACY_EDIT_CHUNK_NOT_FOUND");
    }
    await this.withKey(documentId, record, security, (vault) => {
      for (const [token] of text.matchAll(/\[PII:[A-Z_]+:\d{4}(?:\|[A-Z]{2,4})?\]/g)) {
        if (!vault.hasToken(token.replace(/\|[A-Z]{2,4}\]$/, "]"))) throw new Error("PRIVACY_EDIT_UNKNOWN_TOKEN");
      }
      // A bracket that only looks like a symbol ("[PII:", "[PII:PERSON:12]") is a broken one.
      if (/\[PII:(?![A-Z_]+:\d{4}(?:\|[A-Z]{2,4})?\])/.test(text)) throw new Error("PRIVACY_EDIT_UNKNOWN_TOKEN");
      const chunks = record.protectedIngestion.chunks.map((chunk) =>
        chunk.index === chunkIndex ? { ...chunk, text } : chunk
      );
      const privacy = record.protectedIngestion.privacy;
      this.replaceProtected(record, chunks, privacy);
    });
    return this.anonymizedVersion(documentId);
  }

  /**
   * Takes a value out of the anonymization: every occurrence of the token
   * gets the value back (a person or address in the nominative, since the
   * stored text does not keep each occurrence's case). With a document's own
   * key the token leaves it; the case's shared key keeps it for the other
   * documents and this document's key simply no longer lists it.
   */
  async removeProtection(
    documentId: string,
    token: string,
    security: DocumentSecurityContext
  ): Promise<AnonymizedVersion & { restored: number }> {
    const record = this.editableRecord(documentId);
    if (!/^\[PII:[A-Z_]+:\d{4}\]$/.test(token)) throw new Error("PRIVACY_KEY_TOKEN_NOT_FOUND");
    const restored = await this.withKey(documentId, record, security, (vault) => {
      if (!vault.hasToken(token)) throw new Error("PRIVACY_KEY_TOKEN_NOT_FOUND");
      const value = vault.restore(token, "NOM").text;
      const kind = /^\[PII:([A-Z_]+):/.exec(token)![1] as PiiKind;
      const pattern = new RegExp(escapeRegExp(token.slice(0, -1)) + "(?:\\|[A-Z]{2,4})?\\]", "g");
      let restored = 0;
      const chunks = record.protectedIngestion.chunks.map((chunk) => ({
        ...chunk,
        text: chunk.text.replace(pattern, () => {
          restored += 1;
          return value;
        })
      }));
      if (!record.sharedKey) vault.remove(token);
      const privacy = record.protectedIngestion.privacy;
      this.replaceProtected(record, chunks, {
        ...privacy,
        findings: Math.max(0, privacy.findings - restored),
        counts: { ...privacy.counts, [kind]: Math.max(0, (privacy.counts[kind] ?? 0) - restored) }
      });
      return restored;
    });
    return { ...this.anonymizedVersion(documentId), restored };
  }

  /**
   * Moves a document with its own key onto the case's shared key without
   * re-running OCR: every token of its key is matched to the shared key (the
   * same person or value keeps one token case-wide, new ones get the next
   * free number) and the anonymized version is rewritten with those tokens.
   */
  async joinSharedKey(
    documentId: string,
    security: DocumentSecurityContext
  ): Promise<AnonymizedVersion & { remapped: number }> {
    const record = this.editableRecord(documentId);
    const store = this.privacyVaultStore;
    if (!store?.withSharedVault || !record.caseId) throw new Error("SHARED_KEY_UNAVAILABLE");
    if (record.sharedKey) return { ...this.anonymizedVersion(documentId), remapped: 0 };
    if (security.caseId !== record.caseId || !security.caseDataKey || !security.keyVersion) {
      throw new Error("DOCUMENT_STORAGE_CONTEXT_REQUIRED");
    }
    const own = record.vault.snapshot().tokens;
    let remapped = 0;
    await store.withSharedVault(
      { caseId: record.caseId, caseDataKey: security.caseDataKey, keyVersion: security.keyVersion },
      documentId,
      async (vault) => {
        const map = new Map<string, string>();
        for (const item of own) {
          map.set(item.token, vault.getOrCreate(item.kind, item.value, item.entity));
        }
        const chunks = record.protectedIngestion.chunks.map((chunk) => ({
          ...chunk,
          // One pass, so a remapped token is never remapped again.
          text: chunk.text.replace(
            /\[PII:([A-Z_]+):(\d{4})(\|[A-Z]{2,4})?\]/g,
            (match, kind: string, sequence: string, requestedCase?: string) => {
              const next = map.get(`[PII:${kind}:${sequence}]`);
              if (!next) return match;
              remapped += 1;
              return requestedCase ? next.slice(0, -1) + requestedCase + "]" : next;
            }
          )
        }));
        this.replaceProtected(record, chunks, record.protectedIngestion.privacy);
        record.vault = vault;
      }
    );
    record.sharedKey = true;
    await this.persistEdit(documentId, record, security, false);
    return { ...this.anonymizedVersion(documentId), remapped };
  }

  /** Corrects case forms of a person or address in the key (case-wide with a shared key). */
  async updateKeyForms(
    documentId: string,
    token: string,
    forms: Partial<Record<PersonCase, string>>,
    security: DocumentSecurityContext
  ): Promise<AnonymizedVersion> {
    const record = this.editableRecord(documentId);
    for (const value of Object.values(forms)) {
      if (typeof value !== "string" || value.length > 300 || /\[|\]/.test(value)) {
        throw new Error("PRIVACY_EDIT_TEXT_INVALID");
      }
    }
    await this.withKey(documentId, record, security, (vault) => {
      vault.updateForms(token, forms);
    });
    return this.anonymizedVersion(documentId);
  }

  /**
   * Sets what a person token is: a man or a woman (forms of that gender), a
   * family named together (plural forms), or a firm (never inflected). The
   * model's key and the restored forms follow.
   */
  async updateKeyGrammar(
    documentId: string,
    token: string,
    grammar: KeyGrammar,
    security: DocumentSecurityContext
  ): Promise<AnonymizedVersion> {
    const record = this.editableRecord(documentId);
    await this.withKey(documentId, record, security, async (vault) => {
      const current = vault.entity(token);
      if (!current) throw new Error("PRIVACY_KEY_ENTITY_NOT_FOUND");
      // The name as the key holds it: a firm as written, a person in the nominative.
      const name = current.canonical;
      if (grammar === "organization") {
        vault.setEntity(token, organizationEntity(name, current.legalForm));
        return;
      }
      const gender = grammar === "f" || grammar === "group-f" ? "f" as const : "m1" as const;
      const group = grammar.startsWith("group");
      const [analysed] = this.personMorphology
        ? await this.personMorphology.analyze([name], [{ genderHint: gender, numberHint: group ? "pl" as const : "sg" as const }])
        : [null];
      if (group && analysed?.number !== "pl") throw new Error("PRIVACY_KEY_GROUP_UNSUPPORTED");
      const { type: _type, legalForm: _legalForm, ...base } = current;
      vault.setEntity(
        token,
        analysed
          ? { ...analysed, status: "ok", genderAlternatives: [], warnings: analysed.warnings.filter((w) => w !== "GENDER_HEURISTIC") }
          : { ...base, gender, status: "ok", genderAlternatives: [], warnings: base.warnings.filter((w) => w !== "GENDER_HEURISTIC") }
      );
    });
    return this.anonymizedVersion(documentId);
  }

  /**
   * Runs a key change on the current key and saves it with the anonymized
   * version: the case's shared key is re-read under the case lock (another
   * document may have added entries since), a document's own key is edited
   * in place.
   */
  private async withKey<T>(
    documentId: string,
    record: PrivateDocumentRecord & { protectedIngestion: PublicDocumentIngestion },
    security: DocumentSecurityContext,
    change: (vault: PseudonymizationVault) => T | Promise<T>
  ): Promise<T> {
    const store = this.privacyVaultStore;
    if (record.sharedKey && store?.withSharedVault && record.caseId) {
      if (security.caseId !== record.caseId || !security.caseDataKey || !security.keyVersion) {
        throw new Error("DOCUMENT_STORAGE_CONTEXT_REQUIRED");
      }
      const result = await store.withSharedVault(
        { caseId: record.caseId, caseDataKey: security.caseDataKey, keyVersion: security.keyVersion },
        documentId,
        async (vault) => {
          const value = await change(vault);
          record.vault = vault;
          return value;
        }
      );
      await this.persistEdit(documentId, record, security, false);
      return result;
    }
    const result = await change(record.vault);
    await this.persistEdit(documentId, record, security, true);
    return result;
  }

  private replaceProtected(
    record: PrivateDocumentRecord & { protectedIngestion: PublicDocumentIngestion },
    chunks: PublicDocumentChunk[],
    privacy: PublicDocumentIngestion["privacy"]
  ): void {
    record.protectedIngestion = {
      ...record.protectedIngestion,
      chunks,
      pseudonymizedChars: chunks.reduce((sum, chunk) => sum + chunk.text.length, 0),
      privacy
    };
    record.protectedChunks = chunks.map((chunk) => ({ ...chunk }));
  }

  private async persistEdit(
    documentId: string,
    record: PrivateDocumentRecord & { protectedIngestion: PublicDocumentIngestion },
    security: DocumentSecurityContext,
    saveVault: boolean
  ): Promise<void> {
    if (!record.caseId) return;
    if (
      !this.secureDocumentStore ||
      !this.privacyVaultStore ||
      security.caseId !== record.caseId ||
      !security.caseDataKey ||
      !security.keyVersion
    ) {
      throw new Error("DOCUMENT_STORAGE_CONTEXT_REQUIRED");
    }
    const context = {
      caseId: record.caseId,
      documentId,
      caseDataKey: security.caseDataKey,
      keyVersion: security.keyVersion
    };
    // The key first: a version never refers to a token its key lacks.
    if (saveVault) await this.privacyVaultStore.saveDocumentVault({ ...context, vault: record.vault });
    await this.secureDocumentStore.saveProtected({ ...context, ingestion: record.protectedIngestion });
  }

  forget(documentId: string): boolean {
    return this.documents.delete(documentId);
  }
}
