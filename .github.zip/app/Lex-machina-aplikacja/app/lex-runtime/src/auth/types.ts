export type AppRole = "ADMIN" | "USER";

// PROFESSIONAL: cases, modes and the firm's tools. INDIVIDUAL: a private person's chat only, in the
// automatic mode, with conversations named from the question instead of cases.
export type AccountKind = "PROFESSIONAL" | "INDIVIDUAL";

export type CaseRole =
  | "OWNER"
  | "EDITOR"
  | "ANALYST"
  | "VIEWER";

export type LocalUserStatus =
  | "ACTIVE"
  | "DISABLED";

export type AssistantModelProvider =
  | "openai"
  | "anthropic"
  | "xai"
  | "google";

export type AuthKdfPolicy = {
  algorithm: "ARGON2ID";
  memoryKiB: number;
  iterations: number;
  parallelism: number;
  keyLength: number;
  version: number;
};

export type PublicLocalUser = {
  userId: string;
  loginName: string;
  displayName: string;
  appRole: AppRole;
  accountKind?: AccountKind;
  status: LocalUserStatus;
  passwordSetupPending?: boolean;
  createdAt: string;
  lastLoginAt?: string;
};

export type StoredLocalUser = PublicLocalUser & {
  normalizedLoginName: string;
  updatedAt: string;
  authEpoch: number;
  kdf: AuthKdfPolicy;
  kdfSalt: Buffer;
  umkWrapNonce: Buffer;
  umkWrapCiphertext: Buffer;
  umkWrapTag: Buffer;
  umkKeyVersion: number;
  sharingPublicKeyAlgorithm?: "X25519";
  sharingPublicKey?: Buffer;
  sharingPrivateKeyWrapNonce?: Buffer;
  sharingPrivateKeyWrapCiphertext?: Buffer;
  sharingPrivateKeyWrapTag?: Buffer;
  sharingKeyVersion?: number;
};

export type AuthSessionView = {
  sessionId: string;
  userId: string;
  createdAt: string;
  lastActivityAt: string;
  lastFullAuthenticationAt: string;
  idleExpiresAt: string;
  overallExpiresAt: string;
};

export type AuthenticatedContext = {
  user: PublicLocalUser;
  session: AuthSessionView;
};

export type AuthSuccess = AuthenticatedContext & {
  sessionToken: string;
};

export type AuthStatus = {
  initialized: boolean;
  requiresBootstrap: boolean;
  temporaryAdminCredentialsActive: boolean;
};

export type AuthClock = {
  now(): number;
};

export type AuthSessionPolicy = {
  idleTimeoutMs: number;
  overallTimeoutMs: number;
};

export const DEFAULT_AUTH_SESSION_POLICY:
  AuthSessionPolicy = {
    idleTimeoutMs: 15 * 60 * 1000,
    overallTimeoutMs: 8 * 60 * 60 * 1000
  };

export const DEFAULT_AUTH_KDF:
  AuthKdfPolicy = {
    algorithm: "ARGON2ID",
    memoryKiB: 64 * 1024,
    iterations: 3,
    parallelism: 1,
    keyLength: 32,
    version: 1
  };


export type StoredRecoveryEnvelope = {
  userId: string;
  algorithm: "HKDF-SHA256-AES-256-GCM";
  salt: Buffer;
  nonce: Buffer;
  ciphertext: Buffer;
  tag: Buffer;
  keyVersion: number;
  createdAt: string;
  updatedAt: string;
};

export type RecoveryCodeResult = {
  recoveryCode: string;
  createdAt: string;
};

export type AuthRecoverySuccess =
  AuthSuccess & {
    recoveryCode: string;
  };

export type StoredGoogleRecoveryLink = {
  userId: string;
  googleSub: string;
  googleEmail: string;
  salt: Buffer;
  nonce: Buffer;
  ciphertext: Buffer;
  tag: Buffer;
  keyVersion: number;
  driveFileId: string;
  createdAt: string;
  updatedAt: string;
};

export type GoogleRecoveryLinkView = {
  googleEmail: string;
  linkedAt: string;
};
