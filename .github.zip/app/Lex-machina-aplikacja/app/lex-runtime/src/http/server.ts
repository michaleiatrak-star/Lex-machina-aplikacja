import { UserGroupStore } from "../user-groups.js";
import { LocalDocumentDecryptor } from "../document-decryption.js";
import { LocalWhisperTranscriber, TranscriptionModelManager } from "../transcription.js";
import { OcrAccelerationManager } from "../ocr/ocr-acceleration.js";
import { TranscriptionAccelerationManager } from "../transcription-acceleration.js";
import { registerSnProxyRoutes, SN_PROXY_PREFIX, SnVerificationProxy } from "./sn-proxy.js";
import { registryEnrichmentFor } from "../privacy/registry-enrichment.js";
import { LocalPageImageMasker } from "../document-evidence.js";
import { configureCaseLawStore } from "../case-law-store.js";
import { timingSafeEqual } from "node:crypto";
import express, {
  type NextFunction,
  type Request,
  type Response
} from "express";
import helmet from "helmet";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { allowedPublicOrigin, createLexHttpApp, jsonErrorHandler, sessionActivityMiddleware } from "./app.js";
import { BrowserAccess, DEFAULT_BROWSER_PORT, browserSameOrigin, registerWebApp, resolveWebRoot } from "./browser-access.js";
import { certificateNames, ensureCertificate } from "./tls-certificate.js";
import { localOnlyRoute } from "../server-mode/routes.js";
import { GoogleRecoveryController } from "../google/recovery-controller.js";
import { GoogleWorkspaceController } from "../google/workspace-controller.js";
import { MicrosoftController } from "../microsoft/controller.js";
import { GOOGLE_CALLBACK_PATH } from "../google/config.js";
import { registerLegacyMigrationRoutes } from "./legacy-migration-routes.js";
import { registerWorkspaceRoutes } from "./workspace-routes.js";
import { registerQualityBenchmarkRoutes } from "./quality-benchmark-routes.js";
import { QualityBenchmarkService } from "../quality-benchmark-service.js";
import { LocalOfficeEditor } from "../office-edit.js";
import { LocalPdfFormFiller } from "../pdf-form.js";
import { registerMaintenanceRoutes } from "./maintenance-routes.js";
import { AnomalyJournal, withAnomalyJournal } from "../anomaly-journal.js";
import { registerCoreLawRoutes } from "./core-law-routes.js";
import { registerMcpConnectorRoutes } from "./mcp-connector-routes.js";
import { registerInvoiceRoutes } from "./invoice-routes.js";
import { registerWidgetRoutes } from "./widget-routes.js";
import { WidgetFrameStore } from "../widget-runtime.js";
import { ServerModeStore } from "../server-mode/store.js";
import { ServerSecretBox } from "../server-mode/secret-box.js";
import { ServerModeService } from "../server-mode/service.js";
import { ServerModeCredentialResolver } from "../server-mode/credentials.js";
import { registerServerModeRoutes } from "../server-mode/routes.js";
import { EncryptedInvoiceStore } from "../invoice-store.js";
import {
  LexMcpConnectorStore,
  lexMcpPackagePath
} from "../lex-mcp-connectors.js";
import { LexSkillRegistry } from "../registry.js";
import { warmChatPaths } from "../chat-warmup.js";
import { DynamicModelCatalog } from "../providers/model-catalog.js";
import {
  EnvironmentCredentialResolver,
  MemoryOverlayCredentialResolver
} from "../providers/credentials.js";
import { createLiveProviderRegistry } from "../providers/ai-sdk-adapter.js";
import {
  AccountSessionManager
} from "../providers/account-session.js";
import { ProviderGateway } from "../providers/gateway.js";
import {
  applicationUpdateDiscovery
} from "../update-discovery.js";
import {
  applyAccountSkills
} from "../account-skills.js";
import {
  CoreLawIndex
} from "../core-law-index.js";
import {
  LocalPersonMorphology
} from "../privacy/person-morphology.js";
import {
  MaintenanceService,
  commitSkillOverlayRuntimeHealth,
  recoverSkillOverlayForStartup
} from "../maintenance-service.js";
import { LocalModelRuntime } from "../local-model-runtime.js";
import { SafeSessionExecutor } from "../session-executor.js";
import { LegalVerificationToolRuntime } from "../verification-tool-runtime.js";
import { configureDomainFallback } from "../domain-fallback.js";
import { SupremeCourtCaseVerifier, withSnSession } from "../case-law-verifier.js";
import { CaseLawSearchService } from "../case-law-search.js";
import { LegalFederationToolRuntime } from "../legal-federation-tool-runtime.js";
import { TemporalSourceFreshnessChecker } from "../temporal-source-freshness.js";
import { OfficialLegalSourceVerifier } from "../legal-source-verifier.js";
import { LocalPdfTextExtractor } from "../pdf-text-extractor.js";
import { CompleteDocumentIngestor } from "../document-ingestion.js";
import { PdfJsDocumentPageSource } from "../pdf-document-page-source.js";
import { LocalPaddleOcrEngine } from "../ocr/paddle-ocr-engine.js";
import { LocalPaddleImageOcrEngine } from "../ocr/paddle-image-ocr-engine.js";
import { CompleteImageIngestor } from "../image-ingestion.js";
import { LocalStanzaNamedEntityRecognizer } from "../privacy/stanza-ner.js";
import {
  CompositeRecognizer,
  LocalGazetteerRecognizer
} from "../privacy/gazetteer-ner.js";
import { LocalLlmPrivacyNamedEntityRecognizer } from "../privacy/local-llm-ner.js";
import { LocalPrivateDocumentService } from "../document-service.js";
import { LocalVisionLineReader } from "../ocr-vision.js";
import { LocalCaseFileStore } from "../case-file-store.js";
import { LocalAuthStore } from "../auth/store.js";
import { LocalAuthService } from "../auth/service.js";
import {
  LocalCaseAccessService
} from "../case-access.js";
import {
  LocalSharedTemplateStore
} from "../shared-template-store.js";
import {
  LocalTemplateProfileService
} from "../template-profile-service.js";
import {
  EncryptedPrivacyVaultStore
} from "../privacy/vault-store.js";
import {
  SecureCaseUploadStore
} from "../case-secure-store.js";
import {
  CaseSecurityRotationCoordinator
} from "../case-security-rotation.js";
import {
  SecureCaseDocumentStore
} from "../case-document-store.js";
import {
  LocalCaseKnowledgeSearch
} from "../case-knowledge-search.js";
import {
  SecureCaseArtifactStore
} from "../case-artifact-store.js";
import {
  EncryptedCaseWorkspaceStore
} from "../case-workspace-store.js";
import {
  EncryptedCaseScheduleStore
} from "../case-schedule-store.js";
import {
  LegacyCaseStorageMigrator
} from "../legacy-case-migration.js";
import {
  LocalOfficeDocumentTextExtractor
} from "../office-document-extractor.js";
import {
  LocalSpreadsheetTextExtractor
} from "../spreadsheet-extractor.js";
import {
  DocumentGenerationStateStore
} from "../document-generation-state.js";
import {
  LocalDocumentAuthoringService
} from "../document-authoring-service.js";
import {
  DeanonymizationReauthorizationManager
} from "../auth/reauthorization.js";
import {
  SensitiveDownloadTicketManager
} from "../sensitive-download-ticket.js";
import {
  LegalDocumentAstGenerator
} from "../legal-document-ast-generator.js";
import {
  LocalSupportService
} from "../support-service.js";
import {
  GuideSessionStateStore
} from "../guide-session-state.js";

const DEFAULT_HOST = "127.0.0.1";
const DEFAULT_PORT = 4317;

export function assertLoopbackHost(host: string): void {
  if (!["127.0.0.1", "localhost", "::1"].includes(host)) {
    throw new Error(
      "Lex Machina local server refuses non-loopback bind addresses."
    );
  }
}

function isLoopbackOrigin(
  origin: string
): boolean {
  try {
    const url = new URL(origin);
    return (
      (url.protocol === "http:" ||
        url.protocol === "https:") &&
      [
        "localhost",
        "127.0.0.1",
        "::1",
        "[::1]"
      ].includes(url.hostname)
    );
  } catch {
    return false;
  }
}

function desktopBootstrapGuard(
  req: Request,
  res: Response,
  next: NextFunction
): void {
  const expected =
    process.env
      .LEX_DESKTOP_BOOTSTRAP_TOKEN
      ?.trim();
  // The system browser cannot send the desktop secret. The Google callback
  // only completes flows a bootstrapped client started and returns a static
  // page.
  if (
    !expected ||
    (req.method === "GET" &&
      req.path === GOOGLE_CALLBACK_PATH)
  ) {
    next();
    return;
  }

  const provided =
    req.get(
      "x-lex-desktop-bootstrap"
    )?.trim() ?? "";
  const expectedBytes =
    Buffer.from(
      expected,
      "utf8"
    );
  const providedBytes =
    Buffer.from(
      provided,
      "utf8"
    );
  const accepted =
    expectedBytes.length ===
      providedBytes.length &&
    expectedBytes.length >
      0 &&
    timingSafeEqual(
      expectedBytes,
      providedBytes
    );
  expectedBytes.fill(0);
  providedBytes.fill(0);

  if (!accepted) {
    res.status(401).json({
      error:
        "DESKTOP_BOOTSTRAP_REQUIRED"
    });
    return;
  }
  next();
}

function loopbackOriginGuard(
  req: Request,
  res: Response,
  next: NextFunction
): void {
  const origin = req.get("origin");
  if (
    !origin ||
    // The sandboxed sn.pl verification window (opaque origin): its ticket, never a login.
    (origin === "null" && req.path.startsWith(`${SN_PROXY_PREFIX}/s/`)) ||
    isLoopbackOrigin(origin) ||
    allowedPublicOrigin(origin) ||
    browserSameOrigin(req)
  ) {
    next();
    return;
  }
  res.status(403).json({
    error: "ORIGIN_NOT_ALLOWED"
  });
}

export function bundledRuntimeRoot(): string {
  const here =
    path.dirname(
      fileURLToPath(
        import.meta.url
      )
    );
  const repositoryRoot =
    path.resolve(
      here,
      "../../../.."
    );
  return path.resolve(
    path.join(
      repositoryRoot,
      "Wersja rozwojowa rozpakowana"
    )
  );
}

export function resolveRuntimeRoot(): string {
  const explicitlyConfigured =
    process.env
      .LEX_SKILLS_PATH
      ?.trim();
  if (explicitlyConfigured) {
    return path.resolve(
      explicitlyConfigured
    );
  }

  // Desktop (sidecar) podaje korpus wbudowany osobno, aby nakładka skilli
  // przeszła walidację przy starcie i w razie awarii wróciła do poprzedniej
  // lub wbudowanej wersji.
  const bundledFromEnv =
    process.env
      .LEX_BUNDLED_SKILLS_PATH
      ?.trim();
  const bundled =
    bundledFromEnv
      ? path.resolve(
          bundledFromEnv
        )
      : bundledRuntimeRoot();
  const recovered =
    recoverSkillOverlayForStartup(
      bundled
    );
  return recovered.root ??
    bundled;
}

// Newer legal skills from the model accounts, unless the corpus path is
// pinned explicitly (development, validation).
function resolveAccountSkillRoot(
  baseRoot: string
): string {
  if (process.env.LEX_SKILLS_PATH?.trim()) {
    return baseRoot;
  }
  try {
    const result =
      applyAccountSkills(
        baseRoot
      );
    for (const skill of result.applied) {
      process.stderr.write(
        `LEX_ACCOUNT_SKILL_APPLIED:${skill.name}:${skill.source}:${skill.bundledVersion ?? "none"}->${skill.version}\n`
      );
    }
    for (const skill of result.rejected) {
      process.stderr.write(
        `LEX_ACCOUNT_SKILL_REJECTED:${skill.name}:${skill.source}:${skill.reason}\n`
      );
    }
    return result.root;
  } catch (error) {
    process.stderr.write(
      `LEX_ACCOUNT_SKILLS_UNAVAILABLE:${error instanceof Error ? error.message : String(error)}\n`
    );
    return baseRoot;
  }
}

// A text model idle this long gives the card to OCR (ms).
const LOCAL_MODEL_OCR_RELEASE_IDLE_MS = 60_000;

export async function startLocalServer(options?: {
  host?: string;
  port?: number;
}): Promise<{
  host: string;
  port: number;
  close(): Promise<void>;
}> {
  const host = options?.host ?? process.env.LEX_HOST ?? DEFAULT_HOST;
  const rawPort = options?.port ?? Number(process.env.LEX_PORT ?? DEFAULT_PORT);
  const port = Number.isInteger(rawPort) && rawPort >= 0 && rawPort <= 65535
    ? rawPort
    : DEFAULT_PORT;

  assertLoopbackHost(host);

  const baseRuntimeRoot =
    resolveRuntimeRoot();
  const runtimeRoot =
    resolveAccountSkillRoot(
      baseRuntimeRoot
    );
  const registry =
    new LexSkillRegistry(
      runtimeRoot
    );
  const issues = [...registry.scan(), ...registry.validateDeclarations()];
  if (issues.length > 0) {
    throw new Error(
      `Lex corpus validation failed before HTTP startup: ${issues.length} issue(s).`
    );
  }

  const caseFileStore =
    new LocalCaseFileStore();
  // Decisions downloaded once (verification, preview): quotes are marked on this copy.
  configureCaseLawStore(path.join(caseFileStore.rootDir, "case-law"));
  // Model zapasowy routingu dziedzin (Ustawienia, domyślnie wyłączony).
  configureDomainFallback(path.join(caseFileStore.rootDir, "settings"));
  const authStore =
    new LocalAuthStore({
      rootDir:
        caseFileStore.rootDir
    });
  const sharedTemplateStore =
    new LocalSharedTemplateStore({
      rootDir:
        caseFileStore.rootDir
    });
  const officeEditor =
    new LocalOfficeEditor();
  const templateProfileService =
    new LocalTemplateProfileService(
      sharedTemplateStore
    );
  const privacyVaultStore =
    new EncryptedPrivacyVaultStore({
      rootDir:
        caseFileStore.rootDir
    });
  const secureCaseUploadStore =
    new SecureCaseUploadStore({
      rootDir:
        caseFileStore.rootDir
    });
  const secureCaseDocumentStore =
    new SecureCaseDocumentStore({
      rootDir:
        caseFileStore.rootDir
    });
  const secureCaseArtifactStore =
    new SecureCaseArtifactStore({
      rootDir:
        caseFileStore.rootDir
    });
  const workspaceStore =
    new EncryptedCaseWorkspaceStore({
      rootDir:
        caseFileStore.rootDir
    });
  const caseScheduleStore =
    new EncryptedCaseScheduleStore({
      rootDir:
        caseFileStore.rootDir
    });
  const documentGenerationState =
    new DocumentGenerationStateStore({
      rootDir:
        caseFileStore.rootDir
    });
  const caseKnowledgeSearch =
    new LocalCaseKnowledgeSearch(
      secureCaseDocumentStore
    );
  const legacyCaseStorageMigrator =
    new LegacyCaseStorageMigrator(
      secureCaseUploadStore,
      {
        rootDir:
          caseFileStore.rootDir
      }
    );
  const caseSecurityRotation =
    new CaseSecurityRotationCoordinator(
      privacyVaultStore,
      secureCaseUploadStore,
      secureCaseDocumentStore,
      secureCaseArtifactStore,
      workspaceStore,
      caseScheduleStore
    );
  await secureCaseUploadStore
    .cleanupOrphanedWorkdirs();

  const authService =
    new LocalAuthService(
      authStore
    );
  if (
    authService.status()
      .requiresBootstrap
  ) {
    const bootstrap =
      await authService.bootstrap({
        loginName: "admin",
        displayName: "Administrator",
        password: "admin",
        passwordSetupPending: true
      });
    authService.logoutAuthorization(
      `Bearer ${bootstrap.sessionToken}`
    );
  }
  const guideSessionStore =
    new GuideSessionStateStore();
  const unsubscribeGuideRevocation =
    authService.onSessionRevoked(
      (event) => {
        guideSessionStore.revoke(
          event.sessionId
        );
      }
    );
  const supportService =
    new LocalSupportService({
      installationId:
        process.env
          .LEX_SUPPORT_INSTALLATION_ID,
      challengePublicKey:
        process.env
          .LEX_SUPPORT_CHALLENGE_PUBLIC_KEY,
      vendorPublicKeyPem:
        process.env
          .LEX_SUPPORT_VENDOR_PUBLIC_KEY_PEM,
      vendorKeyId:
        process.env
          .LEX_SUPPORT_VENDOR_KEY_ID,
      securityEvents:
        authStore
    });
  const caseAccessService =
    new LocalCaseAccessService(
      authStore,
      authService,
      caseFileStore,
      caseSecurityRotation,
      caseScheduleStore
    );
  const documentAuthoringService =
    new LocalDocumentAuthoringService(
      privacyVaultStore,
      secureCaseArtifactStore,
      documentGenerationState
    );
  const reauthorizationManager =
    new DeanonymizationReauthorizationManager(
      authService,
      caseAccessService,
      authStore,
      documentGenerationState
    );
  const sensitiveDownloadTickets =
    new SensitiveDownloadTicketManager(
      authService
    );

  const updateDiscovery =
    applicationUpdateDiscovery();
  const maintenance =
    new MaintenanceService(
      updateDiscovery
    );
  const localModels =
    new LocalModelRuntime();
  const transcriptionModel = new TranscriptionModelManager(path.join(localModels.rootDir, "transcription"));
  const ocrAcceleration = new OcrAccelerationManager(path.join(localModels.rootDir, "ocr-acceleration"));
  const transcriptionAcceleration = new TranscriptionAccelerationManager(path.join(localModels.rootDir, "transcription-acceleration"));
  transcriptionAcceleration.modelInstalled = () => transcriptionModel.installed();

  // Server mode (off by default; LEX_SERVER_MODE_FORCE=on|off fixes it for a container).
  const serverModeDir = path.join(caseFileStore.rootDir, "server");
  const serverMode = new ServerModeService(
    new ServerModeStore(serverModeDir),
    new ServerSecretBox({ keyPath: path.join(serverModeDir, "secret.key"), envKey: process.env.LEX_SERVER_SECRET_KEY }),
    authService,
    { forceEnv: process.env.LEX_SERVER_MODE_FORCE }
  );
  // Server mode: the admin's global API keys for every account.
  const environmentCredentials =
    new EnvironmentCredentialResolver();
  const credentials =
    new ServerModeCredentialResolver(
      new MemoryOverlayCredentialResolver(
        environmentCredentials
      ),
      environmentCredentials,
      serverMode
    );
  const accountSessions =
    new AccountSessionManager();
  const providerRegistry = createLiveProviderRegistry(
    credentials,
    localModels,
    accountSessions
  );
  const providerGateway = new ProviderGateway(providerRegistry, serverMode);
  // Stanza NER plus the SGJP name dictionary and address patterns. The Stanza model
  // is loaded once, in the background now, not for every checked message.
  const stanzaRecognizer =
    new LocalStanzaNamedEntityRecognizer();
  stanzaRecognizer.warmUp();
  const gazetteerRecognizer =
    new LocalGazetteerRecognizer();
  gazetteerRecognizer.warmUp();
  const stanzaNamedEntities =
    new CompositeRecognizer([
      stanzaRecognizer,
      gazetteerRecognizer
    ]);
  // Start check of the local recognizers (Stanza, Morfeusz): a failure and its reason are
  // logged now and shown in the first document preview, not found out on a leaked name.
  void stanzaNamedEntities.selfTest().then((statuses) => {
    for (const status of statuses) {
      process.stderr.write(`PRIVACY_RECOGNIZER_SELF_TEST:${status.name}:${status.ok ? "OK" : status.reason ?? "FAILED"}\n`);
    }
  });
  const privacyNamedEntities =
    new LocalLlmPrivacyNamedEntityRecognizer(
      providerGateway,
      localModels,
      stanzaNamedEntities
    );
  const modelCatalog =
    new DynamicModelCatalog(
      credentials,
      undefined,
      localModels
    );

  const legalSourceVerifier =
    new OfficialLegalSourceVerifier(
      undefined,
      undefined,
      new LocalPdfTextExtractor(undefined, { lines: true, markSmallLines: true })
    );
  // Konto może nadpisać korpus samymi skillami — serwery MCP bierzemy z pierwszego korpusu, który je ma.
  const mcpConnectors =
    new LexMcpConnectorStore(
      [
        runtimeRoot,
        baseRuntimeRoot,
        bundledRuntimeRoot()
      ].find(
        (root) =>
          fs.existsSync(
            lexMcpPackagePath(root)
          )
      ) ?? runtimeRoot
    );
  const snFetch = withSnSession(globalThis.fetch.bind(globalThis), () => mcpConnectors.snSession());
  const legalFederationTools =
    new LegalFederationToolRuntime(
      undefined,
      undefined,
      mcpConnectors
    );

  // Morfeusz2/SGJP person-name morphology in the payload Python.
  const personMorphology =
    new LocalPersonMorphology();
  personMorphology.warmUp();

  // Official ELI texts of every act named in the domain act maps; refreshed
  // in the background, kept locally for offline and local-model use. Scanned
  // PDFs (old Dz.U.) are read with the local OCR.
  const coreLawIndex =
    new CoreLawIndex(undefined, undefined, undefined, undefined, undefined, new LocalPaddleOcrEngine());
  try {
    coreLawIndex.load(
      runtimeRoot
    );
    if (
      !/^(off|0|false)$/i.test(
        process.env.LEX_CORE_LAW_REFRESH?.trim() ?? ""
      )
    ) {
      void coreLawIndex
        .refresh()
        .catch((error) => {
          process.stderr.write(
            `LEX_CORE_LAW_REFRESH_FAILED:${error instanceof Error ? error.message : String(error)}\n`
          );
        });
      // Daily ELI check while the application runs, not only at start.
      coreLawIndex.startSchedule();
    }
  } catch (error) {
    process.stderr.write(
      `LEX_CORE_LAW_UNAVAILABLE:${error instanceof Error ? error.message : String(error)}\n`
    );
  }

  // Nieprawidłowości każdej sesji (ścieżki skilli, blokady, błędy) - bez treści spraw.
  const anomalyJournal =
    new AnomalyJournal(caseFileStore.rootDir);
  // Pamięć dowodowa wątku: przepis z poprzedniej wiadomości tylko przy tym samym t.j. w ELI.
  const actFreshness = new TemporalSourceFreshnessChecker();
  const sessionExecutor = withAnomalyJournal(
    new SafeSessionExecutor(
      registry,
      providerGateway,
      undefined,
      (ledger, context) =>
        new LegalVerificationToolRuntime(
          ledger,
          legalSourceVerifier,
          undefined,
          new TemporalSourceFreshnessChecker(),
          // sn.pl with the session the user verified in the app's sn.pl window,
          // as the SN connector of the case-law search does.
          new SupremeCourtCaseVerifier(snFetch),
          new CaseLawSearchService(snFetch),
          coreLawIndex,
          undefined,
          (act) => coreLawIndex.adopt(act),
          context?.localModel === true
        ),
      privacyNamedEntities,
      legalFederationTools,
      coreLawIndex,
      personMorphology,
      (act) => actFreshness.check(act)
    ),
    anomalyJournal
  );
  const documentAstGenerator =
    new LegalDocumentAstGenerator(
      sessionExecutor
    );
  // OCR on the card: a text model idle for a minute gives the card back first (the next answer
  // starts it again); during a series of documents, when it answers every few seconds, it stays.
  const ocrCardEnvironment = () => {
    const environment = ocrAcceleration.environment();
    if (environment) void localModels.releaseIfIdle(LOCAL_MODEL_OCR_RELEASE_IDLE_MS, "OCR");
    return environment;
  };
  const caseOcrEngine = new LocalPaddleOcrEngine({
    lineCrops: () => localModels.visionOcr() !== null,
    acceleration: ocrCardEnvironment,
    textModelResident: () => localModels.resident,
    persistent: true
  });
  // After a series of documents or a conversation: the model's memory back after a quiet while.
  const idleMinutes = Number(process.env.LEX_LOCAL_MODEL_IDLE_MINUTES ?? "5");
  if (Number.isFinite(idleMinutes) && idleMinutes > 0) {
    setInterval(() => {
      void localModels.releaseIfIdle(idleMinutes * 60_000, "IDLE");
    }, 60_000).unref();
  }
  // The measurement reads without the vision model's line images, like any plain OCR.
  const benchmarkOcr = new LocalPaddleOcrEngine();
  ocrAcceleration.reader = (data, pages, acceleration) => benchmarkOcr.benchmarkRead(data, pages, acceleration);
  // The card is set up by the app itself, once: a few minutes after the start (not to slow
  // the first minutes of work); the 6-hourly check only retries a failed attempt.
  const autoOcrAcceleration = () => {
    ocrAcceleration.autoSetup().catch((error: unknown) => {
      process.stderr.write(`OCR_ACCEL_AUTO_FAILED:${error instanceof Error ? error.message : String(error)}\n`);
    });
  };
  setTimeout(autoOcrAcceleration, 3 * 60_000).unref();
  setInterval(autoOcrAcceleration, 6 * 60 * 60_000).unref();
  // Transcription on an NVIDIA card: the same once-only setup, a little later than the OCR one
  // (both measurements are background work and would only wait for each other).
  const recordingTranscriber = new LocalWhisperTranscriber(() => transcriptionModel.dir, {
    acceleration: () => transcriptionAcceleration.environment(),
    speakersDir: () => (transcriptionModel.speakersInstalled() ? transcriptionModel.speakersDir : null),
    speakerCount: () => transcriptionModel.speakerCount(),
    mlxDir: () => (transcriptionModel.mlxInstalled() ? transcriptionModel.mlxDir : null)
  });
  // Speaker models (tens of MB) for a transcription model installed before they existed: fetched
  // once in the background, checked against their SHA-256 (the administrator chose transcription).
  // (and on Apple Silicon the GPU copy of the model)
  if (!process.env.VITEST && transcriptionModel.installed() && !transcriptionModel.complete()) {
    setTimeout(() => {
      transcriptionModel.start().catch(() => undefined);
    }, 20_000).unref();
  }
  transcriptionAcceleration.reader = (data, env) => recordingTranscriber.benchmark(data, "audio/opus", env);
  const autoTranscriptionAcceleration = () => {
    transcriptionAcceleration.autoSetup().catch((error: unknown) => {
      process.stderr.write(`STT_ACCEL_AUTO_FAILED:${error instanceof Error ? error.message : String(error)}\n`);
    });
  };
  setTimeout(autoTranscriptionAcceleration, 8 * 60_000).unref();
  setInterval(autoTranscriptionAcceleration, 6 * 60 * 60_000).unref();
  const documentService =
    new LocalPrivateDocumentService(
      new CompleteDocumentIngestor(
        new PdfJsDocumentPageSource(),
        caseOcrEngine
      ),
      privacyNamedEntities,
      24_000,
      new CompleteImageIngestor(
        new LocalPaddleImageOcrEngine({
          lineCrops: () => localModels.visionOcr() !== null,
          acceleration: () => ocrAcceleration.environment(),
          persistent: true
        })
      ),
      privacyVaultStore,
      secureCaseDocumentStore,
      new LocalOfficeDocumentTextExtractor(),
      new LocalSpreadsheetTextExtractor(),
      personMorphology,
      new LocalPageImageMasker(),
      registryEnrichmentFor(legalFederationTools),
      () => {
        const vision = localModels.visionOcr();
        return vision ? new LocalVisionLineReader(vision.executable, vision.model, { gpuOffload: vision.gpuOffload }) : null;
      },
      // The vision step: a running text model gives its memory to the vision model.
      async () => {
        if (localModels.status().state !== "STOPPED") await localModels.stop();
      },
      // "z lokalnym AI": the text model starts right before the detection of personal data.
      async () => {
        const modelId = localModels.configuredModelId();
        if (modelId && localModels.status().state !== "READY") await localModels.ensureRunning(modelId);
      },
      recordingTranscriber,
      (fn, fallback) => localModels.withExclusiveModel(fn, fallback)
    );

  const coreApp = createLexHttpApp({
    registry,
    documentDecryptor: new LocalDocumentDecryptor(),
    // Off until a Google OAuth client is configured (see google/config.ts).
    googleRecovery:
      new GoogleRecoveryController(authService),
    googleWorkspace:
      new GoogleWorkspaceController(authService, caseFileStore.rootDir),
    microsoft: new MicrosoftController(authService, caseFileStore.rootDir),
    userGroups: new UserGroupStore(caseFileStore.rootDir, (userId) => authStore.getUserById(userId) !== undefined),
    personMorphology,
    modelCatalog,
    credentialResolver: credentials,
    credentialManager: credentials,
    accountSessions,
    updateDiscovery,
    guideSessionStore,
    processWorkflowStore:
      workspaceStore,
    courtAnalysisWorkflowStore:
      workspaceStore,
    chronologyWorkflowStore:
      workspaceStore,
    contractWorkflowStore:
      workspaceStore,
    orderedCaseWorkflowStore:
      workspaceStore,
    caseMemoryStore:
      workspaceStore,
    documentGenerationState,
    caseFileStore,
    secureCaseUploadStore,
    sharedTemplateStore,
    officeEditor,
    templateProfileService,
    authService,
    supportService,
    caseAccessService,
    caseScheduleService:
      caseAccessService,
    caseKnowledgeSearch,
    documentAuthoringService,
    documentAstGenerator,
    reauthorizationManager,
    sensitiveDownloadTickets,
    secureCaseArtifactStore,
    documentService,
    sessionExecutor
  });

  const app = express();
  app.disable("x-powered-by");
  // Strona w przeglądarce: w aplikacji desktop osobny nasłuch (LEX_BROWSER_PORT, domyślnie 4317,
  // 0 wyłącza); bez aplikacji desktop główny nasłuch serwera.
  const desktop = Boolean(process.env.LEX_DESKTOP_BOOTSTRAP_TOKEN?.trim());
  const browserPortSetting = Number(process.env.LEX_BROWSER_PORT ?? DEFAULT_BROWSER_PORT);
  const browserAccess = new BrowserAccess(
    app,
    desktop ? (Number.isInteger(browserPortSetting) && browserPortSetting > 0 && browserPortSetting <= 65535 ? browserPortSetting : 0) : port,
    () => process.env.LEX_PUBLIC_BASE_URL?.trim() ?? "",
    host,
    () => {
      if (serverMode.browserProtocol() !== "HTTPS") return undefined;
      const extra = (process.env.LEX_ALLOWED_HOSTS ?? "").split(",");
      try {
        const base = process.env.LEX_PUBLIC_BASE_URL?.trim();
        if (base) extra.push(new URL(base).hostname);
      } catch {
        // Niepoprawny adres nie trafia do certyfikatu.
      }
      try {
        return ensureCertificate(path.join(serverModeDir, "tls"), certificateNames(extra));
      } catch (error) {
        process.stderr.write(`BROWSER_TLS_UNAVAILABLE:${error instanceof Error ? error.message : String(error)}\n`);
        return undefined;
      }
    }
  );
  app.use(helmet());
  app.use(browserAccess.guard(localOnlyRoute));
  app.use((req, res, next) => {
    if (browserAccess.isBrowserSocket(req.socket)) next();
    else desktopBootstrapGuard(req, res, next);
  });
  app.use(loopbackOriginGuard);
  app.use(express.json({ limit: "2mb" }));
  app.use("/api", sessionActivityMiddleware(authService));
  registerServerModeRoutes(app, { authService, serverMode, browserAccess });
  registerLegacyMigrationRoutes(
    app,
    {
      authService,
      securityEvents: authStore,
      caseAccessService,
      migrator:
        legacyCaseStorageMigrator
    }
  );
  registerWorkspaceRoutes(
    app,
    {
      authService,
      caseAccessService,
      uploads:
        secureCaseUploadStore,
      templates:
        sharedTemplateStore,
      privacyVaults:
        privacyVaultStore,
      documentService,
      protectedDocuments:
        secureCaseDocumentStore,
      workspace:
        workspaceStore,
      rootDir:
        caseFileStore.rootDir,
      officeEditor,
      pdfForms: new LocalPdfFormFiller(),
      artifacts:
        secureCaseArtifactStore
    }
  );
  registerMaintenanceRoutes(
    app,
    {
      authService,
      localModels,
      maintenance,
      anomalyJournal,
      transcriptionModel,
      ocrAcceleration,
      transcriptionAcceleration
    }
  );
  registerCoreLawRoutes(app, {
    authService,
    index: coreLawIndex
  });
  // Miernik jakości: runtime woła własne API (adres znany po starcie nasłuchu).
  let selfBaseUrl = "";
  registerQualityBenchmarkRoutes(app, {
    authService,
    benchmark: new QualityBenchmarkService({
      rootDir: caseFileStore.rootDir,
      baseUrl: () => selfBaseUrl,
      ...(process.env.LEX_DESKTOP_BOOTSTRAP_TOKEN?.trim() ? { desktopBootstrapToken: process.env.LEX_DESKTOP_BOOTSTRAP_TOKEN.trim() } : {})
    })
  });
  // sn.pl verification window through this server (server mode, browser): sn-proxy.ts.
  registerSnProxyRoutes(app, { authService, proxy: new SnVerificationProxy(mcpConnectors) });
  registerMcpConnectorRoutes(
    app,
    {
      authService,
      caseAccess:
        caseAccessService,
      connectors:
        mcpConnectors,
      search:
        new LegalFederationToolRuntime(
          undefined,
          undefined,
          mcpConnectors
        )
    }
  );
  registerWidgetRoutes(app, { authService, frames: new WidgetFrameStore() });
  registerInvoiceRoutes(app, {
    authService,
    invoices: new EncryptedInvoiceStore({
      rootDir: caseFileStore.rootDir
    }),
    legalText: new LegalFederationToolRuntime(
      undefined,
      undefined,
      mcpConnectors
    )
  });
  registerWebApp(app, resolveWebRoot());
  app.use(coreApp);
  app.use(jsonErrorHandler);

  const networkAtStart = serverMode.networkAccess();
  if (!desktop) {
    // Bez aplikacji desktop: jeden nasłuch na stronę i API (127.0.0.1 albo z sieci).
    await browserAccess.start(networkAtStart);
    if (browserAccess.state !== "LISTENING") {
      throw new Error(`LEX_PORT_UNAVAILABLE:${port}:${browserAccess.error ?? ""}`);
    }
    try {
      commitSkillOverlayRuntimeHealth(baseRuntimeRoot);
    } catch (error) {
      await browserAccess.stop();
      gazetteerRecognizer.close();
      personMorphology.close();
      throw error;
    }
    selfBaseUrl = `http://127.0.0.1:${browserAccess.listeningPort}`;
    return {
      host: networkAtStart === "NETWORK" ? "0.0.0.0" : host,
      port: browserAccess.listeningPort,
      close: async () => {
        await browserAccess.stop();
        void localModels.stop();
        stanzaRecognizer.close();
        gazetteerRecognizer.close();
        personMorphology.close();
        credentials.close();
        serverMode.close();
        supportService.close();
        unsubscribeGuideRevocation();
        guideSessionStore.clear();
        authService.close();
      }
    };
  }
  if (browserAccess.listeningPort > 0) await browserAccess.start(networkAtStart);

  return new Promise((resolve, reject) => {
    const server = app.listen(port, host);
    server.once("error", reject);
    server.once("listening", () => {
      try {
        commitSkillOverlayRuntimeHealth(
          baseRuntimeRoot
        );
      } catch (error) {
        gazetteerRecognizer.close();
        personMorphology.close();
        server.close(() => {
          reject(
            error instanceof Error
              ? error
              : new Error(
                  String(error)
                )
          );
        });
        return;
      }

      const address = server.address();
      const actualPort =
        typeof address === "object" && address
          ? address.port
          : port;
      selfBaseUrl = `http://${host.includes(":") ? `[${host}]` : host}:${actualPort}`;
      // Chat routing indexes built a few seconds after start (the UI's first requests first),
      // not on the user's first question (chat-warmup.ts).
      if (!process.env.VITEST && process.env.LEX_CHAT_WARMUP !== "off") {
        setTimeout(() => {
          const ms = warmChatPaths(registry);
          process.stderr.write(`LEX_CHAT_WARMUP:${ms}ms\n`);
        }, 3_000).unref();
      }

      resolve({
        host,
        port: actualPort,
        close: () =>
          new Promise<void>((closeResolve, closeReject) => {
            void browserAccess.stop();
            server.close((error) => {
              void localModels.stop();
              stanzaRecognizer.close();
              gazetteerRecognizer.close();
              personMorphology.close();
              credentials.close();
              serverMode.close();
              supportService.close();
              unsubscribeGuideRevocation();
              guideSessionStore.clear();
              authService.close();
              if (error) closeReject(error);
              else closeResolve();
            });
          })
      });
    });
  });
}

// The parent at start (the desktop app); an orphan is re-parented, on macOS and Linux
// to launchd/init (pid 1).
const PARENT_AT_START = process.ppid;

/** Where the runtime notes what nearly or did end it (no case text: the error and its stack). */
export function runtimeCrashLogPath(env: NodeJS.ProcessEnv = process.env): string {
  return env.LOCALAPPDATA
    ? path.join(env.LOCALAPPDATA, "LexMachina", "runtime-crash.log")
    : path.join(os.tmpdir(), "LexMachina-runtime-crash.log");
}

function noteRuntimeFault(kind: string, error: unknown): void {
  const detail = error instanceof Error ? `${error.name}: ${error.message}\n${error.stack ?? ""}` : String(error);
  const line = `--- ${new Date().toISOString()} ${kind}\n${detail.slice(0, 4000)}\n`;
  process.stderr.write(`RUNTIME_${kind}:${detail.split("\n")[0]?.slice(0, 300)}\n`);
  try {
    const file = runtimeCrashLogPath();
    fs.mkdirSync(path.dirname(file), { recursive: true });
    const previous = fs.existsSync(file) ? fs.readFileSync(file, "utf8").slice(-60_000) : "";
    fs.writeFileSync(file, previous + line);
  } catch {
    // The note never adds a second failure.
  }
}

export function installRuntimeCrashGuards(): void {
  process.on("unhandledRejection", (reason) => noteRuntimeFault("UNHANDLED_REJECTION", reason));
  process.on("uncaughtException", (error) => {
    noteRuntimeFault("UNCAUGHT_EXCEPTION", error);
    process.exit(70);
  });
}
export function desktopParentGone(ppid = process.ppid, platform = process.platform): boolean {
  return ppid !== PARENT_AT_START || (platform !== "win32" && ppid === 1);
}

if (
  process.argv[1] &&
  path.resolve(fileURLToPath(import.meta.url)) ===
    path.resolve(process.argv[1])
) {
  // One rejected promise nobody awaited (a background task, a timer) ended the whole runtime
  // on Node 24: chat, OCR and transcription stopped at once and the app showed no server.
  // It is logged and the runtime goes on; an uncaught exception still ends it (its state is
  // unknown) and the desktop sidecar starts it again.
  installRuntimeCrashGuards();
  const server = await startLocalServer();
  process.stdout.write(
    `Lex Machina runtime listening on http://${server.host}:${server.port}\n`
  );
  // Desktop: the runtime ends with the application that started it. On macOS an app
  // that crashed or was force-quit left node and its Python workers running (a new
  // set at every launch); the parent changing means it is gone.
  if (process.env.LEX_DESKTOP_BOOTSTRAP_TOKEN?.trim()) {
    setInterval(() => {
      if (desktopParentGone()) process.exit(0);
    }, 5_000).unref();
  }
}
