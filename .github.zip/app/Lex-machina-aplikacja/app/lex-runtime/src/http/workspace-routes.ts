import { LocalPdfFormFiller, pdfFormValues } from "../pdf-form.js";
import {
  appendDraftVersion,
  emptyProcessPleadingDraft,
  withDraftRemarks,
  type ProcessPleadingDraft
} from "../process-pleading-draft.js";
import {
  FORMAT_MEDIA_TYPE,
  editableMediaType,
  type EditableFormat,
  type EditableModel,
  type LocalOfficeEditor
} from "../office-edit.js";
import { randomBytes } from "node:crypto";
import {
  lstat,
  mkdir,
  readdir,
  rm,
  stat,
  writeFile
} from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import type {
  Express,
  Request,
  Response
} from "express";
import type { AuthService } from "../auth/service.js";
import type { LocalCaseAccessService } from "../case-access.js";
import type { SecureCaseUploadStore } from "../case-secure-store.js";
import type { LocalSharedTemplateStore } from "../shared-template-store.js";
import type { EncryptedPrivacyVaultStore } from "../privacy/vault-store.js";
import type { LocalPrivateDocumentService } from "../document-service.js";
import type { SecureCaseDocumentStore } from "../case-document-store.js";
import type { SecureCaseArtifactStore } from "../case-artifact-store.js";
import {
  documentIdFromSha256,
  purgeSecureCaseDocument
} from "../case-document-purge.js";
import type {
  EncryptedCaseWorkspaceStore,
  WorkspaceThreadMessage
} from "../case-workspace-store.js";
import {
  PROCESS_PLEADING_CHECKPOINTS,
  acceptProcessPleadingStart,
  confirmProcessCheckpoint,
  reopenProcessPleadingDraft,
  requestProcessCheckpointRevision,
  createProcessPleadingState,
  markProcessCheckpointNotApplicable,
  type ProcessPleadingCheckpoint,
  type ProcessPleadingMode
} from "../process-pleading-state.js";
import {
  createCourtAnalysisState
} from "../court-analysis-state.js";
import {
  createChronologyState
} from "../chronology-state.js";
import {
  createContractAnalysisState,
  type ContractWorkflowMode
} from "../contract-analysis-state.js";
import {
  createOrderedCaseWorkflowState,
  nextOrderedCaseCheckpoint,
  type OrderedCaseWorkflowId
} from "../ordered-case-workflow-state.js";

const CASE_ID = /^case_[a-f0-9]{32}$/;
const UPLOAD_ID = /^upload_[a-f0-9]{32}$/;
const TEMPLATE_ID = /^template_[a-f0-9]{32}$/;
const ARTIFACT_ID = /^artifact_[a-f0-9]{32}$/;
const FOLDER_ID = /^folder_[a-f0-9]{32}$/;
const OPEN_TOKEN = /^open_[a-f0-9]{32}(?:\.[a-z0-9]{1,10})?$/;
const PREVIEW_MAX_BYTES = 64 * 1024 * 1024;
const OPEN_MAX_BYTES = 512 * 1024 * 1024;

function draftView(draft: ProcessPleadingDraft | null) {
  if (!draft) return null;
  const latest = draft.versions.at(-1) ?? null;
  return {
    revision: draft.revision,
    latest,
    versions: draft.versions.map(({ text, ...item }) => ({ ...item, chars: text.length })),
    ...(draft.remarks ? { remarks: draft.remarks } : {})
  };
}

function caseIdFrom(req: Request): string {
  return String(req.params.caseId ?? "").trim();
}

function isPdf(mediaType: string, filename: string): boolean {
  return mediaType.split(";")[0]!.trim().toLowerCase() === "application/pdf" || /\.pdf$/iu.test(filename);
}

function errorCode(error: unknown): string {
  return error instanceof Error ? error.message : "WORKSPACE_OPERATION_FAILED";
}

function sendError(res: Response, error: unknown): void {
  const code = errorCode(error);
  if (["AUTHENTICATION_REQUIRED", "SESSION_REVOKED"].includes(code)) {
    res.status(401).json({ error: code });
    return;
  }
  if (code === "CASE_ACCESS_DENIED") {
    res.status(403).json({ error: code });
    return;
  }
  if (
    code === "CASE_NOT_FOUND" ||
    code.endsWith("_NOT_FOUND") ||
    code === "ENOENT"
  ) {
    res.status(404).json({ error: code });
    return;
  }
  if (
    code === "CASE_ARCHIVED" ||
    code === "WORKSPACE_FOLDER_NOT_EMPTY" ||
    code === "PROCESS_PLEADING_STATE_EXISTS" ||
    code === "PROCESS_PLEADING_STATE_CONFLICT" ||
    code === "PROCESS_PLEADING_DRAFT_CONFLICT" ||
    code === "COURT_ANALYSIS_STATE_EXISTS" ||
    code === "COURT_ANALYSIS_STATE_CONFLICT" ||
    code === "ORDERED_WORKFLOW_STATE_CONFLICT" ||
    code === "CHRONOLOGY_STATE_EXISTS" ||
    code === "CHRONOLOGY_STATE_CONFLICT" ||
    code === "CONTRACT_STATE_EXISTS" ||
    code === "CONTRACT_STATE_CONFLICT" ||
    code.includes("PROCESS_PLEADING_CONFIRMATION") ||
    code.includes("PROCESS_PLEADING_START_TRANSITION")
  ) {
    res.status(409).json({ error: code });
    return;
  }
  if (
    code.includes("INVALID") ||
    code.includes("TOO_LARGE") ||
    code.includes("LIMIT_EXCEEDED") ||
    code.includes("TRANSITION") ||
    (code.startsWith("OFFICE_EDIT_") && code.includes("UNSUPPORTED")) ||
    // A form the user can correct: unknown field, value not allowed, encrypted or no fields.
    (code.startsWith("PDF_FORM_") && !code.startsWith("PDF_FORM_FAILED") && code !== "PDF_FORM_TIMEOUT")
  ) {
    res.status(422).json({ error: code });
    return;
  }
  // Do klienta trafia tylko kod błędu, nie treść komunikatu (np. ENOENT ze ścieżką).
  const detail = /^[A-Z][A-Z0-9_]{2,80}$/.test(code) ? code : undefined;
  if (!detail) console.error("WORKSPACE_OPERATION_FAILED", error);
  res.status(500).json({ error: "WORKSPACE_OPERATION_FAILED", ...(detail ? { detail } : {}) });
}

/**
 * Sends file bytes and wipes them once the response is done: the socket may
 * still hold the buffer after send() returns, so wiping earlier corrupts it.
 */
function sendAndWipe(res: Response, data: Buffer): void {
  res.once("close", () => data.fill(0));
  res.send(data);
}

function extensionFor(filename: string): string {
  const extension = path.extname(filename).toLowerCase().replace(/^\./, "");
  return /^[a-z0-9]{1,10}$/.test(extension) ? extension : "";
}

export function contentDisposition(filename: string): string {
  const safe = filename
    .normalize("NFKC")
    .replace(/[\r\n"\\/]/g, "_")
    .slice(0, 180) || "document.bin";
  // Node rejects non-Latin-1 header bytes (a Polish name would fail with
  // ERR_INVALID_CHAR): ASCII fallback plus the RFC 5987 UTF-8 name.
  const ascii = safe.replace(/[^\x20-\x7e]/g, "_");
  return `inline; filename="${ascii}"; filename*=UTF-8''${encodeURIComponent(safe)}`;
}

// "Otwórz w programie" uruchamia domyślną aplikację dla rozszerzenia: tylko dokumenty
// i obrazy, nigdy pliki wykonywalne (.exe, .bat, .hta, .command...) ani dokumenty z makrami.
// Lista zgodna z OPEN_ALLOWED_EXTENSIONS w lex-desktop/src-tauri/src/lib.rs.
export const OPEN_ALLOWED_EXTENSIONS = new Set([
  "pdf", "docx", "doc", "odt", "rtf", "txt", "md", "csv",
  "xlsx", "xls", "ods", "pptx", "ppt", "odp",
  "png", "jpg", "jpeg", "gif", "webp", "bmp", "tif", "tiff"
]);

/** Odszyfrowana kopia do otwarcia w zewnętrznym programie; zwraca token pliku. */
export async function stageWorkspaceOpenCopy(root: string, filename: string, data: Buffer): Promise<string> {
  const extension = extensionFor(filename);
  if (!OPEN_ALLOWED_EXTENSIONS.has(extension)) throw new Error("WORKSPACE_OPEN_FILE_TYPE_INVALID");
  await mkdir(root, { recursive: true, mode: 0o700 });
  // Wspólny /tmp (Linux): katalog założony wcześniej przez kogoś innego, link symboliczny
  // albo katalog zapisywalny dla innych nie dostaje odszyfrowanej treści.
  const info = await lstat(root);
  const uid = typeof process.getuid === "function" ? process.getuid() : undefined;
  if (
    !info.isDirectory() ||
    info.isSymbolicLink() ||
    (uid !== undefined && (info.uid !== uid || (info.mode & 0o077) !== 0))
  ) {
    throw new Error("WORKSPACE_OPEN_ROOT_UNSAFE");
  }
  await cleanupOpenCopies(root);
  const token = `open_${randomBytes(16).toString("hex")}.${extension}`;
  if (!OPEN_TOKEN.test(token)) throw new Error("WORKSPACE_OPEN_TOKEN_INVALID");
  await writeFile(path.join(root, token), data, { flag: "wx", mode: 0o600 });
  return token;
}

async function cleanupOpenCopies(root: string): Promise<void> {
  let names: string[];
  try {
    names = await readdir(root);
  } catch (error) {
    if (error instanceof Error && "code" in error && error.code === "ENOENT") return;
    throw error;
  }
  const threshold = Date.now() - 60 * 60 * 1000;
  await Promise.all(names.map(async (name) => {
    if (!OPEN_TOKEN.test(name)) return;
    const target = path.join(root, name);
    try {
      const info = await stat(target);
      if (info.isFile() && info.mtimeMs < threshold) {
        await rm(target, { force: true });
      }
    } catch {
      // Cleanup is best-effort and must not expose another path.
    }
  }));
}

export function registerWorkspaceRoutes(
  app: Express,
  dependencies: {
    authService: Pick<AuthService, "authenticateAuthorization">;
    caseAccessService: Pick<
      LocalCaseAccessService,
      "assertAccess" | "openCase" | "withCaseDataKey"
    >;
    uploads: Pick<
      SecureCaseUploadStore,
      "listUploads" | "readUploadPayload"
    >;
    templates: Pick<
      LocalSharedTemplateStore,
      "listTemplates" | "readTemplate"
    > & { templatesDir: string };
    privacyVaults: Pick<
      EncryptedPrivacyVaultStore,
      "deleteDocumentVault"
    >;
    documentService: Pick<
      LocalPrivateDocumentService,
      "forget"
    >;
    // Zanonimizowane wersje pozostałych dokumentów: z nich wiadomo, które
    // wpisy wspólnego klucza sprawy są jeszcze używane po usunięciu dokumentu.
    protectedDocuments?: Pick<SecureCaseDocumentStore, "loadProtected">;
    workspace: EncryptedCaseWorkspaceStore;
    rootDir: string;
    officeEditor?: Pick<LocalOfficeEditor, "read" | "write">;
    pdfForms?: Pick<LocalPdfFormFiller, "fields" | "fill">;
    // Documents made by a model (with placeholders or deanonymized).
    artifacts?: Pick<SecureCaseArtifactStore, "listArtifacts" | "readArtifact" | "renameArtifact">;
  }
): void {
  const actorFor = (req: Request) =>
    dependencies.authService.authenticateAuthorization(
      req.get("authorization")
    );

  const resourcesFor = async (
    actor: ReturnType<typeof actorFor>,
    caseId: string,
    capability: "READ" | "WRITE" = "READ"
  ) => {
    dependencies.caseAccessService.assertAccess(actor, caseId, capability);
    const caseView = dependencies.caseAccessService.openCase(actor, caseId);
    return await dependencies.caseAccessService.withCaseDataKey(
      actor,
      caseId,
      capability,
      async (caseDataKey) => {
        const uploads = await dependencies.uploads.listUploads({
          caseId,
          caseDataKey,
          keyVersion: caseView.keyVersion
        });
        const templates = caseView.caseKind === "FIRM_KNOWLEDGE"
          ? await dependencies.templates.listTemplates()
          : [];
        const itemIds = [
          ...uploads.map((item) => item.uploadId),
          ...templates.map((item) => item.templateId)
        ];
        const workspace = await dependencies.workspace.listWorkspace({
          caseId,
          caseDataKey,
          keyVersion: caseView.keyVersion,
          itemIds
        });
        return { caseView, caseDataKey, uploads, templates, itemIds, workspace };
      }
    );
  };

  app.get("/api/cases/:caseId/workspace", async (req, res) => {
    try {
      const actor = actorFor(req);
      const caseId = caseIdFrom(req);
      const data = await resourcesFor(actor, caseId);
      res.json({
        caseId,
        caseKind: data.caseView.caseKind,
        caseDisplayName:
          data.caseView.displayName ??
          "Sprawa bez nazwy",
        folders: data.workspace.folders,
        itemLocations: data.workspace.itemLocations,
        items: [
          ...data.uploads.map((item) => ({
            kind: "UPLOAD" as const,
            itemId: item.uploadId,
            filename: item.filename,
            mediaType: item.mediaType,
            bytes: item.bytes,
            createdAt: item.storedAt,
            archive: item.archive
          })),
          ...data.templates.map((item) => ({
            kind: "TEMPLATE" as const,
            itemId: item.templateId,
            filename: item.filename,
            mediaType: item.mediaType,
            bytes: item.bytes,
            createdAt: item.createdAt,
            archive: false
          }))
        ]
      });
    } catch (error) {
      sendError(res, error);
    }
  });

  app.get(
    "/api/cases/:caseId/workflow/process-pleading",
    async (req, res) => {
      try {
        const actor = actorFor(req);
        const caseId = caseIdFrom(req);
        dependencies.caseAccessService
          .assertAccess(
            actor,
            caseId,
            "READ"
          );
        const caseView =
          dependencies.caseAccessService
            .openCase(
              actor,
              caseId
            );
        const state =
          await dependencies
            .caseAccessService
            .withCaseDataKey(
              actor,
              caseId,
              "READ",
              (caseDataKey) =>
                dependencies.workspace
                  .getProcessPleadingState({
                    caseId,
                    caseDataKey,
                    keyVersion:
                      caseView.keyVersion
                  })
            );
        res.json({
          caseId,
          state
        });
      } catch (error) {
        sendError(res, error);
      }
    }
  );

  app.post(
    "/api/cases/:caseId/workflow/process-pleading/initialize",
    async (req, res) => {
      try {
        const actor = actorFor(req);
        const caseId = caseIdFrom(req);
        const mode: ProcessPleadingMode =
          req.body?.mode === "AUTO"
            ? "AUTO"
            : "CHECKPOINT";
        dependencies.caseAccessService
          .assertAccess(
            actor,
            caseId,
            "WRITE"
          );
        const caseView =
          dependencies.caseAccessService
            .openCase(
              actor,
              caseId
            );
        const state =
          await dependencies
            .caseAccessService
            .withCaseDataKey(
              actor,
              caseId,
              "WRITE",
              async (caseDataKey) => {
                const existing =
                  await dependencies
                    .workspace
                    .getProcessPleadingState({
                      caseId,
                      caseDataKey,
                      keyVersion:
                        caseView.keyVersion
                    });
                if (existing) {
                  throw new Error(
                    "PROCESS_PLEADING_STATE_EXISTS"
                  );
                }
                return await dependencies
                  .workspace
                  .saveProcessPleadingState({
                    caseId,
                    caseDataKey,
                    keyVersion:
                      caseView.keyVersion,
                    state:
                      createProcessPleadingState(
                        caseId,
                        mode
                      )
                  });
              }
            );
        res.status(201).json({
          caseId,
          state
        });
      } catch (error) {
        sendError(res, error);
      }
    }
  );

  app.post(
    "/api/cases/:caseId/workflow/process-pleading/accept-start",
    async (req, res) => {
      try {
        const actor = actorFor(req);
        const caseId = caseIdFrom(req);
        dependencies.caseAccessService
          .assertAccess(
            actor,
            caseId,
            "WRITE"
          );
        const caseView =
          dependencies.caseAccessService
            .openCase(
              actor,
              caseId
            );
        const state =
          await dependencies
            .caseAccessService
            .withCaseDataKey(
              actor,
              caseId,
              "WRITE",
              async (caseDataKey) => {
                const current =
                  await dependencies
                    .workspace
                    .getProcessPleadingState({
                      caseId,
                      caseDataKey,
                      keyVersion:
                        caseView.keyVersion
                    });
                if (!current) {
                  throw new Error(
                    "PROCESS_PLEADING_STATE_NOT_FOUND"
                  );
                }
                const next =
                  acceptProcessPleadingStart(
                    current
                  );
                return await dependencies
                  .workspace
                  .saveProcessPleadingState({
                    caseId,
                    caseDataKey,
                    keyVersion:
                      caseView.keyVersion,
                    state: next,
                    expectedRevision:
                      current.revision
                  });
              }
            );
        res.json({
          caseId,
          state
        });
      } catch (error) {
        sendError(res, error);
      }
    }
  );

  app.post(
    "/api/cases/:caseId/workflow/process-pleading/confirm",
    async (req, res) => {
      try {
        const actor = actorFor(req);
        const caseId = caseIdFrom(req);
        const checkpoint =
          typeof req.body?.checkpoint ===
            "string"
            ? req.body.checkpoint.trim()
            : "";
        if (
          !PROCESS_PLEADING_CHECKPOINTS
            .includes(
              checkpoint as
                ProcessPleadingCheckpoint
            )
        ) {
          throw new Error(
            "PROCESS_PLEADING_CHECKPOINT_INVALID"
          );
        }
        dependencies.caseAccessService
          .assertAccess(
            actor,
            caseId,
            "WRITE"
          );
        const caseView =
          dependencies.caseAccessService
            .openCase(
              actor,
              caseId
            );
        const state =
          await dependencies
            .caseAccessService
            .withCaseDataKey(
              actor,
              caseId,
              "WRITE",
              async (caseDataKey) => {
                const current =
                  await dependencies
                    .workspace
                    .getProcessPleadingState({
                      caseId,
                      caseDataKey,
                      keyVersion:
                        caseView.keyVersion
                    });
                if (!current) {
                  throw new Error(
                    "PROCESS_PLEADING_STATE_NOT_FOUND"
                  );
                }
                const next =
                  confirmProcessCheckpoint(
                    current,
                    checkpoint as
                      ProcessPleadingCheckpoint
                  );
                return await dependencies
                  .workspace
                  .saveProcessPleadingState({
                    caseId,
                    caseDataKey,
                    keyVersion:
                      caseView.keyVersion,
                    state: next,
                    expectedRevision:
                      current.revision
                  });
              }
            );
        res.json({
          caseId,
          state
        });
      } catch (error) {
        sendError(res, error);
      }
    }
  );

  app.post(
    "/api/cases/:caseId/workflow/process-pleading/not-applicable",
    async (req, res) => {
      try {
        const actor = actorFor(req);
        const caseId = caseIdFrom(req);
        const checkpoint =
          typeof req.body?.checkpoint === "string"
            ? req.body.checkpoint.trim()
            : "";
        const reason =
          typeof req.body?.reason === "string"
            ? req.body.reason
            : "";
        const expectedRevision =
          Number(req.body?.expectedRevision);

        if (
          !PROCESS_PLEADING_CHECKPOINTS.includes(
            checkpoint as ProcessPleadingCheckpoint
          ) ||
          !Number.isSafeInteger(expectedRevision) ||
          expectedRevision < 1
        ) {
          throw new Error(
            "PROCESS_PLEADING_NA_REQUEST_INVALID"
          );
        }

        dependencies.caseAccessService.assertAccess(
          actor,
          caseId,
          "WRITE"
        );
        const caseView =
          dependencies.caseAccessService.openCase(
            actor,
            caseId
          );

        const state =
          await dependencies.caseAccessService
            .withCaseDataKey(
              actor,
              caseId,
              "WRITE",
              async (caseDataKey) => {
                const current =
                  await dependencies.workspace
                    .getProcessPleadingState({
                      caseId,
                      caseDataKey,
                      keyVersion:
                        caseView.keyVersion
                    });
                if (!current) {
                  throw new Error(
                    "PROCESS_PLEADING_STATE_NOT_FOUND"
                  );
                }
                if (
                  current.revision !==
                    expectedRevision
                ) {
                  throw new Error(
                    "PROCESS_PLEADING_STATE_CONFLICT"
                  );
                }
                const next =
                  markProcessCheckpointNotApplicable(
                    current,
                    checkpoint as
                      ProcessPleadingCheckpoint,
                    reason
                  );
                return await dependencies.workspace
                  .saveProcessPleadingState({
                    caseId,
                    caseDataKey,
                    keyVersion:
                      caseView.keyVersion,
                    state: next,
                    expectedRevision:
                      current.revision
                  });
              }
            );

        res.json({ caseId, state });
      } catch (error) {
        sendError(res, error);
      }
    }
  );

  // The pleading text between the stages: newest version, history, pending remarks.
  app.get("/api/cases/:caseId/workflow/process-pleading/draft", async (req, res) => {
    try {
      const actor = actorFor(req);
      const caseId = caseIdFrom(req);
      dependencies.caseAccessService.assertAccess(actor, caseId, "READ");
      const caseView = dependencies.caseAccessService.openCase(actor, caseId);
      const draft = await dependencies.caseAccessService.withCaseDataKey(actor, caseId, "READ", (caseDataKey) =>
        dependencies.workspace.getProcessPleadingDraft({ caseId, caseDataKey, keyVersion: caseView.keyVersion })
      );
      res.json({ caseId, draft: draftView(draft) });
    } catch (error) {
      sendError(res, error);
    }
  });

  // The user's own version of the pleading: a minor correction keeps the closed checks,
  // a substantive one (facts, legal basis) reopens CP-ATAK and the W3 checks (§7.2).
  app.post("/api/cases/:caseId/workflow/process-pleading/draft", async (req, res) => {
    try {
      const actor = actorFor(req);
      const caseId = caseIdFrom(req);
      const text = typeof req.body?.text === "string" ? req.body.text : "";
      const change = req.body?.change === "SUBSTANTIVE" ? "SUBSTANTIVE" : req.body?.change === "MINOR" ? "MINOR" : null;
      const expectedRevision = Number(req.body?.expectedRevision);
      if (!text.trim() || !change || !Number.isSafeInteger(expectedRevision) || expectedRevision < 0) {
        throw new Error("PROCESS_PLEADING_DRAFT_REQUEST_INVALID");
      }
      dependencies.caseAccessService.assertAccess(actor, caseId, "WRITE");
      const caseView = dependencies.caseAccessService.openCase(actor, caseId);
      const result = await dependencies.caseAccessService.withCaseDataKey(actor, caseId, "WRITE", async (caseDataKey) => {
        const keyVersion = caseView.keyVersion;
        const state = await dependencies.workspace.getProcessPleadingState({ caseId, caseDataKey, keyVersion });
        if (!state) throw new Error("PROCESS_PLEADING_STATE_NOT_FOUND");
        if (!["W2", "W3", "FINAL"].includes(state.stage)) throw new Error("PROCESS_PLEADING_DRAFT_STAGE_INVALID");
        const current = await dependencies.workspace.getProcessPleadingDraft({ caseId, caseDataKey, keyVersion });
        const draft = await dependencies.workspace.saveProcessPleadingDraft({
          caseId,
          caseDataKey,
          keyVersion,
          draft: appendDraftVersion(current ?? emptyProcessPleadingDraft(caseId), { text, source: "USER", stage: state.stage, change }),
          expectedRevision
        });
        const nextState =
          change === "SUBSTANTIVE"
            ? await dependencies.workspace.saveProcessPleadingState({
                caseId,
                caseDataKey,
                keyVersion,
                state: reopenProcessPleadingDraft(state, "zmiana merytoryczna projektu pisma przez użytkownika"),
                expectedRevision: state.revision
              })
            : state;
        return { draft, state: nextState };
      });
      res.json({ caseId, draft: draftView(result.draft), state: result.state });
    } catch (error) {
      sendError(res, error);
    }
  });

  // CHECKPOINT mode: the step waiting for confirmation goes back with the user's remarks.
  app.post("/api/cases/:caseId/workflow/process-pleading/revise", async (req, res) => {
    try {
      const actor = actorFor(req);
      const caseId = caseIdFrom(req);
      const checkpoint = typeof req.body?.checkpoint === "string" ? req.body.checkpoint.trim() : "";
      const remarks = typeof req.body?.remarks === "string" ? req.body.remarks : "";
      if (!PROCESS_PLEADING_CHECKPOINTS.includes(checkpoint as ProcessPleadingCheckpoint) || !remarks.trim()) {
        throw new Error("PROCESS_PLEADING_REVISION_REQUEST_INVALID");
      }
      dependencies.caseAccessService.assertAccess(actor, caseId, "WRITE");
      const caseView = dependencies.caseAccessService.openCase(actor, caseId);
      const state = await dependencies.caseAccessService.withCaseDataKey(actor, caseId, "WRITE", async (caseDataKey) => {
        const keyVersion = caseView.keyVersion;
        const current = await dependencies.workspace.getProcessPleadingState({ caseId, caseDataKey, keyVersion });
        if (!current) throw new Error("PROCESS_PLEADING_STATE_NOT_FOUND");
        const next = requestProcessCheckpointRevision(current, checkpoint as ProcessPleadingCheckpoint);
        const draft = await dependencies.workspace.getProcessPleadingDraft({ caseId, caseDataKey, keyVersion });
        await dependencies.workspace.saveProcessPleadingDraft({
          caseId,
          caseDataKey,
          keyVersion,
          draft: withDraftRemarks(draft ?? emptyProcessPleadingDraft(caseId), checkpoint as ProcessPleadingCheckpoint, remarks),
          expectedRevision: draft?.revision ?? 0
        });
        return await dependencies.workspace.saveProcessPleadingState({
          caseId,
          caseDataKey,
          keyVersion,
          state: next,
          expectedRevision: current.revision
        });
      });
      res.json({ caseId, state });
    } catch (error) {
      sendError(res, error);
    }
  });

  app.post(
    "/api/cases/:caseId/workflow/process-pleading/reset",
    async (req, res) => {
      try {
        const actor = actorFor(req);
        const caseId = caseIdFrom(req);
        const expectedRevision =
          Number(req.body?.expectedRevision);
        const confirmation =
          typeof req.body?.confirmation === "string"
            ? req.body.confirmation
            : "";

        if (
          confirmation !==
            "RESET_PROCESS_PLEADING" ||
          !Number.isSafeInteger(
            expectedRevision
          ) ||
          expectedRevision < 1
        ) {
          throw new Error(
            "PROCESS_PLEADING_RESET_REQUEST_INVALID"
          );
        }

        dependencies.caseAccessService.assertAccess(
          actor,
          caseId,
          "WRITE"
        );
        const caseView =
          dependencies.caseAccessService.openCase(
            actor,
            caseId
          );
        const cleared =
          await dependencies.caseAccessService
            .withCaseDataKey(
              actor,
              caseId,
              "WRITE",
              (caseDataKey) =>
                dependencies.workspace
                  .clearProcessPleadingState({
                    caseId,
                    caseDataKey,
                    keyVersion:
                      caseView.keyVersion,
                    expectedRevision
                  })
            );

        if (!cleared) {
          throw new Error(
            "PROCESS_PLEADING_STATE_NOT_FOUND"
          );
        }
        res.json({
          caseId,
          reset: true
        });
      } catch (error) {
        sendError(res, error);
      }
    }
  );

  app.get(
    "/api/cases/:caseId/workflow/court-analysis",
    async (req, res) => {
      try {
        const actor = actorFor(req);
        const caseId = caseIdFrom(req);
        dependencies.caseAccessService
          .assertAccess(
            actor,
            caseId,
            "READ"
          );
        const caseView =
          dependencies.caseAccessService
            .openCase(
              actor,
              caseId
            );
        const state =
          await dependencies
            .caseAccessService
            .withCaseDataKey(
              actor,
              caseId,
              "READ",
              (caseDataKey) =>
                dependencies.workspace
                  .getCourtAnalysisState({
                    caseId,
                    caseDataKey,
                    keyVersion:
                      caseView.keyVersion
                  })
            );
        res.json({
          caseId,
          state
        });
      } catch (error) {
        sendError(res, error);
      }
    }
  );

  app.post(
    "/api/cases/:caseId/workflow/court-analysis/initialize",
    async (req, res) => {
      try {
        const actor = actorFor(req);
        const caseId = caseIdFrom(req);
        dependencies.caseAccessService
          .assertAccess(
            actor,
            caseId,
            "WRITE"
          );
        const caseView =
          dependencies.caseAccessService
            .openCase(
              actor,
              caseId
            );
        const state =
          await dependencies
            .caseAccessService
            .withCaseDataKey(
              actor,
              caseId,
              "WRITE",
              async (caseDataKey) => {
                const existing =
                  await dependencies
                    .workspace
                    .getCourtAnalysisState({
                      caseId,
                      caseDataKey,
                      keyVersion:
                        caseView.keyVersion
                    });
                if (existing) {
                  throw new Error(
                    "COURT_ANALYSIS_STATE_EXISTS"
                  );
                }
                return await dependencies
                  .workspace
                  .saveCourtAnalysisState({
                    caseId,
                    caseDataKey,
                    keyVersion:
                      caseView.keyVersion,
                    state:
                      createCourtAnalysisState(
                        caseId
                      )
                  });
              }
            );
        res.status(201).json({
          caseId,
          state
        });
      } catch (error) {
        sendError(res, error);
      }
    }
  );

  app.post(
    "/api/cases/:caseId/workflow/court-analysis/reset",
    async (req, res) => {
      try {
        const actor = actorFor(req);
        const caseId = caseIdFrom(req);
        const expectedRevision =
          Number(
            req.body
              ?.expectedRevision
          );
        const confirmation =
          typeof req.body
            ?.confirmation ===
            "string"
            ? req.body
                .confirmation
            : "";

        if (
          confirmation !==
            "RESET_COURT_ANALYSIS" ||
          !Number.isSafeInteger(
            expectedRevision
          ) ||
          expectedRevision < 1
        ) {
          throw new Error(
            "COURT_ANALYSIS_RESET_REQUEST_INVALID"
          );
        }

        dependencies.caseAccessService
          .assertAccess(
            actor,
            caseId,
            "WRITE"
          );
        const caseView =
          dependencies.caseAccessService
            .openCase(
              actor,
              caseId
            );
        const cleared =
          await dependencies
            .caseAccessService
            .withCaseDataKey(
              actor,
              caseId,
              "WRITE",
              (caseDataKey) =>
                dependencies.workspace
                  .clearCourtAnalysisState({
                    caseId,
                    caseDataKey,
                    keyVersion:
                      caseView.keyVersion,
                    expectedRevision
                  })
            );

        if (!cleared) {
          throw new Error(
            "COURT_ANALYSIS_STATE_NOT_FOUND"
          );
        }
        res.json({
          caseId,
          reset: true
        });
      } catch (error) {
        sendError(res, error);
      }
    }
  );

  app.get(
    "/api/cases/:caseId/workflow/chronology",
    async (req, res) => {
      try {
        const actor = actorFor(req);
        const caseId = caseIdFrom(req);
        dependencies.caseAccessService
          .assertAccess(
            actor,
            caseId,
            "READ"
          );
        const caseView =
          dependencies.caseAccessService
            .openCase(
              actor,
              caseId
            );
        const state =
          await dependencies
            .caseAccessService
            .withCaseDataKey(
              actor,
              caseId,
              "READ",
              (caseDataKey) =>
                dependencies.workspace
                  .getChronologyState({
                    caseId,
                    caseDataKey,
                    keyVersion:
                      caseView.keyVersion
                  })
            );
        res.json({
          caseId,
          state
        });
      } catch (error) {
        sendError(res, error);
      }
    }
  );

  app.post(
    "/api/cases/:caseId/workflow/chronology/initialize",
    async (req, res) => {
      try {
        const actor = actorFor(req);
        const caseId = caseIdFrom(req);
        dependencies.caseAccessService
          .assertAccess(
            actor,
            caseId,
            "WRITE"
          );
        const caseView =
          dependencies.caseAccessService
            .openCase(
              actor,
              caseId
            );
        const state =
          await dependencies
            .caseAccessService
            .withCaseDataKey(
              actor,
              caseId,
              "WRITE",
              async (caseDataKey) => {
                const existing =
                  await dependencies
                    .workspace
                    .getChronologyState({
                      caseId,
                      caseDataKey,
                      keyVersion:
                        caseView.keyVersion
                    });
                if (existing) {
                  throw new Error(
                    "CHRONOLOGY_STATE_EXISTS"
                  );
                }
                return await dependencies
                  .workspace
                  .saveChronologyState({
                    caseId,
                    caseDataKey,
                    keyVersion:
                      caseView.keyVersion,
                    state:
                      createChronologyState(
                        caseId
                      )
                  });
              }
            );
        res.status(201).json({
          caseId,
          state
        });
      } catch (error) {
        sendError(res, error);
      }
    }
  );

  app.post(
    "/api/cases/:caseId/workflow/chronology/reset",
    async (req, res) => {
      try {
        const actor = actorFor(req);
        const caseId = caseIdFrom(req);
        const expectedRevision =
          Number(
            req.body
              ?.expectedRevision
          );
        const confirmation =
          typeof req.body
            ?.confirmation ===
            "string"
            ? req.body
                .confirmation
            : "";

        if (
          confirmation !==
            "RESET_CHRONOLOGY" ||
          !Number.isSafeInteger(
            expectedRevision
          ) ||
          expectedRevision < 1
        ) {
          throw new Error(
            "CHRONOLOGY_RESET_REQUEST_INVALID"
          );
        }

        dependencies.caseAccessService
          .assertAccess(
            actor,
            caseId,
            "WRITE"
          );
        const caseView =
          dependencies.caseAccessService
            .openCase(
              actor,
              caseId
            );
        const cleared =
          await dependencies
            .caseAccessService
            .withCaseDataKey(
              actor,
              caseId,
              "WRITE",
              (caseDataKey) =>
                dependencies.workspace
                  .clearChronologyState({
                    caseId,
                    caseDataKey,
                    keyVersion:
                      caseView.keyVersion,
                    expectedRevision
                  })
            );

        if (!cleared) {
          throw new Error(
            "CHRONOLOGY_STATE_NOT_FOUND"
          );
        }
        res.json({
          caseId,
          reset: true
        });
      } catch (error) {
        sendError(res, error);
      }
    }
  );

  app.get(
    "/api/cases/:caseId/workflow/contract-analysis",
    async (req, res) => {
      try {
        const actor = actorFor(req);
        const caseId = caseIdFrom(req);
        dependencies.caseAccessService
          .assertAccess(
            actor,
            caseId,
            "READ"
          );
        const caseView =
          dependencies.caseAccessService
            .openCase(
              actor,
              caseId
            );
        const state =
          await dependencies
            .caseAccessService
            .withCaseDataKey(
              actor,
              caseId,
              "READ",
              (caseDataKey) =>
                dependencies.workspace
                  .getContractAnalysisState({
                    caseId,
                    caseDataKey,
                    keyVersion:
                      caseView.keyVersion
                  })
            );
        res.json({
          caseId,
          state
        });
      } catch (error) {
        sendError(res, error);
      }
    }
  );

  app.post(
    "/api/cases/:caseId/workflow/contract-analysis/initialize",
    async (req, res) => {
      try {
        const actor = actorFor(req);
        const caseId = caseIdFrom(req);
        const rawMode =
          typeof req.body?.mode ===
            "string"
            ? req.body.mode
                .trim()
                .toUpperCase()
            : "";
        if (
          ![
            "ANALYSIS",
            "REDACTION",
            "DRAFT",
            "SUPPLEMENT"
          ].includes(rawMode)
        ) {
          throw new Error(
            "CONTRACT_MODE_INVALID"
          );
        }
        const mode =
          rawMode as
            ContractWorkflowMode;

        dependencies.caseAccessService
          .assertAccess(
            actor,
            caseId,
            "WRITE"
          );
        const caseView =
          dependencies.caseAccessService
            .openCase(
              actor,
              caseId
            );

        const state =
          await dependencies
            .caseAccessService
            .withCaseDataKey(
              actor,
              caseId,
              "WRITE",
              async (
                caseDataKey
              ) => {
                const existing =
                  await dependencies
                    .workspace
                    .getContractAnalysisState({
                      caseId,
                      caseDataKey,
                      keyVersion:
                        caseView.keyVersion
                    });
                if (existing) {
                  throw new Error(
                    "CONTRACT_STATE_EXISTS"
                  );
                }
                return await dependencies
                  .workspace
                  .saveContractAnalysisState({
                    caseId,
                    caseDataKey,
                    keyVersion:
                      caseView.keyVersion,
                    state:
                      createContractAnalysisState(
                        caseId,
                        mode
                      )
                  });
              }
            );

        res.status(201).json({
          caseId,
          state
        });
      } catch (error) {
        sendError(res, error);
      }
    }
  );

  app.post(
    "/api/cases/:caseId/workflow/contract-analysis/reset",
    async (req, res) => {
      try {
        const actor = actorFor(req);
        const caseId = caseIdFrom(req);
        const expectedRevision =
          Number(
            req.body
              ?.expectedRevision
          );
        const confirmation =
          typeof req.body
            ?.confirmation ===
            "string"
            ? req.body
                .confirmation
            : "";

        if (
          confirmation !==
            "RESET_CONTRACT_ANALYSIS" ||
          !Number.isSafeInteger(
            expectedRevision
          ) ||
          expectedRevision < 1
        ) {
          throw new Error(
            "CONTRACT_RESET_REQUEST_INVALID"
          );
        }

        dependencies.caseAccessService
          .assertAccess(
            actor,
            caseId,
            "WRITE"
          );
        const caseView =
          dependencies.caseAccessService
            .openCase(
              actor,
              caseId
            );
        const cleared =
          await dependencies
            .caseAccessService
            .withCaseDataKey(
              actor,
              caseId,
              "WRITE",
              (caseDataKey) =>
                dependencies.workspace
                  .clearContractAnalysisState({
                    caseId,
                    caseDataKey,
                    keyVersion:
                      caseView.keyVersion,
                    expectedRevision
                  })
            );

        if (!cleared) {
          throw new Error(
            "CONTRACT_STATE_NOT_FOUND"
          );
        }
        res.json({
          caseId,
          reset: true
        });
      } catch (error) {
        sendError(res, error);
      }
    }
  );

  app.get(
    "/api/cases/:caseId/workflow/ordered/:workflowId",
    async (req, res) => {
      try {
        const actor = actorFor(req);
        const caseId = caseIdFrom(req);
        const workflowId =
          String(
            req.params.workflowId ?? ""
          ).trim() as
            OrderedCaseWorkflowId;
        if (
          ![
            "EVIDENCE_ANALYSIS_V1",
            "WITNESS_QUESTIONING_V1"
          ].includes(
            workflowId
          )
        ) {
          throw new Error(
            "ORDERED_WORKFLOW_ID_INVALID"
          );
        }
        dependencies.caseAccessService
          .assertAccess(
            actor,
            caseId,
            "ANALYZE"
          );
        const caseView =
          dependencies.caseAccessService
            .openCase(
              actor,
              caseId
            );
        const state =
          await dependencies
            .caseAccessService
            .withCaseDataKey(
              actor,
              caseId,
              "ANALYZE",
              (caseDataKey) =>
                dependencies.workspace
                  .getOrderedCaseWorkflowState({
                    caseId,
                    workflowId,
                    caseDataKey,
                    keyVersion:
                      caseView.keyVersion
                  })
            );
        res.json({
          caseId,
          workflowId,
          state,
          nextCheckpoint:
            state
              ? nextOrderedCaseCheckpoint(
                  state
                )
              : null
        });
      } catch (error) {
        sendError(res, error);
      }
    }
  );

  app.post(
    "/api/cases/:caseId/workflow/ordered/:workflowId/initialize",
    async (req, res) => {
      try {
        const actor = actorFor(req);
        const caseId = caseIdFrom(req);
        const workflowId =
          String(
            req.params.workflowId ?? ""
          ).trim() as
            OrderedCaseWorkflowId;
        if (
          ![
            "EVIDENCE_ANALYSIS_V1",
            "WITNESS_QUESTIONING_V1"
          ].includes(
            workflowId
          )
        ) {
          throw new Error(
            "ORDERED_WORKFLOW_ID_INVALID"
          );
        }
        dependencies.caseAccessService
          .assertAccess(
            actor,
            caseId,
            "WRITE"
          );
        const caseView =
          dependencies.caseAccessService
            .openCase(
              actor,
              caseId
            );
        const state =
          await dependencies
            .caseAccessService
            .withCaseDataKey(
              actor,
              caseId,
              "WRITE",
              async (
                caseDataKey
              ) => {
                const existing =
                  await dependencies
                    .workspace
                    .getOrderedCaseWorkflowState({
                      caseId,
                      workflowId,
                      caseDataKey,
                      keyVersion:
                        caseView.keyVersion
                    });
                if (existing) {
                  return existing;
                }
                return await dependencies
                  .workspace
                  .saveOrderedCaseWorkflowState({
                    caseId,
                    workflowId,
                    caseDataKey,
                    keyVersion:
                      caseView.keyVersion,
                    state:
                      createOrderedCaseWorkflowState(
                        workflowId,
                        caseId
                      )
                  });
              }
            );
        res.json({
          caseId,
          workflowId,
          state,
          nextCheckpoint:
            nextOrderedCaseCheckpoint(
              state
            )
        });
      } catch (error) {
        sendError(res, error);
      }
    }
  );

  app.post(
    "/api/cases/:caseId/workflow/ordered/:workflowId/reset",
    async (req, res) => {
      try {
        const actor = actorFor(req);
        const caseId = caseIdFrom(req);
        const workflowId =
          String(
            req.params.workflowId ?? ""
          ).trim() as
            OrderedCaseWorkflowId;
        const expectedRevision =
          Number(
            req.body
              ?.expectedRevision
          );
        const confirmation =
          typeof req.body
            ?.confirmation ===
            "string"
            ? req.body
                .confirmation
            : "";
        if (
          ![
            "EVIDENCE_ANALYSIS_V1",
            "WITNESS_QUESTIONING_V1"
          ].includes(
            workflowId
          ) ||
          confirmation !==
            "RESET_ORDERED_WORKFLOW" ||
          !Number.isSafeInteger(
            expectedRevision
          ) ||
          expectedRevision < 1
        ) {
          throw new Error(
            "ORDERED_WORKFLOW_RESET_REQUEST_INVALID"
          );
        }

        dependencies.caseAccessService
          .assertAccess(
            actor,
            caseId,
            "WRITE"
          );
        const caseView =
          dependencies.caseAccessService
            .openCase(
              actor,
              caseId
            );
        const cleared =
          await dependencies
            .caseAccessService
            .withCaseDataKey(
              actor,
              caseId,
              "WRITE",
              (caseDataKey) =>
                dependencies.workspace
                  .clearOrderedCaseWorkflowState({
                    caseId,
                    workflowId,
                    caseDataKey,
                    keyVersion:
                      caseView.keyVersion,
                    expectedRevision
                  })
            );
        if (!cleared) {
          throw new Error(
            "ORDERED_WORKFLOW_STATE_NOT_FOUND"
          );
        }
        res.json({
          caseId,
          workflowId,
          reset: true
        });
      } catch (error) {
        sendError(res, error);
      }
    }
  );

  app.post("/api/cases/:caseId/workspace/folders", async (req, res) => {
    try {
      const actor = actorFor(req);
      const caseId = caseIdFrom(req);
      const name = typeof req.body?.name === "string" ? req.body.name : "";
      const parentId = req.body?.parentId === null || req.body?.parentId === undefined
        ? null
        : String(req.body.parentId);
      const caseView = dependencies.caseAccessService.openCase(actor, caseId);
      const folder = await dependencies.caseAccessService.withCaseDataKey(
        actor,
        caseId,
        "WRITE",
        (caseDataKey) => dependencies.workspace.createFolder({
          caseId,
          caseDataKey,
          keyVersion: caseView.keyVersion,
          name,
          parentId
        })
      );
      res.status(201).json({ folder });
    } catch (error) {
      sendError(res, error);
    }
  });

  app.delete("/api/cases/:caseId/workspace/folders/:folderId", async (req, res) => {
    try {
      const actor = actorFor(req);
      const caseId = caseIdFrom(req);
      const folderId = String(req.params.folderId ?? "");
      if (!FOLDER_ID.test(folderId)) throw new Error("WORKSPACE_FOLDER_ID_INVALID");
      const caseView = dependencies.caseAccessService.openCase(actor, caseId);
      await dependencies.caseAccessService.withCaseDataKey(
        actor,
        caseId,
        "WRITE",
        (caseDataKey) => dependencies.workspace.deleteFolder({
          caseId,
          caseDataKey,
          keyVersion: caseView.keyVersion,
          folderId
        })
      );
      res.status(204).end();
    } catch (error) {
      sendError(res, error);
    }
  });

  app.patch("/api/cases/:caseId/workspace/items/:itemId", async (req, res) => {
    try {
      const actor = actorFor(req);
      const caseId = caseIdFrom(req);
      const itemId = String(req.params.itemId ?? "");
      const folderId = req.body?.folderId === null ? null : String(req.body?.folderId ?? "");
      const data = await resourcesFor(actor, caseId, "WRITE");
      await dependencies.caseAccessService.withCaseDataKey(
        actor,
        caseId,
        "WRITE",
        (caseDataKey) => dependencies.workspace.moveItem({
          caseId,
          caseDataKey,
          keyVersion: data.caseView.keyVersion,
          itemId,
          folderId,
          knownItemIds: data.itemIds
        })
      );
      res.json({ itemId, folderId });
    } catch (error) {
      sendError(res, error);
    }
  });

  app.delete("/api/cases/:caseId/workspace/items/:itemId", async (req, res) => {
    try {
      const actor = actorFor(req);
      const caseId = caseIdFrom(req);
      const itemId = String(req.params.itemId ?? "");
      const data = await resourcesFor(actor, caseId, "WRITE");
      if (!data.itemIds.includes(itemId)) throw new Error("WORKSPACE_ITEM_NOT_FOUND");

      if (UPLOAD_ID.test(itemId)) {
        const upload = data.uploads.find((item) => item.uploadId === itemId);
        if (!upload) throw new Error("WORKSPACE_ITEM_NOT_FOUND");
        await dependencies.caseAccessService.withCaseDataKey(
          actor,
          caseId,
          "WRITE",
          async (caseDataKey) => {
            const payload = await dependencies.uploads.readUploadPayload({
              caseId,
              uploadId: itemId,
              caseDataKey,
              keyVersion: data.caseView.keyVersion,
              maxBytes: Math.max(1, upload.bytes)
            });
            payload.fill(0);

            const documentIds = [
              ...new Set(
                [
                  upload.sha256,
                  ...upload.extracted.map((entry) => entry.sha256)
                ].map(documentIdFromSha256)
              )
            ];
            // Ten sam plik wgrany drugi raz ma ten sam dokument: jego wersja
            // zanonimizowana i klucz zostają, dopóki używa ich inny upload.
            const stillUsed = new Set(
              data.uploads
                .filter((item) => item.uploadId !== itemId)
                .flatMap((item) => [item.sha256, ...item.extracted.map((entry) => entry.sha256)])
                .map(documentIdFromSha256)
            );
            for (const documentId of documentIds) {
              if (stillUsed.has(documentId)) continue;
              const protectedDocuments = dependencies.protectedDocuments;
              await dependencies.privacyVaults.deleteDocumentVault({
                caseId,
                documentId,
                caseDataKey,
                keyVersion: data.caseView.keyVersion,
                ...(protectedDocuments
                  ? {
                      remainingText: async (memberIds: string[]) => {
                        const texts: string[] = [];
                        for (const memberId of memberIds) {
                          try {
                            const ingestion = await protectedDocuments.loadProtected({
                              caseId,
                              documentId: memberId,
                              caseDataKey,
                              keyVersion: data.caseView.keyVersion
                            });
                            texts.push(JSON.stringify(ingestion));
                          } catch {
                            // Nieczytelny dokument: nie wiadomo, czego używa, klucz zostaje.
                            return null;
                          }
                        }
                        return texts;
                      }
                    }
                  : {})
              });
              await purgeSecureCaseDocument({
                rootDir: dependencies.rootDir,
                caseId,
                documentId
              });
              dependencies.documentService.forget(documentId);
            }

            const target = path.resolve(
              dependencies.rootDir,
              "cases",
              caseId,
              "secure",
              "incoming",
              itemId
            );
            const base = path.resolve(
              dependencies.rootDir,
              "cases",
              caseId,
              "secure",
              "incoming"
            ) + path.sep;
            if (!target.startsWith(base)) throw new Error("CASE_PATH_ESCAPE");
            await rm(target, { recursive: true, force: true });
            await dependencies.workspace.forgetItem({
              caseId,
              caseDataKey,
              keyVersion: data.caseView.keyVersion,
              itemId
            });
          }
        );
      } else if (TEMPLATE_ID.test(itemId)) {
        if (data.caseView.caseKind !== "FIRM_KNOWLEDGE" || actor.user.appRole !== "ADMIN") {
          throw new Error("CASE_ACCESS_DENIED");
        }
        const template = await dependencies.templates.readTemplate(itemId);
        template.data.fill(0);
        const target = path.resolve(dependencies.templates.templatesDir, itemId);
        const base = path.resolve(dependencies.templates.templatesDir) + path.sep;
        if (!target.startsWith(base)) throw new Error("TEMPLATE_PATH_ESCAPE");
        await rm(target, { recursive: true, force: true });
        await dependencies.caseAccessService.withCaseDataKey(
          actor,
          caseId,
          "WRITE",
          (caseDataKey) => dependencies.workspace.forgetItem({
            caseId,
            caseDataKey,
            keyVersion: data.caseView.keyVersion,
            itemId
          })
        );
      } else {
        throw new Error("WORKSPACE_ITEM_NOT_FOUND");
      }
      res.status(204).end();
    } catch (error) {
      sendError(res, error);
    }
  });

  const readItem = async (
    actor: ReturnType<typeof actorFor>,
    caseId: string,
    itemId: string,
    maxBytes: number
  ): Promise<{ filename: string; mediaType: string; data: Buffer }> => {
    const data = await resourcesFor(actor, caseId, "READ");
    if (UPLOAD_ID.test(itemId)) {
      const upload = data.uploads.find((item) => item.uploadId === itemId);
      if (!upload) throw new Error("WORKSPACE_ITEM_NOT_FOUND");
      if (upload.bytes > maxBytes) throw new Error("WORKSPACE_ITEM_TOO_LARGE");
      const payload = await dependencies.caseAccessService.withCaseDataKey(
        actor,
        caseId,
        "READ",
        (caseDataKey) => dependencies.uploads.readUploadPayload({
          caseId,
          uploadId: itemId,
          caseDataKey,
          keyVersion: data.caseView.keyVersion,
          maxBytes
        })
      );
      return { filename: upload.filename, mediaType: upload.mediaType, data: payload };
    }
    if (ARTIFACT_ID.test(itemId) && dependencies.artifacts) {
      const artifacts = dependencies.artifacts;
      return await dependencies.caseAccessService.withCaseDataKey(
        actor,
        caseId,
        "READ",
        async (caseDataKey) => {
          const context = { caseId, caseDataKey, keyVersion: data.caseView.keyVersion };
          const artifact = (await artifacts.listArtifacts(context)).find(
            (item) => item.artifactId === itemId
          );
          if (!artifact) throw new Error("WORKSPACE_ITEM_NOT_FOUND");
          if (artifact.bytes > maxBytes) throw new Error("WORKSPACE_ITEM_TOO_LARGE");
          return {
            filename: artifact.filename,
            mediaType: artifact.mediaType,
            data: await artifacts.readArtifact({ ...context, artifactId: itemId, maxBytes })
          };
        }
      );
    }
    if (TEMPLATE_ID.test(itemId) && data.caseView.caseKind === "FIRM_KNOWLEDGE") {
      const template = await dependencies.templates.readTemplate(itemId);
      if (template.data.byteLength > maxBytes) {
        template.data.fill(0);
        throw new Error("WORKSPACE_ITEM_TOO_LARGE");
      }
      return {
        filename: template.manifest.filename,
        mediaType: template.manifest.mediaType,
        data: template.data
      };
    }
    throw new Error("WORKSPACE_ITEM_NOT_FOUND");
  };

  // Documents made by a model in this case: the file with placeholders and
  // the deanonymized file made from it (sourceArtifactId).
  app.get("/api/cases/:caseId/workspace/artifacts", async (req, res) => {
    try {
      const actor = actorFor(req);
      const caseId = caseIdFrom(req);
      if (!dependencies.artifacts) {
        res.json({ artifacts: [] });
        return;
      }
      const artifacts = dependencies.artifacts;
      dependencies.caseAccessService.assertAccess(actor, caseId, "READ");
      const caseView = dependencies.caseAccessService.openCase(actor, caseId);
      const list = await dependencies.caseAccessService.withCaseDataKey(
        actor,
        caseId,
        "READ",
        (caseDataKey) => artifacts.listArtifacts({ caseId, caseDataKey, keyVersion: caseView.keyVersion })
      );
      res.setHeader("Cache-Control", "no-store");
      res.json({
        artifacts: list.map((item) => ({
          artifactId: item.artifactId,
          filename: item.filename,
          mediaType: item.mediaType,
          bytes: item.bytes,
          createdAt: item.createdAt,
          sensitivity: item.sensitivity,
          ...(item.sourceArtifactId ? { sourceArtifactId: item.sourceArtifactId } : {})
        }))
      });
    } catch (error) {
      sendError(res, error);
    }
  });

  // Renames a document made by a model; the case files and the chat card
  // both read the name from the artifact manifest.
  app.patch("/api/cases/:caseId/workspace/artifacts/:artifactId", async (req, res) => {
    try {
      const actor = actorFor(req);
      const caseId = caseIdFrom(req);
      const artifactId = String(req.params.artifactId ?? "");
      if (!ARTIFACT_ID.test(artifactId)) throw new Error("ARTIFACT_ID_INVALID");
      const filename = typeof req.body?.filename === "string" ? req.body.filename : "";
      if (!dependencies.artifacts) throw new Error("ARTIFACT_NOT_FOUND");
      const artifacts = dependencies.artifacts;
      dependencies.caseAccessService.assertAccess(actor, caseId, "WRITE");
      const caseView = dependencies.caseAccessService.openCase(actor, caseId);
      const renamed = await dependencies.caseAccessService.withCaseDataKey(
        actor,
        caseId,
        "WRITE",
        (caseDataKey) => artifacts.renameArtifact({
          caseId,
          artifactId,
          filename,
          caseDataKey,
          keyVersion: caseView.keyVersion
        })
      );
      res.json({ artifactId, filename: renamed.filename });
    } catch (error) {
      sendError(res, error);
    }
  });

  app.get("/api/cases/:caseId/workspace/items/:itemId/preview", async (req, res) => {
    let payload: Buffer | undefined;
    try {
      const actor = actorFor(req);
      const item = await readItem(actor, caseIdFrom(req), String(req.params.itemId ?? ""), PREVIEW_MAX_BYTES);
      payload = item.data;
      res.setHeader("Content-Type", item.mediaType || "application/octet-stream");
      res.setHeader("Content-Disposition", contentDisposition(item.filename));
      res.setHeader("Cache-Control", "no-store");
      sendAndWipe(res, payload);
      payload = undefined;
    } catch (error) {
      sendError(res, error);
    } finally {
      payload?.fill(0);
    }
  });

  // Editable model of a DOCX/ODT document or XLSX/CSV sheet for the in-app editor.
  app.get("/api/cases/:caseId/workspace/items/:itemId/editable", async (req, res) => {
    let payload: Buffer | undefined;
    try {
      if (!dependencies.officeEditor) throw new Error("OFFICE_EDIT_UNAVAILABLE");
      const actor = actorFor(req);
      const item = await readItem(actor, caseIdFrom(req), String(req.params.itemId ?? ""), PREVIEW_MAX_BYTES);
      payload = item.data;
      const mediaType = editableMediaType(item.mediaType, item.filename);
      if (!mediaType) throw new Error("OFFICE_EDIT_MEDIA_TYPE_UNSUPPORTED");
      const model = await dependencies.officeEditor.read(payload, mediaType);
      res.setHeader("Cache-Control", "no-store");
      res.json({ filename: item.filename, mediaType: item.mediaType, model });
    } catch (error) {
      sendError(res, error);
    } finally {
      payload?.fill(0);
    }
  });

  // An edited model rendered to a new file; the client stores it as a new
  // case file, so the original is never overwritten.
  app.post("/api/cases/:caseId/workspace/render", async (req, res) => {
    let output: Buffer | undefined;
    try {
      if (!dependencies.officeEditor) throw new Error("OFFICE_EDIT_UNAVAILABLE");
      const actor = actorFor(req);
      dependencies.caseAccessService.assertAccess(actor, caseIdFrom(req), "WRITE");
      const format = String(req.body?.format ?? "") as EditableFormat;
      const model = req.body?.model as EditableModel | undefined;
      if (!(format in FORMAT_MEDIA_TYPE) || !model || typeof model !== "object") {
        throw new Error("OFFICE_EDIT_INVALID_REQUEST");
      }
      const delimiter = typeof req.body?.delimiter === "string" ? req.body.delimiter.slice(0, 1) : undefined;
      // Tracked changes: the author is the signed-in user, never a name sent by the client.
      const baseline = req.body?.trackChanges?.baseline as EditableModel | undefined;
      const track =
        format === "docx" && baseline && typeof baseline === "object" && baseline.kind === "document"
          ? { baseline, author: actor.user.displayName, date: new Date().toISOString().replace(/\.\d{3}Z$/u, "Z") }
          : undefined;
      output = await dependencies.officeEditor.write(format, model, delimiter, track);
      res.setHeader("Content-Type", FORMAT_MEDIA_TYPE[format]);
      res.setHeader("Cache-Control", "no-store");
      sendAndWipe(res, output);
      output = undefined;
    } catch (error) {
      sendError(res, error);
    } finally {
      output?.fill(0);
    }
  });

  // Fields of a PDF form in the case files.
  app.get("/api/cases/:caseId/workspace/items/:itemId/form", async (req, res) => {
    let payload: Buffer | undefined;
    try {
      if (!dependencies.pdfForms) throw new Error("PDF_FORM_UNAVAILABLE");
      const actor = actorFor(req);
      const item = await readItem(actor, caseIdFrom(req), String(req.params.itemId ?? ""), PREVIEW_MAX_BYTES);
      payload = item.data;
      if (!isPdf(item.mediaType, item.filename)) throw new Error("PDF_FORM_MEDIA_TYPE_UNSUPPORTED");
      res.setHeader("Cache-Control", "no-store");
      res.json({ filename: item.filename, fields: await dependencies.pdfForms.fields(payload) });
    } catch (error) {
      sendError(res, error);
    } finally {
      payload?.fill(0);
    }
  });

  // The form filled in as a new PDF; the client stores it as a new case file.
  app.post("/api/cases/:caseId/workspace/items/:itemId/form/fill", async (req, res) => {
    let payload: Buffer | undefined;
    let output: Buffer | undefined;
    try {
      if (!dependencies.pdfForms) throw new Error("PDF_FORM_UNAVAILABLE");
      const actor = actorFor(req);
      const caseId = caseIdFrom(req);
      dependencies.caseAccessService.assertAccess(actor, caseId, "WRITE");
      const values = pdfFormValues(req.body?.values);
      const item = await readItem(actor, caseId, String(req.params.itemId ?? ""), PREVIEW_MAX_BYTES);
      payload = item.data;
      if (!isPdf(item.mediaType, item.filename)) throw new Error("PDF_FORM_MEDIA_TYPE_UNSUPPORTED");
      output = await dependencies.pdfForms.fill(payload, values, req.body?.flatten === true);
      res.setHeader("Content-Type", "application/pdf");
      res.setHeader("Cache-Control", "no-store");
      sendAndWipe(res, output);
      output = undefined;
    } catch (error) {
      sendError(res, error);
    } finally {
      payload?.fill(0);
      output?.fill(0);
    }
  });

  app.post("/api/cases/:caseId/workspace/items/:itemId/open", async (req, res) => {
    let payload: Buffer | undefined;
    try {
      const actor = actorFor(req);
      const item = await readItem(actor, caseIdFrom(req), String(req.params.itemId ?? ""), OPEN_MAX_BYTES);
      payload = item.data;
      const token = await stageWorkspaceOpenCopy(path.join(os.tmpdir(), "LexMachinaOpen"), item.filename, payload);
      res.json({
        token,
        filename: item.filename,
        expiresAt: new Date(Date.now() + 60 * 60 * 1000).toISOString()
      });
    } catch (error) {
      sendError(res, error);
    } finally {
      payload?.fill(0);
    }
  });

  app.get("/api/cases/:caseId/workspace/thread", async (req, res) => {
    try {
      const actor = actorFor(req);
      const caseId = caseIdFrom(req);
      const caseView = dependencies.caseAccessService.openCase(actor, caseId);
      const messages = await dependencies.caseAccessService.withCaseDataKey(
        actor,
        caseId,
        "READ",
        (caseDataKey) => dependencies.workspace.loadThread({
          caseId,
          caseDataKey,
          keyVersion: caseView.keyVersion
        })
      );
      res.json({ caseId, messages });
    } catch (error) {
      sendError(res, error);
    }
  });

  app.post("/api/cases/:caseId/workspace/thread/messages", async (req, res) => {
    try {
      const actor = actorFor(req);
      const caseId = caseIdFrom(req);
      const caseView = dependencies.caseAccessService.openCase(actor, caseId);
      const raw = req.body as Partial<WorkspaceThreadMessage>;
      const message: WorkspaceThreadMessage = {
        messageId: String(raw.messageId ?? ""),
        role: raw.role as WorkspaceThreadMessage["role"],
        content: String(raw.content ?? ""),
        createdAt: String(raw.createdAt ?? ""),
        ...(typeof raw.meta === "string" ? { meta: raw.meta } : {}),
        ...(Array.isArray(raw.documentCitations)
          ? {
              documentCitations:
                raw.documentCitations as NonNullable<
                  WorkspaceThreadMessage["documentCitations"]
                >
            }
          : {}),
        ...(Array.isArray(raw.restorations)
          ? {
              restorations:
                raw.restorations as NonNullable<
                  WorkspaceThreadMessage["restorations"]
                >
            }
          : {}),
        ...(Array.isArray(raw.widgets)
          ? { widgets: raw.widgets as NonNullable<WorkspaceThreadMessage["widgets"]> }
          : {}),
        ...(raw.evidence !== undefined ? { evidence: raw.evidence } : {}),
        ...(raw.auxiliarySources !== undefined ? { auxiliarySources: raw.auxiliarySources } : {}),
        ...(raw.mandatoryPath !== undefined ? { mandatoryPath: raw.mandatoryPath } : {}),
        ...(raw.pipelineNext !== undefined ? { pipelineNext: raw.pipelineNext } : {}),
        ...(raw.documentCoverage !== undefined ? { documentCoverage: raw.documentCoverage } : {}),
        ...(raw.documentAnalysis !== undefined ? { documentAnalysis: raw.documentAnalysis } : {}),
        ...(raw.answerDocument !== undefined ? { answerDocument: raw.answerDocument as NonNullable<WorkspaceThreadMessage["answerDocument"]> } : {}),
        ...(raw.corrections !== undefined ? { corrections: raw.corrections } : {}),
        ...(raw.generatedDocument && typeof raw.generatedDocument === "object"
          ? {
              generatedDocument:
                raw.generatedDocument as NonNullable<
                  WorkspaceThreadMessage["generatedDocument"]
                >
            }
          : {})
      };
      const saved = await dependencies.caseAccessService.withCaseDataKey(
        actor,
        caseId,
        "WRITE",
        (caseDataKey) => dependencies.workspace.appendThreadMessage({
          caseId,
          caseDataKey,
          keyVersion: caseView.keyVersion,
          message
        })
      );
      res.status(201).json({ message: saved });
    } catch (error) {
      sendError(res, error);
    }
  });
}
