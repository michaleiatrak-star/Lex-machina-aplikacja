import { encryptedKind, passwordFromHeader, type DocumentDecryptor } from "../document-decryption.js";
import { RECORDING_MEDIA_TYPES } from "../transcription.js";
import { lastFailedApplicationUpdate } from "../application-update-journal.js";
import { parseDirectImages } from "../direct-images.js";
import { SN_PROXY_PREFIX } from "./sn-proxy.js";
import { browserSameOrigin } from "./browser-access.js";
import type { LegalStyleProfile } from "../legal-document-ast.js";
import { answerDocumentMarkup, answerValidationContext } from "../answer-document.js";
import { letterMarkupAst } from "../letter-markup.js";
import { caseLawRepository } from "../case-law-store.js";
import { evaluateCheckpointOutput, processStepDone } from "../process-checkpoint-contract.js";
import type { EvidencePolicy } from "../document-evidence.js";
import { asksAbout, asksToDraft } from "../skill-schema-catalog.js";
import {
  PERSON_CASES,
  type NameFormCorrection,
  type PersonCase,
  type PersonMorphology
} from "../privacy/person-morphology.js";
import type { PiiKind } from "../privacy/pseudonymizer.js";
import { FORMAT_MEDIA_TYPE, LocalOfficeEditor, editableMediaType } from "../office-edit.js";
import { anonymizeDocx } from "../docx-anonymize.js";
import { deanonymizeModel } from "../deanonymize-file.js";
import { decodePlainText } from "../document-service.js";
import {
  ProcessingProgressRegistry,
  progressIdFrom
} from "../processing-progress.js";
import { createHash, randomUUID } from "node:crypto";
import express, {
  type Express,
  type NextFunction,
  type Request,
  type Response
} from "express";
import helmet from "helmet";
import { saveToDownloads } from "../download-save.js";
import fs from "node:fs";
import { LexSkillRegistry } from "../registry.js";
import { latestUserTurn } from "../execution-engine.js";
import { applyPleadingChatReply, bareRefusal, lastAssistantTurn, reopensDraft, pleadingChatReply, pleadingContinuationQuery, PLEADING_CONTINUATION } from "../process-pleading-chat-reply.js";
import { threadUserText } from "../skill-selection.js";
import {
  appendDraftVersion,
  emptyProcessPleadingDraft,
  withDraftRemarks,
  latestDraftVersion,
  PLEADING_CONTINUATIONS_MAX,
  PLEADING_END,
  PLEADING_START,
  pleadingContinuationPrompt,
  pleadingStepText,
  withoutDraftRemarks,
  writesPleading
} from "../process-pleading-draft.js";

// The citations that blocked a part of a long letter, as the corrections its rewrite needs.
function blockedPartProblems(references: ReadonlyArray<{ claim: string; status: string }>): string[] {
  const seen = new Set<string>();
  const problems: string[] = [];
  for (const reference of references) {
    if (seen.has(reference.claim)) continue;
    seen.add(reference.claim);
    problems.push(
      reference.status === "CONFLICTING_STATUS"
        ? `${reference.claim}: sprzeczne oznaczenia weryfikacji`
        : `${reference.claim}: niezweryfikowany w ELI (sprawdź, czy to właściwy akt, np. u.p.k. zamiast KC; zweryfikuj albo usuń powołanie)`
    );
    if (problems.length >= 12) break;
  }
  return problems.length ? problems : ["część zablokowana przez bramki weryfikacji: napisz ją ponownie z powołaniami zweryfikowanymi w ELI"];
}

// A writing step whose pleading text was not kept (cut, unfinished, a change to no section).
function pleadingDraftNotice(checkpoint: string, problems: readonly string[]): string {
  return `**Projekt pisma nie został zaktualizowany (${checkpoint}):** ${problems.join("; ")}. Zapisana pozostaje poprzednia wersja; powtórz krok albo popraw projekt.`;
}

// A message that only moves a document pipeline on (its subject is earlier in the thread).
const PIPELINE_CONTINUATION =
  /(?<![\p{L}])(?:kontynuuj\p{L}*|dalej|następn\p{L}*\s+etap|kolejn\p{L}*\s+etap|zatwierdzam|akceptuj\p{L}*|potwierdzam|popraw\p{L}*|uzupełnij\p{L}*|pipeline\p{L}*|checkpoint\p{L}*)(?![\p{L}])/iu;
import {
  DynamicModelCatalog,
  type ModelDescriptor
} from "../providers/model-catalog.js";
import {
  MissingProviderCredentialError,
  providerConfigurationStatus,
  type ProviderCredentialResolver,
  type ProviderCredentialManager
} from "../providers/credentials.js";
import {
  ProviderGatewayError
} from "../providers/gateway.js";
import { accountPolicyResponse } from "../server-mode/service.js";
import type { ProviderId } from "../providers/types.js";
import type {
  AccountSessionManager
} from "../providers/account-session.js";
import type {
  UpdateDiscovery
} from "../update-discovery.js";
import {
  SESSION_EXECUTION_INTERNAL,
  type SessionDocumentAttachment,
  type SessionExecutor,
  type SessionExecutionRequest,
  type SessionExecutionResponse
} from "../session-executor.js";
import type { CaseFileAccess } from "../case-file-tool-runtime.js";
import { mergeThreadEvidence, type ThreadEvidence } from "../thread-evidence.js";
import { caseMaterialSignatures } from "../finalization-gate.js";
import { realValueHashes } from "../privacy/example-data.js";
import { defaultTemplateFor, draftingTarget, validTemplateRole, type GenerationDocumentType } from "../template-roles.js";
import { detectQueryMode, parseModeSignals, type ModeSignals } from "../query-mode.js";
import {
  MAX_SUMMARY_CHARS,
  SUMMARY_CHUNK_CHARS,
  droppedMessageCount,
  queryWithSummary,
  summaryForDroppedHistory
} from "../thread-summary.js";
import type {
  DocumentChunkSelection,
  DocumentSecurityContext,
  DocumentService,
  KeyGrammar,
  ResolvedDocumentAttachment,
  PagePrivacyDirective,
  SupportedDocumentMediaType
} from "../document-service.js";
import { RoutingCatalog } from "./routing-catalog.js";
import {
  decodeUploadFilename,
  type LocalCaseFileStore
} from "../case-file-store.js";
import {
  AuthError,
  type AuthService
} from "../auth/service.js";
import {
  SupportError,
  type LocalSupportService,
  type SupportSessionView
} from "../support-service.js";
import type {
  AuthenticatedContext,
  CaseRole
} from "../auth/types.js";
import {
  parseGuideTransition,
  type GuideSessionStateStore
} from "../guide-session-state.js";
import {
  CaseAccessError,
  type LocalCaseAccessService
} from "../case-access.js";
import {
  ReauthorizationError,
  type DeanonymizationReauthorizationManager
} from "../auth/reauthorization.js";
import {
  ExportGateBlockedError,
  type LocalDocumentAuthoringService
} from "../document-authoring-service.js";
import {
  DocumentAstSessionBlockedError,
  type LegalDocumentAstGenerator
} from "../legal-document-ast-generator.js";
import type {
  LocalTemplateProfileService
} from "../template-profile-service.js";
import type {
  LocalCaseKnowledgeSearch
} from "../case-knowledge-search.js";
import type {
  LocalSharedTemplateStore
} from "../shared-template-store.js";
import { DOCX_MEDIA_TYPE } from "../shared-template-store.js";
import { ExecutionSteps, type ExecutionPhase } from "../execution-steps.js";
import {
  ContextBudgetError,
  estimateDocumentFit,
  HOSTED_CONTEXT_TOKENS,
  LOCAL_MAX_DOCUMENT_ATTACHMENTS,
  MAX_DOCUMENT_ATTACHMENTS
} from "../context-orchestrator.js";
import {
  MAX_FIRM_TEMPLATES,
  templateChunks,
  templateText
} from "../firm-template-text.js";
import type {
  SecureCaseUploadStore
} from "../case-secure-store.js";
import type {
  SecureCaseArtifactStore
} from "../case-artifact-store.js";
import type {
  SensitiveDownloadTicketManager
} from "../sensitive-download-ticket.js";
import type {
  StoredUpload
} from "../case-file-store.js";
import {
  assertStoredDocumentSignature,
  storedDocumentMediaType
} from "../stored-document-source.js";
import type {
  EncryptedCaseWorkspaceStore
} from "../case-workspace-store.js";
import type {
  DocumentGenerationStateStore
} from "../document-generation-state.js";
import {
  parseSkillSelectionEnvelope,
  resolveAdditionalSkills,
  SKILL_SELECTION_ENVELOPE_PREFIX
} from "../skill-selection.js";
import { isTrivialChatCommand } from "../execution-engine.js";
import { isFactCorrection, isNonLegalMessage, registryFlashRoutes } from "../turn-gate.js";
import {
  assessMatterComplexity,
  describeMatterComplexity
} from "../matter-complexity.js";
import {
  createDeterministicWorkflowPlan
} from "../deterministic-workflow.js";
import type {
  ProcessPleadingCheckpoint,
  ProcessPleadingStage,
  ProcessPleadingState
} from "../process-pleading-state.js";
import {
  completeProcessExecution,
  processCheckpointRegister,
  requireProcessExecutionPermit,
  type ProcessExecutionPermit
} from "../process-pleading-execution-gate.js";
import {
  PROCESS_AUTO_MAX_STEPS,
  runBoundedProcessAutoSequence
} from "../process-pleading-auto-runner.js";
import {
  applyDeterministicProcessApplicability,
  evidenceInventoryFromUploads,
  type ProcessEvidenceInventory
} from "../process-pleading-applicability.js";
import {
  createCourtAnalysisState,
  nextCourtAnalysisCheckpoint,
  type CourtAnalysisState
} from "../court-analysis-state.js";
import {
  completeCourtAnalysisExecution,
  requireCourtAnalysisExecutionPermit,
  type CourtAnalysisExecutionPermit
} from "../court-analysis-execution-gate.js";
import {
  createChronologyState,
  nextChronologyCheckpoint,
  requireChronologyTemporalGate,
  type ChronologyState
} from "../chronology-state.js";
import {
  completeChronologyExecution,
  requireChronologyExecutionPermit,
  type ChronologyExecutionPermit
} from "../chronology-execution-gate.js";
import {
  chronologyTemporalGateRequired
} from "../chronology-date-trigger.js";
import {
  nextContractCheckpoint,
  type ContractAnalysisState
} from "../contract-analysis-state.js";
import {
  completeContractExecution,
  requireContractExecutionPermit,
  type ContractExecutionPermit
} from "../contract-analysis-execution-gate.js";
import type { GoogleRecoveryController } from "../google/recovery-controller.js";
import type { GoogleWorkspaceController } from "../google/workspace-controller.js";
import type { MicrosoftController } from "../microsoft/controller.js";
import { shareWithGroup, UserGroupError, type UserGroupStore } from "../user-groups.js";
import { registerMicrosoftPublicRoutes, registerMicrosoftRoutes } from "../microsoft/http-routes.js";
import {
  registerGoogleAuthenticatedRoutes,
  registerGooglePublicRoutes,
  registerGoogleWorkspaceRoutes
} from "../google/http-routes.js";
import { chronologyBlock, chronologyFromAnswer, queryWithChronology } from "../case-chronology.js";
import { overviewBlock, overviewFromAnswer, overviewRequested, queryWithOverviewTemplate } from "../case-overview.js";
import { caseWorkBlock, caseWorkLine, recordCaseWork, turnIssues, type CaseWorkItem } from "../case-work.js";
import { addresseeCourt, courtOfCaseDocuments, type CaseCourt } from "../courts/case-court.js";
import { courtByName } from "../courts/court-base.js";
import { checkWokanda, defaultFetchText, effectiveWokandaCourt, parseCommonSignature, type FetchText } from "../courts/wokanda.js";
import { checkPart, continuationBlock, isComplete, joinParts, latestUserMessage, namesDocumentPart, nextPart, parsePart, presentPart, requestedPart, withPart, type LongDocumentState } from "../long-document.js";
import { isoDates } from "../supervised-content.js";
import {
  buildWorkflowAuditArtifact,
  isStatefulWorkflowAuditId,
  parseWorkflowAuditArtifact,
  type StatefulWorkflowAuditId
} from "../workflow-audit-artifact.js";
import {
  completeOrderedCaseExecution,
  createOrderedCaseWorkflowState,
  nextOrderedCaseCheckpoint,
  requireOrderedCaseExecutionPermit,
  type OrderedCaseExecutionPermit,
  type OrderedCaseWorkflowId,
  type OrderedCaseWorkflowState
} from "../ordered-case-workflow-state.js";

// A local model's share of the case memory (register, overview, timeline) and the thread text
// it summarizes in one call: its window is 32k tokens and every character costs time on a CPU.
const LOCAL_CASE_MEMORY_CHARS = 4_000;
const LOCAL_SUMMARY_CHUNK_CHARS = 20_000;

const PROVIDERS = new Set<ProviderId>([
  "openai",
  "anthropic",
  "xai",
  "google"
]);

// Recognizer codes behind CHAT_PRIVACY_GATE_FAILED ("Powód" in the chat diagnostics).
function privacyGateReason(error: unknown): { reason?: string } {
  const reason = (error as { reason?: unknown } | null)?.reason;
  return typeof reason === "string" && reason ? { reason } : {};
}

function isProviderId(value: string): value is ProviderId {
  return PROVIDERS.has(value as ProviderId);
}

const DOCUMENT_MEDIA_TYPES =
  new Set<SupportedDocumentMediaType>([
    "application/pdf",
    "image/jpeg",
    "image/png",
    "image/webp",
    "image/tiff",
    "text/plain",
    "text/markdown",
    "text/csv",
    "text/tab-separated-values",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "application/vnd.oasis.opendocument.text",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "application/vnd.ms-excel.sheet.macroenabled.12",
    // E-mail and RTF: read as text by the office worker.
    "message/rfc822",
    "application/rtf",
    // Recordings: the local speech-to-text model writes the text (transcription.ts).
    ...(Object.keys(RECORDING_MEDIA_TYPES) as SupportedDocumentMediaType[])
  ]);

type ImageDocumentMediaType =
  Parameters<
    DocumentService[
      "ingestImage"
    ]
  >[1];

function isImageDocumentMediaType(
  value:
    SupportedDocumentMediaType
): value is
  ImageDocumentMediaType {
  return [
    "image/jpeg",
    "image/png",
    "image/webp",
    "image/tiff"
  ].includes(value);
}

async function ingestDocumentMedia(
  service:
    DocumentService,
  data:
    Uint8Array,
  mediaType:
    SupportedDocumentMediaType,
  security?:
    Parameters<
      DocumentService[
        "review"
      ]
    >[2]
) {
  if (
    mediaType ===
      "application/pdf"
  ) {
    return await service
      .ingestPdf(
        data,
        security
      );
  }
  if (
    isImageDocumentMediaType(
      mediaType
    )
  ) {
    return await service
      .ingestImage(
        data,
        mediaType,
        security
      );
  }
  const review =
    await service.review(
      data,
      mediaType,
      security
    );
  return await service
    .finalizeReview(
      review.documentId,
      [],
      security
    );
}

function requestDocumentMediaType(
  req: Request
): SupportedDocumentMediaType | null {
  const raw = req.get("content-type")
    ?.split(";", 1)[0]
    ?.trim()
    .toLowerCase();
  return raw &&
    DOCUMENT_MEDIA_TYPES.has(
      raw as SupportedDocumentMediaType
    )
    ? raw as SupportedDocumentMediaType
    : null;
}

const PRIVACY_KINDS = new Set([
  "PESEL",
  "NIP",
  "REGON",
  "IBAN",
  "EMAIL",
  "PHONE",
  "PERSON",
  "ADDRESS",
  "ID_CARD",
  "PASSPORT",
  "KRS",
  "LAND_REGISTRY",
  "BIRTH_DATE",
  "VEHICLE_PLATE",
  "BAR_NUMBER",
  "PAYMENT_CARD",
  "CUSTOM",
  // The user's mark of a firm name (a firm token, see ManualPrivacyDirective).
  "FIRM"
] as const);

function parsePrivacyDirectives(
  value: unknown
): PagePrivacyDirective[] | null {
  if (!Array.isArray(value)) return null;

  const directives: PagePrivacyDirective[] = [];
  for (const item of value) {
    if (
      !item ||
      typeof item !== "object" ||
      Array.isArray(item)
    ) {
      return null;
    }
    const record = item as Record<string, unknown>;
    const action = record.action;
    if (
      !Number.isInteger(record.page) ||
      !Number.isInteger(record.start) ||
      !Number.isInteger(record.end) ||
      !["PSEUDONYMIZE", "KEEP", "LABEL"]
        .includes(String(action))
    ) {
      return null;
    }

    const rawKind =
      typeof record.kind === "string"
        ? record.kind
        : undefined;
    if (
      rawKind !== undefined &&
      !PRIVACY_KINDS.has(
        rawKind as
          typeof PRIVACY_KINDS extends Set<infer T>
            ? T
            : never
      )
    ) {
      return null;
    }

    const kind = rawKind as
      | NonNullable<PagePrivacyDirective["kind"]>
      | undefined;

    directives.push({
      page: Number(record.page),
      start: Number(record.start),
      end: Number(record.end),
      action: action as PagePrivacyDirective["action"],
      ...(kind !== undefined
        ? { kind }
        : {}),
      ...(typeof record.label === "string"
        ? { label: record.label }
        : {})
    });
  }
  return directives;
}

function isLoopbackOrigin(origin: string): boolean {
  try {
    const url = new URL(origin);
    return (
      (url.protocol === "http:" || url.protocol === "https:") &&
      (
        url.hostname === "localhost" ||
        url.hostname === "127.0.0.1" ||
        url.hostname === "::1" ||
        url.hostname === "[::1]"
      )
    );
  } catch {
    return false;
  }
}

/**
 * Server mode behind the firm's reverse proxy: the public address of the web
 * application (LEX_ALLOWED_ORIGINS, exact origins separated by commas).
 * Unset (the desktop): only loopback origins, as before.
 */
export function allowedPublicOrigin(origin: string): boolean {
  const allowed = process.env.LEX_ALLOWED_ORIGINS?.split(",").map((item) => item.trim()).filter(Boolean) ?? [];
  return allowed.includes(origin);
}

function loopbackOriginGuard(
  req: Request,
  res: Response,
  next: NextFunction
): void {
  const origin = req.get("origin");
  // The sandboxed sn.pl verification window (sn-proxy.ts) has an opaque origin ("null"); its
  // requests carry only the window's ticket, never the user's login.
  const snWindow = origin === "null" && req.path.startsWith(`${SN_PROXY_PREFIX}/s/`);
  if (!origin || snWindow || isLoopbackOrigin(origin) || allowedPublicOrigin(origin) || browserSameOrigin(req)) {
    next();
    return;
  }

  res.status(403).json({
    error: "ORIGIN_NOT_ALLOWED"
  });
}

export type LexHttpAppOptions = {
  registry: LexSkillRegistry;
  // Receives word forms the user corrected in a restored answer or document.
  personMorphology?: Pick<PersonMorphology, "saveCorrection">;
  modelCatalog:
    Pick<DynamicModelCatalog, "list"> &
    Partial<
      Pick<
        DynamicModelCatalog,
        | "localContextWindow"
        | "localTokenCharsPerToken"
      >
    >;
  credentialResolver?: ProviderCredentialResolver;
  credentialManager?: ProviderCredentialManager;
  accountSessions?: Pick<
    AccountSessionManager,
    | "statusAll"
    | "login"
    | "logout"
    | "setAnthropicOAuthToken"
    | "clearAnthropicOAuthToken"
  > &
    Partial<Pick<AccountSessionManager, "startProvision" | "provisionProgress" | "uninstall">>;
  updateDiscovery?: UpdateDiscovery;
  sessionExecutor?: SessionExecutor;
  guideSessionStore?: Pick<
    GuideSessionStateStore,
    | "get"
    | "initialize"
    | "transition"
    | "revoke"
  >;
  processWorkflowStore?: Pick<
    EncryptedCaseWorkspaceStore,
    | "getProcessPleadingState"
    | "saveProcessPleadingState"
  > &
    Partial<Pick<EncryptedCaseWorkspaceStore, "getProcessPleadingDraft" | "saveProcessPleadingDraft">>;
  courtAnalysisWorkflowStore?: Pick<
    EncryptedCaseWorkspaceStore,
    | "getCourtAnalysisState"
    | "saveCourtAnalysisState"
  >;
  chronologyWorkflowStore?: Pick<
    EncryptedCaseWorkspaceStore,
    | "getChronologyState"
    | "saveChronologyState"
  >;
  contractWorkflowStore?: Pick<
    EncryptedCaseWorkspaceStore,
    | "getContractAnalysisState"
    | "saveContractAnalysisState"
  >;
  // Pamięć sprawy (dowody z poprzednich odpowiedzi, streszczenie wątku).
  caseMemoryStore?: Pick<EncryptedCaseWorkspaceStore, "getCaseMemory" | "saveCaseMemory">;
  // Tests: the court sites of the wokanda check (courts/wokanda.ts).
  wokandaFetch?: FetchText;
  orderedCaseWorkflowStore?: Pick<
    EncryptedCaseWorkspaceStore,
    | "getOrderedCaseWorkflowState"
    | "saveOrderedCaseWorkflowState"
  >;
  documentGenerationState?: Pick<
    DocumentGenerationStateStore,
    "readState"
  >;
  documentService?: DocumentService;
  // Password-protected PDF/DOCX/XLSX opened with the password the user typed.
  documentDecryptor?: DocumentDecryptor;
  caseFileStore?:
    Pick<
      LocalCaseFileStore,
      | "createCase"
      | "saveUpload"
      | "assertCase"
    > &
    Partial<
      Pick<
        LocalCaseFileStore,
        "listUploads"
      >
    >;
  secureCaseUploadStore?: Pick<
    SecureCaseUploadStore,
    | "saveUpload"
    | "listUploads"
    | "readUploadPayload"
    | "readExtractedPayload"
  >;
  authService?: AuthService;
  googleRecovery?: GoogleRecoveryController;
  googleWorkspace?: GoogleWorkspaceController;
  // Named groups of users to share a case with at once (user-groups.ts).
  userGroups?: UserGroupStore;
  // OneDrive and SharePoint (Microsoft Graph), read-only.
  microsoft?: MicrosoftController;
  supportService?: Pick<
    LocalSupportService,
    | "status"
    | "issueChallenge"
    | "activate"
    | "authenticateAuthorization"
    | "assertCapability"
    | "recordOperation"
    | "deactivateAuthorization"
  >;
  sharedTemplateStore?: Pick<
    LocalSharedTemplateStore,
    | "saveTemplate"
    | "listTemplates"
  > &
    Partial<Pick<LocalSharedTemplateStore, "readTemplate" | "setRole">>;
  // Reads firm templates (DOCX/ODT) as text for the model.
  officeEditor?: Pick<LocalOfficeEditor, "read">;
  caseKnowledgeSearch?: Pick<
    LocalCaseKnowledgeSearch,
    "search"
  > &
    Partial<Pick<LocalCaseKnowledgeSearch, "listDocuments">>;
  documentAuthoringService?: Pick<
    LocalDocumentAuthoringService,
    | "aliasManifest"
    | "createTokenized"
    | "createReady"
    | "deanonymizeConsumed"
  > &
    Partial<
      Pick<
        LocalDocumentAuthoringService,
        "previewDeanonymization"
      >
    >;
  documentAstGenerator?: Pick<
    LegalDocumentAstGenerator,
    "generate"
  >;
  templateProfileService?: Pick<
    LocalTemplateProfileService,
    "resolve"
  >;
  reauthorizationManager?: Pick<
    DeanonymizationReauthorizationManager,
    | "createIntent"
    | "authorizeIntent"
    | "consumeGrant"
  > &
    Partial<
      Pick<
        DeanonymizationReauthorizationManager,
        "previewGrant" | "authorizeIntentInSession"
      >
    >;
  sensitiveDownloadTickets?: Pick<
    SensitiveDownloadTicketManager,
    | "issue"
    | "consume"
  >;
  secureCaseArtifactStore?: Pick<
    SecureCaseArtifactStore,
    | "saveArtifact"
    | "listArtifacts"
    | "readArtifact"
    | "deleteArtifact"
  >;
  caseAccessService?: Pick<
    LocalCaseAccessService,
    | "createCase"
    | "createFirmKnowledgeWorkspace"
    | "getFirmKnowledgeWorkspace"
    | "listCases"
    | "openCase"
    | "renameCase"
    | "setCaseArchived"
    | "deleteCase"
    | "listLegacyCases"
    | "importLegacyCase"
    | "assertAccess"
    | "listAccess"
    | "listAccessCandidates"
    | "grantAccess"
    | "transferOwnership"
    | "revokeAccess"
    | "rotateCaseKey"
    | "withCaseDataKey"
  > &
    Partial<Pick<LocalCaseAccessService, "listAccessOverview" | "withCaseDataKeyForRead">>;
  caseScheduleService?: Pick<
    LocalCaseAccessService,
    | "listCaseSchedule"
    | "addCaseScheduleEvent"
    | "deleteCaseScheduleEvent"
    | "listUpcomingEvents"
    | "listCaseContacts"
    | "addCaseContact"
    | "deleteCaseContact"
  >;
};

/** Steps the session audit recorded as BLOCKED (the targets, shortened). */
export function blockedAuditSteps(result: SessionExecutionResponse): string[] {
  return (result[SESSION_EXECUTION_INTERNAL]?.auditEvents ?? [])
    .filter((event) => event.status === "BLOCKED")
    .map((event) => String(event.target).slice(0, 120))
    .slice(0, 8);
}

async function persistWorkflowAuditArtifact(
  args: {
    store: Pick<
      SecureCaseArtifactStore,
      | "saveArtifact"
      | "deleteArtifact"
    >;
    caseId: string;
    caseDataKey: Buffer;
    keyVersion: number;
    createdByUserId: string;
    workflowId:
      StatefulWorkflowAuditId;
    checkpoint: string;
    result:
      SessionExecutionResponse;
  }
): Promise<{
  artifactId: string;
  auditRef: string;
  sha256: string;
  bytes: number;
}> {
  const payload =
    buildWorkflowAuditArtifact({
      caseId:
        args.caseId,
      workflowId:
        args.workflowId,
      checkpoint:
        args.checkpoint,
      result:
        args.result
    });

  try {
    const artifact =
      await args.store
        .saveArtifact({
          caseId:
            args.caseId,
          filename:
            [
              "workflow-audit",
              args.workflowId
                .toLowerCase(),
              args.checkpoint
                .toLowerCase(),
              args.result
                .sessionId
            ].join("-") +
            ".json",
          mediaType:
            "application/vnd.lexmachina.workflow-audit+json",
          data:
            payload,
          caseDataKey:
            args.caseDataKey,
          keyVersion:
            args.keyVersion,
          sensitivity:
            "PROTECTED",
          createdByUserId:
            args.createdByUserId
        });

    return {
      artifactId:
        artifact.artifactId,
      auditRef:
        "artifact://" +
        artifact.artifactId,
      sha256:
        artifact.sha256,
      bytes:
        artifact.bytes
    };
  } finally {
    payload.fill(0);
  }
}


/**
 * Ostatni handler błędów: klient dostaje tylko kod w JSON, a nie domyślną stronę Express
 * ze stosem wywołań i ścieżkami bezwzględnymi (NODE_ENV nie jest ustawiane). Szczegóły
 * zostają w logu serwera.
 */
export function jsonErrorHandler(
  error: unknown,
  _req: Request,
  res: Response,
  next: NextFunction
): void {
  const status =
    typeof (error as { status?: unknown })?.status === "number"
      ? (error as { status: number }).status
      : typeof (error as { statusCode?: unknown })?.statusCode === "number"
        ? (error as { statusCode: number }).statusCode
        : 500;
  const clientError = status >= 400 && status < 500;
  if (!clientError) {
    console.error("HTTP_UNHANDLED_ERROR", error);
  }
  if (res.headersSent) {
    next(error);
    return;
  }
  const type = (error as { type?: unknown })?.type;
  res.status(clientError ? status : 500).json({
    error: !clientError
      ? "INTERNAL_ERROR"
      : type === "entity.too.large"
        ? "REQUEST_BODY_TOO_LARGE"
        : type === "entity.parse.failed"
          ? "INVALID_JSON_BODY"
          : "BAD_REQUEST"
  });
}

function safeDiagnosticText(
  value: unknown
): string {
  const raw =
    value instanceof Error
      ? `${value.name}: ${value.message}`
      : String(value);
  return raw
    .replace(
      /Bearer\s+[A-Za-z0-9._~+\/-]+=*/gi,
      "Bearer [REDACTED]"
    )
    .replace(
      /\bsk-[A-Za-z0-9_-]{8,}\b/g,
      "sk-[REDACTED]"
    )
    .replace(
      /(api[_-]?key\s*[:=]\s*)[^\s,;]+/gi,
      "$1[REDACTED]"
    )
    .slice(0, 2000);
}

function sendReauthorizationError(
  res: Response,
  error: unknown
): boolean {
  if (
    !(error instanceof
      ReauthorizationError)
  ) {
    return false;
  }
  const status =
    error.code ===
      "REAUTH_INTENT_NOT_FOUND" ||
    error.code ===
      "REAUTH_GRANT_NOT_FOUND"
      ? 404
      : error.code ===
          "REAUTH_SESSION_MISMATCH"
        ? 403
        : 409;
  res.status(status).json({
    error: error.code
  });
  return true;
}

function sendProcessWorkflowError(
  res: Response,
  error: unknown
): boolean {
  if (
    !(error instanceof Error) ||
    !error.message.startsWith(
      "PROCESS_PLEADING_"
    )
  ) {
    return false;
  }

  res.status(409).json({
    error:
      error.message
        .split(":", 1)[0]
  });
  return true;
}

function sendCourtWorkflowError(
  res: Response,
  error: unknown
): boolean {
  if (
    !(error instanceof Error) ||
    !error.message.startsWith(
      "COURT_ANALYSIS_"
    )
  ) {
    return false;
  }

  res.status(409).json({
    error:
      error.message
        .split(":", 1)[0]
  });
  return true;
}

function sendChronologyWorkflowError(
  res: Response,
  error: unknown
): boolean {
  if (
    !(error instanceof Error) ||
    !error.message.startsWith(
      "CHRONOLOGY_"
    )
  ) {
    return false;
  }

  res.status(409).json({
    error:
      error.message
        .split(":", 1)[0]
  });
  return true;
}

function sendContractWorkflowError(
  res: Response,
  error: unknown
): boolean {
  if (
    !(error instanceof Error) ||
    !error.message.startsWith(
      "CONTRACT_"
    )
  ) {
    return false;
  }

  res.status(409).json({
    error:
      error.message
        .split(":", 1)[0]
  });
  return true;
}

const PLEADING_FIDELITY_MIN = 0.8;

// Share of the stored pleading's words (4+ letters, outside personal-data symbols)
// that the generated document carries.
export function pleadingFidelity(source: string, ast: unknown): number {
  const words = (text: string) =>
    (text
      .replace(/\[[^\]\n]{0,80}\]/g, " ")
      .toLocaleLowerCase("pl")
      .match(/\p{L}{4,}/gu) ?? []);
  const collected: string[] = [];
  const visit = (value: unknown): void => {
    if (typeof value === "string") return;
    if (Array.isArray(value)) value.forEach(visit);
    else if (value && typeof value === "object") {
      for (const [key, item] of Object.entries(value)) {
        if (key === "text" && typeof item === "string") collected.push(item);
        else visit(item);
      }
    }
  };
  visit(ast);
  const expected = words(source);
  if (!expected.length) return 1;
  const present = new Map<string, number>();
  for (const word of words(collected.join(" "))) present.set(word, (present.get(word) ?? 0) + 1);
  let found = 0;
  for (const word of expected) {
    const count = present.get(word) ?? 0;
    if (count > 0) {
      found += 1;
      present.set(word, count - 1);
    }
  }
  return found / expected.length;
}

function sendOrderedWorkflowError(
  res: Response,
  error: unknown
): boolean {
  if (!(error instanceof Error) || !error.message.startsWith("ORDERED_WORKFLOW_")) {
    return false;
  }
  const [code, workflowId] = error.message.split(":", 2);
  res.status(error.message.startsWith("ORDERED_WORKFLOW_STATE_SERVICE") ? 503 : 409).json({
    error: code,
    ...(workflowId ? { reason: workflowId } : {})
  });
  return true;
}

function sendSupportError(
  res: Response,
  error: unknown
): boolean {
  if (!(error instanceof SupportError)) {
    return false;
  }
  res.status(error.httpStatus).json({
    error: error.code
  });
  return true;
}

function sendAuthError(
  res: Response,
  error: unknown
): boolean {
  if (!(error instanceof AuthError)) {
    return false;
  }
  res.status(error.httpStatus).json({
    error: error.code,
    ...(error.retryAfter
      ? { retryAfter: error.retryAfter }
      : {})
  });
  return true;
}

// Server mode: a model call refused by the account's plan or the global limit (see server-mode/service.ts).
export function sendAccountPolicyError(
  res: Response,
  error: unknown
): boolean {
  if (!(error instanceof ProviderGatewayError) || error.code !== "ACCOUNT_POLICY") {
    return false;
  }
  const refusal = accountPolicyResponse(error.message);
  res.status(refusal.status).json(refusal.body);
  return true;
}

/** The references behind a refused export, for the user (not only reason codes). */
function exportBlockedDetails(error: unknown): Record<string, unknown> {
  return error instanceof ExportGateBlockedError
    ? { reasons: error.reasons, references: error.references, draftAvailable: error.draftAvailable }
    : {};
}

function sendCaseAccessError(
  res: Response,
  error: unknown
): boolean {
  if (
    !(error instanceof
      CaseAccessError)
  ) {
    return false;
  }
  res.status(
    error.httpStatus
  ).json({
    error: error.code
  });
  return true;
}

// A file from a long letter is converted piece by piece for many minutes (a local model: much
// longer); the desktop proxy drops a request silent for 1200 s. Asked with `keepAlive: true`,
// the response starts as 200 after DEFERRED_RESPONSE_AFTER_MS and sends a space every
// DEFERRED_RESPONSE_INTERVAL_MS (JSON allows leading whitespace); its JSON carries the real
// status as `deferredStatus`, which the client reads like the HTTP status.
const DEFERRED_RESPONSE_AFTER_MS = 20_000;
const DEFERRED_RESPONSE_INTERVAL_MS = 20_000;

/**
 * The client asked for a kept-alive response (`X-Lex-Keep-Alive: 1`, or `keepAlive: true` in a
 * JSON body): OCR with the vision model, the local model's (Bielik) check of personal data
 * and a chat answer from a local model can each run longer than the proxy waits in silence.
 */
export function keepAliveRequested(req: Request): boolean {
  if (req.get("x-lex-keep-alive") === "1") return true;
  const body: unknown = req.body;
  return Boolean(body && typeof body === "object" && !Buffer.isBuffer(body) && (body as { keepAlive?: unknown }).keepAlive === true);
}

export function keepResponseAlive(
  res: Response,
  timing: { afterMs: number; intervalMs: number } = { afterMs: DEFERRED_RESPONSE_AFTER_MS, intervalMs: DEFERRED_RESPONSE_INTERVAL_MS }
): void {
  let started = false;
  let status = 200;
  let timer: NodeJS.Timeout | undefined;
  const stop = () => clearTimeout(timer);
  const originalStatus = res.status.bind(res);
  const originalJson = res.json.bind(res);
  const beat = () => {
    if (res.writableEnded || res.destroyed) return;
    if (!started) {
      if (res.headersSent) return;
      started = true;
      originalStatus(200);
      res.setHeader("Content-Type", "application/json; charset=utf-8");
      res.setHeader("Cache-Control", "no-store");
      res.flushHeaders();
    }
    res.write(" ");
    timer = setTimeout(beat, timing.intervalMs);
  };
  timer = setTimeout(beat, timing.afterMs);
  res.once("close", stop);
  res.status = ((code: number) => {
    if (started) {
      status = code;
      return res;
    }
    return originalStatus(code);
  }) as Response["status"];
  res.json = ((body: unknown) => {
    stop();
    if (!started) return originalJson(body);
    const payload = body && typeof body === "object" && !Array.isArray(body) ? { ...(body as Record<string, unknown>), deferredStatus: status } : { body, deferredStatus: status };
    res.end(JSON.stringify(payload));
    return res;
  }) as Response["json"];
}

const EXECUTION_ID_PATTERN =
  /^[A-Za-z0-9-]{16,64}$/;
const EXECUTION_DRAFT_TTL_MS =
  15 * 60_000;
const EXECUTION_DRAFT_MAX_ENTRIES = 64;
const EXECUTION_DRAFT_MAX_CHARS = 200_000;
// While a request is still running, refresh the idle deadline this often.
const IN_FLIGHT_ACTIVITY_INTERVAL_MS = 60_000;

/**
 * Żądanie zmieniające stan (nie GET, nie blokada) przedłuża sesję; trwające żądanie
 * (długa odpowiedź lokalnego modelu, OCR, render) podtrzymuje ją, dopóki się nie skończy.
 * Raz na żądanie: trasy rejestrowane w server.ts przed coreApp też tu trafiają.
 */
function trackSessionActivity(
  authService: Pick<AuthService, "touchSession">,
  req: Request,
  res: Response,
  sessionId: string
): void {
  if (
    req.method === "GET" ||
    req.path === "/auth/lock" ||
    res.locals.lexSessionActivity === true
  ) {
    return;
  }
  res.locals.lexSessionActivity = true;
  authService.touchSession(sessionId);
  const keepAlive = setInterval(
    () => authService.touchSession(sessionId),
    IN_FLIGHT_ACTIVITY_INTERVAL_MS
  );
  keepAlive.unref();
  const stop = () => clearInterval(keepAlive);
  res.once("finish", stop);
  res.once("close", stop);
}

/**
 * Aktywność sesji dla tras zarejestrowanych poza createLexHttpApp (workspace, faktury,
 * MCP, akty podstawowe...): uwierzytelniają się same, ale nie przedłużały sesji.
 * Brak lub błąd sesji nie jest tu obsługiwany: odpowiada sama trasa.
 */
export function sessionActivityMiddleware(
  authService: Pick<AuthService, "authenticateAuthorization" | "touchSession">
): (req: Request, res: Response, next: NextFunction) => void {
  return (req, res, next) => {
    if (req.method !== "GET" && req.get("authorization")) {
      try {
        const context = authService.authenticateAuthorization(req.get("authorization"));
        trackSessionActivity(authService, req, res, context.session.sessionId);
      } catch {
        // Trasa sama odpowie błędem uwierzytelnienia.
      }
    }
    next();
  };
}

export const MAX_SESSION_QUERY_CHARS = 320_000;

function responseAuthContext(
  res: Response
): AuthenticatedContext {
  const context =
    res.locals.lexAuth as
      | AuthenticatedContext
      | undefined;
  if (!context) {
    throw new Error(
      "AUTH_CONTEXT_MISSING"
    );
  }
  return context;
}

function responseSupportContext(
  res: Response
): SupportSessionView {
  const context =
    res.locals.lexSupport as
      | SupportSessionView
      | undefined;
  if (!context) {
    throw new Error(
      "SUPPORT_CONTEXT_MISSING"
    );
  }
  return context;
}

function publicSkill(skill: {
  name: string;
  frontmatter: Record<string, unknown>;
}): Record<string, unknown> {
  const fm = skill.frontmatter;
  return {
    name: skill.name,
    ...(typeof fm.version === "string" ? { version: fm.version } : {}),
    ...(typeof fm.type === "string" ? { type: fm.type } : {}),
    ...(typeof fm.status === "string" ? { status: fm.status } : {}),
    ...(typeof fm.description === "string"
      ? { description: fm.description }
      : {}),
    category: /^dr-\d{2}-/.test(skill.name)
      ? "domain"
      : "execution"
  };
}

function sanitizeModels(models: ModelDescriptor[]): ModelDescriptor[] {
  return models.map((model) => ({ ...model }));
}

function parseDocumentAttachments(
  value: unknown
): Array<
  DocumentChunkSelection & {
    caseId?: string;
  }
> | null {
  if (value === undefined) return [];
  if (!Array.isArray(value) || value.length > MAX_DOCUMENT_ATTACHMENTS) {
    return null;
  }

  const selections: Array<
    DocumentChunkSelection & {
      caseId?: string;
    }
  > = [];
  for (const item of value) {
    if (
      !item ||
      typeof item !== "object" ||
      Array.isArray(item)
    ) {
      return null;
    }
    const record = item as Record<string, unknown>;
    const caseId =
      typeof record.caseId === "string"
        ? record.caseId.trim()
        : "";
    const documentId =
      typeof record.documentId === "string"
        ? record.documentId.trim()
        : "";
    const chunkIndices =
      Array.isArray(record.chunkIndices)
        ? record.chunkIndices
        : null;

    if (
      (
        caseId &&
        !/^case_[a-f0-9]{32}$/.test(caseId)
      ) ||
      !/^doc_[a-f0-9]{24}$/.test(documentId) ||
      !chunkIndices ||
      chunkIndices.length < 1 ||
      chunkIndices.length > 32 ||
      chunkIndices.some(
        (index) =>
          !Number.isInteger(index) ||
          Number(index) < 1
      )
    ) {
      return null;
    }

    selections.push({
      ...(caseId
        ? { caseId }
        : {}),
      documentId,
      chunkIndices:
        [...new Set(
          chunkIndices.map(Number)
        )]
    });
  }

  return selections;
}

function isFirmScope(scope: SessionDocumentAttachment["sourceScope"]): boolean {
  return scope === "FIRM_KNOWLEDGE" || scope === "FIRM_TEMPLATE";
}

/** Firm templates (DOCX/ODT from the firm workspace) sent with a message. */
/**
 * Page images a chat message sends as evidence: photos by default, pages
 * with text too when the user ticks it ("all"), none when switched off.
 * Local models read text only, so they get no images.
 */
function evidencePolicyFor(value: unknown, model: string): EvidencePolicy | undefined {
  if (model.startsWith("local/") || value === false || value === "none") return undefined;
  return value === "all" ? "all" : "photos";
}

function parseFirmTemplates(value: unknown): string[] | null {
  if (value === undefined) return [];
  if (
    !Array.isArray(value) ||
    value.length > MAX_FIRM_TEMPLATES ||
    value.some((item) => typeof item !== "string" || !/^template_[a-f0-9]{32}$/.test(item))
  ) {
    return null;
  }
  return [...new Set(value as string[])];
}

type SessionKnowledgeRequest = {
  caseId?: string;
  includeCase: boolean;
  includeFirm: boolean;
  limit: number;
};

function parseSessionKnowledgeRequest(
  value: unknown
): SessionKnowledgeRequest | null {
  if (value === undefined) {
    return {
      includeCase: false,
      includeFirm: false,
      limit: 8
    };
  }
  if (
    !value ||
    typeof value !== "object" ||
    Array.isArray(value)
  ) {
    return null;
  }

  const record =
    value as
      Record<string, unknown>;
  const caseId =
    typeof record.caseId ===
      "string"
      ? record.caseId.trim()
      : undefined;
  const includeCase =
    record.includeCase ===
      true;
  const includeFirm =
    record.includeFirm ===
      true;
  const limit =
    record.limit ===
      undefined
      ? 8
      : Number(
          record.limit
        );

  if (
    (
      caseId !== undefined &&
      !/^case_[a-f0-9]{32}$/
        .test(caseId)
    ) ||
    (
      includeCase &&
      !caseId
    ) ||
    !Number.isInteger(
      limit
    ) ||
    limit < 1 ||
    limit > 12
  ) {
    return null;
  }

  return {
    ...(caseId
      ? { caseId }
      : {}),
    includeCase,
    includeFirm,
    limit
  };
}

async function assertDocumentWorkflowFinalizationAllowed(
  options: Pick<
    LexHttpAppOptions,
    | "documentGenerationState"
    | "processWorkflowStore"
  >,
  args: {
    caseId: string;
    artifactId: string;
    caseDataKey: Buffer;
    keyVersion: number;
  }
): Promise<void> {
  if (!options.documentGenerationState) {
    throw new Error(
      "DOCUMENT_GENERATION_STATE_SERVICE_UNAVAILABLE"
    );
  }
  const generation =
    await options
      .documentGenerationState
      .readState(
        args.caseId,
        args.artifactId
      );
  if (!generation) {
    throw new Error(
      "GENERATION_STATE_MISSING"
    );
  }
  if (
    generation.workflowRequirement !==
      "PROCESS_PLEADING_FINAL"
  ) {
    return;
  }
  if (!options.processWorkflowStore) {
    throw new Error(
      "PROCESS_PLEADING_STATE_SERVICE_UNAVAILABLE"
    );
  }
  const processState =
    await options
      .processWorkflowStore
      .getProcessPleadingState({
        caseId: args.caseId,
        caseDataKey:
          args.caseDataKey,
        keyVersion:
          args.keyVersion
      });
  if (generation.processDocumentStatus === "DRAFT") {
    throw new Error("PROCESS_PLEADING_DRAFT_ARTIFACT");
  }
  if (
    !processState ||
    processState.stage !== "FINAL" ||
    processState.documentStatus !==
      "FINAL" ||
    processState.pendingCheckpoint !==
      null
  ) {
    throw new Error(
      "PROCESS_PLEADING_FINAL_REQUIRED"
    );
  }
}

/**
 * Legal gate for chat: a trivial command without attachments is answered in
 * the conversational lane. The work mode's pinned workflow, the router, case
 * retrieval and legal skills are not used for it.
 */
export function applyTrivialChatGate(
  registry: LexSkillRegistry,
  request: SessionExecutionRequest,
  attachmentCount: number
): boolean {
  const envelope =
    parseSkillSelectionEnvelope(request.query);
  if (
    attachmentCount > 0 ||
    !isTrivialChatCommand(envelope.query)
  ) {
    return false;
  }
  const domain =
    request.primarySkill.startsWith("dr-") &&
    registry.get(request.primarySkill)
      ? request.primarySkill
      : [...registry.skills.keys()]
          .filter((name) => name.startsWith("dr-"))
          .sort()[0];
  if (!domain) return false;
  request.primarySkill = domain;
  request.query =
    SKILL_SELECTION_ENVELOPE_PREFIX +
    " " +
    JSON.stringify({ auto: false, manual: [], workflow: null }) +
    "\n" +
    envelope.query;
  request.conversationalOnly = true;
  delete request.modelSelectsSkills;
  return true;
}

/**
 * A correction of a fact in a running matter (turn-gate.ts isFactCorrection): acknowledged in
 * the conversational lane with the recent conversation, the workflow step not run again; the
 * correction goes into the case's work register. Documents of the matter may be attached
 * (the client sends them with every message); the acknowledgement does not read them.
 */
export function applyFactCorrectionGate(registry: LexSkillRegistry, request: SessionExecutionRequest): boolean {
  const envelope = parseSkillSelectionEnvelope(request.query);
  if (envelope.manualSkills.length > 0 || !isFactCorrection(envelope.query)) return false;
  const domain =
    request.primarySkill.startsWith("dr-") && registry.get(request.primarySkill)
      ? request.primarySkill
      : [...registry.skills.keys()].filter((name) => name.startsWith("dr-")).sort()[0];
  if (!domain) return false;
  request.primarySkill = domain;
  request.query = SKILL_SELECTION_ENVELOPE_PREFIX + " " + JSON.stringify({ auto: false, manual: [], workflow: null }) + "\n" + envelope.query;
  request.conversationalOnly = true;
  request.factCorrection = true;
  delete request.modelSelectsSkills;
  return true;
}

/**
 * Legal gate for chat, beyond trivial commands: a general request with no legal signal
 * ("jak upiec sernik", "napisz funkcję w Pythonie") in AUTO, without documents, case
 * material, a chosen skill or a pinned workflow, is answered in the conversational
 * lane like a trivial one (turn-gate.ts; doubt stays legal). Every provider: an API
 * model no longer reads the router and the mandatory path for it, a local model no
 * longer pays for a routing pass.
 */
export function applyNonLegalChatGate(
  registry: LexSkillRegistry,
  request: SessionExecutionRequest,
  attachmentCount: number,
  caseMaterial: boolean
): boolean {
  const envelope = parseSkillSelectionEnvelope(request.query);
  if (
    attachmentCount > 0 ||
    caseMaterial ||
    request.primarySkill !== "AUTO" ||
    !envelope.automatic ||
    envelope.manualSkills.length > 0 ||
    envelope.workflowExecutionSkill !== null ||
    !isNonLegalMessage(envelope.query, registryFlashRoutes(registry))
  ) {
    return false;
  }
  const domain = [...registry.skills.keys()].filter((name) => name.startsWith("dr-")).sort()[0];
  if (!domain) return false;
  request.primarySkill = domain;
  request.query =
    SKILL_SELECTION_ENVELOPE_PREFIX +
    " " +
    JSON.stringify({ auto: false, manual: [], workflow: null }) +
    "\n" +
    envelope.query;
  request.conversationalOnly = true;
  delete request.modelSelectsSkills;
  return true;
}

/** People speaking in a recording asked for at processing: 0 (estimated) or 2-12; else none. */
export function transcriptSpeakers(value: unknown): number | undefined {
  return typeof value === "number" && Number.isInteger(value) && (value === 0 || (value >= 2 && value <= 12)) ? value : undefined;
}

/**
 * X-Lex-Processing on a raw document upload: "local-ai" (the local model also
 * checks personal data) and "ocr-fix" (the local model corrects OCR errors),
 * comma separated; absent = plain OCR and rules-based anonymization.
 */
export function documentProcessingOptions(
  header: string | undefined
): { localAi?: true; ocrFix?: true; detect?: false; background?: true } {
  const flags = new Set(
    (header ?? "")
      .split(",")
      .map((item) => item.trim().toLowerCase())
      .filter(Boolean)
  );
  return {
    ...(flags.has("local-ai") ? { localAi: true as const } : {}),
    ...(flags.has("ocr-fix") ? { ocrFix: true as const } : {}),
    // "ocr-only": read the document now, detect personal data later (POST .../detect).
    ...(flags.has("ocr-only") ? { detect: false as const } : {}),
    // "background": a file added to the case, read before the user's decision; it yields to
    // the user's own document work (see document-work.ts).
    ...(flags.has("background") ? { background: true as const } : {})
  };
}

// Workflows the engine runs only with their persisted state (G39I state binding).
const CHAT_PIPELINE_WORKFLOWS: ReadonlySet<string> = new Set([
  "LEGAL_GUIDE_V1",
  "COURT_ANALYSIS_V1",
  "CHRONOLOGY_V1",
  "CONTRACT_ANALYSIS_V1",
  "EVIDENCE_ANALYSIS_V1",
  "WITNESS_QUESTIONING_V1"
]);

function previewSessionWorkflow(
  registry: LexSkillRegistry,
  request: SessionExecutionRequest
) {
  const envelope =
    parseSkillSelectionEnvelope(
      request.query
    );
  const effectiveQuery =
    envelope.query.trim();
  if (!effectiveQuery) {
    throw new Error(
      "EMPTY_QUERY_AFTER_SKILL_ENVELOPE"
    );
  }
  const selection =
    resolveAdditionalSkills(
      registry,
      effectiveQuery,
      request.primarySkill,
      envelope.automatic,
      envelope.manualSkills,
      envelope.domainAllowList,
      envelope.domainRestrictionActive,
      envelope.executionAllowList,
      envelope.executionRestrictionActive,
      envelope.workflowExecutionSkill
    );
  return createDeterministicWorkflowPlan(
    registry,
    selection.workflowExecutionSkill
  );
}

function parseSessionRequest(
  body: unknown
): SessionExecutionRequest | null {
  if (!body || typeof body !== "object" || Array.isArray(body)) {
    return null;
  }

  const value = body as Record<string, unknown>;
  const query =
    typeof value.query === "string"
      ? value.query.trim()
      : "";
  const provider =
    typeof value.provider === "string"
      ? value.provider
      : "";
  const model =
    typeof value.model === "string"
      ? value.model.trim()
      : "";
  const primarySkill =
    typeof value.primarySkill === "string"
      ? value.primarySkill.trim()
      : "";
  const mode =
    value.mode === "LAIK" || value.mode === "PRAWNIK"
      ? value.mode
      : "PRAWNIK";
  const auxiliaryText =
    typeof value.auxiliaryText ===
      "string"
      ? value.auxiliaryText
          .normalize("NFKC")
          .trim()
      : "";

  const directImages = parseDirectImages(value.directImages);
  if (
    directImages === null ||
    query.length < 1 ||
    // Conversation history is sized to the model window by the client (Claude up to
    // ~300k characters); the envelope adds a little.
    query.length > MAX_SESSION_QUERY_CHARS ||
    !isProviderId(provider) ||
    model.length < 1 ||
    model.length > 256 ||
    primarySkill.length < 1 ||
    primarySkill.length > 160 ||
    auxiliaryText.length > 12_000
  ) {
    return null;
  }

  return {
    query,
    provider,
    model,
    primarySkill,
    mode,
    ...(auxiliaryText
      ? { auxiliaryText }
      : {}),
    ...(directImages.length ? { directImages } : {})
  };
}

// Returns the values restored from the documents' vaults (real data).
function restoreSessionDocumentAliases(
  result: SessionExecutionResponse,
  documentService:
    DocumentService | undefined
): string[] {
  const restored: string[] = [];
  if (
    !documentService
      ?.deanonymize
  ) {
    return restored;
  }

  const documentIds =
    result[
      SESSION_EXECUTION_INTERNAL
    ]?.documentAliasDocumentIds ??
    [];
  if (
    documentIds.length === 0
  ) {
    return restored;
  }

  const restoreText = (
    text: string
  ): string =>
    text.replace(
      /\[LMPII:D(\d{2}):([A-Z_]+):(\d{4})(?:\|([A-Z]{2,4}))?\]/g,
      (
        token,
        documentNumber,
        kind,
        sequence,
        requestedCase?: string
      ) => {
        const index =
          Number(
            documentNumber
          ) - 1;
        const documentId =
          documentIds[index];
        if (!documentId) {
          return token;
        }
        // The case a model asked for travels with the token to the local vault.
        const sourceToken =
          requestedCase
            ? `[PII:${kind}:${sequence}|${requestedCase}]`
            : `[PII:${kind}:${sequence}]`;
        try {
          const value = documentService
            .deanonymize!(
              documentId,
              sourceToken
            );
          if (value !== token) restored.push(value);
          return value;
        } catch {
          // Keep the opaque alias when the matching local vault is unavailable.
          // Never guess or substitute PII from another document.
          return token;
        }
      }
    );

  if (
    typeof result.answer ===
      "string"
  ) {
    result.answer =
      restoreText(
        result.answer
      );
  }

  if (
    result.processAuto
  ) {
    for (
      const step
      of result.processAuto.steps
    ) {
      if (
        typeof step.answer ===
          "string"
      ) {
        step.answer =
          restoreText(
            step.answer
          );
      }
    }
  }

  if (
    result.reportBlueprint
  ) {
    const visit = (
      value: unknown
    ): unknown => {
      if (
        typeof value ===
          "string"
      ) {
        return restoreText(
          value
        );
      }
      if (
        Array.isArray(value)
      ) {
        return value.map(
          visit
        );
      }
      if (
        value &&
        typeof value ===
          "object"
      ) {
        return Object.fromEntries(
          Object.entries(
            value as
              Record<
                string,
                unknown
              >
          ).map(
            ([key, item]) => [
              key,
              visit(item)
            ]
          )
        );
      }
      return value;
    };
    result.reportBlueprint =
      visit(
        result.reportBlueprint
      ) as
        typeof result.reportBlueprint;
  }
  return restored;
}

async function refreshDocumentCitations(args: {
  result: SessionExecutionResponse;
  documentService: DocumentService;
  caseAccessService?: Pick<
    LocalCaseAccessService,
    "assertAccess" | "openCase" | "withCaseDataKey"
  >;
  actor?: AuthenticatedContext;
}): Promise<number> {
  const citations =
    args.result.documentCitations ?? [];
  if (citations.length === 0) {
    return 0;
  }

  for (const citation of citations) {
    if (
      citation.caseId &&
      args.caseAccessService &&
      args.documentService.restoreDocument
    ) {
      if (!args.actor) {
        throw new Error(
          "DOCUMENT_CITATION_REFRESH_AUTH_REQUIRED"
        );
      }
      args.caseAccessService.assertAccess(
        args.actor,
        citation.caseId,
        "ANALYZE"
      );
      const caseView =
        args.caseAccessService.openCase(
          args.actor,
          citation.caseId
        );
      await args.caseAccessService
        .withCaseDataKey(
          args.actor,
          citation.caseId,
          "ANALYZE",
          (caseDataKey) =>
            args.documentService
              .restoreDocument!({
                caseId:
                  citation.caseId!,
                documentId:
                  citation.documentId,
                caseDataKey,
                keyVersion:
                  caseView.keyVersion
              })
        );
    }

    const refreshed =
      await args.documentService
        .resolveProtectedChunks({
          documentId:
            citation.documentId,
          chunkIndices: [
            citation.chunkIndex
          ]
        });
    const chunk =
      refreshed.chunks.find(
        (item) =>
          item.index ===
            citation.chunkIndex
      );
    if (!chunk) {
      throw new Error(
        "DOCUMENT_CITATION_SOURCE_UNAVAILABLE"
      );
    }
    if (
      chunk.pageStart !==
        citation.pageStart ||
      chunk.pageEnd !==
        citation.pageEnd ||
      chunk.text !==
        citation.contextText
    ) {
      throw new Error(
        "DOCUMENT_CITATION_SOURCE_CHANGED"
      );
    }
  }

  return citations.length;
}

/**
 * After an answer: the provisions it verified and the skills it read join the
 * matter's evidence memory. A caller without write access, or a failed write,
 * leaves the memory as it was; the answer is not affected.
 */
async function rememberThreadEvidence(args: {
  store: Pick<EncryptedCaseWorkspaceStore, "saveCaseMemory">;
  caseAccessService: Pick<LocalCaseAccessService, "openCase" | "withCaseDataKey">;
  actor: AuthenticatedContext;
  caseId: string;
  previous: ThreadEvidence | null;
  result: SessionExecutionResponse;
  realValues?: string[];
}): Promise<void> {
  const records = args.result[SESSION_EXECUTION_INTERNAL]?.verificationRecords ?? [];
  const skills = args.result.loadedSkills ?? [];
  if (records.length === 0 && skills.length === 0 && !args.result.mandatoryPath && !args.result.modeDecision && !args.realValues?.length) return;
  try {
    const caseView = args.caseAccessService.openCase(args.actor, args.caseId);
    await args.caseAccessService.withCaseDataKey(args.actor, args.caseId, "WRITE", (caseDataKey) =>
      args.store.saveCaseMemory({
        caseId: args.caseId,
        caseDataKey,
        keyVersion: caseView.keyVersion,
        evidence: mergeThreadEvidence(args.previous, records, skills, new Date().toISOString(), {
          ...(args.result.modeDecision && args.result.modeDecision.decision !== "NIEROZSTRZYGNIETY"
            ? { mode: args.result.modeDecision.mode }
            : {}),
          ...(args.result.mandatoryPath ? { path: args.result.mandatoryPath } : {}),
          realValueHashes: realValueHashes(args.realValues ?? []),
          caseReferences: args.result[SESSION_EXECUTION_INTERNAL]?.caseReferences ?? []
        })
      })
    );
  } catch (error) {
    process.stderr.write(`CASE_MEMORY_NOT_SAVED:${error instanceof Error ? error.message : String(error)}\n`);
  }
}

// KROK 1 signal table of the current corpus (re-read after a skill update).
let modeSignalsCache: { root: string; signals: ModeSignals | null } | null = null;
function modeSignals(registry: LexSkillRegistry): ModeSignals | null {
  if (modeSignalsCache?.root === registry.root) return modeSignalsCache.signals;
  let signals: ModeSignals | null = null;
  try {
    const file = registry.resolveResource("prawny-router-v3", "references/KROK1-detekcja.md");
    signals = file ? parseModeSignals(fs.readFileSync(file, "utf8")) : null;
  } catch {
    signals = null;
  }
  modeSignalsCache = { root: registry.root, signals };
  return signals;
}

/** The matter's files for the case file tools, on the caller's case access. */
// The case's files searched for a signature the answer names (session-executor
// registerCaseFileSignatures): no tool for the model, so also for a local model and the file.
function createCaseSignatureSearch(args: {
  caseId: string;
  actor: AuthenticatedContext;
  caseAccessService: Pick<LocalCaseAccessService, "openCase" | "withCaseDataKey">;
  caseKnowledgeSearch: Pick<LocalCaseKnowledgeSearch, "search">;
}): Pick<CaseFileAccess, "search"> {
  return {
    search: async (query, limit) => {
      const caseView = args.caseAccessService.openCase(args.actor, args.caseId);
      return await args.caseAccessService.withCaseDataKey(args.actor, args.caseId, "ANALYZE", (caseDataKey) =>
        args.caseKnowledgeSearch.search({ caseId: args.caseId, caseDataKey, keyVersion: caseView.keyVersion, query, limit, reviewedOnly: true })
      );
    }
  };
}

function createCaseFileAccess(args: {
  caseId: string;
  actor: AuthenticatedContext;
  caseAccessService: Pick<LocalCaseAccessService, "openCase" | "withCaseDataKey">;
  caseKnowledgeSearch: Pick<LocalCaseKnowledgeSearch, "search" | "listDocuments">;
  documentService: DocumentService;
  // Documents on the shared key the chat uses in this turn.
  sharedMembers: Set<string> | null;
}): CaseFileAccess {
  const withKey = async <T>(work: (caseDataKey: Buffer, keyVersion: number) => Promise<T>): Promise<T> => {
    const caseView = args.caseAccessService.openCase(args.actor, args.caseId);
    return await args.caseAccessService.withCaseDataKey(args.actor, args.caseId, "ANALYZE", (caseDataKey) =>
      work(caseDataKey, caseView.keyVersion)
    );
  };
  // Restored locally once per turn: its key turns the document's aliases in
  // the answer back into names.
  const restored = new Set<string>();
  const restore = async (documentId: string, caseDataKey: Buffer, keyVersion: number): Promise<void> => {
    if (restored.has(documentId)) return;
    await args.documentService.restoreDocument!({ caseId: args.caseId, documentId, caseDataKey, keyVersion });
    restored.add(documentId);
  };
  return {
    caseId: args.caseId,
    listDocuments: () =>
      withKey((caseDataKey, keyVersion) =>
        args.caseKnowledgeSearch.listDocuments({ caseId: args.caseId, caseDataKey, keyVersion, reviewedOnly: true })
      ),
    search: (query, limit) =>
      withKey(async (caseDataKey, keyVersion) => {
        const hits = await args.caseKnowledgeSearch.search({ caseId: args.caseId, caseDataKey, keyVersion, query, limit, reviewedOnly: true });
        // Snippets carry the documents' symbols too.
        for (const documentId of new Set(hits.map((hit) => hit.documentId))) {
          await restore(documentId, caseDataKey, keyVersion);
        }
        return hits;
      }),
    readChunks: async (documentId, chunkIndices) => {
      await withKey((caseDataKey, keyVersion) => restore(documentId, caseDataKey, keyVersion));
      const resolved = await args.documentService.resolveProtectedChunks({ documentId, chunkIndices }, { remote: true });
      return {
        totalPages: resolved.totalPages ?? 0,
        chunks: resolved.chunks.map((chunk) => ({
          index: chunk.index,
          pageStart: chunk.pageStart,
          pageEnd: chunk.pageEnd,
          text: chunk.text
        }))
      };
    },
    sharedKey: (documentId) => args.sharedMembers?.has(documentId) ?? false
  };
}

export function createLexHttpApp(options: LexHttpAppOptions): Express {
  const app = express();
  const routing = new RoutingCatalog(options.registry);

  // Resolves primarySkill "AUTO" for a session request. Returns false when an
  // error response has already been sent.
  async function resolveAutoPrimarySkill(
    request: SessionExecutionRequest,
    res: Response,
    attachmentCount: number,
    {
      allowModelSelection,
      allowConversational
    }: {
      allowModelSelection: boolean;
      allowConversational: boolean;
    }
  ): Promise<boolean> {
      // AUTO with an account or API model: the model picks the skills itself
      // (router-v3 first, enforced by the corpus tools) instead of a separate
      // routing pass. Local models keep the compact routing pass.
      const autoEnvelope =
        request.primarySkill === "AUTO"
          ? parseSkillSelectionEnvelope(
              request.query
            )
          : null;
      const modelSelectsSkills =
        allowModelSelection &&
        autoEnvelope !== null &&
        autoEnvelope.automatic &&
        autoEnvelope.manualSkills.length === 0 &&
        autoEnvelope.workflowExecutionSkill === null &&
        !request.model.startsWith("local/");
      if (modelSelectsSkills) {
        const placeholder =
          [...options.registry.skills.keys()]
            .filter((name) =>
              name.startsWith("dr-") &&
              (
                !autoEnvelope.domainRestrictionActive ||
                autoEnvelope.domainAllowList.includes(name)
              )
            )
            .sort()[0];
        if (!placeholder) {
          res.status(422).json({
            error:
              "AUTO_ROUTING_FAILED",
            reason:
              "AUTO_ROUTING_NO_DOMAIN_CANDIDATES"
          });
          return false;
        }
        request.primarySkill =
          placeholder;
        request.modelSelectsSkills =
          true;
      }

      if (
        request.primarySkill ===
          "AUTO"
      ) {
        const resolveAutoRouting =
          options.sessionExecutor
            ?.resolveAutoRouting
            ?.bind(
              options.sessionExecutor
            );
        if (!resolveAutoRouting) {
          res.status(503).json({
            error:
              "AUTO_ROUTING_UNAVAILABLE"
          });
          return false;
        }
        try {
          const routed =
            await resolveAutoRouting(
              request
            );
          request.primarySkill =
            routed.decision
              .primarySkill;
          request.query =
            routed.query;
          if (
            routed.decision.legal ===
              false &&
            attachmentCount === 0 &&
            allowConversational
          ) {
            request.conversationalOnly =
              true;
          }
        } catch (error) {
          if (sendAccountPolicyError(res, error)) {
            return false;
          }
          if (
            error instanceof Error &&
            error.message ===
              "CHAT_PRIVACY_GATE_FAILED"
          ) {
            res.status(503).json({
              error:
                "CHAT_PRIVACY_GATE_FAILED",
              ...privacyGateReason(error)
            });
            return false;
          }

          const localFailureMessage =
            request.model.startsWith(
              "local/"
            )
              ? (
                  error instanceof
                    ProviderGatewayError &&
                  error.causeValue instanceof
                    Error
                    ? error.causeValue
                        .message
                    : error instanceof Error
                      ? error.message
                      : ""
                )
              : "";
          const parsedLocalReason =
            localFailureMessage
              .split(
                ":",
                1
              )[0] ?? "";
          if (
            request.model.startsWith(
              "local/"
            ) &&
            /^LOCAL_MODEL_[A-Z0-9_]+$/.test(
              parsedLocalReason
            )
          ) {
            res.status(503).json({
              error:
                "LOCAL_MODEL_EXECUTION_FAILED",
              reason:
                parsedLocalReason
            });
            return false;
          }

          if (
            error instanceof
              ProviderGatewayError
          ) {
            const rawReason =
              error.causeValue instanceof
                Error
                ? error.causeValue
                    .message
                : "";
            const parsedReason =
              rawReason.split(
                ":",
                1
              )[0] ?? "";
            res.status(502).json({
              error:
                "PROVIDER_EXECUTION_FAILED",
              provider:
                error.provider,
              reason:
                /^[A-Z0-9_]+$/.test(
                  parsedReason
                )
                  ? parsedReason
                  : "PROVIDER_UNCODED_FAILURE",
              ...(rawReason
                ? {
                    description:
                      safeDiagnosticText(
                        rawReason
                      )
                  }
                : {})
            });
            return false;
          }

          const reason =
            error instanceof Error &&
            /^AUTO_ROUTING_[A-Z0-9_]+$/.test(
              error.message
            )
              ? error.message
              : "AUTO_ROUTING_FAILED";
          res.status(422).json({
            error:
              "AUTO_ROUTING_FAILED",
            reason
          });
          return false;
        }
      }
    return true;
  }

  const processingProgress =
    new ProcessingProgressRegistry();
  const documentCaseIds =
    new Map<string, string>();

  app.disable("x-powered-by");
  app.use(helmet());
  app.use(loopbackOriginGuard);
  // A long conversation (query up to MAX_SESSION_QUERY_CHARS, Polish UTF-8) fits.
  const json2mb = express.json({ limit: "2mb" });
  // A message with images sent as they are (direct-images.ts, up to 4 x ~5 MB) has its own limit.
  app.use((req, res, next) => (req.path === "/api/sessions/execute" ? next() : json2mb(req, res, next)));

  app.get("/health", (_req, res) => {
    res.json({
      status: "ok",
      service: "lex-machina-runtime",
      localOnly: true
    });
  });

  app.get(
    "/api/auth/status",
    (_req, res) => {
      if (!options.authService) {
        res.status(503).json({
          error:
            "AUTH_SERVICE_UNAVAILABLE"
        });
        return;
      }
      res.json(
        options.authService.status()
      );
    }
  );

  app.post(
    "/api/auth/bootstrap-managed",
    async (req, res) => {
      if (
        !process.env
          .LEX_DESKTOP_BOOTSTRAP_TOKEN
          ?.trim()
      ) {
        res.status(403).json({
          error:
            "DESKTOP_BOOTSTRAP_REQUIRED"
        });
        return;
      }
      if (!options.authService) {
        res.status(503).json({
          error:
            "AUTH_SERVICE_UNAVAILABLE"
        });
        return;
      }
      const password =
        typeof req.body?.password ===
          "string"
          ? req.body.password
          : "";
      try {
        const result =
          await options.authService
            .bootstrap({
              loginName:
                "local-admin",
              displayName:
                "Administrator lokalny",
              password,
              passwordSetupPending:
                true
            });
        res.status(201).json(result);
      } catch (error) {
        if (
          !sendAuthError(
            res,
            error
          )
        ) {
          res.status(500).json({
            error:
              "AUTH_BOOTSTRAP_FAILED"
          });
        }
      }
    }
  );

  app.post(
    "/api/auth/bootstrap",
    async (req, res) => {
      if (!options.authService) {
        res.status(503).json({
          error:
            "AUTH_SERVICE_UNAVAILABLE"
        });
        return;
      }
      const loginName =
        typeof req.body?.loginName ===
          "string"
          ? req.body.loginName
          : "";
      const displayName =
        typeof req.body?.displayName ===
          "string"
          ? req.body.displayName
          : "";
      const password =
        typeof req.body?.password ===
          "string"
          ? req.body.password
          : "";

      try {
        const result =
          await options.authService
            .bootstrap({
              loginName,
              displayName,
              password
            });
        res.status(201).json(result);
      } catch (error) {
        if (
          !sendAuthError(
            res,
            error
          )
        ) {
          res.status(500).json({
            error:
              "AUTH_BOOTSTRAP_FAILED"
          });
        }
      }
    }
  );

  app.post(
    "/api/auth/login",
    async (req, res) => {
      if (!options.authService) {
        res.status(503).json({
          error:
            "AUTH_SERVICE_UNAVAILABLE"
        });
        return;
      }
      const loginName =
        typeof req.body?.loginName ===
          "string"
          ? req.body.loginName
          : "";
      const password =
        typeof req.body?.password ===
          "string"
          ? req.body.password
          : "";

      try {
        res.json(
          await options.authService
            .login({
              loginName,
              password
            })
        );
      } catch (error) {
        if (
          !sendAuthError(
            res,
            error
          )
        ) {
          res.status(500).json({
            error:
              "AUTH_LOGIN_FAILED"
          });
        }
      }
    }
  );

  app.post(
    "/api/auth/recover",
    async (req, res) => {
      if (!options.authService) {
        res.status(503).json({
          error:
            "AUTH_SERVICE_UNAVAILABLE"
        });
        return;
      }
      const loginName =
        typeof req.body?.loginName ===
          "string"
          ? req.body.loginName
          : "";
      const recoveryCode =
        typeof req.body?.recoveryCode ===
          "string"
          ? req.body.recoveryCode
          : "";
      const newPassword =
        typeof req.body?.newPassword ===
          "string"
          ? req.body.newPassword
          : "";

      try {
        res.json(
          await options.authService
            .recoverAccount({
              loginName,
              recoveryCode,
              newPassword
            })
        );
      } catch (error) {
        if (
          !sendAuthError(
            res,
            error
          )
        ) {
          res.status(500).json({
            error:
              "AUTH_RECOVERY_FAILED"
          });
        }
      }
    }
  );

  app.post(
    "/api/auth/logout",
    (req, res) => {
      if (!options.authService) {
        res.status(503).json({
          error:
            "AUTH_SERVICE_UNAVAILABLE"
        });
        return;
      }
      options.authService
        .logoutAuthorization(
          req.get("authorization")
        );
      res.status(204).end();
    }
  );

  if (options.supportService) {
    app.use(
      "/api/support",
      (req, res, next) => {
        try {
          res.locals.lexSupport =
            options.supportService!
              .authenticateAuthorization(
                req.get(
                  "x-lex-service-authorization"
                )
              );
          next();
        } catch (error) {
          if (
            !sendSupportError(
              res,
              error
            )
          ) {
            res.status(401).json({
              error:
                "SUPPORT_SESSION_REQUIRED"
            });
          }
        }
      }
    );

    app.get(
      "/api/support/me",
      (_req, res) => {
        res.json({
          session:
            responseSupportContext(res)
        });
      }
    );

    app.get(
      "/api/support/diagnostics",
      (_req, res) => {
        const session =
          responseSupportContext(res);
        try {
          options.supportService!
            .assertCapability(
              session,
              "DIAGNOSTICS"
            );
          options.supportService!
            .recordOperation(
              session,
              "diagnostics_read"
            );
          res.json({
            service:
              "lex-machina-runtime",
            localOnly: true,
            role: "SERVICE",
            installationId:
              session.installationId,
            expiresAt:
              session.expiresAt
          });
        } catch (error) {
          if (
            !sendSupportError(
              res,
              error
            )
          ) {
            res.status(500).json({
              error:
                "SUPPORT_DIAGNOSTICS_FAILED"
            });
          }
        }
      }
    );

    app.post(
      "/api/support/logout",
      (req, res) => {
        options.supportService!
          .deactivateAuthorization(
            req.get(
              "x-lex-service-authorization"
            )
          );
        res.status(204).end();
      }
    );
  }

  if (options.microsoft) {
    registerMicrosoftPublicRoutes(app, options.microsoft);
  }

  if (options.googleRecovery) {
    registerGooglePublicRoutes(
      app,
      options.googleRecovery,
      options.googleWorkspace
    );
  }

  if (options.authService) {
    app.use(
      "/api",
      (req, res, next) => {
        try {
          const context =
            options.authService!
              .authenticateAuthorization(
                req.get(
                  "authorization"
                )
              );
          res.locals.lexAuth =
            context;

          trackSessionActivity(
            options.authService!,
            req,
            res,
            context.session.sessionId
          );
          next();
        } catch (error) {
          if (
            !sendAuthError(
              res,
              error
            )
          ) {
            res.status(401).json({
              error:
                "AUTHENTICATION_REQUIRED"
            });
          }
        }
      }
    );

    app.get(
      "/api/auth/me",
      (_req, res) => {
        res.json(
          responseAuthContext(res)
        );
      }
    );

    app.get(
      "/api/guide/state",
      (_req, res) => {
        if (
          !options.guideSessionStore
        ) {
          res.status(503).json({
            error:
              "GUIDE_SESSION_STATE_UNAVAILABLE"
          });
          return;
        }
        const actor =
          responseAuthContext(res);
        res.json({
          state:
            options.guideSessionStore
              .get(
                actor.session
                  .sessionId
              )
        });
      }
    );

    app.post(
      "/api/guide/initialize",
      (req, res) => {
        if (
          !options.guideSessionStore
        ) {
          res.status(503).json({
            error:
              "GUIDE_SESSION_STATE_UNAVAILABLE"
          });
          return;
        }
        const actor =
          responseAuthContext(res);
        const audience =
          req.body?.audience ===
            "LAIK" ||
          req.body?.audience ===
            "PRAWNIK"
            ? req.body.audience
            : null;
        if (!audience) {
          res.status(400).json({
            error:
              "GUIDE_AUDIENCE_INVALID"
          });
          return;
        }
        res.json({
          state:
            options.guideSessionStore
              .initialize(
                actor.session
                  .sessionId,
                audience
              )
        });
      }
    );

    app.post(
      "/api/guide/transition",
      (req, res) => {
        if (
          !options.guideSessionStore
        ) {
          res.status(503).json({
            error:
              "GUIDE_SESSION_STATE_UNAVAILABLE"
          });
          return;
        }
        const expectedRevision =
          Number(
            req.body
              ?.expectedRevision
          );
        const transition =
          parseGuideTransition(
            req.body?.transition
          );
        if (
          !Number.isSafeInteger(
            expectedRevision
          ) ||
          expectedRevision < 1 ||
          !transition
        ) {
          res.status(400).json({
            error:
              "GUIDE_TRANSITION_REQUEST_INVALID"
          });
          return;
        }

        try {
          const actor =
            responseAuthContext(res);
          res.json({
            state:
              options.guideSessionStore
                .transition({
                  sessionId:
                    actor.session
                      .sessionId,
                  expectedRevision,
                  transition
                })
          });
        } catch (error) {
          const code =
            error instanceof Error
              ? error.message
              : "GUIDE_TRANSITION_FAILED";
          res.status(
            code ===
              "GUIDE_SESSION_STATE_CONFLICT" ||
            code ===
              "GUIDE_IRREVERSIBLE_ACTION_PENDING"
              ? 409
              : code.includes(
                    "INVALID"
                  ) ||
                  code.includes(
                    "TRANSITION"
                  ) ||
                  code.includes(
                    "MISMATCH"
                  ) ||
                  code.includes(
                    "CONFIRMATION_REQUIRED"
                  )
                ? 422
                : code ===
                    "GUIDE_SESSION_STATE_NOT_FOUND"
                  ? 404
                  : 500
          ).json({
            error: code
          });
        }
      }
    );

    // User input in the window (typing, reading with scroll/mouse) counts as
    // activity; the authentication middleware above already refreshed the
    // idle deadline for this non-GET request.
    app.post(
      "/api/auth/activity",
      (_req, res) => {
        res.status(204).end();
      }
    );

    // "Zapisz formę": the user corrected how a restored name inflects.
    app.post(
      "/api/privacy/name-forms",
      async (req, res) => {
        const body = req.body as Partial<NameFormCorrection> | undefined;
        if (!options.personMorphology?.saveCorrection) {
          res.status(503).json({ error: "PERSON_MORPHOLOGY_UNAVAILABLE" });
          return;
        }
        try {
          await options.personMorphology.saveCorrection({
            canonical: String(body?.canonical ?? ""),
            gender: body?.gender === "f" ? "f" : "m1",
            case: String(body?.case ?? "") as NameFormCorrection["case"],
            text: String(body?.text ?? "")
          });
          res.status(204).end();
        } catch (error) {
          const code = error instanceof Error ? error.message : "NAME_FORM_INVALID";
          res.status(code.startsWith("NAME_FORM_") ? 400 : 500).json({ error: code.startsWith("NAME_FORM_") ? code : "NAME_FORM_SAVE_FAILED" });
        }
      }
    );

    app.post(
      "/api/auth/lock",
      (_req, res) => {
        const context =
          responseAuthContext(res);
        options.authService!
          .lockSession(
            context.session
              .sessionId
          );
        res.status(204).end();
      }
    );

    if (options.googleRecovery) {
      registerGoogleAuthenticatedRoutes(
        app,
        options.googleRecovery,
        responseAuthContext
      );
    }

    if (
      options.googleWorkspace &&
      options.caseAccessService &&
      options.secureCaseUploadStore
    ) {
      const access = options.caseAccessService;
      const store = options.secureCaseUploadStore;
      registerGoogleWorkspaceRoutes(
        app,
        options.googleWorkspace,
        responseAuthContext,
        async (context, caseId, files) => {
          access.assertAccess(context, caseId, "WRITE");
          const caseView = access.openCase(context, caseId);
          return await access.withCaseDataKey(
            context,
            caseId,
            "WRITE",
            async (caseDataKey) => {
              const stored: StoredUpload[] = [];
              for (const file of files) {
                stored.push(
                  await store.saveUpload({
                    caseId,
                    filename: file.filename,
                    mediaType: file.mediaType,
                    data: file.data,
                    caseDataKey,
                    keyVersion: caseView.keyVersion
                  })
                );
              }
              return stored;
            }
          );
        },
        sendCaseAccessError
      );
    }

    if (
      options.microsoft &&
      options.caseAccessService &&
      options.secureCaseUploadStore
    ) {
      const access = options.caseAccessService;
      const store = options.secureCaseUploadStore;
      registerMicrosoftRoutes(
        app,
        options.microsoft,
        responseAuthContext,
        async (context, caseId, files) => {
          access.assertAccess(context, caseId, "WRITE");
          const caseView = access.openCase(context, caseId);
          return await access.withCaseDataKey(
            context,
            caseId,
            "WRITE",
            async (caseDataKey) => {
              const stored: StoredUpload[] = [];
              for (const file of files) {
                stored.push(
                  await store.saveUpload({
                    caseId,
                    filename: file.filename,
                    mediaType: file.mediaType,
                    data: file.data,
                    caseDataKey,
                    keyVersion: caseView.keyVersion
                  })
                );
              }
              return stored;
            }
          );
        },
        sendCaseAccessError
      );
    }

    app.post(
      "/api/auth/recovery-code",
      async (req, res) => {
        const password =
          typeof req.body?.password ===
            "string"
            ? req.body.password
            : "";
        try {
          res.status(201).json(
            await options
              .authService!
              .createRecoveryCode(
                responseAuthContext(
                  res
                ),
                { password }
              )
          );
        } catch (error) {
          if (
            !sendAuthError(
              res,
              error
            )
          ) {
            res.status(500).json({
              error:
                "RECOVERY_CODE_CREATE_FAILED"
            });
          }
        }
      }
    );

    app.post(
      "/api/auth/password",
      async (req, res) => {
        const currentPassword =
          typeof req.body
            ?.currentPassword ===
            "string"
            ? req.body
                .currentPassword
            : "";
        const newPassword =
          typeof req.body?.newPassword ===
            "string"
            ? req.body.newPassword
            : "";
        try {
          res.json(
            await options
              .authService!
              .changePassword(
                responseAuthContext(
                  res
                ),
                {
                  currentPassword,
                  newPassword
                }
              )
          );
        } catch (error) {
          if (
            !sendAuthError(
              res,
              error
            )
          ) {
            res.status(500).json({
              error:
                "PASSWORD_CHANGE_FAILED"
            });
          }
        }
      }
    );
  }

  app.get(
    "/api/admin/support/status",
    (_req, res) => {
      if (!options.supportService) {
        res.status(503).json({
          error:
            "SUPPORT_SERVICE_UNAVAILABLE"
        });
        return;
      }
      const actor =
        responseAuthContext(res);
      if (
        actor.user.appRole !==
          "ADMIN"
      ) {
        res.status(403).json({
          error:
            "SUPPORT_ADMIN_REQUIRED"
        });
        return;
      }
      res.json(
        options.supportService
          .status()
      );
    }
  );

  app.post(
    "/api/admin/support/challenge",
    (_req, res) => {
      if (!options.supportService) {
        res.status(503).json({
          error:
            "SUPPORT_SERVICE_UNAVAILABLE"
        });
        return;
      }
      try {
        res.status(201).json(
          options.supportService
            .issueChallenge(
              responseAuthContext(
                res
              )
            )
        );
      } catch (error) {
        if (
          !sendSupportError(
            res,
            error
          )
        ) {
          res.status(500).json({
            error:
              "SUPPORT_CHALLENGE_FAILED"
          });
        }
      }
    }
  );

  app.post(
    "/api/admin/support/activate",
    (req, res) => {
      if (!options.supportService) {
        res.status(503).json({
          error:
            "SUPPORT_SERVICE_UNAVAILABLE"
        });
        return;
      }
      try {
        res.status(201).json(
          options.supportService
            .activate(
              responseAuthContext(
                res
              ),
              req.body
            )
        );
      } catch (error) {
        if (
          !sendSupportError(
            res,
            error
          )
        ) {
          res.status(500).json({
            error:
              "SUPPORT_ACTIVATION_FAILED"
          });
        }
      }
    }
  );

  app.get(
    "/api/admin/users",
    (_req, res) => {
      if (!options.authService) {
        res.status(503).json({
          error:
            "AUTH_SERVICE_UNAVAILABLE"
        });
        return;
      }
      try {
        res.json({
          users:
            options.authService
              .listUsers(
                responseAuthContext(
                  res
                )
              )
        });
      } catch (error) {
        if (
          !sendAuthError(
            res,
            error
          )
        ) {
          res.status(500).json({
            error:
              "USER_LIST_FAILED"
          });
        }
      }
    }
  );

  app.post(
    "/api/admin/users",
    async (req, res) => {
      if (!options.authService) {
        res.status(503).json({
          error:
            "AUTH_SERVICE_UNAVAILABLE"
        });
        return;
      }
      const loginName =
        typeof req.body?.loginName ===
          "string"
          ? req.body.loginName
          : "";
      const displayName =
        typeof req.body?.displayName ===
          "string"
          ? req.body.displayName
          : "";
      const password =
        typeof req.body?.password ===
          "string"
          ? req.body.password
          : "";
      try {
        const user =
          await options.authService
            .createUser(
              responseAuthContext(res),
              {
                loginName,
                displayName,
                password,
                ...(req.body?.accountKind === "INDIVIDUAL" ? { accountKind: "INDIVIDUAL" as const } : {})
              }
            );
        res.status(201).json({
          user
        });
      } catch (error) {
        if (
          !sendAuthError(
            res,
            error
          )
        ) {
          res.status(500).json({
            error:
              "USER_CREATE_FAILED"
          });
        }
      }
    }
  );

  app.patch(
    "/api/admin/users/:userId/status",
    (req, res) => {
      if (!options.authService) {
        res.status(503).json({
          error:
            "AUTH_SERVICE_UNAVAILABLE"
        });
        return;
      }
      const userId =
        String(
          req.params.userId ?? ""
        ).trim();
      const status =
        req.body?.status ===
          "ACTIVE" ||
        req.body?.status ===
          "DISABLED"
          ? req.body.status
          : null;
      if (!status) {
        res.status(400).json({
          error:
            "INVALID_USER_REQUEST"
        });
        return;
      }
      try {
        const user =
          options.authService
            .setUserStatus(
              responseAuthContext(
                res
              ),
              userId,
              status
            );
        res.json({ user });
      } catch (error) {
        if (
          !sendAuthError(
            res,
            error
          )
        ) {
          res.status(500).json({
            error:
              "USER_STATUS_UPDATE_FAILED"
          });
        }
      }
    }
  );

  // Account kind, set by the administrator (INDIVIDUAL: chat only).
  app.patch(
    "/api/admin/users/:userId/account-kind",
    (req, res) => {
      if (!options.authService) {
        res.status(503).json({ error: "AUTH_SERVICE_UNAVAILABLE" });
        return;
      }
      const accountKind = req.body?.accountKind === "INDIVIDUAL" || req.body?.accountKind === "PROFESSIONAL" ? req.body.accountKind : null;
      if (!accountKind) {
        res.status(400).json({ error: "INVALID_USER_REQUEST" });
        return;
      }
      try {
        const user = options.authService.setAccountKind(responseAuthContext(res), String(req.params.userId ?? "").trim(), accountKind);
        res.json({ user });
      } catch (error) {
        if (!sendAuthError(res, error)) res.status(500).json({ error: "USER_UPDATE_FAILED" });
      }
    }
  );

  app.delete(
    "/api/admin/users/:userId",
    (req, res) => {
      if (!options.authService) {
        res.status(503).json({
          error:
            "AUTH_SERVICE_UNAVAILABLE"
        });
        return;
      }
      const userId =
        String(
          req.params.userId ?? ""
        ).trim();
      try {
        res.json(
          options.authService
            .deleteUser(
              responseAuthContext(
                res
              ),
              userId
            )
        );
      } catch (error) {
        if (
          !sendAuthError(
            res,
            error
          )
        ) {
          res.status(500).json({
            error:
              "USER_DELETE_FAILED"
          });
        }
      }
    }
  );

  app.get(
    "/api/shared/templates",
    async (_req, res) => {
      if (
        !options.sharedTemplateStore
      ) {
        res.status(503).json({
          error:
            "SHARED_TEMPLATE_STORE_UNAVAILABLE"
        });
        return;
      }
      try {
        res.json({
          templates:
            await options
              .sharedTemplateStore
              .listTemplates()
        });
      } catch {
        res.status(500).json({
          error:
            "SHARED_TEMPLATE_LIST_FAILED"
        });
      }
    }
  );

  // The firm sets what a template is for and its default per document kind.
  app.put(
    "/api/shared/templates/:sharedTemplateId/role",
    express.json({ limit: "4kb" }),
    async (req, res) => {
      if (!options.sharedTemplateStore) {
        res.status(503).json({ error: "SHARED_TEMPLATE_STORE_UNAVAILABLE" });
        return;
      }
      if (responseAuthContext(res).user.appRole !== "ADMIN") {
        res.status(403).json({ error: "AUTHORIZATION_DENIED" });
        return;
      }
      const role = req.body?.role === null ? null : validTemplateRole(req.body?.role);
      if (role === null && req.body?.role !== null) {
        res.status(400).json({ error: "TEMPLATE_ROLE_INVALID" });
        return;
      }
      try {
        if (!options.sharedTemplateStore.setRole) throw new Error("TEMPLATE_ROLES_UNAVAILABLE");
        await options.sharedTemplateStore.setRole(String(req.params.sharedTemplateId ?? ""), role);
        res.json({ templates: await options.sharedTemplateStore.listTemplates() });
      } catch {
        res.status(404).json({ error: "SHARED_TEMPLATE_NOT_FOUND" });
      }
    }
  );

  const sharedTemplateBody =
    express.raw({
      type: () => true,
      limit: "64mb"
    });

  // Desktop: save a generated document in the user's Downloads folder (the WebView
  // does not perform <a download> of blob URLs). Authenticated like every /api route.
  app.post(
    "/api/downloads/save",
    sharedTemplateBody,
    async (req, res) => {
      if (!res.locals.lexAuth) {
        res.status(401).json({ error: "AUTHENTICATION_REQUIRED" });
        return;
      }
      if (
        !Buffer.isBuffer(req.body) ||
        req.body.byteLength === 0
      ) {
        res.status(400).json({ error: "DOWNLOAD_BODY_REQUIRED" });
        return;
      }
      let filename: string;
      try {
        filename = decodeURIComponent(String(req.get("X-Lex-Filename") ?? ""));
      } catch {
        res.status(400).json({ error: "DOWNLOAD_FILENAME_INVALID" });
        return;
      }
      try {
        res.json(await saveToDownloads(filename, req.body));
      } catch (error) {
        const code = error instanceof Error ? error.message : "DOWNLOAD_SAVE_FAILED";
        res.status(code === "DOWNLOAD_FILE_TYPE_NOT_ALLOWED" ? 400 : 500).json({
          error: /^DOWNLOAD_[A-Z_]+$/.test(code) ? code : "DOWNLOAD_SAVE_FAILED"
        });
      }
    }
  );

  app.post(
    "/api/shared/templates",
    sharedTemplateBody,
    async (req, res) => {
      if (
        !options.sharedTemplateStore
      ) {
        res.status(503).json({
          error:
            "SHARED_TEMPLATE_STORE_UNAVAILABLE"
        });
        return;
      }
      const context =
        responseAuthContext(res);
      if (
        context.user.appRole !==
          "ADMIN"
      ) {
        res.status(403).json({
          error:
            "AUTHORIZATION_DENIED"
        });
        return;
      }
      if (
        !Buffer.isBuffer(req.body) ||
        req.body.byteLength === 0
      ) {
        res.status(400).json({
          error:
            "TEMPLATE_BODY_REQUIRED"
        });
        return;
      }

      const mediaType =
        req.get("content-type")
          ?.split(";", 1)[0]
          ?.trim()
          .toLowerCase() ||
        "application/octet-stream";
      const filename =
        decodeUploadFilename(
          req.get("x-lex-filename")
        );

      try {
        const stored =
          await options
            .sharedTemplateStore
            .saveTemplate({
              filename,
              mediaType,
              data:
                new Uint8Array(
                  req.body
                ),
              createdByUserId:
                context.user.userId
            });
        res.status(201).json(
          stored
        );
      } catch (error) {
        if (
          error instanceof Error &&
          error.message ===
            "UNSUPPORTED_TEMPLATE_MEDIA_TYPE"
        ) {
          res.status(415).json({
            error:
              "UNSUPPORTED_TEMPLATE_MEDIA_TYPE"
          });
          return;
        }
        res.status(422).json({
          error:
            "SHARED_TEMPLATE_STORE_FAILED"
        });
      }
    }
  );

  app.get(
    "/api/firm-knowledge",
    (_req, res) => {
      if (
        !options.caseAccessService
      ) {
        res.status(503).json({
          error:
            "CASE_ACCESS_UNAVAILABLE"
        });
        return;
      }
      try {
        const workspace =
          options.caseAccessService
            .getFirmKnowledgeWorkspace(
              responseAuthContext(
                res
              )
            );
        res.json({
          workspace
        });
      } catch (error) {
        if (
          !sendCaseAccessError(
            res,
            error
          )
        ) {
          res.status(500).json({
            error:
              "FIRM_KNOWLEDGE_STATUS_FAILED"
          });
        }
      }
    }
  );

  app.post(
    "/api/firm-knowledge",
    async (_req, res) => {
      if (
        !options.caseAccessService
      ) {
        res.status(503).json({
          error:
            "CASE_ACCESS_UNAVAILABLE"
        });
        return;
      }
      try {
        const workspace =
          await options
            .caseAccessService
            .createFirmKnowledgeWorkspace(
              responseAuthContext(
                res
              )
            );
        res.status(201).json({
          workspace
        });
      } catch (error) {
        if (
          !sendAuthError(
            res,
            error
          ) &&
          !sendCaseAccessError(
            res,
            error
          )
        ) {
          res.status(500).json({
            error:
              "FIRM_KNOWLEDGE_CREATE_FAILED"
          });
        }
      }
    }
  );

  app.get(
    "/api/cases",
    (_req, res) => {
      if (
        !options.caseAccessService
      ) {
        res.status(503).json({
          error:
            "CASE_ACCESS_UNAVAILABLE"
        });
        return;
      }
      try {
        const cases =
          options.caseAccessService
            .listCases(
              responseAuthContext(res)
            );
        res.json({
          cases
        });
      } catch (error) {
        if (
          !sendCaseAccessError(
            res,
            error
          )
        ) {
          res.status(500).json({
            error:
              "CASE_LIST_FAILED"
          });
        }
      }
    }
  );

  app.get(
    "/api/cases/legacy",
    async (_req, res) => {
      if (
        !options.caseAccessService
      ) {
        res.status(503).json({
          error:
            "CASE_ACCESS_UNAVAILABLE"
        });
        return;
      }
      try {
        res.json({
          cases:
            await options
              .caseAccessService
              .listLegacyCases(
                responseAuthContext(
                  res
                )
              )
        });
      } catch (error) {
        if (
          !sendCaseAccessError(
            res,
            error
          )
        ) {
          res.status(500).json({
            error:
              "LEGACY_CASE_LIST_FAILED"
          });
        }
      }
    }
  );

  app.post(
    "/api/cases/:caseId/import-legacy",
    async (req, res) => {
      if (
        !options.caseAccessService
      ) {
        res.status(503).json({
          error:
            "CASE_ACCESS_UNAVAILABLE"
        });
        return;
      }
      try {
        const imported =
          await options
            .caseAccessService
            .importLegacyCase(
              responseAuthContext(
                res
              ),
              String(
                req.params.caseId ??
                ""
              )
            );
        res.status(201).json(
          imported
        );
      } catch (error) {
        if (
          !sendCaseAccessError(
            res,
            error
          )
        ) {
          res.status(500).json({
            error:
              "LEGACY_CASE_IMPORT_FAILED"
          });
        }
      }
    }
  );

  app.get(
    "/api/cases/:caseId",
    (req, res) => {
      if (
        !options.caseAccessService
      ) {
        res.status(503).json({
          error:
            "CASE_ACCESS_UNAVAILABLE"
        });
        return;
      }
      try {
        res.json(
          options.caseAccessService
            .openCase(
              responseAuthContext(
                res
              ),
              String(
                req.params.caseId ??
                ""
              )
            )
        );
      } catch (error) {
        if (
          !sendCaseAccessError(
            res,
            error
          )
        ) {
          res.status(500).json({
            error:
              "CASE_OPEN_FAILED"
          });
        }
      }
    }
  );

  app.post(
    "/api/cases",
    async (req, res) => {
      if (!options.caseFileStore) {
        res.status(503).json({
          error:
            "CASE_STORAGE_UNAVAILABLE"
        });
        return;
      }

      const displayName =
        typeof req.body?.displayName ===
          "string"
          ? req.body.displayName
          : undefined;

      try {
        const created =
          options.caseAccessService
            ? await options
                .caseAccessService
                .createCase(
                  responseAuthContext(
                    res
                  ),
                  displayName
                )
            : await options
                .caseFileStore
                .createCase(
                  displayName
                );
        res.status(201).json(
          created
        );
      } catch (error) {
        if (
          !sendCaseAccessError(
            res,
            error
          )
        ) {
          res.status(500).json({
            error:
              "CASE_CREATE_FAILED"
          });
        }
      }
    }
  );

  app.patch(
    "/api/cases/:caseId",
    async (req, res) => {
      if (
        !options.caseAccessService
      ) {
        res.status(503).json({
          error:
            "CASE_ACCESS_UNAVAILABLE"
        });
        return;
      }
      const displayName =
        typeof req.body
          ?.displayName ===
          "string"
          ? req.body
              .displayName
          : "";
      try {
        res.json(
          await options
            .caseAccessService
            .renameCase(
              responseAuthContext(
                res
              ),
              String(
                req.params.caseId ??
                ""
              ),
              displayName
            )
        );
      } catch (error) {
        if (
          !sendCaseAccessError(
            res,
            error
          )
        ) {
          res.status(500).json({
            error:
              "CASE_RENAME_FAILED"
          });
        }
      }
    }
  );

  // Pamięć sprawy: streszczenie starszej części wątku (do poprawy) i pamięć dowodowa (podgląd).
  const withCaseMemory = async <T>(
    res: Response,
    caseId: string,
    action: "ANALYZE" | "WRITE",
    work: (key: { caseId: string; caseDataKey: Buffer; keyVersion: number }) => Promise<T>
  ): Promise<T> => {
    const actor = responseAuthContext(res);
    const caseView = options.caseAccessService!.openCase(actor, caseId);
    return await options.caseAccessService!.withCaseDataKey(actor, caseId, action, (caseDataKey) =>
      work({ caseId, caseDataKey, keyVersion: caseView.keyVersion })
    );
  };

  app.get("/api/cases/:caseId/memory", async (req, res) => {
    if (!options.caseMemoryStore || !options.caseAccessService) {
      res.status(503).json({ error: "CASE_MEMORY_UNAVAILABLE" });
      return;
    }
    try {
      const memory = await withCaseMemory(res, String(req.params.caseId ?? ""), "ANALYZE", (key) =>
        options.caseMemoryStore!.getCaseMemory(key)
      );
      res.json({
        summary: memory.summary ?? null,
        chronology: memory.chronology ? { text: memory.chronology.text, updatedAt: memory.chronology.updatedAt, source: memory.chronology.source } : null,
        overview: memory.overview ? { text: memory.overview.text, updatedAt: memory.overview.updatedAt } : null,
        work: (memory.work ?? []).map((item) => ({ ...item, line: caseWorkLine(item) })),
        evidence: memory.evidence
          ? {
              updatedAt: memory.evidence.updatedAt,
              provisions: memory.evidence.provisions.map((record) => ({
                claim: record.claim,
                status: record.status,
                sourceUrl: record.sourceAnchorUrl ?? record.sourceUrl ?? null,
                consolidatedText: record.currentEli ?? null,
                fetchedAt: record.fetchedAt,
                freshnessCheckedAt: record.freshnessCheckedAt ?? null
              })),
              sources: memory.evidence.sources,
              skills: memory.evidence.skills
            }
          : null
      });
    } catch (error) {
      if (!sendCaseAccessError(res, error)) res.status(500).json({ error: "CASE_MEMORY_READ_FAILED" });
    }
  });

  // The court and signature of a case (courts/case-court.ts), set by the user: documents do not
  // replace it. The court must be one of the common courts of the court base.
  app.get("/api/cases/:caseId/court", async (req, res) => {
    if (!options.caseMemoryStore || !options.caseAccessService) {
      res.status(503).json({ error: "CASE_MEMORY_UNAVAILABLE" });
      return;
    }
    try {
      const memory = await withCaseMemory(res, String(req.params.caseId ?? ""), "ANALYZE", (key) => options.caseMemoryStore!.getCaseMemory(key));
      const court = memory.court ?? null;
      res.json({ court, wokanda: court ? effectiveWokandaCourt(court.nazwa) : null });
    } catch (error) {
      if (!sendCaseAccessError(res, error)) res.status(500).json({ error: "CASE_MEMORY_READ_FAILED" });
    }
  });

  app.patch("/api/cases/:caseId/court", async (req, res) => {
    if (!options.caseMemoryStore || !options.caseAccessService) {
      res.status(503).json({ error: "CASE_MEMORY_UNAVAILABLE" });
      return;
    }
    const body = (req.body ?? {}) as Record<string, unknown>;
    const name = typeof body.nazwa === "string" ? body.nazwa.trim() : "";
    const known = name ? courtByName(name) : null;
    const wydzial = typeof body.wydzial === "string" ? body.wydzial.trim().slice(0, 120) : "";
    const sygnatura = typeof body.sygnatura === "string" ? body.sygnatura.replace(/\s+/gu, " ").trim() : "";
    if (name && !known) {
      res.status(400).json({ error: "CASE_COURT_UNKNOWN" });
      return;
    }
    if (sygnatura && (sygnatura.length > 40 || !parseCommonSignature(sygnatura))) {
      res.status(400).json({ error: "CASE_SIGNATURE_INVALID" });
      return;
    }
    try {
      const court: CaseCourt | null = known
        ? { nazwa: known.nazwa, ...(wydzial ? { wydzial } : {}), ...(sygnatura ? { sygnatura } : {}), zrodlo: "UZYTKOWNIK", at: new Date().toISOString() }
        : null;
      await withCaseMemory(res, String(req.params.caseId ?? ""), "WRITE", (key) => options.caseMemoryStore!.saveCaseMemory({ ...key, court }));
      res.json({ court, wokanda: court ? effectiveWokandaCourt(court.nazwa) : null });
    } catch (error) {
      if (!sendCaseAccessError(res, error)) res.status(500).json({ error: "CASE_MEMORY_WRITE_FAILED" });
    }
  });

  // The case's hearings on its court's wokanda, on the user's request (courts/wokanda.ts): one
  // search by the signature and the details of each hearing; never in the background.
  app.post("/api/cases/:caseId/wokanda", async (req, res) => {
    if (!options.caseMemoryStore || !options.caseAccessService) {
      res.status(503).json({ error: "CASE_MEMORY_UNAVAILABLE" });
      return;
    }
    try {
      const memory = await withCaseMemory(res, String(req.params.caseId ?? ""), "ANALYZE", (key) => options.caseMemoryStore!.getCaseMemory(key));
      const court = memory.court;
      if (!court?.sygnatura) {
        res.status(409).json({ error: court ? "CASE_SIGNATURE_MISSING" : "CASE_COURT_MISSING" });
        return;
      }
      res.json(await checkWokanda(court.nazwa, court.sygnatura, options.wokandaFetch ?? defaultFetchText, () => new Date(), (name) => effectiveWokandaCourt(name)));
    } catch (error) {
      if (!sendCaseAccessError(res, error)) res.status(500).json({ error: "WOKANDA_CHECK_FAILED" });
    }
  });

  app.patch("/api/cases/:caseId/memory/summary", async (req, res) => {
    if (!options.caseMemoryStore || !options.caseAccessService) {
      res.status(503).json({ error: "CASE_MEMORY_UNAVAILABLE" });
      return;
    }
    const text = typeof req.body?.text === "string" ? req.body.text.trim() : "";
    if (!text || text.length > MAX_SUMMARY_CHARS) {
      res.status(400).json({ error: "CASE_SUMMARY_INVALID", maxChars: MAX_SUMMARY_CHARS });
      return;
    }
    try {
      const summary = await withCaseMemory(res, String(req.params.caseId ?? ""), "WRITE", async (key) => {
        const current = (await options.caseMemoryStore!.getCaseMemory(key)).summary;
        if (!current) return null;
        const next = { ...current, text, updatedAt: new Date().toISOString(), editedByUser: true as const };
        await options.caseMemoryStore!.saveCaseMemory({ ...key, summary: next });
        return next;
      });
      if (!summary) {
        res.status(404).json({ error: "CASE_SUMMARY_NOT_FOUND" });
        return;
      }
      res.json({ summary });
    } catch (error) {
      if (!sendCaseAccessError(res, error)) res.status(500).json({ error: "CASE_MEMORY_WRITE_FAILED" });
    }
  });

  app.delete("/api/cases/:caseId/memory", async (req, res) => {
    if (!options.caseMemoryStore || !options.caseAccessService) {
      res.status(503).json({ error: "CASE_MEMORY_UNAVAILABLE" });
      return;
    }
    try {
      await withCaseMemory(res, String(req.params.caseId ?? ""), "WRITE", (key) =>
        options.caseMemoryStore!.saveCaseMemory({ ...key, evidence: null, summary: null, chronology: null, overview: null, work: null, answerDocument: null })
      );
      res.json({ cleared: true });
    } catch (error) {
      if (!sendCaseAccessError(res, error)) res.status(500).json({ error: "CASE_MEMORY_WRITE_FAILED" });
    }
  });

  app.get(
    "/api/cases/:caseId/schedule",
    async (req, res) => {
      if (
        !options.caseScheduleService
      ) {
        res.status(503).json({
          error:
            "CASE_SCHEDULE_UNAVAILABLE"
        });
        return;
      }
      try {
        res.json({
          events:
            await options
              .caseScheduleService
              .listCaseSchedule(
                responseAuthContext(
                  res
                ),
                String(
                  req.params.caseId ??
                    ""
                )
              )
        });
      } catch (error) {
        if (
          !sendCaseAccessError(
            res,
            error
          )
        ) {
          res.status(500).json({
            error:
              "CASE_SCHEDULE_LIST_FAILED"
          });
        }
      }
    }
  );

  app.post(
    "/api/cases/:caseId/schedule",
    async (req, res) => {
      if (
        !options.caseScheduleService
      ) {
        res.status(503).json({
          error:
            "CASE_SCHEDULE_UNAVAILABLE"
        });
        return;
      }
      try {
        res.status(201).json(
          await options
            .caseScheduleService
            .addCaseScheduleEvent(
              responseAuthContext(
                res
              ),
              String(
                req.params.caseId ??
                  ""
              ),
              {
                kind:
                  req.body?.kind,
                title:
                  req.body?.title,
                startsAt:
                  req.body?.startsAt,
                location:
                  req.body?.location,
                notes:
                  req.body?.notes
              }
            )
        );
      } catch (error) {
        if (
          !sendCaseAccessError(
            res,
            error
          )
        ) {
          res.status(500).json({
            error:
              "CASE_SCHEDULE_CREATE_FAILED"
          });
        }
      }
    }
  );

  app.delete(
    "/api/cases/:caseId/schedule/:eventId",
    async (req, res) => {
      if (
        !options.caseScheduleService
      ) {
        res.status(503).json({
          error:
            "CASE_SCHEDULE_UNAVAILABLE"
        });
        return;
      }
      try {
        res.json(
          await options
            .caseScheduleService
            .deleteCaseScheduleEvent(
              responseAuthContext(
                res
              ),
              String(
                req.params.caseId ??
                  ""
              ),
              String(
                req.params.eventId ??
                  ""
              )
            )
        );
      } catch (error) {
        if (
          !sendCaseAccessError(
            res,
            error
          )
        ) {
          res.status(500).json({
            error:
              "CASE_SCHEDULE_DELETE_FAILED"
          });
        }
      }
    }
  );

  const scheduleRoute =
    (
      failure: string,
      handler: (
        service: NonNullable<LexHttpAppOptions["caseScheduleService"]>,
        req: Request,
        res: Response
      ) => Promise<void>
    ) =>
    async (req: Request, res: Response) => {
      if (!options.caseScheduleService) {
        res.status(503).json({ error: "CASE_SCHEDULE_UNAVAILABLE" });
        return;
      }
      try {
        await handler(options.caseScheduleService, req, res);
      } catch (error) {
        if (!sendCaseAccessError(res, error)) {
          res.status(500).json({ error: failure });
        }
      }
    };

  // Home screen and calendar: events of all the user's active cases.
  app.get(
    "/api/schedule/upcoming",
    scheduleRoute("CASE_SCHEDULE_LIST_FAILED", async (service, req, res) => {
      const limit = Number(req.query.limit);
      res.json({
        events: await service.listUpcomingEvents(responseAuthContext(res), {
          ...(Number.isFinite(limit) ? { limit } : {}),
          ...(typeof req.query.from === "string" ? { from: req.query.from } : {}),
          ...(typeof req.query.until === "string" ? { until: req.query.until } : {})
        })
      });
    })
  );

  app.get(
    "/api/cases/:caseId/contacts",
    scheduleRoute("CASE_CONTACT_LIST_FAILED", async (service, req, res) => {
      res.json({
        contacts: await service.listCaseContacts(
          responseAuthContext(res),
          String(req.params.caseId ?? "")
        )
      });
    })
  );

  app.post(
    "/api/cases/:caseId/contacts",
    scheduleRoute("CASE_CONTACT_CREATE_FAILED", async (service, req, res) => {
      res.status(201).json(
        await service.addCaseContact(
          responseAuthContext(res),
          String(req.params.caseId ?? ""),
          {
            kind: req.body?.kind,
            name: req.body?.name,
            role: req.body?.role,
            phone: req.body?.phone,
            email: req.body?.email,
            address: req.body?.address,
            notes: req.body?.notes
          }
        )
      );
    })
  );

  app.delete(
    "/api/cases/:caseId/contacts/:contactId",
    scheduleRoute("CASE_CONTACT_DELETE_FAILED", async (service, req, res) => {
      res.json(
        await service.deleteCaseContact(
          responseAuthContext(res),
          String(req.params.caseId ?? ""),
          String(req.params.contactId ?? "")
        )
      );
    })
  );

  app.post(
    "/api/cases/:caseId/archive",
    async (req, res) => {
      if (
        !options.caseAccessService
      ) {
        res.status(503).json({
          error:
            "CASE_ACCESS_UNAVAILABLE"
        });
        return;
      }
      try {
        res.json(
          await options
            .caseAccessService
            .setCaseArchived(
              responseAuthContext(
                res
              ),
              String(
                req.params.caseId ??
                ""
              ),
              true
            )
        );
      } catch (error) {
        if (
          !sendCaseAccessError(
            res,
            error
          )
        ) {
          res.status(500).json({
            error:
              "CASE_ARCHIVE_FAILED"
          });
        }
      }
    }
  );

  app.post(
    "/api/cases/:caseId/unarchive",
    async (req, res) => {
      if (
        !options.caseAccessService
      ) {
        res.status(503).json({
          error:
            "CASE_ACCESS_UNAVAILABLE"
        });
        return;
      }
      try {
        res.json(
          await options
            .caseAccessService
            .setCaseArchived(
              responseAuthContext(
                res
              ),
              String(
                req.params.caseId ??
                ""
              ),
              false
            )
        );
      } catch (error) {
        if (
          !sendCaseAccessError(
            res,
            error
          )
        ) {
          res.status(500).json({
            error:
              "CASE_UNARCHIVE_FAILED"
          });
        }
      }
    }
  );

  app.delete(
    "/api/cases/:caseId",
    async (req, res) => {
      if (
        !options.caseAccessService
      ) {
        res.status(503).json({
          error:
            "CASE_ACCESS_UNAVAILABLE"
        });
        return;
      }
      const password =
        typeof req.body?.password ===
          "string"
          ? req.body.password
          : "";
      try {
        const deleted =
          await options
            .caseAccessService
            .deleteCase(
              responseAuthContext(
                res
              ),
              String(
                req.params.caseId ??
                ""
              ),
              password
            );
        // The case's copies of decisions go with it (the library keeps its own).
        caseLawRepository()?.removeCase(String(req.params.caseId ?? ""));
        res.json(deleted);
      } catch (error) {
        if (
          !sendAuthError(
            res,
            error
          ) &&
          !sendCaseAccessError(
            res,
            error
          )
        ) {
          res.status(500).json({
            error:
              "CASE_DELETE_FAILED"
          });
        }
      }
    }
  );

  app.post(
    "/api/cases/:caseId/knowledge/search",
    async (req, res) => {
      if (
        !options.caseAccessService ||
        !options.caseKnowledgeSearch
      ) {
        res.status(503).json({
          error:
            "CASE_KNOWLEDGE_UNAVAILABLE"
        });
        return;
      }

      const caseId =
        String(
          req.params.caseId ?? ""
        ).trim();
      const query =
        typeof req.body?.query ===
          "string"
          ? req.body.query.trim()
          : "";
      const limit =
        req.body?.limit ===
          undefined
          ? 8
          : Number(
              req.body.limit
            );

      if (
        !/^case_[a-f0-9]{32}$/
          .test(caseId) ||
        query.length < 2 ||
        query.length > 500 ||
        !Number.isInteger(
          limit
        ) ||
        limit < 1 ||
        limit > 16
      ) {
        res.status(400).json({
          error:
            "INVALID_KNOWLEDGE_QUERY"
        });
        return;
      }

      try {
        const context =
          responseAuthContext(
            res
          );
        const caseView =
          options.caseAccessService
            .openCase(
              context,
              caseId
            );
        const hits =
          await options
            .caseAccessService
            .withCaseDataKey(
              context,
              caseId,
              "READ",
              async (
                caseDataKey
              ) =>
                await options
                  .caseKnowledgeSearch!
                  .search({
                    caseId,
                    caseDataKey,
                    keyVersion:
                      caseView
                        .keyVersion,
                    query,
                    limit
                  })
            );
        res.json({
          caseId,
          caseKind:
            caseView.caseKind,
          hits: hits.map(
            (hit) => ({
              documentId:
                hit.documentId,
              chunkIndex:
                hit.chunkIndex,
              pageStart:
                hit.pageStart,
              pageEnd:
                hit.pageEnd,
              score:
                hit.score,
              text:
                hit.text
            })
          )
        });
      } catch (error) {
        if (
          sendCaseAccessError(
            res,
            error
          )
        ) {
          return;
        }
        if (
          error instanceof Error &&
          [
            "INVALID_KNOWLEDGE_QUERY",
            "INVALID_KNOWLEDGE_LIMIT"
          ].includes(
            error.message
          )
        ) {
          res.status(400).json({
            error:
              error.message
          });
          return;
        }
        res.status(422).json({
          error:
            "CASE_KNOWLEDGE_SEARCH_FAILED"
        });
      }
    }
  );

  app.get(
    "/api/admin/case-access",
    (_req, res) => {
      const service = options.caseAccessService;
      if (!service?.listAccessOverview) {
        res.status(503).json({ error: "CASE_ACCESS_UNAVAILABLE" });
        return;
      }
      try {
        res.json({
          cases: service.listAccessOverview(responseAuthContext(res))
        });
      } catch (error) {
        if (!sendCaseAccessError(res, error)) {
          res.status(500).json({ error: "CASE_ACCESS_OVERVIEW_FAILED" });
        }
      }
    }
  );

  app.get(
    "/api/cases/:caseId/access-candidates",
    (req, res) => {
      if (
        !options.caseAccessService
      ) {
        res.status(503).json({
          error:
            "CASE_ACCESS_UNAVAILABLE"
        });
        return;
      }
      try {
        res.json({
          users:
            options.caseAccessService
              .listAccessCandidates(
                responseAuthContext(
                  res
                ),
                String(
                  req.params.caseId ??
                    ""
                )
              )
        });
      } catch (error) {
        if (
          !sendCaseAccessError(
            res,
            error
          )
        ) {
          res.status(500).json({
            error:
              "CASE_ACCESS_CANDIDATES_FAILED"
          });
        }
      }
    }
  );

  if (options.userGroups && options.caseAccessService) {
    const groups = options.userGroups;
    const access = options.caseAccessService;
    const groupError = (res: Response, error: unknown): void => {
      if (error instanceof UserGroupError) {
        res.status(error.httpStatus).json({ error: error.code });
        return;
      }
      if (!sendCaseAccessError(res, error)) res.status(500).json({ error: "USER_GROUP_FAILED" });
    };
    const admin = (res: Response): boolean => {
      if (responseAuthContext(res).user.appRole === "ADMIN") return true;
      res.status(403).json({ error: "AUTHORIZATION_DENIED" });
      return false;
    };
    // Every signed-in user sees the groups (to share a case); only an administrator changes them.
    app.get("/api/user-groups", async (_req, res) => {
      try {
        responseAuthContext(res);
        res.json({ groups: await groups.list() });
      } catch (error) {
        groupError(res, error);
      }
    });
    app.post("/api/user-groups", async (req, res) => {
      if (!admin(res)) return;
      try {
        res.status(201).json(await groups.create({ name: req.body?.name, memberUserIds: req.body?.memberUserIds }));
      } catch (error) {
        groupError(res, error);
      }
    });
    app.patch("/api/user-groups/:groupId", async (req, res) => {
      if (!admin(res)) return;
      try {
        res.json(
          await groups.update(String(req.params.groupId ?? ""), {
            ...(req.body?.name !== undefined ? { name: req.body.name } : {}),
            ...(req.body?.memberUserIds !== undefined ? { memberUserIds: req.body.memberUserIds } : {})
          })
        );
      } catch (error) {
        groupError(res, error);
      }
    });
    app.delete("/api/user-groups/:groupId", async (req, res) => {
      if (!admin(res)) return;
      try {
        await groups.remove(String(req.params.groupId ?? ""));
        res.json({ deleted: true });
      } catch (error) {
        groupError(res, error);
      }
    });
    // The case shared with each member of a group (the case owner's or manager's own grant).
    app.post("/api/cases/:caseId/access/group", async (req, res) => {
      const role = typeof req.body?.role === "string" ? req.body.role : "";
      if (!["EDITOR", "ANALYST", "VIEWER"].includes(role) || typeof req.body?.canReidentify !== "boolean" || typeof req.body?.groupId !== "string") {
        res.status(400).json({ error: "INVALID_CASE_ACCESS_REQUEST" });
        return;
      }
      try {
        const context = responseAuthContext(res);
        const caseId = String(req.params.caseId ?? "");
        const group = await groups.get(req.body.groupId);
        const current = new Set(access.listAccess(context, caseId).map((entry) => entry.user.userId));
        res.json(
          await shareWithGroup({
            group,
            actorUserId: context.user.userId,
            hasAccess: (userId) => current.has(userId),
            grant: (userId) =>
              access.grantAccess(context, caseId, { userId, role: role as "EDITOR" | "ANALYST" | "VIEWER", canReidentify: req.body.canReidentify })
          })
        );
      } catch (error) {
        groupError(res, error);
      }
    });
  }

  app.get(
    "/api/cases/:caseId/access",
    (req, res) => {
      if (
        !options.caseAccessService
      ) {
        res.status(503).json({
          error:
            "CASE_ACCESS_UNAVAILABLE"
        });
        return;
      }
      try {
        res.json({
          access:
            options.caseAccessService
              .listAccess(
                responseAuthContext(
                  res
                ),
                String(
                  req.params.caseId ??
                  ""
                )
              )
        });
      } catch (error) {
        if (
          !sendCaseAccessError(
            res,
            error
          )
        ) {
          res.status(500).json({
            error:
              "CASE_ACCESS_LIST_FAILED"
          });
        }
      }
    }
  );

  app.post(
    "/api/cases/:caseId/access",
    async (req, res) => {
      if (
        !options.caseAccessService
      ) {
        res.status(503).json({
          error:
            "CASE_ACCESS_UNAVAILABLE"
        });
        return;
      }
      const role =
        typeof req.body?.role ===
          "string"
          ? req.body.role
          : "";
      if (
        ![
          "EDITOR",
          "ANALYST",
          "VIEWER"
        ].includes(role) ||
        typeof req.body
          ?.canReidentify !==
          "boolean" ||
        typeof req.body?.userId !==
          "string"
      ) {
        res.status(400).json({
          error:
            "INVALID_CASE_ACCESS_REQUEST"
        });
        return;
      }
      try {
        const granted =
          await options
            .caseAccessService
            .grantAccess(
              responseAuthContext(
                res
              ),
              String(
                req.params.caseId ??
                ""
              ),
              {
                userId:
                  req.body.userId,
                role:
                  role as Exclude<
                    CaseRole,
                    "OWNER"
                  >,
                canReidentify:
                  req.body
                    .canReidentify
              }
            );
        res.status(201).json(
          granted
        );
      } catch (error) {
        if (
          !sendCaseAccessError(
            res,
            error
          )
        ) {
          res.status(500).json({
            error:
              "CASE_ACCESS_GRANT_FAILED"
          });
        }
      }
    }
  );

  app.post(
    "/api/cases/:caseId/transfer-owner",
    async (req, res) => {
      if (
        !options.caseAccessService
      ) {
        res.status(503).json({
          error:
            "CASE_ACCESS_UNAVAILABLE"
        });
        return;
      }
      const userId =
        typeof req.body?.userId ===
          "string"
          ? req.body.userId
          : "";
      const password =
        typeof req.body?.password ===
          "string"
          ? req.body.password
          : "";
      try {
        res.json(
          await options
            .caseAccessService
            .transferOwnership(
              responseAuthContext(
                res
              ),
              String(
                req.params.caseId ??
                  ""
              ),
              {
                userId,
                password
              }
            )
        );
      } catch (error) {
        if (
          !sendAuthError(
            res,
            error
          ) &&
          !sendCaseAccessError(
            res,
            error
          )
        ) {
          res.status(500).json({
            error:
              "CASE_OWNER_TRANSFER_FAILED"
          });
        }
      }
    }
  );

  app.delete(
    "/api/cases/:caseId/access/:userId",
    async (req, res) => {
      if (
        !options.caseAccessService
      ) {
        res.status(503).json({
          error:
            "CASE_ACCESS_UNAVAILABLE"
        });
        return;
      }
      try {
        res.json(
          await options
            .caseAccessService
            .revokeAccess(
              responseAuthContext(
                res
              ),
              String(
                req.params.caseId ??
                ""
              ),
              String(
                req.params.userId ??
                ""
              )
            )
        );
      } catch (error) {
        if (
          !sendCaseAccessError(
            res,
            error
          )
        ) {
          res.status(500).json({
            error:
              "CASE_ACCESS_REVOKE_FAILED"
          });
        }
      }
    }
  );

  app.post(
    "/api/cases/:caseId/rotate-key",
    async (req, res) => {
      if (
        !options.caseAccessService
      ) {
        res.status(503).json({
          error:
            "CASE_ACCESS_UNAVAILABLE"
        });
        return;
      }
      try {
        res.json(
          await options
            .caseAccessService
            .rotateCaseKey(
              responseAuthContext(
                res
              ),
              String(
                req.params.caseId ??
                ""
              )
            )
        );
      } catch (error) {
        if (
          !sendCaseAccessError(
            res,
            error
          )
        ) {
          res.status(500).json({
            error:
              "CASE_KEY_ROTATE_FAILED"
          });
        }
      }
    }
  );

  const caseUploadBody = express.raw({
    type: () => true,
    limit: "512mb"
  });

  app.get(
    "/api/cases/:caseId/files",
    async (req, res) => {
      if (
        !options.caseFileStore ||
        !options.caseFileStore
          .listUploads
      ) {
        res.status(503).json({
          error:
            "CASE_STORAGE_UNAVAILABLE"
        });
        return;
      }
      const caseId =
        String(
          req.params.caseId ??
          ""
        ).trim();
      try {
        options.caseAccessService
          ?.assertAccess(
            responseAuthContext(
              res
            ),
            caseId,
            "READ"
          );
        let uploads:
          StoredUpload[];
        if (
          options
            .secureCaseUploadStore &&
          options.caseAccessService
        ) {
          const context =
            responseAuthContext(
              res
            );
          const caseView =
            options.caseAccessService
              .openCase(
                context,
                caseId
              );
          // Not behind the case's operation lock: the list answers while a file is processed.
          const service = options.caseAccessService;
          const withKey = <T,>(callback: (caseDataKey: Buffer) => Promise<T>) =>
            service.withCaseDataKeyForRead
              ? service.withCaseDataKeyForRead(context, caseId, callback)
              : service.withCaseDataKey(context, caseId, "READ", callback);
          uploads =
            await withKey(
                async (
                  caseDataKey: Buffer
                ) =>
                  await options
                    .secureCaseUploadStore!
                    .listUploads({
                      caseId,
                      caseDataKey,
                      keyVersion:
                        caseView.keyVersion
                    })
              );
        } else {
          uploads =
            await options
              .caseFileStore
              .listUploads!(
                caseId
              );
        }
        let enrichedUploads:
          Array<
            StoredUpload & {
              processing?: {
                documentId: string;
                complete: true;
                totalPages: number;
                digitalPages: number;
                ocrPages: number;
                blankPages: number;
                chunkIndices: number[];
                // false: OCR/text only, sent in clear (no anonymization key).
                anonymized: boolean;
                // On the case's shared key (one symbol per entity in the case).
                sharedKey: boolean;
                // false: not confirmed after a preview; never sent to a model outside the computer.
                reviewed?: boolean;
              };
            }
          > =
          uploads.map(
            (item) => ({
              ...item
            })
          );

        if (
          options.documentService
            ?.restoreDocument &&
          options.caseAccessService
        ) {
          const context =
            responseAuthContext(
              res
            );
          const caseView =
            options.caseAccessService
              .openCase(
                context,
                caseId
              );

          const readService = options.caseAccessService;
          enrichedUploads =
            await (readService.withCaseDataKeyForRead
              ? readService.withCaseDataKeyForRead.bind(readService)
              : (ctx: AuthenticatedContext, id: string, callback: (caseDataKey: Buffer) => Promise<typeof uploads>) =>
                  readService.withCaseDataKey(ctx, id, "READ", callback))(
                context,
                caseId,
                async (
                  caseDataKey: Buffer
                ) =>
                  await Promise.all(
                    uploads.map(
                      async (
                        item
                      ) => {
                        if (
                          item.archive
                        ) {
                          return {
                            ...item
                          };
                        }

                        const documentId =
                          "doc_" +
                          item.sha256
                            .slice(
                              0,
                              24
                            );
                        try {
                          const restored =
                            await options
                              .documentService!
                              .restoreDocument!({
                                caseId,
                                documentId,
                                caseDataKey,
                                keyVersion:
                                  caseView
                                    .keyVersion
                              });
                          return {
                            ...item,
                            processing: {
                              documentId:
                                restored
                                  .documentId,
                              complete:
                                true as const,
                              totalPages:
                                restored
                                  .totalPages,
                              digitalPages:
                                restored
                                  .digitalPages,
                              ocrPages:
                                restored
                                  .ocrPages,
                              blankPages:
                                restored
                                  .blankPages,
                              chunkIndices:
                                restored
                                  .chunks
                                  .slice(0, 32)
                                  .map(
                                    (chunk) =>
                                      chunk.index
                                  ),
                              anonymized:
                                restored.privacy.findings > 0,
                              sharedKey:
                                options.documentService!.usesSharedKey?.(restored.documentId) ?? false,
                              ...(restored.privacy.reviewed === false ? { reviewed: false } : {})
                            }
                          };
                        } catch {
                          return {
                            ...item
                          };
                        }
                      }
                    )
                  )
              );
        }

        res.json({
          caseId,
          uploads:
            enrichedUploads
        });
      } catch (error) {
        if (
          !sendCaseAccessError(
            res,
            error
          )
        ) {
          res.status(422).json({
            error:
              "CASE_FILE_LIST_FAILED"
          });
        }
      }
    }
  );

  // A file read before the user's decision, outside the case lock (see document-work.ts).
  async function reviewInBackground(
    context: ReturnType<typeof responseAuthContext>,
    caseId: string,
    file: { data: Uint8Array; mediaType: SupportedDocumentMediaType },
    req: Request
  ) {
    const access = options.caseAccessService!;
    const onProgress = processingProgress.reporter(caseId, progressIdFrom(req.get("x-lex-progress")));
    try {
      return await options.documentService!.review(file.data, file.mediaType, {
        caseId,
        ...(onProgress ? { onProgress } : {}),
        ...(req.body?.localAi === true ? { localAi: true } : {}),
        ...(typeof req.body?.ocrFix === "boolean" ? { ocrFix: req.body.ocrFix } : {}),
        ...(req.body?.detect === false ? { detect: false } : {}),
        ...(transcriptSpeakers(req.body?.speakers) !== undefined ? { speakers: transcriptSpeakers(req.body?.speakers)! } : {}),
        background: true,
        storeUnderLock: (save) =>
          access.withCaseDataKey(context, caseId, "WRITE", async (caseDataKey) =>
            save({ caseDataKey, keyVersion: access.openCase(context, caseId).keyVersion })
          )
      });
    } finally {
      file.data.fill(0);
    }
  }

  async function processStoredCaseFile(
    req: Request,
    res: Response,
    fileId?: string
  ): Promise<void> {
    if (keepAliveRequested(req)) keepResponseAlive(res);
    if (
      !options.documentService ||
      !options.caseAccessService ||
      !options.secureCaseUploadStore
    ) {
      res.status(503).json({
        error:
          "STORED_FILE_PROCESSING_UNAVAILABLE"
      });
      return;
    }

    const caseId =
      String(
        req.params.caseId ?? ""
      ).trim();
    const uploadId =
      String(
        req.params.uploadId ?? ""
      ).trim();
    const memberId =
      fileId?.trim();

    if (
      !/^case_[a-f0-9]{32}$/
        .test(caseId) ||
      !/^upload_[a-f0-9]{32}$/
        .test(uploadId) ||
      (
        memberId !== undefined &&
        !/^file_[a-f0-9]{32}$/
          .test(memberId)
      )
    ) {
      res.status(400).json({
        error:
          "INVALID_STORED_FILE_REQUEST"
      });
      return;
    }

    try {
      const context =
        responseAuthContext(res);
      options.caseAccessService
        .assertAccess(
          context,
          caseId,
          "WRITE"
        );
      const caseView =
        options.caseAccessService
          .openCase(
            context,
            caseId
          );
      // Background OCR: only reading the stored file and saving the read take the case lock;
      // the OCR itself runs outside it, so the user's work in the case does not wait for it.
      const background = req.body?.background === true;
      let deferred: { data: Uint8Array; mediaType: SupportedDocumentMediaType } | undefined;

      const locked =
        await options
          .caseAccessService
          .withCaseDataKey(
            context,
            caseId,
            "WRITE",
            async (caseDataKey) => {
              let data: Buffer;
              let mediaType:
                SupportedDocumentMediaType;
              let sourceFileId:
                string | undefined;

              if (memberId) {
                const restored =
                  await options
                    .secureCaseUploadStore!
                    .readExtractedPayload({
                      caseId,
                      uploadId,
                      fileId:
                        memberId,
                      caseDataKey,
                      keyVersion:
                        caseView.keyVersion,
                      maxBytes:
                        512 *
                        1024 *
                        1024
                    });
                if (
                  !restored
                    .manifest
                    .processable
                ) {
                  restored.data.fill(0);
                  throw new Error(
                    "STORED_FILE_NOT_PROCESSABLE"
                  );
                }
                const resolved =
                  storedDocumentMediaType(
                    restored
                      .manifest
                      .mediaType
                  );
                if (!resolved) {
                  restored.data.fill(0);
                  throw new Error(
                    "STORED_FILE_MEDIA_UNSUPPORTED"
                  );
                }
                data =
                  restored.data;
                mediaType =
                  resolved;
                sourceFileId =
                  restored
                    .manifest
                    .fileId;
              } else {
                const uploads =
                  await options
                    .secureCaseUploadStore!
                    .listUploads({
                      caseId,
                      caseDataKey,
                      keyVersion:
                        caseView.keyVersion
                    });
                const upload =
                  uploads.find(
                    (item) =>
                      item.uploadId ===
                        uploadId
                  );
                if (!upload) {
                  throw new Error(
                    "STORED_UPLOAD_NOT_FOUND"
                  );
                }
                if (upload.archive) {
                  throw new Error(
                    "STORED_ARCHIVE_MEMBER_REQUIRED"
                  );
                }
                const resolved =
                  storedDocumentMediaType(
                    upload.mediaType
                  );
                if (!resolved) {
                  throw new Error(
                    "STORED_FILE_MEDIA_UNSUPPORTED"
                  );
                }
                data =
                  await options
                    .secureCaseUploadStore!
                    .readUploadPayload({
                      caseId,
                      uploadId,
                      caseDataKey,
                      keyVersion:
                        caseView.keyVersion,
                      maxBytes:
                        512 *
                        1024 *
                        1024
                    });
                const digest =
                  createHash(
                    "sha256"
                  )
                    .update(data)
                    .digest("hex");
                if (
                  data.byteLength !==
                    upload.bytes ||
                  digest !==
                    upload.sha256
                ) {
                  data.fill(0);
                  throw new Error(
                    "STORED_UPLOAD_INTEGRITY_FAILED"
                  );
                }
                mediaType =
                  resolved;
              }

              try {
                assertStoredDocumentSignature(
                  data,
                  mediaType
                );
                if (background) {
                  deferred = { data: new Uint8Array(data), mediaType };
                  return null;
                }
                const onProgress =
                  processingProgress.reporter(
                    caseId,
                    progressIdFrom(req.get("x-lex-progress"))
                  );
                return await options
                  .documentService!
                  .review(
                    data,
                    mediaType,
                    {
                      caseId,
                      caseDataKey,
                      keyVersion:
                        caseView.keyVersion,
                      ...(onProgress ? { onProgress } : {}),
                      ...(req.body?.localAi === true ? { localAi: true } : {}),
                      ...(typeof req.body?.ocrFix === "boolean" ? { ocrFix: req.body.ocrFix } : {}),
                      // OCR only now; personal data later (POST /api/documents/:id/detect).
                      ...(req.body?.detect === false ? { detect: false } : {}),
                      ...(transcriptSpeakers(req.body?.speakers) !== undefined ? { speakers: transcriptSpeakers(req.body?.speakers)! } : {})
                    }
                  );
              } finally {
                data.fill(0);
              }
            }
          );
      const result = locked ?? (await reviewInBackground(context, caseId, deferred!, req));

      documentCaseIds.set(
        result.documentId,
        caseId
      );
      res.status(201).json({
        ...result,
        caseId,
        uploadId,
        ...(memberId
          ? {
              fileId:
                memberId
            }
          : {})
      });
    } catch (error) {
      if (
        sendCaseAccessError(
          res,
          error
        )
      ) {
        return;
      }
      const code =
        error instanceof Error
          ? error.message
          : "";
      if (
        code ===
          "STORED_UPLOAD_NOT_FOUND" ||
        code ===
          "INVALID_FILE_ID" ||
        code ===
          "ENOENT"
      ) {
        res.status(404).json({
          error:
            "STORED_FILE_NOT_FOUND"
        });
        return;
      }
      if (
        code ===
          "STORED_FILE_MEDIA_UNSUPPORTED" ||
        code ===
          "STORED_FILE_NOT_PROCESSABLE" ||
        code ===
          "STORED_ARCHIVE_MEMBER_REQUIRED"
      ) {
        res.status(415).json({
          error: code
        });
        return;
      }
      if (
        code ===
          "STORED_DOCUMENT_SIGNATURE_MISMATCH" ||
        code ===
          "STORED_UPLOAD_INTEGRITY_FAILED" ||
        code ===
          "EXTRACTED_PAYLOAD_INTEGRITY_FAILED"
      ) {
        res.status(422).json({
          error:
            "STORED_FILE_VALIDATION_FAILED"
        });
        return;
      }
      // A coded cause (never document content) so the UI can tell an OCR
      // failure from a privacy/NER or extraction failure.
      const errorCode =
        error instanceof Error &&
        typeof (error as { code?: unknown }).code === "string"
          ? String((error as { code?: unknown }).code)
          : "";
      const errorName =
        error instanceof Error && /^[A-Za-z]{3,60}$/.test(error.name) && error.name !== "Error"
          ? error.name.replace(/([a-z])([A-Z])/g, "$1_$2").toUpperCase()
          : "";
      const reason =
        /^[A-Z][A-Z0-9_]{2,80}$/.test(errorCode)
          ? errorCode
          : /^[A-Z][A-Z0-9_]{2,80}(?=$|:)/.exec(code)?.[0] ??
            (errorName ? `INTERNAL_${errorName}` : undefined);
      // Code and error type only: the message may quote document content.
      console.error(
        `STORED_FILE_PROCESSING_FAILED:${reason ?? "UNKNOWN"}`
      );
      res.status(422).json({
        error:
          "STORED_FILE_PROCESSING_FAILED",
        ...(reason
          ? {
              reason
            }
          : {})
      });
    }
  }

  // The anonymized version of a case document with its key; edits change
  // both at once (add a value to the anonymization, take one out, correct
  // case forms). Local only - nothing here goes to a model.
  async function withRestoredDocument(
    req: Request,
    res: Response,
    access: "ANALYZE" | "WRITE",
    action: (args: {
      caseId: string;
      documentId: string;
      security: DocumentSecurityContext;
    }) => Promise<unknown>
  ): Promise<void> {
    const caseId = String(req.params.caseId ?? "").trim();
    const documentId = String(req.params.documentId ?? "").trim();
    const service = options.documentService;
    if (
      !service?.restoreDocument ||
      !service.anonymizedVersion ||
      !service.addProtection ||
      !service.removeProtection ||
      !service.updateKeyForms ||
      !options.caseAccessService
    ) {
      res.status(503).json({ error: "ANONYMIZED_VERSION_UNAVAILABLE" });
      return;
    }
    if (!/^case_[a-f0-9]{32}$/.test(caseId) || !/^doc_[a-f0-9]{24}$/.test(documentId)) {
      res.status(400).json({ error: "INVALID_ANONYMIZED_VERSION_REQUEST" });
      return;
    }
    try {
      const context = responseAuthContext(res);
      options.caseAccessService.assertAccess(context, caseId, access);
      const caseView = options.caseAccessService.openCase(context, caseId);
      const result = await options.caseAccessService.withCaseDataKey(
        context,
        caseId,
        access,
        async (caseDataKey) => {
          await service.restoreDocument!({ caseId, documentId, caseDataKey, keyVersion: caseView.keyVersion });
          return await action({
            caseId,
            documentId,
            security: { caseId, caseDataKey, keyVersion: caseView.keyVersion }
          });
        }
      );
      res.setHeader("Cache-Control", "no-store");
      res.json(result);
    } catch (error) {
      if (sendCaseAccessError(res, error)) return;
      const code = error instanceof Error ? error.message : "";
      if (code === "ENOENT" || code.endsWith("NOT_FOUND") || code === "UNKNOWN_LOCAL_DOCUMENT") {
        res.status(404).json({ error: code === "ENOENT" ? "DOCUMENT_NOT_FOUND" : code });
        return;
      }
      if (code.startsWith("PRIVACY_EDIT_") || code.startsWith("PRIVACY_KEY_")) {
        res.status(422).json({ error: code });
        return;
      }
      console.error(`ANONYMIZED_VERSION_FAILED:${/^[A-Z][A-Z0-9_]{2,80}/.exec(code)?.[0] ?? "UNKNOWN"}`);
      res.status(500).json({ error: "ANONYMIZED_VERSION_FAILED" });
    }
  }

  const EDITABLE_PII_KINDS = new Set<string>([
    "PERSON", "ADDRESS", "PESEL", "NIP", "REGON", "IBAN", "EMAIL", "PHONE", "ID_CARD",
    "PASSPORT", "BIRTH_DATE", "LAND_REGISTRY", "KRS", "VEHICLE_PLATE", "BAR_NUMBER", "PAYMENT_CARD", "CUSTOM"
  ]);

  app.get("/api/cases/:caseId/documents/:documentId/anonymized", (req, res) =>
    withRestoredDocument(req, res, "ANALYZE", async ({ documentId }) =>
      options.documentService!.anonymizedVersion!(documentId)
    )
  );

  app.post("/api/cases/:caseId/documents/:documentId/anonymized/protect", (req, res) =>
    withRestoredDocument(req, res, "WRITE", async ({ documentId, security }) => {
      const text = typeof req.body?.text === "string" ? req.body.text : "";
      const kind = String(req.body?.kind ?? "");
      if (!EDITABLE_PII_KINDS.has(kind)) throw new Error("PRIVACY_EDIT_KIND_INVALID");
      return await options.documentService!
        .addProtection!(documentId, text, kind as PiiKind, security);
    })
  );

  // The user's confirmation after the preview of the anonymized version.
  app.post("/api/cases/:caseId/documents/:documentId/anonymized/approve", (req, res) =>
    withRestoredDocument(req, res, "WRITE", async ({ documentId, security }) => {
      if (!options.documentService!.markReviewed) throw new Error("ANONYMIZED_VERSION_UNAVAILABLE");
      return await options.documentService!.markReviewed(documentId, security);
    })
  );

  app.post("/api/cases/:caseId/documents/:documentId/join-shared-key", (req, res) =>
    withRestoredDocument(req, res, "WRITE", async ({ documentId, security }) => {
      if (!options.documentService!.joinSharedKey) throw new Error("SHARED_KEY_UNAVAILABLE");
      return await options.documentService!.joinSharedKey(documentId, security);
    })
  );

  // The user's correction of one fragment of the anonymized version (symbols must stay the key's).
  app.post("/api/cases/:caseId/documents/:documentId/anonymized/text", (req, res) =>
    withRestoredDocument(req, res, "WRITE", async ({ documentId, security }) => {
      if (!options.documentService!.editProtectedText) throw new Error("ANONYMIZED_VERSION_UNAVAILABLE");
      const chunkIndex = Number(req.body?.chunkIndex);
      if (!Number.isInteger(chunkIndex) || chunkIndex < 0) throw new Error("PRIVACY_EDIT_CHUNK_NOT_FOUND");
      return await options.documentService!.editProtectedText(
        documentId,
        chunkIndex,
        typeof req.body?.text === "string" ? req.body.text : "",
        security
      );
    })
  );

  app.post("/api/cases/:caseId/documents/:documentId/anonymized/unprotect", (req, res) =>
    withRestoredDocument(req, res, "WRITE", async ({ documentId, security }) =>
      await options.documentService!
        .removeProtection!(documentId, String(req.body?.token ?? ""), security)
    )
  );

  app.post("/api/cases/:caseId/documents/:documentId/anonymized/forms", (req, res) =>
    withRestoredDocument(req, res, "WRITE", async ({ documentId, security }) => {
      const raw = req.body?.forms;
      if (!raw || typeof raw !== "object") throw new Error("PRIVACY_EDIT_TEXT_INVALID");
      const forms: Partial<Record<PersonCase, string>> = {};
      for (const personCase of PERSON_CASES) {
        const value = (raw as Record<string, unknown>)[personCase];
        if (typeof value === "string") forms[personCase] = value;
      }
      return await options.documentService!
        .updateKeyForms!(documentId, String(req.body?.token ?? ""), forms, security);
    })
  );

  // What a person token is: a man, a woman, several persons, a firm.
  app.post("/api/cases/:caseId/documents/:documentId/anonymized/grammar", (req, res) =>
    withRestoredDocument(req, res, "WRITE", async ({ documentId, security }) => {
      const grammar = String(req.body?.grammar ?? "");
      if (!["m", "f", "group-m", "group-f", "organization"].includes(grammar)) throw new Error("PRIVACY_EDIT_GRAMMAR_INVALID");
      if (!options.documentService!.updateKeyGrammar) throw new Error("PRIVACY_EDIT_GRAMMAR_UNAVAILABLE");
      return await options.documentService!.updateKeyGrammar(
        documentId,
        String(req.body?.token ?? ""),
        grammar as KeyGrammar,
        security
      );
    })
  );

  // A file with placeholders (e.g. an answer from an external model) with the
  // values of one case document's key put back, saved as a new case file.
  app.post(
    "/api/cases/:caseId/files/:uploadId/deanonymize",
    async (req, res) => {
      const caseId = String(req.params.caseId ?? "").trim();
      const uploadId = String(req.params.uploadId ?? "").trim();
      const documentId = String(req.body?.documentId ?? "").trim();
      const service = options.documentService;
      if (!service?.restoreDocument || !service.restoreText || !options.caseAccessService || !options.secureCaseUploadStore) {
        res.status(503).json({ error: "FILE_DEANONYMIZATION_UNAVAILABLE" });
        return;
      }
      if (
        !/^case_[a-f0-9]{32}$/.test(caseId) ||
        !/^upload_[a-f0-9]{32}$/.test(uploadId) ||
        !/^doc_[a-f0-9]{24}$/.test(documentId)
      ) {
        res.status(400).json({ error: "INVALID_FILE_DEANONYMIZATION_REQUEST" });
        return;
      }
      try {
        const context = responseAuthContext(res);
        options.caseAccessService.assertAccess(context, caseId, "WRITE");
        const caseView = options.caseAccessService.openCase(context, caseId);
        const result = await options.caseAccessService.withCaseDataKey(
          context,
          caseId,
          "WRITE",
          async (caseDataKey) => {
            const store = options.secureCaseUploadStore!;
            const keyVersion = caseView.keyVersion;
            const upload = (await store.listUploads({ caseId, caseDataKey, keyVersion })).find(
              (item) => item.uploadId === uploadId
            );
            if (!upload) throw new Error("STORED_UPLOAD_NOT_FOUND");
            const mediaType = upload.mediaType.split(";")[0]!.trim().toLowerCase();
            await service.restoreDocument!({ caseId, documentId, caseDataKey, keyVersion });
            const restore = (text: string) => service.restoreText!(documentId, text);
            const data = await store.readUploadPayload({
              caseId,
              uploadId,
              caseDataKey,
              keyVersion,
              maxBytes: 64 * 1024 * 1024
            });
            let output: Uint8Array;
            let count: number;
            let unresolved: string[];
            try {
              const editable = editableMediaType(mediaType, upload.filename);
              if (editable && editable !== "text/csv" && editable !== "text/tab-separated-values") {
                const editor = new LocalOfficeEditor();
                const model = await editor.read(data, editable);
                const restored = deanonymizeModel(model, restore);
                const format =
                  editable.includes("opendocument") ? "odt" : editable.includes("wordprocessing") ? "docx" : "xlsx";
                output = await editor.write(format, restored.model);
                ({ count, unresolved } = restored);
              } else if (/^text\//.test(mediaType) || /\.(txt|md|markdown|csv|tsv)$/i.test(upload.filename)) {
                const restored = restore(decodePlainText(data));
                output = Buffer.from(restored.text, "utf8");
                ({ count, unresolved } = restored);
              } else {
                throw new Error("FILE_DEANONYMIZATION_MEDIA_UNSUPPORTED");
              }
            } finally {
              data.fill(0);
            }
            if (count === 0 && unresolved.length === 0) throw new Error("FILE_DEANONYMIZATION_NO_PLACEHOLDERS");
            const dot = upload.filename.lastIndexOf(".");
            const filename =
              (dot > 0 ? upload.filename.slice(0, dot) : upload.filename) +
              " (deanonimizowany)" +
              (dot > 0 ? upload.filename.slice(dot) : "");
            const outputType =
              mediaType === "text/markdown" || mediaType === "text/csv" || mediaType === "text/tab-separated-values"
                ? mediaType
                : /^text\//.test(mediaType)
                  ? "text/plain"
                  : upload.mediaType.includes("macroenabled")
                    ? "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                    : mediaType;
            const stored = await store.saveUpload({
              caseId,
              filename: outputType !== mediaType && /\.xlsm$/i.test(filename) ? filename.replace(/\.xlsm$/i, ".xlsx") : filename,
              mediaType: outputType,
              data: output,
              caseDataKey,
              keyVersion
            });
            return { upload: stored, restored: count, unresolved };
          }
        );
        res.status(201).json(result);
      } catch (error) {
        if (sendCaseAccessError(res, error)) return;
        const code = error instanceof Error ? error.message : "";
        if (code === "ENOENT" || code.endsWith("NOT_FOUND") || code === "UNKNOWN_LOCAL_DOCUMENT") {
          res.status(404).json({ error: code === "ENOENT" ? "DOCUMENT_NOT_FOUND" : code });
          return;
        }
        if (code.startsWith("FILE_DEANONYMIZATION_") || code.startsWith("OFFICE_EDIT_")) {
          res.status(422).json({ error: /^[A-Z_]+/.exec(code)![0] });
          return;
        }
        console.error(`FILE_DEANONYMIZATION_FAILED:${/^[A-Z][A-Z0-9_]{2,80}/.exec(code)?.[0] ?? "UNKNOWN"}`);
        res.status(500).json({ error: "FILE_DEANONYMIZATION_FAILED" });
      }
    }
  );

  // The anonymized version of a .docx as a .docx: formatting, footnotes, comments,
  // headers and footers kept, values replaced by tokens (docx-anonymize.ts). Downloaded,
  // not stored in the case.
  app.post("/api/cases/:caseId/files/:uploadId/anonymized-docx", async (req, res) => {
    const caseId = String(req.params.caseId ?? "").trim();
    const uploadId = String(req.params.uploadId ?? "").trim();
    const documentId = String(req.body?.documentId ?? "").trim();
    const service = options.documentService;
    if (!service?.restoreDocument || !service.anonymizedDocxPlan || !options.caseAccessService || !options.secureCaseUploadStore) {
      res.status(503).json({ error: "DOCX_ANONYMIZED_UNAVAILABLE" });
      return;
    }
    if (!/^case_[a-f0-9]{32}$/.test(caseId) || !/^upload_[a-f0-9]{32}$/.test(uploadId) || !/^doc_[a-f0-9]{24}$/.test(documentId)) {
      res.status(400).json({ error: "INVALID_DOCX_ANONYMIZED_REQUEST" });
      return;
    }
    try {
      const context = responseAuthContext(res);
      options.caseAccessService.assertAccess(context, caseId, "ANALYZE");
      const caseView = options.caseAccessService.openCase(context, caseId);
      const result = await options.caseAccessService.withCaseDataKey(context, caseId, "ANALYZE", async (caseDataKey) => {
        const store = options.secureCaseUploadStore!;
        const keyVersion = caseView.keyVersion;
        const upload = (await store.listUploads({ caseId, caseDataKey, keyVersion })).find((item) => item.uploadId === uploadId);
        if (!upload) throw new Error("STORED_UPLOAD_NOT_FOUND");
        if (editableMediaType(upload.mediaType, upload.filename) !== FORMAT_MEDIA_TYPE.docx) throw new Error("DOCX_ANONYMIZED_MEDIA_UNSUPPORTED");
        await service.restoreDocument!({ caseId, documentId, caseDataKey, keyVersion });
        const plan = service.anonymizedDocxPlan!(documentId);
        const data = await store.readUploadPayload({ caseId, uploadId, caseDataKey, keyVersion, maxBytes: 64 * 1024 * 1024 });
        try {
          const output = await anonymizeDocx(data, plan);
          const dot = upload.filename.lastIndexOf(".");
          return {
            filename: `${dot > 0 ? upload.filename.slice(0, dot) : upload.filename} (zanonimizowany).docx`,
            mediaType: FORMAT_MEDIA_TYPE.docx,
            data: output.data.toString("base64"),
            warnings: output.warnings
          };
        } finally {
          data.fill(0);
        }
      });
      res.setHeader("Cache-Control", "no-store");
      res.json(result);
    } catch (error) {
      if (sendCaseAccessError(res, error)) return;
      const code = error instanceof Error ? error.message : "";
      if (code === "ENOENT" || code.endsWith("NOT_FOUND") || code === "UNKNOWN_LOCAL_DOCUMENT") {
        res.status(404).json({ error: code === "ENOENT" ? "DOCUMENT_NOT_FOUND" : code });
        return;
      }
      if (code.startsWith("DOCX_ANONYMIZED_") || code.startsWith("OFFICE_DOCUMENT_")) {
        res.status(422).json({ error: /^[A-Z_]+/.exec(code)![0] });
        return;
      }
      console.error(`DOCX_ANONYMIZED_FAILED:${/^[A-Z][A-Z0-9_]{2,80}/.exec(code)?.[0] ?? "UNKNOWN"}`);
      res.status(500).json({ error: "DOCX_ANONYMIZED_FAILED" });
    }
  });

  // Stage and page counts of a running OCR/anonymization request.
  app.get(
    "/api/cases/:caseId/progress/:progressId",
    (req, res) => {
      const caseId = String(req.params.caseId ?? "").trim();
      const progressId = progressIdFrom(req.params.progressId);
      if (!options.caseAccessService || !/^case_[a-f0-9]{32}$/.test(caseId) || !progressId) {
        res.status(400).json({ error: "INVALID_PROGRESS_REQUEST" });
        return;
      }
      try {
        options.caseAccessService.assertAccess(responseAuthContext(res), caseId, "ANALYZE");
      } catch (error) {
        if (!sendCaseAccessError(res, error)) res.status(403).json({ error: "CASE_ACCESS_DENIED" });
        return;
      }
      res.setHeader("Cache-Control", "no-store");
      res.json({ progress: processingProgress.get(caseId, progressId) ?? null });
    }
  );

  // The anonymization key of one processed case document, for the user on
  // this computer only (never part of a model request).
  app.get(
    "/api/cases/:caseId/documents/:documentId/privacy-key",
    async (req, res) => {
      const caseId = String(req.params.caseId ?? "").trim();
      const documentId = String(req.params.documentId ?? "").trim();
      if (
        !options.documentService?.restoreDocument ||
        !options.documentService.privacyKey ||
        !options.caseAccessService
      ) {
        res.status(503).json({ error: "PRIVACY_KEY_UNAVAILABLE" });
        return;
      }
      if (!/^case_[a-f0-9]{32}$/.test(caseId) || !/^doc_[a-f0-9]{24}$/.test(documentId)) {
        res.status(400).json({ error: "INVALID_PRIVACY_KEY_REQUEST" });
        return;
      }
      try {
        const context = responseAuthContext(res);
        options.caseAccessService.assertAccess(context, caseId, "ANALYZE");
        const caseView = options.caseAccessService.openCase(context, caseId);
        await options.caseAccessService.withCaseDataKey(
          context,
          caseId,
          "ANALYZE",
          (caseDataKey) =>
            options.documentService!.restoreDocument!({
              caseId,
              documentId,
              caseDataKey,
              keyVersion: caseView.keyVersion
            })
        );
        res.setHeader("Cache-Control", "no-store");
        res.json({
          documentId,
          entries: options.documentService.privacyKey(documentId)
        });
      } catch (error) {
        if (sendCaseAccessError(res, error)) return;
        const code = error instanceof Error ? error.message : "";
        if (code === "ENOENT" || code.includes("NOT_FOUND") || code === "UNKNOWN_LOCAL_DOCUMENT") {
          res.status(404).json({ error: "PRIVACY_KEY_NOT_FOUND" });
          return;
        }
        console.error(`PRIVACY_KEY_FAILED:${/^[A-Z][A-Z0-9_]{2,80}/.exec(code)?.[0] ?? "UNKNOWN"}`);
        res.status(500).json({ error: "PRIVACY_KEY_FAILED" });
      }
    }
  );

  app.post(
    "/api/cases/:caseId/files/:uploadId/process",
    async (req, res) => {
      await processStoredCaseFile(
        req,
        res
      );
    }
  );

  app.post(
    "/api/cases/:caseId/files/:uploadId/members/:fileId/process",
    async (req, res) => {
      await processStoredCaseFile(
        req,
        res,
        String(
          req.params.fileId ?? ""
        )
      );
    }
  );

  app.get(
    "/api/cases/:caseId/templates",
    async (req, res) => {
      if (
        !options.caseAccessService ||
        !options.sharedTemplateStore
      ) {
        res.status(503).json({
          error:
            "CASE_TEMPLATE_LIBRARY_UNAVAILABLE"
        });
        return;
      }
      const caseId =
        String(
          req.params.caseId ??
          ""
        ).trim();
      try {
        options.caseAccessService
          .assertAccess(
            responseAuthContext(
              res
            ),
            caseId,
            "READ"
          );
        res.json({
          caseId,
          scope: "FIRM_SHARED",
          templates:
            await options
              .sharedTemplateStore
              .listTemplates()
        });
      } catch (error) {
        if (
          !sendCaseAccessError(
            res,
            error
          )
        ) {
          res.status(500).json({
            error:
              "CASE_TEMPLATE_LIST_FAILED"
          });
        }
      }
    }
  );

  app.post(
    "/api/cases/:caseId/files",
    caseUploadBody,
    async (req, res) => {
      if (!options.caseFileStore) {
        res.status(503).json({
          error:
            "CASE_STORAGE_UNAVAILABLE"
        });
        return;
      }
      if (
        !Buffer.isBuffer(req.body) ||
        req.body.byteLength === 0
      ) {
        res.status(400).json({
          error:
            "FILE_BODY_REQUIRED"
        });
        return;
      }

      const caseId =
        String(req.params.caseId ?? "")
          .trim();
      const mediaType =
        req.get("content-type")
          ?.split(";", 1)[0]
          ?.trim()
          .toLowerCase() ||
        "application/octet-stream";
      const filename =
        decodeUploadFilename(
          req.get("x-lex-filename")
        );

      try {
        let stored:
          StoredUpload;
        if (
          options.caseAccessService
        ) {
          const context =
            responseAuthContext(
              res
            );
          options.caseAccessService
            .assertAccess(
              context,
              caseId,
              "WRITE"
            );
          if (
            options
              .secureCaseUploadStore
          ) {
          const caseView =
            options.caseAccessService
              .openCase(
                context,
                caseId
              );
          stored =
            await options
              .caseAccessService
              .withCaseDataKey(
                context,
                caseId,
                "WRITE",
                async (
                  caseDataKey
                ) =>
                  await options
                    .secureCaseUploadStore!
                    .saveUpload({
                      caseId,
                      filename,
                      mediaType,
                      data:
                        new Uint8Array(
                          req.body
                        ),
                      caseDataKey,
                      keyVersion:
                        caseView.keyVersion
                    })
              );
          } else {
            stored =
              await options
                .caseFileStore
                .saveUpload({
                  caseId,
                  filename,
                  mediaType,
                  data:
                    new Uint8Array(
                      req.body
                    ),
                  extractArchive: true
                });
          }
        } else {
          stored =
            await options
              .caseFileStore
              .saveUpload({
                caseId,
                filename,
                mediaType,
                data:
                  new Uint8Array(
                    req.body
                  ),
                extractArchive: true
              });
        }
        res.status(201).json(
          stored
        );
      } catch (error) {
        if (
          !sendCaseAccessError(
            res,
            error
          )
        ) {
          res.status(422).json({
            error:
              "CASE_FILE_STORE_FAILED"
          });
        }
      }
    }
  );

  app.get("/api/skills", (_req, res) => {
    const skills = [...options.registry.skills.values()]
      .map((skill) =>
        publicSkill({
          name: skill.name,
          frontmatter: skill.frontmatter
        })
      )
      .sort((a, b) =>
        String(a.name).localeCompare(String(b.name), "pl")
      );

    res.json({
      count: skills.length,
      skills
    });
  });

  app.get("/api/routes", (_req, res) => {
    res.json({
      jurisdiction: "PL",
      primarySkills: routing.listDrSkills()
    });
  });

  app.post("/api/routes/validate", (req, res) => {
    const primarySkill =
      typeof req.body?.primarySkill === "string"
        ? req.body.primarySkill.trim()
        : "";

    if (!primarySkill) {
      res.status(400).json({
        error: "PRIMARY_SKILL_REQUIRED"
      });
      return;
    }

    const result = routing.validate(primarySkill);
    res.status(result.valid ? 200 : 422).json(result);
  });

  app.put(
    "/api/admin/providers/:provider/credential",
    (req, res) => {
      const context =
        responseAuthContext(res);
      if (
        context.user.appRole !==
          "ADMIN"
      ) {
        res.status(403).json({
          error:
            "AUTHORIZATION_DENIED"
        });
        return;
      }
      if (!options.credentialManager) {
        res.status(503).json({
          error:
            "PROVIDER_CREDENTIAL_MANAGER_UNAVAILABLE"
        });
        return;
      }
      const provider =
        String(
          req.params.provider ?? ""
        ).trim();
      if (!isProviderId(provider)) {
        res.status(404).json({
          error:
            "UNKNOWN_PROVIDER"
        });
        return;
      }
      const apiKey =
        typeof req.body?.apiKey ===
          "string"
          ? req.body.apiKey
          : "";
      try {
        options.credentialManager
          .setApiKey(
            provider,
            apiKey
          );
        res.json({
          provider,
          configured: true,
          storage:
            "PROCESS_MEMORY"
        });
      } catch {
        res.status(400).json({
          error:
            "INVALID_PROVIDER_API_KEY"
        });
      }
    }
  );

  app.delete(
    "/api/admin/providers/:provider/credential",
    (req, res) => {
      const context =
        responseAuthContext(res);
      if (
        context.user.appRole !==
          "ADMIN"
      ) {
        res.status(403).json({
          error:
            "AUTHORIZATION_DENIED"
        });
        return;
      }
      if (!options.credentialManager) {
        res.status(503).json({
          error:
            "PROVIDER_CREDENTIAL_MANAGER_UNAVAILABLE"
        });
        return;
      }
      const provider =
        String(
          req.params.provider ?? ""
        ).trim();
      if (!isProviderId(provider)) {
        res.status(404).json({
          error:
            "UNKNOWN_PROVIDER"
        });
        return;
      }
      options.credentialManager
        .clearApiKey(provider);
      res.json({
        provider,
        cleared: true,
        storage:
          "PROCESS_MEMORY"
      });
    }
  );

  app.get(
    "/api/update/status",
    async (_req, res) => {
      if (!options.updateDiscovery) {
        res.status(503).json({
          error:
            "UPDATE_DISCOVERY_UNAVAILABLE"
        });
        return;
      }
      try {
        const status = await options.updateDiscovery.check();
        const lastAttempt = lastFailedApplicationUpdate();
        res.json(lastAttempt ? { ...status, lastAttempt } : status);
      } catch {
        res.status(503).json({
          error:
            "UPDATE_DISCOVERY_UNAVAILABLE"
        });
      }
    }
  );

  app.get(
    "/api/provider-accounts",
    async (_req, res) => {
      if (!options.accountSessions) {
        res.status(503).json({
          error:
            "PROVIDER_ACCOUNT_SESSION_UNAVAILABLE"
        });
        return;
      }
      try {
        res.json({
          providers:
            await options
              .accountSessions
              .statusAll()
        });
      } catch {
        res.status(503).json({
          error:
            "PROVIDER_ACCOUNT_STATUS_FAILED"
        });
      }
    }
  );

  app.put(
    "/api/admin/provider-accounts/anthropic/oauth-token",
    (req, res) => {
      const context =
        responseAuthContext(res);
      if (
        context.user.appRole !==
          "ADMIN"
      ) {
        res.status(403).json({
          error:
            "AUTHORIZATION_DENIED"
        });
        return;
      }
      if (!options.accountSessions) {
        res.status(503).json({
          error:
            "PROVIDER_ACCOUNT_SESSION_UNAVAILABLE"
        });
        return;
      }
      const token =
        typeof req.body?.token ===
          "string"
          ? req.body.token
          : "";
      try {
        options.accountSessions
          .setAnthropicOAuthToken(
            token
          );
        res.json({
          provider: "anthropic",
          configured: true,
          storage:
            "PROCESS_MEMORY"
        });
      } catch {
        res.status(400).json({
          error:
            "INVALID_CLAUDE_OAUTH_TOKEN"
        });
      }
    }
  );

  app.delete(
    "/api/admin/provider-accounts/anthropic/oauth-token",
    (req, res) => {
      const context =
        responseAuthContext(res);
      if (
        context.user.appRole !==
          "ADMIN"
      ) {
        res.status(403).json({
          error:
            "AUTHORIZATION_DENIED"
        });
        return;
      }
      if (!options.accountSessions) {
        res.status(503).json({
          error:
            "PROVIDER_ACCOUNT_SESSION_UNAVAILABLE"
        });
        return;
      }
      options.accountSessions
        .clearAnthropicOAuthToken();
      res.json({
        provider: "anthropic",
        cleared: true,
        storage:
          "PROCESS_MEMORY"
      });
    }
  );

  app.post(
    "/api/provider-accounts/:provider/login",
    async (req, res) => {
      const context =
        responseAuthContext(res);
      if (
        context.user.appRole !==
          "ADMIN"
      ) {
        res.status(403).json({
          error:
            "AUTHORIZATION_DENIED"
        });
        return;
      }
      if (!options.accountSessions) {
        res.status(503).json({
          error:
            "PROVIDER_ACCOUNT_SESSION_UNAVAILABLE"
        });
        return;
      }
      const provider =
        String(
          req.params.provider ?? ""
        ).trim();
      if (!isProviderId(provider)) {
        res.status(404).json({
          error:
            "UNKNOWN_PROVIDER"
        });
        return;
      }
      try {
        res.json(
          await options
            .accountSessions
            .login(provider)
        );
      } catch (error) {
        const message =
          error instanceof Error
            ? error.message
            : "";
        const code =
          message.startsWith(
            "ACCOUNT_SESSION_CLI_NOT_INSTALLED:"
          )
            ? "ACCOUNT_SESSION_CLI_NOT_INSTALLED"
            : message.startsWith(
                "ACCOUNT_SESSION_NOT_SUBSCRIPTION_AUTH:"
              )
              ? "ACCOUNT_SESSION_SUBSCRIPTION_LOGIN_REQUIRED"
              : "ACCOUNT_SESSION_LOGIN_FAILED";
        res.status(
          code ===
            "ACCOUNT_SESSION_CLI_NOT_INSTALLED"
            ? 503
            : 422
        ).json({
          error: code,
          provider
        });
      }
    }
  );

  app.post(
    "/api/provider-accounts/:provider/logout",
    async (req, res) => {
      const context = responseAuthContext(res);
      if (context.user.appRole !== "ADMIN") {
        res.status(403).json({ error: "AUTHORIZATION_DENIED" });
        return;
      }
      if (!options.accountSessions) {
        res.status(503).json({ error: "PROVIDER_ACCOUNT_SESSION_UNAVAILABLE" });
        return;
      }
      const provider = String(req.params.provider ?? "").trim();
      if (!isProviderId(provider)) {
        res.status(404).json({ error: "UNKNOWN_PROVIDER" });
        return;
      }
      try {
        res.json(await options.accountSessions.logout(provider));
      } catch {
        res.status(422).json({ error: "ACCOUNT_SESSION_LOGOUT_FAILED", provider });
      }
    }
  );

  // Downloads the pinned account client (first Gemini CLI / Grok Build
  // install takes minutes) as a background job; the UI polls its stage.
  const provisionRoute = (
    action: "start" | "progress"
  ) =>
    (req: express.Request, res: express.Response) => {
      const context = responseAuthContext(res);
      if (context.user.appRole !== "ADMIN") {
        res.status(403).json({ error: "AUTHORIZATION_DENIED" });
        return;
      }
      const sessions = options.accountSessions;
      if (!sessions?.startProvision || !sessions.provisionProgress) {
        res.status(503).json({ error: "PROVIDER_ACCOUNT_SESSION_UNAVAILABLE" });
        return;
      }
      const provider = String(req.params.provider ?? "").trim();
      if (!isProviderId(provider)) {
        res.status(404).json({ error: "UNKNOWN_PROVIDER" });
        return;
      }
      res.json(
        action === "start"
          ? sessions.startProvision(provider)
          : sessions.provisionProgress(provider)
      );
    };
  // Removes the client Lex downloaded (not the provider login, not a system CLI).
  app.post(
    "/api/provider-accounts/:provider/uninstall",
    async (req, res) => {
      const context = responseAuthContext(res);
      if (context.user.appRole !== "ADMIN") {
        res.status(403).json({ error: "AUTHORIZATION_DENIED" });
        return;
      }
      const sessions = options.accountSessions;
      if (!sessions?.uninstall) {
        res.status(503).json({ error: "PROVIDER_ACCOUNT_SESSION_UNAVAILABLE" });
        return;
      }
      const provider = String(req.params.provider ?? "").trim();
      if (!isProviderId(provider)) {
        res.status(404).json({ error: "UNKNOWN_PROVIDER" });
        return;
      }
      try {
        res.json(await sessions.uninstall(provider));
      } catch (error) {
        const busy =
          error instanceof Error &&
          error.message.startsWith("ACCOUNT_CLIENT_UNINSTALL_BUSY:");
        res.status(busy ? 409 : 422).json({
          error: busy
            ? "ACCOUNT_CLIENT_UNINSTALL_BUSY"
            : "ACCOUNT_CLIENT_UNINSTALL_FAILED",
          provider
        });
      }
    }
  );

  app.post("/api/provider-accounts/:provider/provision", provisionRoute("start"));
  app.get("/api/provider-accounts/:provider/provision", provisionRoute("progress"));

  app.get("/api/providers", async (_req, res) => {
    if (!options.credentialResolver) {
      res.status(503).json({
        error:
          "PROVIDER_CONFIGURATION_STATUS_UNAVAILABLE"
      });
      return;
    }

    const providers =
      await providerConfigurationStatus(
        options.credentialResolver
      );

    res.json({
      providers
    });
  });

  app.get("/api/models/:provider", async (req, res) => {
    const provider = String(req.params.provider ?? "");
    if (!isProviderId(provider)) {
      res.status(404).json({
        error: "UNKNOWN_PROVIDER"
      });
      return;
    }

    try {
      const models = await options.modelCatalog.list(provider);
      res.json({
        provider,
        models: sanitizeModels(models)
      });
    } catch (error) {
      if (
        error instanceof Error &&
        error.message.startsWith(
          "PROCESS_PLEADING_"
        )
      ) {
        const code =
          error.message.split(
            ":",
            1
          )[0]!;
        res.status(
          code ===
            "PROCESS_PLEADING_CASE_REQUIRED"
            ? 422
            : 409
        ).json({
          error: code,
          ...(error.message.includes(":")
            ? {
                detail:
                  error.message.slice(
                    error.message.indexOf(
                      ":"
                    ) + 1
                  )
              }
            : {})
        });
        return;
      }

      if (error instanceof MissingProviderCredentialError) {
        res.status(503).json({
          error: "PROVIDER_NOT_CONFIGURED",
          provider
        });
        return;
      }

      res.status(502).json({
        error: "PROVIDER_MODEL_DISCOVERY_FAILED",
        provider
      });
    }
  });

  const documentBody = express.raw({
    type: [
      "application/pdf",
      "image/jpeg",
      "image/png",
      "image/webp",
      "image/tiff",
      "text/plain",
      "text/markdown",
      "text/csv",
      "text/tab-separated-values",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      "application/vnd.oasis.opendocument.text",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      "application/vnd.ms-excel.sheet.macroenabled.12",
      "message/rfc822",
      "application/rtf",
      ...Object.keys(RECORDING_MEDIA_TYPES)
    ],
    // A recording too: the body is held in memory, so the same bound as a scan (an hour of
    // audio is about 60 MB; a long video above it is refused with 413).
    limit: "512mb"
  });

  app.post(
    "/api/documents/ingest",
    documentBody,
    async (req, res) => {
      if (!options.documentService) {
        res.status(503).json({
          error: "DOCUMENT_INGESTION_UNAVAILABLE"
        });
        return;
      }

      const mediaType =
        requestDocumentMediaType(req);
      if (!mediaType) {
        res.status(415).json({
          error: "UNSUPPORTED_DOCUMENT_MEDIA_TYPE"
        });
        return;
      }

      if (
        !Buffer.isBuffer(req.body) ||
        req.body.byteLength === 0
      ) {
        res.status(400).json({
          error: "DOCUMENT_BODY_REQUIRED"
        });
        return;
      }

      try {
        const data = new Uint8Array(req.body);
        let stored:
          StoredUpload | undefined;
        let caseId:
          string | undefined;

        if (options.caseFileStore) {
          caseId =
            req.get("x-lex-case-id")
              ?.trim();
          if (!caseId) {
            res.status(400).json({
              error: "CASE_ID_REQUIRED"
            });
            return;
          }
          const filename =
            decodeUploadFilename(
              req.get(
                "x-lex-filename"
              )
            );
          if (
            options.caseAccessService
          ) {
            const context =
              responseAuthContext(
                res
              );
            options.caseAccessService
              .assertAccess(
                context,
                caseId,
                "WRITE"
              );
            if (
              options
                .secureCaseUploadStore
            ) {
            const securedCaseId =
              caseId;
            const caseView =
              options.caseAccessService
                .openCase(
                  context,
                  securedCaseId
                );
            stored =
              await options
                .caseAccessService
                .withCaseDataKey(
                  context,
                  securedCaseId,
                  "WRITE",
                  async (
                    caseDataKey
                  ) =>
                    await options
                      .secureCaseUploadStore!
                      .saveUpload({
                        caseId:
                          securedCaseId,
                        filename,
                        mediaType,
                        data,
                        caseDataKey,
                        keyVersion:
                          caseView.keyVersion
                      })
                );
            } else {
              stored =
                await options
                  .caseFileStore
                  .saveUpload({
                    caseId,
                    filename,
                    mediaType,
                    data,
                    extractArchive:
                      false
                  });
            }
          } else {
            stored =
              await options
                .caseFileStore
                .saveUpload({
                  caseId,
                  filename,
                  mediaType,
                  data,
                  extractArchive:
                    false
                });
          }
        }

        let result;
        if (
          caseId &&
          options.caseAccessService
        ) {
          const context =
            responseAuthContext(
              res
            );
          const caseView =
            options.caseAccessService
              .openCase(
                context,
                caseId
              );
          result =
            await options
              .caseAccessService
              .withCaseDataKey(
                context,
                caseId,
                "WRITE",
                async (
                  caseDataKey
                ) =>
                  await ingestDocumentMedia(
                    options
                      .documentService!,
                    data,
                    mediaType,
                    {
                      caseId,
                      caseDataKey,
                      keyVersion:
                        caseView.keyVersion
                    }
                  )
              );
        } else {
          result =
            await ingestDocumentMedia(
              options
                .documentService,
              data,
              mediaType
            );
        }
        if (stored) {
          documentCaseIds.set(
            result.documentId,
            stored.caseId
          );
        }
        res.status(201).json({
          ...result,
          ...(stored
            ? {
                caseId: stored.caseId,
                uploadId: stored.uploadId
              }
            : {})
        });
      } catch (error) {
        if (
          !sendCaseAccessError(
            res,
            error
          )
        ) {
          res.status(422).json({
            error: "DOCUMENT_INGESTION_FAILED"
          });
        }
      }
    }
  );

  app.post(
    "/api/documents/review",
    documentBody,
    async (req, res) => {
      if (keepAliveRequested(req)) keepResponseAlive(res);
      if (!options.documentService) {
        res.status(503).json({
          error: "DOCUMENT_INGESTION_UNAVAILABLE"
        });
        return;
      }

      const mediaType =
        requestDocumentMediaType(req);
      if (!mediaType) {
        res.status(415).json({
          error: "UNSUPPORTED_DOCUMENT_MEDIA_TYPE"
        });
        return;
      }
      if (
        !Buffer.isBuffer(req.body) ||
        req.body.byteLength === 0
      ) {
        res.status(400).json({
          error: "DOCUMENT_BODY_REQUIRED"
        });
        return;
      }

      try {
        let data =
          new Uint8Array(req.body);
        // A password-protected PDF or DOCX/XLSX: opened here with the password the user typed
        // (X-Lex-Document-Password, this request only); without it the user is asked for one.
        const encrypted = options.documentDecryptor ? encryptedKind(data, mediaType) : null;
        if (encrypted && options.documentDecryptor) {
          const password = passwordFromHeader(req.get("x-lex-document-password"));
          try {
            data = await options.documentDecryptor.decrypt(data, encrypted, password ?? "") as Uint8Array<ArrayBuffer>;
          } catch (error) {
            const code = error instanceof Error ? error.message : String(error);
            if (!code.startsWith("DOCUMENT_NOT_ENCRYPTED")) {
              res.status(422).json({
                error: code.startsWith("DOCUMENT_PASSWORD_INVALID")
                  ? password ? "DOCUMENT_PASSWORD_INVALID" : "DOCUMENT_PASSWORD_REQUIRED"
                  : code.split(":", 1)[0]
              });
              return;
            }
          }
        }
        let stored:
          StoredUpload | undefined;
        let caseId:
          string | undefined;

        if (options.caseFileStore) {
          caseId =
            req.get("x-lex-case-id")
              ?.trim();
          if (!caseId) {
            res.status(400).json({
              error: "CASE_ID_REQUIRED"
            });
            return;
          }
          const filename =
            decodeUploadFilename(
              req.get(
                "x-lex-filename"
              )
            );
          if (
            options.caseAccessService
          ) {
            const context =
              responseAuthContext(
                res
              );
            options.caseAccessService
              .assertAccess(
                context,
                caseId,
                "WRITE"
              );
            if (
              options
                .secureCaseUploadStore
            ) {
            const securedCaseId =
              caseId;
            const caseView =
              options.caseAccessService
                .openCase(
                  context,
                  securedCaseId
                );
            stored =
              await options
                .caseAccessService
                .withCaseDataKey(
                  context,
                  securedCaseId,
                  "WRITE",
                  async (
                    caseDataKey
                  ) =>
                    await options
                      .secureCaseUploadStore!
                      .saveUpload({
                        caseId:
                          securedCaseId,
                        filename,
                        mediaType,
                        data,
                        caseDataKey,
                        keyVersion:
                          caseView.keyVersion
                      })
                );
            } else {
              stored =
                await options
                  .caseFileStore
                  .saveUpload({
                    caseId,
                    filename,
                    mediaType,
                    data,
                    extractArchive:
                      false
                  });
            }
          } else {
            stored =
              await options
                .caseFileStore
                .saveUpload({
                  caseId,
                  filename,
                  mediaType,
                  data,
                  extractArchive:
                    false
                });
          }
        }

        let result:
          Awaited<
            ReturnType<
              NonNullable<
                LexHttpAppOptions[
                  "documentService"
                ]
              >["review"]
            >
          >;
        const processing = documentProcessingOptions(req.get("x-lex-processing"));
        if (
          caseId &&
          options.caseAccessService &&
          processing.background
        ) {
          // Read ahead of the user's work: the OCR outside the case lock (see document-work.ts).
          const context = responseAuthContext(res);
          const access = options.caseAccessService;
          const progressId = progressIdFrom(req.get("x-lex-progress"));
          const backgroundCaseId = caseId;
          result = await options.documentService.review(data, mediaType, {
            caseId: backgroundCaseId,
            ...processing,
            ...(progressId ? { onProgress: processingProgress.reporter(backgroundCaseId, progressId)! } : {}),
            storeUnderLock: (save) =>
              access.withCaseDataKey(context, backgroundCaseId, "WRITE", async (caseDataKey) =>
                save({ caseDataKey, keyVersion: access.openCase(context, backgroundCaseId).keyVersion })
              )
          });
        } else if (
          caseId &&
          options.caseAccessService
        ) {
          const context =
            responseAuthContext(
              res
            );
          const caseView =
            options.caseAccessService
              .openCase(
                context,
                caseId
              );
          result =
            await options
              .caseAccessService
              .withCaseDataKey(
                context,
                caseId,
                "WRITE",
                async (
                  caseDataKey
                ) =>
                  await options
                    .documentService!
                    .review(
                      data,
                      mediaType,
                      {
                        caseId,
                        caseDataKey,
                        keyVersion:
                          caseView.keyVersion,
                        ...documentProcessingOptions(
                          req.get("x-lex-processing")
                        ),
                        // Stage and page while the chat's document is processed.
                        ...(progressIdFrom(req.get("x-lex-progress"))
                          ? { onProgress: processingProgress.reporter(caseId, progressIdFrom(req.get("x-lex-progress")))! }
                          : {})
                      }
                    )
              );
        } else {
          result =
            await options
              .documentService
              .review(
                data,
                mediaType,
                caseId
                  ? { caseId }
                  : undefined
              );
        }
        if (stored) {
          documentCaseIds.set(
            result.documentId,
            stored.caseId
          );
        }
        res.status(201).json({
          ...result,
          ...(stored
            ? {
                caseId: stored.caseId,
                uploadId: stored.uploadId
              }
            : {})
        });
      } catch (error) {
        if (
          !sendCaseAccessError(
            res,
            error
          )
        ) {
          res.status(422).json({
            error: "DOCUMENT_REVIEW_FAILED",
            description:
              safeDiagnosticText(
                error
              )
          });
        }
      }
    }
  );

  // The scan of a page next to its text in the preview: the user's own file, local only.
  app.get("/api/documents/:documentId/pages/:page/scan", async (req, res) => {
    const documentService = options.documentService;
    if (!documentService?.pageScan) {
      res.status(503).json({ error: "DOCUMENT_INGESTION_UNAVAILABLE" });
      return;
    }
    const documentId = String(req.params.documentId ?? "").trim();
    const page = Number(req.params.page);
    const requestedCaseId = typeof req.query.caseId === "string" ? req.query.caseId.trim() : "";
    if (
      !/^doc_[a-f0-9]{24}$/.test(documentId) ||
      !Number.isInteger(page) ||
      page < 1 ||
      (requestedCaseId && !/^case_[a-f0-9]{32}$/.test(requestedCaseId))
    ) {
      res.status(400).json({ error: "INVALID_DOCUMENT_PAGE_SCAN" });
      return;
    }
    try {
      let scan;
      if (options.caseAccessService) {
        const caseId = requestedCaseId || documentCaseIds.get(documentId);
        if (!caseId) throw new CaseAccessError("CASE_ACCESS_DENIED", 403);
        const context = responseAuthContext(res);
        options.caseAccessService.assertAccess(context, caseId, "ANALYZE");
        const caseView = options.caseAccessService.openCase(context, caseId);
        scan = await options.caseAccessService.withCaseDataKey(context, caseId, "ANALYZE", async (caseDataKey) =>
          await documentService.pageScan!(documentId, page, { caseId, caseDataKey, keyVersion: caseView.keyVersion })
        );
      } else {
        scan = await documentService.pageScan(documentId, page);
      }
      res.setHeader("Cache-Control", "no-store");
      if (!scan) {
        res.status(404).json({ error: "DOCUMENT_PAGE_SCAN_UNAVAILABLE" });
        return;
      }
      res.json(scan);
    } catch (error) {
      if (!sendCaseAccessError(res, error)) {
        const code = error instanceof Error ? error.message : "";
        if (/^(UNKNOWN_LOCAL_DOCUMENT|INVALID_DOCUMENT_PAGE|ENOENT)$/.test(code)) {
          res.status(404).json({ error: code === "ENOENT" ? "DOCUMENT_NOT_FOUND" : code });
          return;
        }
        res.status(422).json({ error: code === "DOCUMENT_VAULT_CONTEXT_REQUIRED" ? code : "DOCUMENT_PAGE_SCAN_FAILED" });
      }
    }
  });

  app.post(
    "/api/documents/:documentId/pages/:page/text",
    async (req, res) => {
      // Waits for the document work before it (one at a time, see document-work.ts).
      if (keepAliveRequested(req)) keepResponseAlive(res);
      const documentService = options.documentService;
      if (!documentService?.editPage) {
        res.status(503).json({ error: "DOCUMENT_INGESTION_UNAVAILABLE" });
        return;
      }
      const documentId = String(req.params.documentId ?? "").trim();
      const page = Number(req.params.page);
      const requestedCaseId = typeof req.body?.caseId === "string" ? req.body.caseId.trim() : "";
      const text = req.body?.text;
      if (
        !/^doc_[a-f0-9]{24}$/.test(documentId) ||
        !Number.isInteger(page) ||
        page < 1 ||
        typeof text !== "string" ||
        (requestedCaseId && !/^case_[a-f0-9]{32}$/.test(requestedCaseId))
      ) {
        res.status(400).json({ error: "INVALID_DOCUMENT_PAGE_EDIT" });
        return;
      }
      try {
        let result;
        if (options.caseAccessService) {
          const caseId = requestedCaseId || documentCaseIds.get(documentId);
          if (!caseId) throw new CaseAccessError("CASE_ACCESS_DENIED", 403);
          const context = responseAuthContext(res);
          const caseView = options.caseAccessService.openCase(context, caseId);
          result = await options.caseAccessService.withCaseDataKey(
            context,
            caseId,
            "WRITE",
            async (caseDataKey) =>
              await documentService.editPage!(documentId, page, text, {
                caseId,
                caseDataKey,
                keyVersion: caseView.keyVersion
              })
          );
        } else {
          result = await documentService.editPage(documentId, page, text);
        }
        res.json(result);
      } catch (error) {
        if (!sendCaseAccessError(res, error)) {
          const code = error instanceof Error ? error.message : "";
          res.status(422).json({
            error: /^(UNKNOWN_LOCAL_DOCUMENT|INVALID_DOCUMENT_PAGE|DOCUMENT_PAGE_TEXT_TOO_LONG|DOCUMENT_VAULT_CONTEXT_REQUIRED)$/.test(code)
              ? code
              : "DOCUMENT_PAGE_EDIT_FAILED"
          });
        }
      }
    }
  );

  // The user's choice after a background read: the vision model reads the doubtful OCR lines
  // again (only for a document read with line images and not corrected yet).
  app.post("/api/documents/:documentId/correct", async (req, res) => {
    if (keepAliveRequested(req)) keepResponseAlive(res);
    const documentId = String(req.params.documentId ?? "").trim();
    const caseId = typeof req.body?.caseId === "string" ? req.body.caseId.trim() : "";
    const service = options.documentService;
    if (!service?.correct || !options.caseAccessService) {
      res.status(503).json({ error: "DOCUMENT_INGESTION_UNAVAILABLE" });
      return;
    }
    if (!/^doc_[a-f0-9]{24}$/.test(documentId) || !/^case_[a-f0-9]{32}$/.test(caseId)) {
      res.status(400).json({ error: "INVALID_DOCUMENT_PRIVACY_REQUEST" });
      return;
    }
    try {
      const context = responseAuthContext(res);
      const caseView = options.caseAccessService.openCase(context, caseId);
      const progressId = progressIdFrom(req.get("x-lex-progress"));
      const result = await options.caseAccessService.withCaseDataKey(context, caseId, "WRITE", async (caseDataKey) =>
        service.correct!(documentId, {
          caseId,
          caseDataKey,
          keyVersion: caseView.keyVersion,
          ...(progressId ? { onProgress: processingProgress.reporter(caseId, progressId)! } : {})
        })
      );
      res.json(result);
    } catch (error) {
      if (sendCaseAccessError(res, error)) return;
      const code = error instanceof Error ? error.message : "";
      if (code === "UNKNOWN_LOCAL_DOCUMENT") {
        res.status(404).json({ error: code });
        return;
      }
      console.error(`DOCUMENT_CORRECT_FAILED:${/^[A-Z][A-Z0-9_]{2,80}/.exec(code)?.[0] ?? "UNKNOWN"}`);
      res.status(500).json({ error: "DOCUMENT_CORRECT_FAILED" });
    }
  });

  // The second step after "ocr-only": personal data of a document already read (the text model,
  // with "local-ai", is started only now, after the OCR of every file).
  app.post("/api/documents/:documentId/detect", async (req, res) => {
    if (keepAliveRequested(req)) keepResponseAlive(res);
    const documentId = String(req.params.documentId ?? "").trim();
    const caseId = typeof req.body?.caseId === "string" ? req.body.caseId.trim() : "";
    const service = options.documentService;
    if (!service?.detect || !options.caseAccessService) {
      res.status(503).json({ error: "DOCUMENT_INGESTION_UNAVAILABLE" });
      return;
    }
    if (!/^doc_[a-f0-9]{24}$/.test(documentId) || !/^case_[a-f0-9]{32}$/.test(caseId)) {
      res.status(400).json({ error: "INVALID_DOCUMENT_PRIVACY_REQUEST" });
      return;
    }
    try {
      const context = responseAuthContext(res);
      const caseView = options.caseAccessService.openCase(context, caseId);
      const progressId = progressIdFrom(req.get("x-lex-progress"));
      const result = await options.caseAccessService.withCaseDataKey(context, caseId, "WRITE", async (caseDataKey) =>
        service.detect!(documentId, {
          caseId,
          caseDataKey,
          keyVersion: caseView.keyVersion,
          ...documentProcessingOptions(req.get("x-lex-processing")),
          ...(progressId ? { onProgress: processingProgress.reporter(caseId, progressId)! } : {})
        })
      );
      res.json(result);
    } catch (error) {
      if (sendCaseAccessError(res, error)) return;
      const code = error instanceof Error ? error.message : "";
      if (code === "UNKNOWN_LOCAL_DOCUMENT") {
        res.status(404).json({ error: code });
        return;
      }
      if (code.startsWith("LOCAL_PRIVACY_MODEL") || code.startsWith("PRIVACY_RECOGNIZER")) {
        res.status(503).json({ error: code.split(":", 1)[0] });
        return;
      }
      console.error(`DOCUMENT_DETECT_FAILED:${/^[A-Z][A-Z0-9_]{2,80}/.exec(code)?.[0] ?? "UNKNOWN"}`);
      res.status(500).json({ error: "DOCUMENT_DETECT_FAILED" });
    }
  });

  app.post(
    "/api/documents/:documentId/finalize",
    async (req, res) => {
      if (keepAliveRequested(req)) keepResponseAlive(res);
      if (!options.documentService) {
        res.status(503).json({
          error: "DOCUMENT_INGESTION_UNAVAILABLE"
        });
        return;
      }

      const documentId =
        String(req.params.documentId ?? "")
          .trim();
      const requestedCaseId =
        typeof req.body?.caseId ===
          "string"
          ? req.body.caseId.trim()
          : "";
      const directives =
        parsePrivacyDirectives(
          req.body?.directives
        );
      // Confirmed in the preview; a document without it never goes to a model outside the computer.
      const reviewed = req.body?.reviewed === true;
      if (
        !/^doc_[a-f0-9]{24}$/.test(
          documentId
        ) ||
        (
          requestedCaseId &&
          !/^case_[a-f0-9]{32}$/.test(
            requestedCaseId
          )
        ) ||
        directives === null
      ) {
        res.status(400).json({
          error: "INVALID_DOCUMENT_PRIVACY_REQUEST"
        });
        return;
      }

      try {
        let result;
        if (
          options.caseAccessService
        ) {
          const caseId =
            requestedCaseId ||
            documentCaseIds.get(
              documentId
            );
          if (!caseId) {
            throw new CaseAccessError(
              "CASE_ACCESS_DENIED",
              403
            );
          }
          const context =
            responseAuthContext(
              res
            );
          const caseView =
            options.caseAccessService
              .openCase(
                context,
                caseId
              );
          result =
            await options
              .caseAccessService
              .withCaseDataKey(
                context,
                caseId,
                "WRITE",
                async (
                  caseDataKey
                ) =>
                  await options
                    .documentService!
                    .finalizeReview(
                      documentId,
                      directives,
                      {
                        caseId,
                        caseDataKey,
                        keyVersion:
                          caseView.keyVersion,
                        ...(progressIdFrom(req.get("x-lex-progress"))
                          ? {
                              onProgress: processingProgress.reporter(
                                caseId,
                                progressIdFrom(req.get("x-lex-progress"))
                              )!
                            }
                          : {})
                      },
                      reviewed
                    )
              );
        } else {
          result =
            await options
              .documentService
              .finalizeReview(
                documentId,
                directives,
                undefined,
                reviewed
              );
        }
        res.json(result);
      } catch (error) {
        if (
          !sendCaseAccessError(
            res,
            error
          )
        ) {
          // The coded cause only (e.g. OVERLAPPING_PRIVACY_DIRECTIVES), never document text.
          const reason = error instanceof Error ? /^[A-Z][A-Z0-9_]{2,80}(?=$|:)/.exec(error.message)?.[0] : undefined;
          res.status(422).json({
            error: "DOCUMENT_PRIVACY_FINALIZATION_FAILED",
            ...(reason ? { reason } : {})
          });
        }
      }
    }
  );

  app.post(
    "/api/cases/:caseId/authoring/aliases",
    async (req, res) => {
      if (
        !options.caseAccessService ||
        !options.documentAuthoringService
      ) {
        res.status(503).json({
          error:
            "DOCUMENT_AUTHORING_UNAVAILABLE"
        });
        return;
      }
      const caseId =
        String(
          req.params.caseId ??
            ""
        );
      const sourceDocumentIds =
        Array.isArray(
          req.body?.sourceDocumentIds
        )
          ? req.body.sourceDocumentIds
              .filter(
                (
                  value:
                    unknown
                ) =>
                  typeof value ===
                    "string"
              )
          : null;
      if (
        !sourceDocumentIds ||
        sourceDocumentIds.length <
          1 ||
        sourceDocumentIds.length >
          99
      ) {
        res.status(400).json({
          error:
            "INVALID_AUTHORING_REQUEST"
        });
        return;
      }

      try {
        const context =
          responseAuthContext(res);
        const view =
          options.caseAccessService
            .openCase(
              context,
              caseId
            );
        const aliases =
          await options
            .caseAccessService
            .withCaseDataKey(
              context,
              caseId,
              "ANALYZE",
              async (
                caseDataKey
              ) =>
                await options
                  .documentAuthoringService!
                  .aliasManifest({
                    caseId,
                    sourceDocumentIds,
                    caseDataKey,
                    keyVersion:
                      view.keyVersion
                  })
            );
        res.json(aliases);
      } catch (error) {
        if (
          !sendCaseAccessError(
            res,
            error
          )
        ) {
          res.status(422).json({
            error:
              error instanceof
                Error
                ? error.message
                : "DOCUMENT_AUTHORING_ALIAS_FAILED"
          });
        }
      }
    }
  );

  app.post(
    "/api/cases/:caseId/artifacts/generate",
    async (req, res) => {
      if (keepAliveRequested(req)) keepResponseAlive(res);
      // A generated file goes into the case's work register: later turns know it exists.
      const sendJson = res.json.bind(res);
      res.json = ((body: unknown) => {
        const generated = body as { artifact?: { artifactId?: unknown; filename?: unknown }; warnings?: unknown[] } | null;
        const artifactId = generated?.artifact?.artifactId;
        const filename = generated?.artifact?.filename;
        if (typeof artifactId === "string" && typeof filename === "string" && options.caseMemoryStore && options.caseAccessService) {
          const actor = responseAuthContext(res);
          const caseId = String(req.params.caseId);
          void (async () => {
            const caseView = options.caseAccessService!.openCase(actor, caseId);
            await options.caseAccessService!.withCaseDataKey(actor, caseId, "WRITE", async (caseDataKey) => {
              const key = { caseId, caseDataKey, keyVersion: caseView.keyVersion };
              const current = await options.caseMemoryStore!.getCaseMemory(key);
              await options.caseMemoryStore!.saveCaseMemory({
                ...key,
                work: recordCaseWork(current.work ?? [], { now: new Date().toISOString(), files: [{ artifactId, filename, draft: /PROJEKT|draft/iu.test(filename) }] })
              });
            });
          })().catch((error: unknown) => process.stderr.write(`CASE_WORK_FILE_NOT_SAVED:${error instanceof Error ? error.message : String(error)}\n`));
        }
        return sendJson(body);
      }) as typeof res.json;
      if (
        !options.caseAccessService ||
        !options.documentAuthoringService ||
        !options.documentAstGenerator ||
        !options.documentService
      ) {
        res.status(503).json({
          error:
            "DOCUMENT_GENERATION_UNAVAILABLE"
        });
        return;
      }

      const caseId =
        String(
          req.params.caseId ??
            ""
        );
      const sessionRequest =
        parseSessionRequest(
          req.body
        );
      const attachments =
        parseDocumentAttachments(
          req.body?.attachments
        );
      const firmTemplates =
        parseFirmTemplates(
          req.body?.firmTemplates
        );
      // No template picked: the firm's default for the requested document
      // (its layout for the model, its styles for the file).
      const generationTemplate =
        sessionRequest && firmTemplates && firmTemplates.length === 0
          ? await firmDefaultTemplate(
              res,
              sessionRequest.query,
              ["pleading", "contract", "opinion", "letter", "report", "other"].includes(String(req.body?.documentType))
                ? (req.body.documentType as GenerationDocumentType)
                : undefined
            )
          : null;
      if (generationTemplate) firmTemplates!.push(generationTemplate.templateId);
      // Firm templates and firm files may shape the document; they are not
      // case sources, so they get no aliases.
      const firmCaseId =
        firmTemplates?.length ||
        attachments?.some((selection) => selection.caseId && selection.caseId !== caseId)
          ? options.caseAccessService
              ?.getFirmKnowledgeWorkspace(responseAuthContext(res))
              ?.caseId
          : undefined;
      const format =
        req.body?.format;
      const documentType =
        req.body?.documentType;
      const styleProfile =
        req.body?.styleProfile;
      const templateId =
        typeof req.body
          ?.templateId ===
          "string"
          ? req.body
              .templateId
              .trim()
          : generationTemplate?.templateId;
      const requestedStyleValid =
        [
          "lex-classic-clean-v1",
          "lex-light-legal-design-v1",
          "lex-classic-tnr-v1",
          "lex-office-tnr-v1"
        ].includes(
          String(
            styleProfile
          )
        );

      if (
        !sessionRequest ||
        attachments === null ||
        (
          format !== "docx" &&
          format !== "odt"
        ) ||
        ![
          "pleading",
          "contract",
          "opinion",
          "letter",
          "report",
          "other"
        ].includes(
          String(
            documentType
          )
        ) ||
        (
          !templateId &&
          !requestedStyleValid
        ) ||
        (
          templateId !==
            undefined &&
          !/^template_[a-f0-9]{32}$/
            .test(
              templateId
            )
        ) ||
        firmTemplates === null ||
        attachments.length + firmTemplates.length > MAX_DOCUMENT_ATTACHMENTS ||
        attachments.some(
          (selection) =>
            Boolean(
              selection.caseId
            ) &&
            selection.caseId !==
              caseId &&
            selection.caseId !==
              firmCaseId
        )
      ) {
        res.status(400).json({
          error:
            "INVALID_DOCUMENT_GENERATION_REQUEST"
        });
        return;
      }

      // A document request in AUTO mode is routed like a chat turn. The
      // document pipeline (workflow, HYBRID-VAL before the file) needs its
      // domain and workflow before it starts, so it keeps the routing pass.
      if (
        !(await resolveAutoPrimarySkill(
          sessionRequest,
          res,
          attachments.length,
          {
            allowModelSelection: false,
            allowConversational: false
          }
        ))
      ) {
        return;
      }

      const route =
        routing.validate(
          sessionRequest
            .primarySkill
        );
      if (!route.valid) {
        res.status(422).json({
          error:
            "INVALID_ROUTE",
          reason:
            route.reason
        });
        return;
      }

      try {
        const context =
          responseAuthContext(
            res
          );
        const caseView =
          options
            .caseAccessService
            .openCase(
              context,
              caseId
            );

        const resolvedAttachments:
          SessionDocumentAttachment[] =
          [];
        const firmSelections = attachments.filter(
          (selection) => firmCaseId !== undefined && selection.caseId === firmCaseId && firmCaseId !== caseId
        );
        for (
          const selection
          of attachments
        ) {
          if (firmSelections.includes(selection)) continue;
          options
            .caseAccessService
            .assertAccess(
              context,
              caseId,
              "ANALYZE"
            );

          if (
            options
              .documentService
              .restoreDocument
          ) {
            await options
              .caseAccessService
              .withCaseDataKey(
                context,
                caseId,
                "ANALYZE",
                async (
                  caseDataKey
                ) =>
                  await options
                    .documentService!
                    .restoreDocument!({
                      caseId,
                      documentId:
                        selection
                          .documentId,
                      caseDataKey,
                      keyVersion:
                        caseView
                          .keyVersion
                    })
              );
          }

          const resolved =
            await options
              .documentService
              .resolveProtectedChunks({
                documentId:
                  selection
                    .documentId,
                chunkIndices:
                  selection
                    .chunkIndices
              }, { remote: true });
          resolvedAttachments.push({
            caseId,
            documentId:
              resolved
                .documentId,
            sourceScope:
              "MANUAL",
            ...(resolved.grammar
              ? { grammar: resolved.grammar }
              : {}),
            ...(resolved.totalPages
              ? { totalPages: resolved.totalPages }
              : {}),
            chunks:
              resolved.chunks.map(
                (chunk) => ({
                  ...chunk
                })
              )
          });
        }

        const sourceDocumentIds =
          [
            ...new Set(
              resolvedAttachments
                .map(
                  (item) =>
                    item.documentId
                )
            )
          ];

        // Documents on the case's shared key: raw tokens in the context and
        // one alias per person (D00); the instruction is pseudonymized with
        // the same key.
        const sharedGeneration =
          sourceDocumentIds.length > 0 && options.documentService.sharedKeyState
            ? await options.caseAccessService.withCaseDataKey(
                context,
                caseId,
                "ANALYZE",
                (caseDataKey) =>
                  options.documentService!.sharedKeyState!({
                    caseId,
                    caseDataKey,
                    keyVersion: caseView.keyVersion
                  })
              )
            : null;
        if (sharedGeneration) {
          for (const attachment of resolvedAttachments) {
            if (sharedGeneration.members.has(attachment.documentId)) attachment.sharedKey = true;
          }
        }

        const aliases =
          sourceDocumentIds.length > 0
            ? await options
                .caseAccessService
                .withCaseDataKey(
                  context,
                  caseId,
                  "ANALYZE",
                  async (
                    caseDataKey
                  ) =>
                    await options
                      .documentAuthoringService!
                      .aliasManifest({
                        caseId,
                        sourceDocumentIds,
                        caseDataKey,
                        keyVersion:
                          caseView
                            .keyVersion
                      })
                )
            : {
                schemaVersion: 1 as const,
                entries: []
              };

        // Appended after the case sources so their alias prefixes (D01…) stay the same.
        if (firmSelections.length > 0 || firmTemplates.length > 0) {
          const firmMaterial = await resolveSelectedAttachments(res, firmSelections, firmTemplates, firmCaseId);
          if (!firmMaterial) return;
          resolvedAttachments.push(...firmMaterial);
        }

        let effectiveStyleProfile =
          styleProfile as LegalStyleProfile;
        let templateProfile:
          | Awaited<
              ReturnType<
                NonNullable<
                  typeof options.templateProfileService
                >["resolve"]
              >
            >
          | undefined;

        if (templateId) {
          if (
            !options
              .templateProfileService
          ) {
            res.status(503).json({
              error:
                "TEMPLATE_PROFILE_SERVICE_UNAVAILABLE"
            });
            return;
          }
          templateProfile =
            await options
              .templateProfileService
              .resolve(
                templateId
              );
          effectiveStyleProfile =
            templateProfile
              .styleProfile;
        }
        // The firm's DOCX template frames the file: its letterhead (headers, footers with
        // their images, page setup) around the generated body (legal_document_worker).
        let letterheadTemplate: Buffer | undefined;
        if (templateId && format === "docx" && options.sharedTemplateStore?.readTemplate) {
          const template = await options.sharedTemplateStore.readTemplate(templateId);
          if (template.manifest.mediaType === DOCX_MEDIA_TYPE) letterheadTemplate = template.data;
          else template.data.fill(0);
        }

        // "Generuj dokument" under an answer that is itself a letter: its file from that text,
        // mechanically (answer-document.ts), with no model turn that would write it again. The
        // answer's session is the source: HYBRID-VAL and the export gate run on its trail.
        if (req.body?.source === "ANSWER") {
          if (!options.caseMemoryStore || !options.documentAuthoringService) {
            res.status(503).json({ error: "CASE_MEMORY_UNAVAILABLE" });
            return;
          }
          const stored = (
            await options.caseAccessService.withCaseDataKey(context, caseId, "ANALYZE", (caseDataKey) =>
              options.caseMemoryStore!.getCaseMemory({ caseId, caseDataKey, keyVersion: caseView.keyVersion })
            )
          ).answerDocument;
          const wanted = typeof req.body?.answerSessionId === "string" ? req.body.answerSessionId : null;
          if (!stored || (wanted && stored.sessionId !== wanted)) {
            res.status(409).json({ error: "ANSWER_DOCUMENT_MISSING" });
            return;
          }
          const answerMarkup = answerDocumentMarkup(stored.text);
          if (!answerMarkup) {
            res.status(409).json({ error: "ANSWER_DOCUMENT_MISSING" });
            return;
          }
          // An analysis answer is an opinion; its draft names what stayed unverified.
          const ast = letterMarkupAst(answerMarkup.markup, {
            documentType: !answerMarkup.letter ? "opinion" : documentType === "pleading" ? "pleading" : "letter",
            styleProfile: effectiveStyleProfile
          });
          const ready = await options.caseAccessService.withCaseDataKey(context, caseId, "WRITE", (caseDataKey) =>
            options.documentAuthoringService!.createReady({
              // Draft by default: only unverified references -> a file headed „PROJEKT – NIE SKŁADAĆ BEZ
              // WERYFIKACJI” naming them; acceptUnverified: false asks the user first.
              ...(req.body?.acceptUnverified === false ? {} : { acceptUnverified: true }),
              caseId,
              createdByUserId: context.user.userId,
              format,
              ast,
              caseDataKey,
              keyVersion: caseView.keyVersion,
              validationContext: stored.validationContext,
              ...(letterheadTemplate ? { template: letterheadTemplate } : {}),
              ...(typeof req.body?.filename === "string" ? { filename: req.body.filename } : {})
            })
          );
          res.status(201).json({
            ...(generationTemplate ? { firmTemplateApplied: generationTemplate } : {}),
            ...(ready.letterhead ? { letterhead: ready.letterhead } : {}),
            sessionId: stored.sessionId,
            artifact: ready.artifact,
            format: ready.format,
            sha256: ready.sha256,
            warnings: ready.warnings,
            aliasesUsed: [],
            readyForDownload: true,
            mechanical: true,
            ...(templateProfile ? { templateProfile } : {})
          });
          return;
        }

        // A pleading (pisma-procesowe-v3) is written by the case's process pipeline
        // (checkpoints, HYBRID-VAL before the file); the file only renders the text
        // that pipeline produced. Without a started pipeline there is no such text.
        let processRenderOnly: { stage: ProcessPleadingStage } | undefined;
        let processDocumentStatus: "DRAFT" | "FINAL" | undefined;
        let pleadingSource: { version: number; text: string } | undefined;
        // A contract drafted in its pipeline (AU-HYBRID, AU-STRIP closed): the file runs no AU step.
        let contractRenderOnly = false;
        // The pleading's own file after a pipeline step ("Przygotuj plik .docx z pismem...")
        // names no pleading keyword; its document type does.
        // pisma-procesowe-v3 Test A (MOD-REDAKCJA): the user's own pleading corrected in the
        // chat. Its file renders that corrected text without the W1–W3 pipeline (the redaction
        // ran its own HYBRID-VALIDATION, G3); the user's earlier messages must still be Test A.
        const earlierUserTurns = parseSkillSelectionEnvelope(sessionRequest.query)
          .query.split(/\n\n(?=Użytkownik: |Asystent: )/u)
          .filter((part) => part.startsWith("Użytkownik: "))
          .slice(0, -1)
          .map((part) => part.replace(/^Użytkownik: /u, ""));
        const redactionFile =
          req.body?.source === "REDACTION" &&
          earlierUserTurns.length > 0 &&
          options.sessionExecutor?.pleadingRedactionFor?.(earlierUserTurns.join("\n")) === true;
        // A long letter written in parts in the chat (long-document.ts): the file renders the
        // joined parts, each checked against the plan; the export gate and HYBRID-VAL still run.
        const longDocumentId = typeof req.body?.longDocumentId === "string" ? req.body.longDocumentId : null;
        const longDocumentState =
          longDocumentId && options.caseMemoryStore
            ? (await options.caseAccessService.withCaseDataKey(context, caseId, "ANALYZE", (caseDataKey) =>
                options.caseMemoryStore!.getCaseMemory({ caseId, caseDataKey, keyVersion: caseView.keyVersion })
              )).longDocument ?? null
            : null;
        if (longDocumentId && (!longDocumentState || longDocumentState.id !== longDocumentId || !isComplete(longDocumentState) || longDocumentState.failed)) {
          res.status(409).json({ error: "LONG_DOCUMENT_INCOMPLETE" });
          return;
        }
        const longDocumentSource = longDocumentId ? longDocumentState : null;
        if (
          !redactionFile &&
          !longDocumentSource &&
          (documentType === "pleading" ||
          previewSessionWorkflow(options.registry, sessionRequest).id === "PROCESS_PLEADING_V1")
        ) {
          const store = options.processWorkflowStore;
          const stored = store
            ? await options.caseAccessService.withCaseDataKey(
                context,
                caseId,
                "ANALYZE",
                async (caseDataKey) => ({
                  state: await store.getProcessPleadingState({ caseId, caseDataKey, keyVersion: caseView.keyVersion }),
                  draft: store.getProcessPleadingDraft
                    ? await store.getProcessPleadingDraft({ caseId, caseDataKey, keyVersion: caseView.keyVersion })
                    : null
                })
              )
            : null;
          const processState = stored?.state ?? null;
          if (!processState || processState.stage === "CG_ACCEPTANCE") {
            res.status(409).json({ error: "PROCESS_PLEADING_PIPELINE_REQUIRED" });
            return;
          }
          processRenderOnly = { stage: processState.stage };
          processDocumentStatus = processState.documentStatus;
          // The file renders the stored pleading (newest version), not the chat.
          const latest = latestDraftVersion(stored?.draft);
          if (latest) pleadingSource = { version: latest.version, text: latest.text };
        } else {
          // A workflow with persisted checkpoints (contract, chronology, court analysis,
          // evidence, witness questioning, guide) produces its document in its own pipeline
          // in the chat, after the mode is chosen; a one-shot file has no such state, and the
          // engine refused it with HTTP 422 ("Persisted contract-analysis context is required").
          const statefulWorkflow = previewSessionWorkflow(options.registry, sessionRequest).id;
          // analizator-umow-v1: a contract drafted, corrected or supplemented in its pipeline is
          // exported once AU-HYBRID (HYBRID-VALIDATION) and AU-STRIP (markers removed) are closed.
          // Before, such a contract could never become a file.
          const contractExportReady =
            statefulWorkflow === "CONTRACT_ANALYSIS_V1" && options.contractWorkflowStore
              ? await options.caseAccessService.withCaseDataKey(context, caseId, "ANALYZE", async (caseDataKey) => {
                  const state = await options.contractWorkflowStore!.getContractAnalysisState({ caseId, caseDataKey, keyVersion: caseView.keyVersion });
                  return Boolean(state && state.mode !== "ANALYSIS" && state.closedCheckpoints.includes("AU-HYBRID") && state.closedCheckpoints.includes("AU-STRIP"));
                })
              : false;
          if (CHAT_PIPELINE_WORKFLOWS.has(statefulWorkflow) && !contractExportReady) {
            res.status(409).json({ error: "WORKFLOW_PIPELINE_REQUIRED", workflow: statefulWorkflow });
            return;
          }
          contractRenderOnly = contractExportReady;
        }

        // The thread's evidence memory, as in the chat: provisions verified in the conversation are
        // checked again in ELI and the case's signatures stay "z materiałów sprawy". Without it the
        // file's session started from an empty register and blocked them (RD 121/26).
        const threadEvidence = options.caseMemoryStore
          ? await options.caseAccessService
              .withCaseDataKey(context, caseId, "ANALYZE", (caseDataKey) =>
                options.caseMemoryStore!.getCaseMemory({ caseId, caseDataKey, keyVersion: caseView.keyVersion })
              )
              .then((memory) => memory.evidence ?? null)
              .catch(() => null)
          : null;
        // The stored pleading names its signatures from the case's materials with their marker:
        // those count as such in the file too (a thread remembered before the memory kept them).
        const sourceCaseReferences = pleadingSource ? caseMaterialSignatures(pleadingSource.text) : [];
        const fileEvidence: ThreadEvidence | null = sourceCaseReferences.length
          ? {
              ...(threadEvidence ?? { schemaVersion: 1 as const, updatedAt: new Date().toISOString(), provisions: [], skills: [], sources: [] }),
              caseReferences: [...new Set([...(threadEvidence?.caseReferences ?? []), ...sourceCaseReferences])]
            }
          : threadEvidence;
        const generated =
          await options
            .documentAstGenerator
            .generate({
              ...(fileEvidence ? { threadEvidence: fileEvidence } : {}),
              ...(options.caseAccessService && options.caseKnowledgeSearch
                ? {
                    caseSignatureSearch: createCaseSignatureSearch({
                      caseId,
                      actor: context,
                      caseAccessService: options.caseAccessService,
                      caseKnowledgeSearch: options.caseKnowledgeSearch as Pick<LocalCaseKnowledgeSearch, "search">
                    })
                  }
                : {}),
              ...(processRenderOnly ? { processRenderOnly } : {}),
              ...(contractRenderOnly ? { contractRenderOnly: true } : {}),
              ...(longDocumentSource
                ? {
                    sourceText: {
                      label: `długie pismo „${longDocumentSource.plan.tytul}” z ${longDocumentSource.plan.czesci.length} części`,
                      text: joinParts(longDocumentSource)
                    }
                  }
                : pleadingSource
                ? {
                    sourceText: {
                      label: `zapisany projekt pisma, wersja ${pleadingSource.version}${processDocumentStatus === "FINAL" ? " (FINAL)" : ""}`,
                      text: pleadingSource.text
                    }
                  }
                : {}),
              ...(sharedGeneration && sharedGeneration.members.size > 0
                ? { privacySeed: sharedGeneration.snapshot }
                : {}),
              ...(req.body?.acceptUnverified === false ? {} : { acceptUnverified: true }),
              query:
                sessionRequest
                  .query,
              provider:
                sessionRequest
                  .provider,
              model:
                sessionRequest
                  .model,
              primarySkill:
                sessionRequest
                  .primarySkill,
              mode:
                sessionRequest
                  .mode,
              documentType:
                documentType as
                  | "pleading"
                  | "contract"
                  | "opinion"
                  | "letter"
                  | "report"
                  | "other",
              styleProfile:
                effectiveStyleProfile,
              attachments:
                resolvedAttachments,
              aliases
            });

        if (pleadingSource) {
          // The file must carry the stored text, not a retelling of it.
          const fidelity = pleadingFidelity(pleadingSource.text, generated.ast);
          if (fidelity < PLEADING_FIDELITY_MIN) {
            res.status(422).json({
              error: "DOCUMENT_PLEADING_FIDELITY_FAILED",
              reason: `zgodność z zapisanym projektem ${Math.round(fidelity * 100)}% (wymagane ${Math.round(PLEADING_FIDELITY_MIN * 100)}%)`
            });
            return;
          }
        }
        if (processDocumentStatus === "DRAFT") {
          // pisma-procesowe-v3 CP-GATE: a draft file is marked as not for filing.
          (generated.ast as { blocks: unknown[] }).blocks.unshift({
            type: "paragraph",
            content: [
              {
                type: "text",
                text: `PROJEKT – NIE SKŁADAĆ${pleadingSource ? ` (wersja robocza ${pleadingSource.version})` : ""}`
              }
            ]
          });
        }

        if (
          sourceDocumentIds.length ===
            0
        ) {
          const ready =
            await options
              .caseAccessService
              .withCaseDataKey(
                context,
                caseId,
                "WRITE",
                async (
                  caseDataKey
                ) =>
                  await options
                    .documentAuthoringService!
                    .createReady({
                      ...(req.body?.acceptUnverified === false ? {} : { acceptUnverified: true }),
                      caseId,
                      createdByUserId:
                        context.user
                          .userId,
                      format,
                      ast:
                        generated.ast,
                      caseDataKey,
                      keyVersion:
                        caseView
                          .keyVersion,
                      validationContext:
                        generated
                          .validationContext,
                      ...(letterheadTemplate ? { template: letterheadTemplate } : {}),
                      ...(typeof req
                        .body
                        ?.filename ===
                      "string"
                        ? {
                            filename:
                              req.body
                                .filename
                          }
                        : {})
                    })
              );
          res.status(201).json({
            ...(generationTemplate ? { firmTemplateApplied: generationTemplate } : {}),
            ...(ready.letterhead ? { letterhead: ready.letterhead } : {}),
            sessionId:
              generated
                .sessionId,
            artifact:
              ready.artifact,
            format:
              ready.format,
            sha256:
              ready.sha256,
            warnings:
              ready.warnings,
            aliasesUsed: [],
            readyForDownload:
              true,
            ...(templateProfile
              ? {
                  templateProfile
                }
              : {})
          });
          return;
        }

        const tokenized =
          await options
            .caseAccessService
            .withCaseDataKey(
              context,
              caseId,
              "WRITE",
              async (
                caseDataKey
              ) =>
                await options
                  .documentAuthoringService!
                  .createTokenized({
                    ...(processDocumentStatus ? { processDocumentStatus } : {}),
                    ...(req.body?.acceptUnverified === false ? {} : { acceptUnverified: true }),
                    caseId,
                    createdByUserId:
                      context.user
                        .userId,
                    format,
                    ast:
                      generated.ast,
                    sourceDocumentIds,
                    caseDataKey,
                    keyVersion:
                      caseView
                        .keyVersion,
                    validationContext:
                      generated
                        .validationContext,
                    ...(letterheadTemplate ? { template: letterheadTemplate } : {}),
                    ...(typeof req
                      .body
                      ?.filename ===
                    "string"
                      ? {
                          filename:
                            req.body
                              .filename
                        }
                      : {})
                  })
            );

        // The user's own document comes back with the case's data at once, as the chat's answers
        // do (no second password): the signed-in session's grant, the same restoration as
        // /api/deanonymization/finalize. A role without REIDENTIFY, a pleading still in its
        // pipeline or any failure: the placeholder version as before.
        if (req.body?.deanonymize !== false && options.reauthorizationManager?.authorizeIntentInSession) {
          try {
            const manager = options.reauthorizationManager;
            const intent = await manager.createIntent(context, caseId, tokenized.artifact.artifactId);
            const { grant } = await manager.authorizeIntentInSession!(context, intent.intentId);
            const target = await manager.consumeGrant(context, grant.grantId);
            const final = await options.caseAccessService.withCaseDataKey(context, caseId, "REIDENTIFY", async (caseDataKey) => {
              await assertDocumentWorkflowFinalizationAllowed(options, {
                caseId,
                artifactId: target.artifactId,
                caseDataKey,
                keyVersion: target.caseKeyVersion
              });
              return await options.documentAuthoringService!.deanonymizeConsumed({
                target,
                createdByUserId: context.user.userId,
                caseDataKey,
                keyVersion: target.caseKeyVersion,
                ...(typeof req.body?.filename === "string" ? { filename: req.body.filename } : {})
              });
            });
            // The file with the data is downloaded once, by a ticket (CLEAR_PII, as after /finalize).
            const downloadTicket = options.sensitiveDownloadTickets?.issue(context, {
              caseId,
              artifactId: final.artifact.artifactId,
              finalSha256: final.sha256
            });
            res.status(201).json({
              ...(generationTemplate ? { firmTemplateApplied: generationTemplate } : {}),
              ...(tokenized.letterhead ? { letterhead: tokenized.letterhead } : {}),
              sessionId: generated.sessionId,
              artifact: final.artifact,
              format: final.format,
              sha256: final.sha256,
              aliasesUsed: tokenized.aliasesUsed,
              readyForDownload: true,
              deanonymized: {
                tokenizedArtifactId: tokenized.artifact.artifactId,
                replacements: final.replacements,
                ...(final.restorations ? { restorations: final.restorations } : {})
              },
              warnings: tokenized.warnings,
              ...(templateProfile ? { templateProfile } : {}),
              ...(downloadTicket ? { downloadTicket } : {})
            });
            return;
          } catch (error) {
            // The blocking references (provision numbers and signatures, no case text) say why.
            const blocked = error instanceof ExportGateBlockedError
              ? error.references.map((reference) => `${reference.status}:${reference.claim}`).slice(0, 12).join("; ")
              : "";
            console.error("DIRECT_DEANONYMIZATION_SKIPPED", error instanceof Error ? error.message : String(error), blocked);
          }
        }

        res.status(201).json({
            ...(generationTemplate ? { firmTemplateApplied: generationTemplate } : {}),
            ...(tokenized.letterhead ? { letterhead: tokenized.letterhead } : {}),
          sessionId:
            generated
              .sessionId,
          artifact:
            tokenized
              .artifact,
          format:
            tokenized
              .format,
          tokenizedSha256:
            tokenized
              .tokenizedSha256,
          vaultGeneration:
            tokenized
              .vaultGeneration,
          aliasesUsed:
            tokenized
              .aliasesUsed,
          deanonymizationKeyBound:
            tokenized
              .deanonymizationKeyBound,
          readyForDownload:
            false,
          warnings:
            tokenized.warnings,
          ...(templateProfile
            ? {
                templateProfile
              }
            : {})
        });
      } catch (error) {
        if (
          !sendCaseAccessError(
            res,
            error
          ) &&
          !(error instanceof
            MissingProviderCredentialError)
        ) {
          res.status(422).json({
            error:
              error instanceof
                Error
                ? error.message
                : "DOCUMENT_GENERATION_FAILED",
            ...exportBlockedDetails(error),
            ...(error instanceof
              DocumentAstSessionBlockedError
              ? {
                  stage:
                    error.stage,
                  reason:
                    error.reason,
                  description:
                    error.description
                }
              : {})
          });
          return;
        }
        if (
          error instanceof
            MissingProviderCredentialError
        ) {
          res.status(503).json({
            error:
              "PROVIDER_NOT_CONFIGURED",
            provider:
              error.provider
          });
        }
      }
    }
  );

  app.get(
    "/api/cases/:caseId/artifacts/:artifactId/download",
    async (req, res) => {
      if (
        !options.caseAccessService ||
        !options.secureCaseArtifactStore
      ) {
        res.status(503).json({
          error:
            "ARTIFACT_DOWNLOAD_UNAVAILABLE"
        });
        return;
      }

      try {
        const context =
          responseAuthContext(res);
        const caseId =
          String(
            req.params.caseId ??
              ""
          );
        const artifactId =
          String(
            req.params.artifactId ??
              ""
          );

        const view =
          options.caseAccessService
            .openCase(
              context,
              caseId
            );
        options
          .caseAccessService
          .assertAccess(
            context,
            caseId,
            "READ"
          );

        const result =
          await options
            .caseAccessService
            .withCaseDataKey(
              context,
              caseId,
              "ANALYZE",
              async (
                caseDataKey
              ) => {
                const artifacts =
                  await options
                    .secureCaseArtifactStore!
                    .listArtifacts({
                      caseId,
                      caseDataKey,
                      keyVersion:
                        view.keyVersion
                    });
                const artifact =
                  artifacts.find(
                    (item) =>
                      item.artifactId ===
                        artifactId
                  );

                if (
                  !artifact ||
                  artifact.sensitivity !==
                    "PROTECTED" ||
                  (
                    !artifact.filename
                      .toLowerCase()
                      .endsWith(".docx") &&
                    !artifact.filename
                      .toLowerCase()
                      .endsWith(".odt")
                  )
                ) {
                  throw new Error(
                    "GENERATED_ARTIFACT_NOT_DOWNLOADABLE"
                  );
                }

                const data =
                  await options
                    .secureCaseArtifactStore!
                    .readArtifact({
                      caseId,
                      artifactId,
                      caseDataKey,
                      keyVersion:
                        view.keyVersion,
                      maxBytes:
                        64 *
                        1024 *
                        1024
                    });

                return {
                  artifact,
                  data
                };
              }
            );

        res.setHeader(
          "Content-Type",
          result.artifact.mediaType
        );
        res.setHeader(
          "Content-Length",
          String(
            result.data.byteLength
          )
        );
        res.setHeader(
          "Content-Disposition",
          // Non-Latin-1 names (Polish letters) would fail in setHeader.
          `attachment; filename="${result.artifact.filename.replace(/[^\x20-\x7e]|"/g, "_")}"; filename*=UTF-8''${encodeURIComponent(result.artifact.filename)}`
        );
        res.status(200).send(
          result.data
        );
      } catch (error) {
        if (
          !sendCaseAccessError(
            res,
            error
          )
        ) {
          res.status(422).json({
            error:
              error instanceof Error
                ? error.message
                : "ARTIFACT_DOWNLOAD_FAILED"
          });
        }
      }
    }
  );

  app.post(
    "/api/cases/:caseId/artifacts/:artifactId/deanonymization-intent",
    async (req, res) => {
      if (
        !options.reauthorizationManager ||
        !options.caseAccessService ||
        !options.documentGenerationState
      ) {
        res.status(503).json({
          error:
            "DEANONYMIZATION_UNAVAILABLE"
        });
        return;
      }
      try {
        const context =
          responseAuthContext(res);
        const caseId =
          String(
            req.params.caseId ??
              ""
          );
        const artifactId =
          String(
            req.params
              .artifactId ??
              ""
          );
        const caseView =
          options.caseAccessService
            .openCase(
              context,
              caseId
            );
        await options
          .caseAccessService
          .withCaseDataKey(
            context,
            caseId,
            "ANALYZE",
            async (
              caseDataKey
            ) =>
              await assertDocumentWorkflowFinalizationAllowed(
                options,
                {
                  caseId,
                  artifactId,
                  caseDataKey,
                  keyVersion:
                    caseView.keyVersion
                }
              )
          );
        const intent =
          await options
            .reauthorizationManager
            .createIntent(
              context,
              caseId,
              artifactId
            );
        res.status(201).json({
          intent: {
            intentId:
              intent.intentId,
            caseId:
              intent.caseId,
            artifactId:
              intent.artifactId,
            artifactFormat:
              intent
                .artifactFormat,
            expiresAt:
              intent.expiresAt,
            status:
              intent.status
          }
        });
      } catch (error) {
        if (
          !sendCaseAccessError(
            res,
            error
          ) &&
          !sendReauthorizationError(
            res,
            error
          ) &&
          !sendProcessWorkflowError(
            res,
            error
          )
        ) {
          res.status(500).json({
            error:
              "DEANONYMIZATION_INTENT_FAILED"
          });
        }
      }
    }
  );

  app.post(
    "/api/deanonymization/reauthorize",
    async (req, res) => {
      if (
        !options.reauthorizationManager
      ) {
        res.status(503).json({
          error:
            "DEANONYMIZATION_UNAVAILABLE"
        });
        return;
      }
      if (
        typeof req.body
          ?.intentId !==
          "string" ||
        (req.body?.password !== undefined && typeof req.body?.password !== "string")
      ) {
        res.status(400).json({
          error:
            "INVALID_REAUTHORIZATION_REQUEST"
        });
        return;
      }
      try {
        // Without a password: the signed-in session's grant (the chat restores the case's data
        // in its answers the same way); a password still re-authenticates when given.
        const manager = options.reauthorizationManager;
        const context = responseAuthContext(res);
        const result: { grant: Awaited<ReturnType<typeof manager.authorizeIntent>>["grant"]; session?: unknown } =
          typeof req.body.password === "string" && req.body.password !== ""
            ? await manager.authorizeIntent(context, req.body.intentId, req.body.password)
            : manager.authorizeIntentInSession
              ? await manager.authorizeIntentInSession(context, req.body.intentId)
              : await manager.authorizeIntent(context, req.body.intentId, "");
        res.json({
          grant: {
            grantId:
              result.grant
                .grantId,
            intentId:
              result.grant
                .intentId,
            caseId:
              result.grant
                .caseId,
            artifactId:
              result.grant
                .artifactId,
            artifactFormat:
              result.grant
                .artifactFormat,
            expiresAt:
              result.grant
                .expiresAt
          },
          ...(result.session ? { session: result.session } : {})
        });
      } catch (error) {
        if (
          !sendAuthError(
            res,
            error
          ) &&
          !sendCaseAccessError(
            res,
            error
          ) &&
          !sendReauthorizationError(
            res,
            error
          ) &&
          !sendProcessWorkflowError(
            res,
            error
          )
        ) {
          res.status(500).json({
            error:
              "DEANONYMIZATION_REAUTH_FAILED"
          });
        }
      }
    }
  );

  // Review step: restored values with their source, before the one-time
  // final document is written. Needs the same fresh password grant.
  app.post(
    "/api/deanonymization/preview",
    async (req, res) => {
      if (
        !options.reauthorizationManager?.previewGrant ||
        !options.documentAuthoringService?.previewDeanonymization ||
        !options.caseAccessService
      ) {
        res.status(503).json({
          error:
            "DEANONYMIZATION_UNAVAILABLE"
        });
        return;
      }
      if (typeof req.body?.grantId !== "string") {
        res.status(400).json({
          error:
            "INVALID_DEANONYMIZATION_REQUEST"
        });
        return;
      }
      try {
        const context =
          responseAuthContext(res);
        const target =
          await options.reauthorizationManager.previewGrant(
            context,
            req.body.grantId
          );
        const preview =
          await options.caseAccessService.withCaseDataKey(
            context,
            target.caseId,
            "REIDENTIFY",
            (caseDataKey) =>
              options.documentAuthoringService!.previewDeanonymization!({
                target,
                caseDataKey,
                keyVersion:
                  target.caseKeyVersion
              })
          );
        res.setHeader("Cache-Control", "no-store");
        res.json(preview);
      } catch (error) {
        if (
          !sendCaseAccessError(res, error) &&
          !sendReauthorizationError(res, error)
        ) {
          res.status(422).json({
            error:
              error instanceof Error
                ? error.message
                : "DEANONYMIZATION_PREVIEW_FAILED"
          });
        }
      }
    }
  );

  app.post(
    "/api/deanonymization/finalize",
    async (req, res) => {
      if (
        !options.reauthorizationManager ||
        !options.documentAuthoringService ||
        !options.caseAccessService
      ) {
        res.status(503).json({
          error:
            "DEANONYMIZATION_UNAVAILABLE"
        });
        return;
      }
      if (
        typeof req.body
          ?.grantId !==
          "string"
      ) {
        res.status(400).json({
          error:
            "INVALID_DEANONYMIZATION_REQUEST"
        });
        return;
      }

      const rawOverrides =
        req.body?.overrides;
      if (
        rawOverrides !== undefined &&
        (
          !rawOverrides ||
          typeof rawOverrides !== "object" ||
          Array.isArray(rawOverrides) ||
          Object.keys(rawOverrides).length > 500 ||
          Object.values(rawOverrides).some(
            (value) => typeof value !== "string"
          )
        )
      ) {
        res.status(400).json({
          error:
            "INVALID_DEANONYMIZATION_REQUEST"
        });
        return;
      }
      const overrides =
        rawOverrides as
          | Record<string, string>
          | undefined;

      try {
        const context =
          responseAuthContext(res);
        // Consume before CDK unwrap / vault access.
        const target =
          await options
            .reauthorizationManager
            .consumeGrant(
              context,
              req.body.grantId
            );
        const final =
          await options
            .caseAccessService
            .withCaseDataKey(
              context,
              target.caseId,
              "REIDENTIFY",
              async (
                caseDataKey
              ) => {
                await assertDocumentWorkflowFinalizationAllowed(
                  options,
                  {
                    caseId:
                      target.caseId,
                    artifactId:
                      target.artifactId,
                    caseDataKey,
                    keyVersion:
                      target
                        .caseKeyVersion
                  }
                );
                return await options
                  .documentAuthoringService!
                  .deanonymizeConsumed({
                    target,
                    createdByUserId:
                      context.user
                        .userId,
                    caseDataKey,
                    keyVersion:
                      target
                        .caseKeyVersion,
                    ...(typeof req
                      .body
                      ?.filename ===
                    "string"
                      ? {
                          filename:
                            req.body
                              .filename
                        }
                      : {}),
                    ...(overrides
                      ? { overrides }
                      : {})
                  });
              }
            );
        const downloadTicket =
          options
            .sensitiveDownloadTickets
            ?.issue(
              context,
              {
                caseId:
                  target.caseId,
                artifactId:
                  final.artifact
                    .artifactId,
                finalSha256:
                  final.sha256
              }
            );
        res.status(201).json({
          artifact:
            final.artifact,
          format:
            final.format,
          sha256:
            final.sha256,
          replacements:
            final.replacements,
          deanonymizationBasis:
            final
              .deanonymizationBasis,
          ...(final.restorations
            ? { restorations: final.restorations }
            : {}),
          keyBindingVerified:
            final
              .keyBindingVerified,
          ...(downloadTicket
            ? {
                downloadTicket
              }
            : {})
        });
      } catch (error) {
        if (
          !sendCaseAccessError(
            res,
            error
          ) &&
          !sendReauthorizationError(
            res,
            error
          ) &&
          !sendProcessWorkflowError(
            res,
            error
          )
        ) {
          res.status(422).json({
            error:
              error instanceof
                Error
                ? error.message
                : "DEANONYMIZATION_FINALIZE_FAILED",
            ...exportBlockedDetails(error)
          });
        }
      }
    }
  );

  app.get(
    "/api/sensitive-download/:ticketId",
    async (req, res) => {
      if (
        !options.sensitiveDownloadTickets ||
        !options.secureCaseArtifactStore ||
        !options.caseAccessService
      ) {
        res.status(503).json({
          error:
            "SENSITIVE_DOWNLOAD_UNAVAILABLE"
        });
        return;
      }

      try {
        const context =
          responseAuthContext(res);
        // Consume before CDK unwrap / artifact decryption.
        const ticket =
          options
            .sensitiveDownloadTickets
            .consume(
              context,
              String(
                req.params
                  .ticketId ??
                  ""
              )
            );
        const payload =
          await options
            .caseAccessService
            .withCaseDataKey(
              context,
              ticket.caseId,
              "REIDENTIFY",
              async (
                caseDataKey
              ) => {
                const view =
                  options
                    .caseAccessService!
                    .openCase(
                      context,
                      ticket
                        .caseId
                    );
                const artifacts =
                  await options
                    .secureCaseArtifactStore!
                    .listArtifacts({
                      caseId:
                        ticket.caseId,
                      caseDataKey,
                      keyVersion:
                        view
                          .keyVersion
                    });
                const artifact =
                  artifacts.find(
                    (item) =>
                      item.artifactId ===
                        ticket
                          .artifactId
                  );
                if (
                  !artifact ||
                  artifact.sensitivity !==
                    "CLEAR_PII" ||
                  artifact.sha256 !==
                    ticket.finalSha256
                ) {
                  throw new Error(
                    "FINAL_ARTIFACT_NOT_DOWNLOADABLE"
                  );
                }
                const data =
                  await options
                    .secureCaseArtifactStore!
                    .readArtifact({
                      caseId:
                        ticket.caseId,
                      artifactId:
                        ticket
                          .artifactId,
                      caseDataKey,
                      keyVersion:
                        view
                          .keyVersion,
                      maxBytes:
                        64 *
                        1024 *
                        1024
                    });
                const sha =
                  createHash(
                    "sha256"
                  )
                    .update(data)
                    .digest("hex");
                if (
                  sha !==
                    ticket
                      .finalSha256
                ) {
                  data.fill(0);
                  throw new Error(
                    "FINAL_ARTIFACT_HASH_MISMATCH"
                  );
                }
                return {
                  artifact,
                  data
                };
              }
            );

        res.setHeader(
          "Content-Type",
          payload.artifact
            .mediaType
        );
        res.setHeader(
          "Content-Disposition",
          `attachment; filename*=UTF-8''${encodeURIComponent(
            payload.artifact
              .filename
          )}`
        );
        res.setHeader(
          "Cache-Control",
          "no-store"
        );
        res.setHeader(
          "X-Content-Type-Options",
          "nosniff"
        );
        // Bufor zerujemy dopiero po zamknięciu odpowiedzi: przy dużym pliku gniazdo czyta
        // go jeszcze po powrocie z send(), a bilet jest już zużyty (nie ma ponowienia).
        const sent = payload.data;
        res.once("close", () => sent.fill(0));
        res.send(sent);
      } catch (error) {
        if (
          !sendCaseAccessError(
            res,
            error
          )
        ) {
          const message =
            error instanceof
              Error
              ? error.message
              : "SENSITIVE_DOWNLOAD_FAILED";
          const status =
            message.includes(
              "TICKET"
            )
              ? 409
              : 422;
          res.status(status)
            .json({
              error:
                message
            });
        }
      }
    }
  );

  app.get(
    "/api/cases/:caseId/workflow-audits/:artifactId",
    async (req, res) => {
      if (
        !options.caseAccessService ||
        !options
          .secureCaseArtifactStore
      ) {
        res.status(503).json({
          error:
            "WORKFLOW_AUDIT_UNAVAILABLE"
        });
        return;
      }

      const caseId =
        String(
          req.params.caseId ??
            ""
        );
      const artifactId =
        String(
          req.params
            .artifactId ??
            ""
        );
      if (
        !/^case_[a-f0-9]{32}$/.test(
          caseId
        ) ||
        !/^artifact_[a-f0-9]{32}$/.test(
          artifactId
        )
      ) {
        res.status(400).json({
          error:
            "WORKFLOW_AUDIT_ID_INVALID"
        });
        return;
      }

      try {
        const context =
          responseAuthContext(res);
        const view =
          options
            .caseAccessService
            .openCase(
              context,
              caseId
            );

        const result =
          await options
            .caseAccessService
            .withCaseDataKey(
              context,
              caseId,
              "ANALYZE",
              async (
                caseDataKey
              ) => {
                const artifacts =
                  await options
                    .secureCaseArtifactStore!
                    .listArtifacts({
                      caseId,
                      caseDataKey,
                      keyVersion:
                        view.keyVersion
                    });
                const artifact =
                  artifacts.find(
                    (item) =>
                      item.artifactId ===
                        artifactId &&
                      item.sensitivity ===
                        "PROTECTED" &&
                      item.mediaType ===
                        "application/vnd.lexmachina.workflow-audit+json"
                  );
                if (!artifact) {
                  throw new Error(
                    "WORKFLOW_AUDIT_NOT_FOUND"
                  );
                }

                const data =
                  await options
                    .secureCaseArtifactStore!
                    .readArtifact({
                      caseId,
                      artifactId,
                      caseDataKey,
                      keyVersion:
                        view.keyVersion,
                      maxBytes:
                        2 *
                        1024 *
                        1024
                    });
                try {
                  const digest =
                    createHash(
                      "sha256"
                    )
                      .update(data)
                      .digest(
                        "hex"
                      );
                  if (
                    digest !==
                    artifact.sha256
                  ) {
                    throw new Error(
                      "WORKFLOW_AUDIT_HASH_MISMATCH"
                    );
                  }
                  const audit =
                    parseWorkflowAuditArtifact(
                      data
                    );
                  if (
                    audit.caseId !==
                      caseId
                  ) {
                    throw new Error(
                      "WORKFLOW_AUDIT_CASE_MISMATCH"
                    );
                  }
                  return {
                    artifactId,
                    sha256:
                      artifact.sha256,
                    createdAt:
                      artifact.createdAt,
                    audit
                  };
                } finally {
                  data.fill(0);
                }
              }
            );

        res.setHeader(
          "Cache-Control",
          "no-store"
        );
        res.json(result);
      } catch (error) {
        if (
          sendCaseAccessError(
            res,
            error
          )
        ) {
          return;
        }

        const message =
          error instanceof Error
            ? error.message
            : "WORKFLOW_AUDIT_READ_FAILED";
        const status =
          message ===
            "WORKFLOW_AUDIT_NOT_FOUND"
            ? 404
            : message ===
                "WORKFLOW_AUDIT_HASH_MISMATCH" ||
              message ===
                "WORKFLOW_AUDIT_CASE_MISMATCH" ||
              message ===
                "WORKFLOW_AUDIT_ARTIFACT_INVALID" ||
              message ===
                "WORKFLOW_AUDIT_ARTIFACT_SIZE_INVALID"
              ? 409
              : 422;
        res.status(status).json({
          error: message
        });
      }
    }
  );

  // Live drafts of running executions, polled by the UI so the answer appears
  // while it is generated. Owner-bound, in memory only, short-lived.
  const executionDrafts =
    new Map<string, {
      owner: string;
      text: string;
      updatedAt: number;
      steps: ExecutionSteps;
    }>();
  const draftOwner = (
    res: Response
  ): string =>
    options.authService
      ? responseAuthContext(res)
          .session.sessionId
      : "local";
  const pruneExecutionDrafts = () => {
    const now = Date.now();
    for (const [id, entry] of executionDrafts) {
      if (now - entry.updatedAt > EXECUTION_DRAFT_TTL_MS) {
        executionDrafts.delete(id);
      }
    }
    while (executionDrafts.size > EXECUTION_DRAFT_MAX_ENTRIES) {
      const oldest =
        executionDrafts.keys().next().value;
      if (oldest === undefined) break;
      executionDrafts.delete(oldest);
    }
  };

  app.get(
    "/api/sessions/progress/:executionId",
    (req, res) => {
      const entry =
        executionDrafts.get(
          String(req.params.executionId ?? "")
        );
      if (
        !entry ||
        entry.owner !== draftOwner(res)
      ) {
        res.status(404).json({
          error:
            "EXECUTION_PROGRESS_NOT_FOUND"
        });
        return;
      }
      res.set("Cache-Control", "no-store");
      res.json({
        text: entry.text,
        updatedAt:
          new Date(entry.updatedAt).toISOString(),
        steps: entry.steps.snapshot()
      });
    }
  );

  // Documents the user picked for a message (case files, firm files, firm
  // templates), resolved with access checks. Used to send them and to
  // estimate whether they fit the model before sending. Null: response sent.
  const templateTextCache = new Map<string, ReturnType<typeof templateChunks>>();
  const resolveSelectedAttachments = async (
    res: express.Response,
    attachments: Array<DocumentChunkSelection & { caseId?: string }>,
    firmTemplates: string[],
    firmCaseId: string | undefined,
    evidence?: EvidencePolicy,
    // A model outside the computer: documents the user has not reviewed are refused.
    remote = true
  ): Promise<SessionDocumentAttachment[] | null> => {
    const picked: SessionDocumentAttachment[] = [];
    if (attachments.length > 0) {
      if (!options.documentService) {
        res.status(503).json({
          error:
            "DOCUMENT_ATTACHMENT_SERVICE_UNAVAILABLE"
        });
        return null;
      }

      if (
        options.caseAccessService
      ) {
        const context =
          responseAuthContext(res);
        for (
          const selection
          of attachments
        ) {
          const caseId =
            selection.caseId ||
            documentCaseIds.get(
              selection.documentId
            );
          if (!caseId) {
            throw new CaseAccessError(
              "CASE_ACCESS_DENIED",
              403
            );
          }
          options.caseAccessService
            .assertAccess(
              context,
              caseId,
              "ANALYZE"
            );

          if (
            options
              .documentService
              .restoreDocument
          ) {
            const caseView =
              options.caseAccessService
                .openCase(
                  context,
                  caseId
                );
            await options
              .caseAccessService
              .withCaseDataKey(
                context,
                caseId,
                "ANALYZE",
                async (
                  caseDataKey
                ) =>
                  await options
                    .documentService!
                    .restoreDocument!({
                      caseId,
                      documentId:
                        selection
                          .documentId,
                      caseDataKey,
                      keyVersion:
                        caseView
                          .keyVersion
                    })
              );
          }

          const resolved =
            await options
              .documentService!
              .resolveProtectedChunks({
                documentId:
                  selection
                    .documentId,
                chunkIndices:
                  selection
                    .chunkIndices
              }, { remote, ...(evidence ? { images: evidence } : {}) });
          picked.push({
            caseId,
            documentId:
              resolved.documentId,
            sourceScope:
              caseId === firmCaseId
                ? "FIRM_KNOWLEDGE"
                : "MANUAL",
            selectedByUser: true,
            ...(resolved.grammar
              ? { grammar: resolved.grammar }
              : {}),
            ...(resolved.totalPages
              ? { totalPages: resolved.totalPages }
              : {}),
            ...(resolved.images ? { images: resolved.images } : {}),
            chunks:
              resolved.chunks.map(
                (chunk) => ({
                  ...chunk
                })
              )
          });
        }
      } else {
        const resolved =
          await Promise.all(
            attachments.map(
              (selection) =>
                options
                  .documentService!
                  .resolveProtectedChunks({
                    documentId:
                      selection
                        .documentId,
                    chunkIndices:
                      selection
                        .chunkIndices
                  }, { remote, ...(evidence ? { images: evidence } : {}) })
            )
          );
        picked.push(
          ...resolved.map(
            (attachment) => ({
              documentId:
                attachment.documentId,
              sourceScope:
                "MANUAL" as const,
              selectedByUser: true,
              ...(attachment.grammar
                ? { grammar: attachment.grammar }
                : {}),
              ...(attachment.totalPages
                ? { totalPages: attachment.totalPages }
                : {}),
              ...(attachment.images ? { images: attachment.images } : {}),
              chunks:
                attachment.chunks.map(
                  (chunk) => ({
                    ...chunk
                  })
                )
            })
          )
        );
      }
    }

    if (firmTemplates.length > 0) {
      if (
        !firmCaseId ||
        !options.caseAccessService ||
        !options.sharedTemplateStore?.readTemplate ||
        !options.officeEditor
      ) {
        res.status(503).json({
          error: "FIRM_TEMPLATES_UNAVAILABLE"
        });
        return null;
      }
      options.caseAccessService.assertAccess(
        responseAuthContext(res),
        firmCaseId,
        "READ"
      );
      for (const templateId of firmTemplates) {
        const template =
          await options.sharedTemplateStore.readTemplate(templateId);
        try {
          // Text of a template is read once per file version (checked while picking, then sent).
          const cacheKey = `${templateId}:${template.manifest.sha256}`;
          let chunks = templateTextCache.get(cacheKey);
          if (!chunks) {
            const model = await options.officeEditor.read(
              new Uint8Array(template.data),
              template.manifest.mediaType
            );
            chunks = templateChunks(templateText(model));
            templateTextCache.set(cacheKey, chunks);
            if (templateTextCache.size > 32) {
              templateTextCache.delete(templateTextCache.keys().next().value!);
            }
          }
          picked.push({
            caseId: firmCaseId,
            documentId: templateId,
            title: template.manifest.filename,
            sourceScope: "FIRM_TEMPLATE",
            selectedByUser: true,
            chunks: chunks.map((chunk) => ({ ...chunk }))
          });
        } finally {
          template.data.fill(0);
        }
      }
    }

    return picked;
  };

  // The pleading text kept between the pipeline's stages: what the next step works on.
  async function pleadingDraftContext(
    actor: AuthenticatedContext,
    caseId: string,
    keyVersion: number,
    checkpoint: ProcessPleadingCheckpoint
  ): Promise<Pick<NonNullable<SessionExecutionRequest["processWorkflowContext"]>, "draft" | "remarks">> {
    const store = options.processWorkflowStore;
    if (!store?.getProcessPleadingDraft || !options.caseAccessService) return {};
    const draft = await options.caseAccessService.withCaseDataKey(actor, caseId, "WRITE", (caseDataKey) =>
      store.getProcessPleadingDraft!({ caseId, caseDataKey, keyVersion })
    );
    const latest = latestDraftVersion(draft);
    return {
      ...(latest ? { draft: { version: latest.version, source: latest.source, stage: latest.stage, text: latest.text } } : {}),
      ...(draft?.remarks && draft.remarks.checkpoint === checkpoint ? { remarks: draft.remarks.text } : {})
    };
  }

  // After a passing step: the pleading block of the answer becomes the next version and
  // the remarks to this step are used up. A failure here never fails the answered turn.
  async function recordPleadingStep(
    actor: AuthenticatedContext,
    caseId: string,
    keyVersion: number,
    checkpoint: ProcessPleadingCheckpoint,
    stage: ProcessPleadingStage,
    answer: string,
    problems: string[] = []
  ): Promise<{ version: number; checkpoint: ProcessPleadingCheckpoint } | null> {
    const store = options.processWorkflowStore;
    if (!store?.getProcessPleadingDraft || !store.saveProcessPleadingDraft || !options.caseAccessService) return null;
    try {
      return await options.caseAccessService.withCaseDataKey(actor, caseId, "WRITE", async (caseDataKey) => {
        const current = await store.getProcessPleadingDraft!({ caseId, caseDataKey, keyVersion });
        let next = current ?? emptyProcessPleadingDraft(caseId);
        const before = latestDraftVersion(next)?.version ?? 0;
        // The whole text, or a long draft's changed sections applied to it; a cut block or an
        // unfinished one is said, not kept silently as the previous version.
        const step = writesPleading(checkpoint) ? pleadingStepText(answer, latestDraftVersion(next)?.text ?? null) : null;
        if (step?.kind === "PROBLEM") problems.push(step.problem);
        if (step?.kind === "PARTIAL") problems.push(`pismo niedokończone po ${PLEADING_CONTINUATIONS_MAX} rundach dalszego ciągu: nowa wersja nie została zapisana`);
        const text = step?.kind === "FULL" ? step.text : null;
        if (text) next = appendDraftVersion(next, { text, source: "PIPELINE", stage, checkpoint });
        if (next.remarks?.checkpoint === checkpoint) next = withoutDraftRemarks(next);
        if (next.revision === (current?.revision ?? 0)) return null;
        await store.saveProcessPleadingDraft!({
          caseId,
          caseDataKey,
          keyVersion,
          draft: next,
          expectedRevision: current?.revision ?? 0
        });
        const version = latestDraftVersion(next)?.version ?? 0;
        return version > before ? { version, checkpoint } : null;
      });
    } catch {
      // The step stays committed; the draft keeps its previous version.
      return null;
    }
  }

  // A pleading over one answer (its block ends with "=== CIĄG DALSZY ==="): the rest asked for
  // in the same step, each round through the same gates; the answer then holds the whole block.
  async function completePleadingAnswer(
    request: SessionExecutionRequest,
    result: SessionExecutionResponse
  ): Promise<SessionExecutionResponse> {
    if (!result.answer || !request.processWorkflowContext || !writesPleading(request.processWorkflowContext.checkpoint)) return result;
    const first = pleadingStepText(result.answer, null);
    if (first.kind !== "PARTIAL") return result;
    let written = first.text;
    let tail = "";
    for (let round = 1; round <= PLEADING_CONTINUATIONS_MAX; round += 1) {
      request.onStep?.("PREPARE", `pismo: dalszy ciąg, runda ${round}`);
      const next = await options.sessionExecutor!.execute({ ...request, query: `${request.query}\n\n${pleadingContinuationPrompt(written, round)}` });
      if (next.status !== "DRAFT_PRESENTABLE" || !next.answer) break;
      const piece = pleadingStepText(next.answer, null);
      if (piece.kind !== "PARTIAL" && piece.kind !== "FULL") break;
      written = `${written}\n\n${piece.text}`;
      if (piece.kind === "FULL") {
        tail = next.answer.slice(next.answer.lastIndexOf(PLEADING_END) + PLEADING_END.length).trim();
        const start = result.answer.lastIndexOf(PLEADING_START);
        // In place: the result's internal validation record stays with it.
        result.answer = `${result.answer.slice(0, start)}${PLEADING_START}\n${written}\n${PLEADING_END}${tail ? `\n\n${tail}` : ""}`;
        return result;
      }
    }
    return result;
  }

  function hasFirmWorkspace(res: Response): boolean {
    try {
      return Boolean(options.caseAccessService?.getFirmKnowledgeWorkspace(responseAuthContext(res)));
    } catch {
      return false;
    }
  }

  // The document the thread is drafting: named in this message, or - for a stage of a
  // pipeline ("kontynuuj", "zatwierdzam", "popraw") - in an earlier message of the thread.
  function draftingKind(query: string, documentType?: GenerationDocumentType) {
    const text = parseSkillSelectionEnvelope(query).query;
    const latest = latestUserTurn(text);
    return (
      draftingTarget(latest, documentType) ??
      (latest.length < 300 && PIPELINE_CONTINUATION.test(latest) ? draftingTarget(threadUserText(text)) : null)
    );
  }

  // The firm's default template for the document the message asks to draft (none
  // picked by the user): used as a firm template and, for a file, as its style.
  async function firmDefaultTemplate(
    res: Response,
    query: string,
    documentType?: GenerationDocumentType
  ): Promise<{ templateId: string; filename: string; kind: string } | null> {
    if (!options.sharedTemplateStore || !options.caseAccessService) return null;
    const kind = draftingKind(query, documentType);
    if (!kind) return null;
    try {
      const firm = options.caseAccessService.getFirmKnowledgeWorkspace(responseAuthContext(res));
      if (!firm) return null;
      options.caseAccessService.assertAccess(responseAuthContext(res), firm.caseId, "READ");
      const template = defaultTemplateFor(await options.sharedTemplateStore.listTemplates(), kind);
      return template ? { templateId: template.templateId, filename: template.filename, kind } : null;
    } catch {
      return null;
    }
  }

  // Checked while the user picks files: do they fit the chosen model?
  app.post("/api/sessions/document-fit", async (req, res) => {
    const attachments = parseDocumentAttachments(req.body?.attachments);
    const firmTemplates = parseFirmTemplates(req.body?.firmTemplates);
    const model = typeof req.body?.model === "string" ? req.body.model.trim() : "";
    const provider = typeof req.body?.provider === "string" ? req.body.provider : "";
    if (attachments === null || firmTemplates === null || !model || model.length > 200) {
      res.status(400).json({ error: "INVALID_DOCUMENT_FIT_REQUEST" });
      return;
    }
    const localWindow = options.modelCatalog.localContextWindow?.(model);
    const limit = localWindow !== undefined ? LOCAL_MAX_DOCUMENT_ATTACHMENTS : MAX_DOCUMENT_ATTACHMENTS;
    const count = attachments.length + firmTemplates.length;
    if (count === 0 || count > limit) {
      res.json({ limit, local: localWindow !== undefined, count, estimate: null });
      return;
    }
    try {
      const firmCaseId = options.caseAccessService
        ?.getFirmKnowledgeWorkspace(responseAuthContext(res))
        ?.caseId;
      // Only an estimate of the context: nothing is sent.
      const picked = await resolveSelectedAttachments(res, attachments, firmTemplates, firmCaseId, undefined, false);
      if (!picked) return;
      const charsPerToken = localWindow !== undefined
        ? options.modelCatalog.localTokenCharsPerToken?.(model)
        : undefined;
      res.json({
        limit,
        local: localWindow !== undefined,
        count,
        estimate: estimateDocumentFit({
          attachments: picked,
          modelContextTokens: localWindow ?? HOSTED_CONTEXT_TOKENS[provider] ?? 128_000,
          ...(charsPerToken ? { tokenCharsPerToken: charsPerToken } : {})
        })
      });
    } catch (error) {
      if (!sendAuthError(res, error) && !sendCaseAccessError(res, error)) {
        res.status(422).json({ error: "DOCUMENT_FIT_FAILED" });
      }
    }
  });

  app.post("/api/sessions/execute", express.json({ limit: "32mb" }), async (req, res) => {
    if (keepAliveRequested(req)) keepResponseAlive(res);
    if (!options.sessionExecutor) {
      res.status(503).json({
        error: "SESSION_EXECUTION_UNAVAILABLE"
      });
      return;
    }

    const request = parseSessionRequest(req.body);
    const attachments =
      parseDocumentAttachments(
        req.body?.attachments
      );
    const knowledge =
      parseSessionKnowledgeRequest(
        req.body?.knowledge
      );
    const firmTemplates =
      parseFirmTemplates(
        req.body?.firmTemplates
      );
    if (
      !request ||
      attachments === null ||
      knowledge === null ||
      firmTemplates === null
    ) {
      res.status(400).json({
        error: "INVALID_SESSION_REQUEST"
      });
      return;
    }
    const localModel =
      options.modelCatalog.localContextWindow?.(request.model) !== undefined;
    const documentLimit = localModel
      ? LOCAL_MAX_DOCUMENT_ATTACHMENTS
      : MAX_DOCUMENT_ATTACHMENTS;
    // "Napisz umowę najmu" without a picked template: the firm's default for umowa.
    const appliedTemplate =
      firmTemplates.length === 0 && !localModel ? await firmDefaultTemplate(res, request.query) : null;
    if (appliedTemplate) firmTemplates.push(appliedTemplate.templateId);
    // Drafting a document: the firm's rules and know-how are part of the material
    // (a hosted model; the user's selection of firm files still applies).
    if (
      !localModel &&
      !knowledge.includeFirm &&
      options.caseKnowledgeSearch &&
      draftingKind(request.query) &&
      hasFirmWorkspace(res)
    ) {
      knowledge.includeFirm = true;
    }
    if (attachments.length + firmTemplates.length > documentLimit) {
      res.status(422).json({
        error: "TOO_MANY_DOCUMENT_ATTACHMENTS",
        limit: documentLimit
      });
      return;
    }

    if (
      knowledge.caseId
    ) {
      request.accountSessionKey =
        knowledge.caseId;
    }

    // Document aliases restored locally (the live draft, the court of a party's address).
    if (options.documentService?.deanonymize) {
      const documentService = options.documentService;
      request.restoreDocumentToken = (documentId, sourceToken) =>
        documentService.deanonymize!(documentId, sourceToken);
    }
    const executionId =
      String(
        req.get("x-lex-execution-id") ?? ""
      );
    if (
      EXECUTION_ID_PATTERN.test(
        executionId
      )
    ) {
      const owner =
        draftOwner(res);
      pruneExecutionDrafts();
      executionDrafts.set(
        executionId,
        {
          owner,
          text: "",
          updatedAt: Date.now(),
          steps: new ExecutionSteps()
        }
      );
      request.onStep = (phase, detail) => {
        const entry = executionDrafts.get(executionId);
        if (entry && entry.owner === owner) {
          entry.steps.report(phase, detail);
          entry.updatedAt = Date.now();
        }
      };
      request.onStep("PREPARE", "przygotowanie wiadomości");
      request.onDraft = (text) => {
        const entry =
          executionDrafts.get(
            executionId
          );
        if (entry && entry.owner === owner) {
          entry.text =
            text.slice(-EXECUTION_DRAFT_MAX_CHARS);
          entry.updatedAt = Date.now();
        }
      };
      res.on("finish", () => {
        executionDrafts.delete(
          executionId
        );
      });
    }

    // Server mode: the admin's live view of turns gets the stage and the skill only.
    const observeTurn = res.locals.lexTurnObserver as ((phase: ExecutionPhase, skill: string) => void) | undefined;
    if (observeTurn) {
      const reportStep = request.onStep;
      request.onStep = (phase, detail) => {
        observeTurn(phase, request.primarySkill);
        reportStep?.(phase, detail);
      };
    }

    // A part of a long letter asked for in a case ("Popraw część 3 z 3."): legal work of that
    // letter, never the conversational lane (the router read the short message as non-legal).
    const partRequest =
      Boolean(knowledge.caseId) && namesDocumentPart(latestUserMessage(parseSkillSelectionEnvelope(request.query).query));
    // "a" / "tak" / "ok" / "daj mi dokument" in a thread pinned to the pleading pipeline answers its
    // question (start, a step's checkpoint box), not small talk: the step's answer ends with the
    // checkpoint frame, so the trivial gate would not see the assistant's question.
    const pleadingReply =
      Boolean(knowledge.caseId) &&
      parseSkillSelectionEnvelope(request.query).manualSkills.includes("pisma-procesowe-v3") &&
      (pleadingChatReply(latestUserMessage(parseSkillSelectionEnvelope(request.query).query)) !== null ||
        bareRefusal(latestUserMessage(parseSkillSelectionEnvelope(request.query).query)) ||
        reopensDraft(latestUserMessage(parseSkillSelectionEnvelope(request.query).query)));
    const trivialChat =
      !partRequest &&
      !pleadingReply &&
      (applyTrivialChatGate(
        options.registry,
        request,
        attachments.length + firmTemplates.length
      ) ||
      applyFactCorrectionGate(options.registry, request) ||
      applyNonLegalChatGate(
        options.registry,
        request,
        attachments.length + firmTemplates.length,
        Boolean(knowledge.caseId && knowledge.includeCase)
      ));
    // Entry gate: how much of the legal system this message needs.
    const entryEnvelope =
      parseSkillSelectionEnvelope(request.query);
    const complexity =
      assessMatterComplexity({
        query: entryEnvelope.query,
        attachmentCount:
          attachments.length + firmTemplates.length,
        workflowPinned:
          !trivialChat &&
          (
            entryEnvelope.workflowExecutionSkill !== null ||
            entryEnvelope.manualSkills.length > 0
          )
      });
    request.matterComplexity = complexity;
    const localSimple =
      complexity.level === "SIMPLE" &&
      request.model.startsWith("local/");
    if (trivialChat || localSimple) {
      // No case passages for a greeting; for a simple question on a local
      // model they would cost minutes of prompt reading (selected files
      // still make the matter STANDARD).
      knowledge.includeCase = false;
      knowledge.includeFirm = false;
    }
    request.onStep?.(
      "PREPARE",
      `ocena sprawy: ${describeMatterComplexity(complexity)}`
    );
    request.onStep?.(
      "ROUTING",
      trivialChat
        ? "krótkie polecenie lub pytanie bez kwestii prawnej: bez skilli prawnych i workflow"
        : request.primarySkill === "AUTO"
          ? "prawny-router-v3: wybór dziedziny"
          : `wybrany skill ${request.primarySkill}`
    );
    if (
      !trivialChat &&
      !(await resolveAutoPrimarySkill(
        request,
        res,
        attachments.length,
        {
          allowModelSelection: true,
          allowConversational: !partRequest
        }
      ))
    ) {
      return;
    }

    const route = routing.validate(request.primarySkill);
    if (!route.valid) {
      res.status(422).json({
        error: "INVALID_ROUTE",
        reason: route.reason
      });
      return;
    }

    if (options.authService) {
      const actor =
        responseAuthContext(res);

      // The guide pinned in the chat's envelope (the route is a DR then) as the only
      // executive skill runs LEGAL_GUIDE_V1 too and needs its session state (E2E: 422).
      const pinnedExecutive = parseSkillSelectionEnvelope(request.query).manualSkills.filter(
        (name) => !/^dr-\d{2}-/u.test(name) && name !== "prawny-router-v3" && name !== "prawo-polskie-v2" && name !== "shared"
      );
      if (
        request.primarySkill ===
          "przewodnik-prawny-v2" ||
        (pinnedExecutive.length === 1 && pinnedExecutive[0] === "przewodnik-prawny-v2")
      ) {
        if (
          !options.guideSessionStore
        ) {
          res.status(503).json({
            error:
              "GUIDE_SESSION_STATE_UNAVAILABLE"
          });
          return;
        }
        let guide =
          options.guideSessionStore
            .get(
              actor.session
                .sessionId
            ) ??
          options.guideSessionStore
            .initialize(
              actor.session
                .sessionId,
              request.mode
            );
        if (
          guide.audience !==
            request.mode
        ) {
          guide =
            options.guideSessionStore
              .transition({
                sessionId:
                  actor.session
                    .sessionId,
                expectedRevision:
                  guide.revision,
                transition: {
                  type:
                    "SET_AUDIENCE",
                  audience:
                    request.mode
                }
              });
        }
        request.guideContext = {
          revision:
            guide.revision,
          audience:
            guide.audience,
          interactionMode:
            guide
              .interactionMode,
          rawAnalysis:
            guide.rawAnalysis,
          step: guide.step,
          guidedQuestionIndex:
            guide
              .guidedQuestionIndex,
          pendingIrreversibleAction:
            guide
              .pendingIrreversibleAction
              ? {
                  ...guide
                    .pendingIrreversibleAction
                }
              : null
        };
      }
    }

    try {
      const sessionAttachments:
        SessionDocumentAttachment[] = [];
      // The firm workspace: its documents are firm material, not case files.
      const firmCaseId =
        attachments.length > 0 || firmTemplates.length > 0
          ? options.caseAccessService
              ?.getFirmKnowledgeWorkspace(responseAuthContext(res))
              ?.caseId
          : undefined;

      const selectedAttachments =
        await resolveSelectedAttachments(
          res,
          attachments,
          firmTemplates,
          firmCaseId,
          evidencePolicyFor(req.body?.evidenceImages, request.model),
          !localModel
        );
      if (!selectedAttachments) return;
      sessionAttachments.push(...selectedAttachments);

      if (
        knowledge.includeCase ||
        knowledge.includeFirm
      ) {
        if (
          !options.caseAccessService ||
          !options.caseKnowledgeSearch
        ) {
          res.status(503).json({
            error:
              "CASE_KNOWLEDGE_UNAVAILABLE"
          });
          return;
        }

        const context =
          responseAuthContext(res);
        const knowledgeSources:
          Array<{
            caseId: string;
            sourceScope:
              | "CASE_KNOWLEDGE"
              | "FIRM_KNOWLEDGE";
          }> = [];

        if (
          knowledge.includeCase &&
          knowledge.caseId
        ) {
          knowledgeSources.push({
            caseId:
              knowledge.caseId,
            sourceScope:
              "CASE_KNOWLEDGE"
          });
        }

        if (
          knowledge.includeFirm
        ) {
          const firm =
            options.caseAccessService
              .getFirmKnowledgeWorkspace(
                context
              );
          if (!firm) {
            throw new CaseAccessError(
              "CASE_ACCESS_DENIED",
              403
            );
          }
          knowledgeSources.push({
            caseId:
              firm.caseId,
            sourceScope:
              "FIRM_KNOWLEDGE"
          });
        }

        const ranked:
          Array<{
            caseId: string;
            sourceScope:
              | "CASE_KNOWLEDGE"
              | "FIRM_KNOWLEDGE";
            documentId: string;
            chunkIndex: number;
            pageStart: number;
            pageEnd: number;
            score: number;
            text: string;
          }> = [];

        for (
          const source
          of knowledgeSources
        ) {
          const caseView =
            options.caseAccessService
              .openCase(
                context,
                source.caseId
              );
          const hits =
            await options
              .caseAccessService
              .withCaseDataKey(
                context,
                source.caseId,
                "ANALYZE",
                async (
                  caseDataKey
                ) =>
                  await options
                    .caseKnowledgeSearch!
                    .search({
                      caseId:
                        source.caseId,
                      caseDataKey,
                      keyVersion:
                        caseView
                          .keyVersion,
                      query:
                        request.query,
                      limit:
                        knowledge.limit,
                      reviewedOnly: !localModel
                    })
              );
          ranked.push(
            ...hits.map(
              (hit) => ({
                ...hit,
                sourceScope:
                  source.sourceScope
              })
            )
          );
        }

        ranked.sort(
          (left, right) =>
            right.score -
              left.score ||
            left.caseId
              .localeCompare(
                right.caseId
              ) ||
            left.documentId
              .localeCompare(
                right.documentId
              ) ||
            left.chunkIndex -
              right.chunkIndex
        );

        const selected =
          ranked.slice(
            0,
            knowledge.limit
          );
        const grouped =
          new Map<
            string,
            SessionDocumentAttachment
          >();

        for (
          const hit
          of selected
        ) {
          const key =
            [
              hit.sourceScope,
              hit.caseId,
              hit.documentId
            ].join(":");
          let attachment =
            grouped.get(key);
          if (!attachment) {
            if (
              sessionAttachments.length +
                grouped.size >=
              4
            ) {
              continue;
            }
            attachment = {
              caseId:
                hit.caseId,
              documentId:
                hit.documentId,
              sourceScope:
                hit.sourceScope,
              chunks: []
            };
            grouped.set(
              key,
              attachment
            );
          }
          attachment.chunks.push({
            index:
              hit.chunkIndex,
            pageStart:
              hit.pageStart,
            pageEnd:
              hit.pageEnd,
            text:
              hit.text
          });
        }

        // Retrieved passages fill what the selected documents leave free.
        sessionAttachments.push(
          ...[...grouped.values()].slice(
            0,
            Math.max(0, documentLimit - sessionAttachments.length)
          )
        );
      }

      // Documents of one case on its shared key: the message is pseudonymized
      // with the same key, so a person has one symbol in the message and in
      // every attached document.
      let sharedMembers: Set<string> | null = null;
      const attachmentCases = [
        ...new Set(
          sessionAttachments
            .map((attachment) => attachment.caseId)
            .filter((value): value is string => Boolean(value) && value !== firmCaseId)
        )
      ];
      if (
        attachmentCases.length === 1 &&
        options.caseAccessService &&
        options.documentService?.sharedKeyState
      ) {
        const sharedCaseId = attachmentCases[0]!;
        const context = responseAuthContext(res);
        const caseView = options.caseAccessService.openCase(context, sharedCaseId);
        const shared = await options.caseAccessService.withCaseDataKey(
          context,
          sharedCaseId,
          "ANALYZE",
          (caseDataKey) =>
            options.documentService!.sharedKeyState!({
              caseId: sharedCaseId,
              caseDataKey,
              keyVersion: caseView.keyVersion
            })
        );
        if (shared && shared.members.size > 0) {
          request.privacySeed = shared.snapshot;
          sharedMembers = shared.members;
          for (const attachment of sessionAttachments) {
            if (attachment.caseId === sharedCaseId && shared.members.has(attachment.documentId)) {
              attachment.sharedKey = true;
            }
          }
        }
      }

      if (
        sessionAttachments.length >
          0
      ) {
        request.documentAttachments =
          sessionAttachments;
      }

      let longDocument: LongDocumentState | null = null;
      let askedLongPart: number | null = null;
      // The court of the case (courts/case-court.ts): from its memory, else from its documents.
      let caseCourt: CaseCourt | null = null;
      // A long letter in parts (any model, also a short "kontynuuj"): the part asked for, with the
      // plan, the last numbers and the end of the previous part from the case's record.
      if (knowledge.caseId && options.caseMemoryStore && options.caseAccessService) {
        try {
          const actor = responseAuthContext(res);
          const caseView = options.caseAccessService.openCase(actor, knowledge.caseId);
          const memory = await options.caseAccessService.withCaseDataKey(actor, knowledge.caseId, "ANALYZE", (caseDataKey) =>
            options.caseMemoryStore!.getCaseMemory({ caseId: knowledge.caseId!, caseDataKey, keyVersion: caseView.keyVersion })
          );
          longDocument = memory.longDocument ?? null;
          caseCourt = memory.court ?? null;
          const askedPart = longDocument && (!isComplete(longDocument) || longDocument.failed) ? requestedPart(latestUserMessage(request.query), longDocument) : null;
          askedLongPart = askedPart;
          if (longDocument && askedPart) {
            request.query = `${request.query}\n\n${continuationBlock(longDocument, askedPart, longDocument.failed?.k === askedPart ? longDocument.failed.problems : [], { local: localModel })}`;
            request.onStep?.("PREPARE", `długie pismo: część ${askedPart} z ${longDocument.plan.czesci.length}`);
          }
        } catch (error) {
          console.error("CASE_MEMORY_LONG_DOCUMENT_READ_FAILED", error instanceof Error ? error.message : String(error));
        }
      }
      // A case's documents name its court (a court's letter, a judgment): found once and kept,
      // the documents of this turn first, then the case's files by a court's head and signature.
      if (knowledge.caseId && options.caseMemoryStore && options.caseAccessService && caseCourt?.zrodlo !== "AKTA" && caseCourt?.zrodlo !== "UZYTKOWNIK") {
        try {
          const actor = responseAuthContext(res);
          const caseView = options.caseAccessService.openCase(actor, knowledge.caseId);
          const texts = sessionAttachments
            .filter((attachment) => attachment.caseId === knowledge.caseId)
            .map((attachment) => ({ documentId: attachment.documentId, text: attachment.chunks[0]?.text ?? "" }));
          if (options.caseKnowledgeSearch) {
            const hits = await options.caseAccessService.withCaseDataKey(actor, knowledge.caseId, "ANALYZE", (caseDataKey) =>
              options.caseKnowledgeSearch!.search({ caseId: knowledge.caseId!, caseDataKey, keyVersion: caseView.keyVersion, query: "Sąd Rejonowy Sąd Okręgowy Wydział Sygn. akt", limit: 6 })
            );
            texts.push(...hits.map((hit) => ({ documentId: hit.documentId, text: hit.text })));
          }
          const fromFiles = courtOfCaseDocuments(texts);
          if (fromFiles) {
            const found: CaseCourt = { ...fromFiles, zrodlo: "AKTA", at: new Date().toISOString() };
            await options.caseAccessService.withCaseDataKey(actor, knowledge.caseId, "WRITE", (caseDataKey) =>
              options.caseMemoryStore!.saveCaseMemory({ caseId: knowledge.caseId!, caseDataKey, keyVersion: caseView.keyVersion, court: found })
            );
            caseCourt = found;
          }
        } catch (error) {
          console.error("CASE_COURT_READ_FAILED", error instanceof Error ? error.message : String(error));
        }
      }
      if (caseCourt) request.caseCourt = caseCourt;

      // Evidence memory of the matter's thread (checked in ELI by the executor). A local model
      // gets it too, with the register and the summary shortened: without them it knew nothing
      // of the earlier work past its 28k-character window.
      let threadEvidence: ThreadEvidence | null = null;
      let caseWork: CaseWorkItem[] = [];
      // The user asked for the case summary (button): the template goes with the request, the
      // answer is kept in the case memory.
      const overviewAsked = overviewRequested(request.query);
      if (overviewAsked) request.query = queryWithOverviewTemplate(request.query);
      if (knowledge.caseId && !trivialChat && options.caseMemoryStore && options.caseAccessService) {
        try {
          const actor = responseAuthContext(res);
          const caseView = options.caseAccessService.openCase(actor, knowledge.caseId);
          const memory = await options.caseAccessService.withCaseDataKey(actor, knowledge.caseId, "ANALYZE", (caseDataKey) =>
            options.caseMemoryStore!.getCaseMemory({ caseId: knowledge.caseId!, caseDataKey, keyVersion: caseView.keyVersion })
          );
          threadEvidence = memory.evidence ?? null;
          if (threadEvidence) request.threadEvidence = threadEvidence;
          caseWork = memory.work ?? [];
          // References left unverified earlier: the executor verifies them before the answer.
          const openClaims = caseWork
            .filter((item) => item.kind === "OPEN_ISSUE" && item.status === "OPEN" && item.label.startsWith("do weryfikacji w źródle: "))
            .map((item) => item.label.slice("do weryfikacji w źródle: ".length));
          if (openClaims.length) request.openIssueClaims = openClaims.slice(0, 12);
          // What the case already has: the register of work done and open, and the timeline
          // of its chronology (a part of the larger work). Later turns use them, not redo them.
          const timeline = memory.chronology ? chronologyBlock(memory.chronology, request.query) : null;
          const overview = memory.overview && !overviewAsked ? overviewBlock(memory.overview, request.query) : null;
          // The dates the model got with the timeline: the executor checks the answer uses them
          // (an API model keeps nothing between calls; the application gives and supervises it).
          if (memory.chronology) request.caseTimelineDates = [...isoDates(memory.chronology.text)].slice(0, 500);
          const register = caseWorkBlock(caseWork);
          if (timeline || register || overview) {
            const block = [register, overview, timeline].filter(Boolean).join("\n\n");
            request.query = queryWithChronology(
              request.query,
              localModel && block.length > LOCAL_CASE_MEMORY_CHARS
                ? `${block.slice(0, LOCAL_CASE_MEMORY_CHARS)}\n[…dalsza część pamięci sprawy pominięta (model lokalny)]`
                : block
            );
            request.onStep?.(
              "PREPARE",
              [register ? `rejestr prac sprawy (${caseWork.length})` : "", timeline ? `oś czasu z ${memory.chronology!.updatedAt.slice(0, 10)}` : ""].filter(Boolean).join(", ")
            );
          }
          // Messages the client left out for the window: replaced with their summary.
          const dropped = droppedMessageCount(request.query);
          if (dropped && options.sessionExecutor.summarizeThread) {
            try {
              request.onStep?.("PREPARE", `streszczenie wcześniejszej części rozmowy (${dropped} wiadomości)`);
              const summarize = options.sessionExecutor.summarizeThread.bind(options.sessionExecutor);
              const result = await summaryForDroppedHistory({
                thread: memory.threadMessages,
                dropped,
                stored: memory.summary ?? null,
                chunkChars: localModel ? LOCAL_SUMMARY_CHUNK_CHARS : SUMMARY_CHUNK_CHARS[request.provider] ?? 120_000,
                now: new Date().toISOString(),
                summarize: (previousSummary, messages) =>
                  summarize({
                    provider: request.provider,
                    model: request.model,
                    ...(request.privacySeed ? { privacySeed: request.privacySeed } : {}),
                    ...(previousSummary ? { previousSummary } : {}),
                    messages,
                    ...(threadEvidence ? { threadEvidence } : {})
                  })
              });
              if (result) {
                if (result.generated) {
                  await options.caseAccessService
                    .withCaseDataKey(actor, knowledge.caseId, "WRITE", (caseDataKey) =>
                      options.caseMemoryStore!.saveCaseMemory({
                        caseId: knowledge.caseId!,
                        caseDataKey,
                        keyVersion: caseView.keyVersion,
                        summary: result.summary
                      })
                    )
                    .catch((error: unknown) =>
                      process.stderr.write(`CASE_SUMMARY_NOT_SAVED:${error instanceof Error ? error.message : String(error)}\n`)
                    );
                }
                request.query = queryWithSummary(request.query, result.summary);
              }
            } catch (error) {
              // The answer goes on with the client's note instead of the summary.
              if (error instanceof CaseAccessError) throw error;
              process.stderr.write(`CASE_SUMMARY_FAILED:${error instanceof Error ? error.message : String(error)}\n`);
            }
          }
        } catch (error) {
          if (error instanceof CaseAccessError) throw error;
          process.stderr.write(`CASE_MEMORY_NOT_READ:${error instanceof Error ? error.message : String(error)}\n`);
        }
      }

      // LAIK / PRAWNIK from the content of the question, at the entry (KROK 1 signals);
      // an ambiguous question keeps the matter's earlier mode.
      if (!trivialChat) {
        const signals = modeSignals(options.registry);
        if (signals) {
          const decision = detectQueryMode(
            request.auxiliaryText ?? latestUserTurn(request.query),
            signals,
            threadEvidence?.mode ?? null
          );
          request.mode = decision.mode;
          request.modeDecision = decision;
          request.onStep?.("ROUTING", `tryb ${decision.mode} (${decision.decision.toLowerCase().replaceAll("_", " ")})`);
        }
      }

      // The excerpts above are cut to the window; with case search on, the
      // model reaches the rest of the matter's files through tools.
      if (
        knowledge.includeCase &&
        knowledge.caseId &&
        !localModel &&
        options.caseAccessService &&
        options.caseKnowledgeSearch?.listDocuments &&
        options.documentService?.restoreDocument
      ) {
        request.caseFiles = createCaseFileAccess({
          caseId: knowledge.caseId,
          actor: responseAuthContext(res),
          caseAccessService: options.caseAccessService,
          caseKnowledgeSearch: options.caseKnowledgeSearch as Pick<LocalCaseKnowledgeSearch, "search" | "listDocuments">,
          documentService: options.documentService,
          sharedMembers:
            attachmentCases.length === 1 && attachmentCases[0] === knowledge.caseId ? sharedMembers : null
        });
      }

      if (knowledge.includeCase && knowledge.caseId && options.caseAccessService && options.caseKnowledgeSearch) {
        request.caseSignatureSearch = createCaseSignatureSearch({
          caseId: knowledge.caseId,
          actor: responseAuthContext(res),
          caseAccessService: options.caseAccessService,
          caseKnowledgeSearch: options.caseKnowledgeSearch as Pick<LocalCaseKnowledgeSearch, "search">
        });
      }

      const localContextWindow =
        options.modelCatalog
          .localContextWindow?.(
            request.model
          );
      if (!localContextWindow && sessionAttachments.length > 0) {
        request.modelContextTokens =
          HOSTED_CONTEXT_TOKENS[request.provider] ?? 128_000;
      }
      if (localContextWindow) {
        request.modelContextTokens =
          localContextWindow;
        const localTokenCharsPerToken =
          options.modelCatalog
            .localTokenCharsPerToken?.(
              request.model
            );
        if (
          localTokenCharsPerToken
        ) {
          request.tokenCharsPerToken =
            localTokenCharsPerToken;
        }
      }

      // AUTO with an API or account model and no delivered material: a stateful
      // workflow (chronology, court, contract, pleading, report) starts only when
      // the router gives the message that executive skill. A single word ("wyrok",
      // "umowa", "klienta", "rekomendacje") used to start one against the router's
      // decision, take the turn off model-selected skills and stop plain questions
      // with *_STATE_REQUIRED (benchmark 2026-10-08, scenarios-5000).
      const keywordPlan =
        previewSessionWorkflow(
          options.registry,
          request
        );
      const routerExecutive =
        request.modelSelectsSkills &&
        sessionAttachments.length === 0 &&
        !(knowledge.caseId && knowledge.includeCase) &&
        keywordPlan.executionSkill &&
        options.sessionExecutor?.executiveSkillFor
          ? options.sessionExecutor.executiveSkillFor(
              request.auxiliaryText ?? latestUserTurn(parseSkillSelectionEnvelope(request.query).query)
            )
          : undefined;
      // pisma-procesowe-v3 Test A: editing the form of a pleading the user pasted is
      // MOD-REDAKCJA (the executor preloads it), not a new pipeline W1–W3 with its state.
      // With a file attached the router is not asked (routerExecutive), so Test A is checked
      // on the message and the attached document itself.
      const pleadingRedaction =
        keywordPlan.id === "PROCESS_PLEADING_V1" &&
        (routerExecutive === "pisma-procesowe-v3" || (request.modelSelectsSkills && sessionAttachments.length > 0)) &&
        options.sessionExecutor?.pleadingRedactionFor?.(
          request.auxiliaryText ?? latestUserTurn(parseSkillSelectionEnvelope(request.query).query),
          sessionAttachments
        ) === true;
      // With delivered files the router decides from the message and the files' kinds: a
      // question about a delivered pleading ("dostałem pozew, co mam zrobić?") is not the
      // pleading pipeline that one word ("pozew") would start (409 *_STATE_REQUIRED).
      const materialSkills =
        request.modelSelectsSkills &&
        sessionAttachments.length > 0 &&
        keywordPlan.executionSkill &&
        options.sessionExecutor?.executiveSkillsWithMaterials
          ? options.sessionExecutor.executiveSkillsWithMaterials(
              request.auxiliaryText ?? latestUserTurn(parseSkillSelectionEnvelope(request.query).query),
              sessionAttachments
            )
          : [];
      const turnMessage =
        request.auxiliaryText ?? latestUserTurn(parseSkillSelectionEnvelope(request.query).query);
      // A question about a kind of clause ("czy kara umowna 50% jest ważna?") with no contract
      // delivered or in the case is a legal question, not the contract pipeline (409).
      const contractQuestion =
        keywordPlan.id === "CONTRACT_ANALYSIS_V1" &&
        sessionAttachments.length === 0 &&
        !(knowledge.caseId && knowledge.includeCase) &&
        !asksToDraft(turnMessage) &&
        (/\?\s*$/u.test(turnMessage.trim()) || asksAbout(turnMessage));
      const previewPlan =
        contractQuestion ||
        pleadingRedaction ||
        (routerExecutive !== undefined &&
          routerExecutive !== keywordPlan.executionSkill) ||
        (materialSkills.length > 0 &&
          (!materialSkills.includes(keywordPlan.executionSkill!) ||
            // The keyword's skill is only the router's next stage ("pozew przeciwko mnie jest
            // bezpodstawny" + the delivered pozew: analysis, then a pleading): without a request
            // to draft, the turn is the analysis, not the pleading pipeline (409).
            (materialSkills[0] !== keywordPlan.executionSkill &&
              !asksToDraft(turnMessage))))
          ? createDeterministicWorkflowPlan(options.registry, null)
          : keywordPlan;
      let processContext:
        | {
            caseId: string;
            permit: ProcessExecutionPermit;
            state: ProcessPleadingState;
          }
        | null = null;
      // What the user's chat reply did to the pleading pipeline (accepted start, confirmed step, AUTO).
      let pleadingReplyNote: string | null = null;
      let pleadingDraftWritten: { version: number; checkpoint: ProcessPleadingCheckpoint } | null = null;

      if (
        previewPlan.id ===
          "PROCESS_PLEADING_V1"
      ) {
        if (
          !options.caseAccessService ||
          !options.processWorkflowStore
        ) {
          res.status(503).json({
            error:
              "PROCESS_PLEADING_STATE_SERVICE_UNAVAILABLE"
          });
          return;
        }

        const nonFirmCaseIds =
          new Set(
            sessionAttachments
              .filter(
                (attachment) =>
                  !isFirmScope(attachment.sourceScope)
              )
              .map(
                (attachment) =>
                  attachment.caseId
              )
              .filter(
                (caseId):
                  caseId is string =>
                    Boolean(caseId)
              )
          );
        const processCaseId =
          knowledge.caseId ??
          (
            nonFirmCaseIds.size === 1
              ? [
                  ...nonFirmCaseIds
                ][0]
              : undefined
          );
        if (!processCaseId) {
          throw new Error(
            "PROCESS_PLEADING_CASE_REQUIRED"
          );
        }

        const actor =
          responseAuthContext(res);
        options.caseAccessService
          .assertAccess(
            actor,
            processCaseId,
            "WRITE"
          );
        const caseView =
          options.caseAccessService
            .openCase(
              actor,
              processCaseId
            );
        const state =
          await options
            .caseAccessService
            .withCaseDataKey(
              actor,
              processCaseId,
              "WRITE",
              async (
                caseDataKey
              ) => {
                const current =
                  await options
                    .processWorkflowStore!
                    .getProcessPleadingState({
                      caseId:
                        processCaseId,
                      caseDataKey,
                      keyVersion:
                        caseView.keyVersion
                    });
                if (!current) {
                  return null;
                }

                let inventory:
                  ProcessEvidenceInventory = {
                    fileCount: null,
                    complete: false,
                    source:
                      "UNAVAILABLE"
                  };

                if (
                  options
                    .secureCaseUploadStore
                ) {
                  const uploads =
                    await options
                      .secureCaseUploadStore
                      .listUploads({
                        caseId:
                          processCaseId,
                        caseDataKey,
                        keyVersion:
                          caseView
                            .keyVersion
                      });
                  inventory =
                    evidenceInventoryFromUploads(
                      uploads,
                      "ENCRYPTED_CASE_UPLOADS"
                    );
                } else if (
                  options
                    .caseFileStore
                    ?.listUploads
                ) {
                  const uploads =
                    await options
                      .caseFileStore
                      .listUploads(
                        processCaseId
                      );
                  inventory =
                    evidenceInventoryFromUploads(
                      uploads,
                      "LEGACY_CASE_UPLOADS"
                    );
                }

                const applicability =
                  applyDeterministicProcessApplicability(
                    current,
                    inventory
                  );
                // A typed reply moves the pipeline as in the chat with the skill: "a"/"tak"
                // accepts the start or the pending step, "daj mi dokument" also runs the rest in AUTO.
                const reply = applyPleadingChatReply(
                  applicability.state,
                  latestUserTurn(parseSkillSelectionEnvelope(request.query).query),
                  undefined,
                  lastAssistantTurn(parseSkillSelectionEnvelope(request.query).query)
                );
                pleadingReplyNote = reply.note;
                // "porzuć ścieżkę D" as an answer to the step: its remarks for the step's next run.
                if (reply.revision) {
                  const store = options.processWorkflowStore!;
                  if (!store.getProcessPleadingDraft || !store.saveProcessPleadingDraft) {
                    throw new Error("PROCESS_PLEADING_DRAFT_STORE_UNAVAILABLE");
                  }
                  const draft = await store.getProcessPleadingDraft({ caseId: processCaseId, caseDataKey, keyVersion: caseView.keyVersion });
                  await store.saveProcessPleadingDraft({
                    caseId: processCaseId,
                    caseDataKey,
                    keyVersion: caseView.keyVersion,
                    draft: withDraftRemarks(draft ?? emptyProcessPleadingDraft(processCaseId), reply.revision.checkpoint, reply.revision.remarks),
                    expectedRevision: draft?.revision ?? 0
                  });
                }

                if (
                  reply.state
                    .revision ===
                  current.revision
                ) {
                  return current;
                }

                return await options
                  .processWorkflowStore!
                  .saveProcessPleadingState({
                    caseId:
                      processCaseId,
                    caseDataKey,
                    keyVersion:
                      caseView
                        .keyVersion,
                    state:
                      reply.state,
                    expectedRevision:
                      current.revision
                  });
              }
            );
        const permit =
          requireProcessExecutionPermit(
            state
          );
        // A short reply to the step ("tak", "c", "B) …"): the step runs as from the panel's
        // "Kontynuuj", with the reply quoted for the model.
        // The thread's first message (the request itself, no "Użytkownik:" history) stays as is.
        const replyText = latestUserTurn(parseSkillSelectionEnvelope(request.query).query).trim();
        if (request.query.includes("\n\nUżytkownik: ") && replyText && replyText.length <= 300 && !replyText.startsWith(PLEADING_CONTINUATION)) {
          request.query = pleadingContinuationQuery(request.query, replyText);
          request.auxiliaryText = `${PLEADING_CONTINUATION} Odpowiedź użytkownika na poprzedni etap: «${replyText}»`;
        }
        request.processWorkflowContext = {
          stage: permit.stage,
          checkpoint:
            permit.checkpoint,
          mode: permit.mode,
          register: processCheckpointRegister(state!),
          ...(await pleadingDraftContext(actor, processCaseId, caseView.keyVersion, permit.checkpoint))
        };
        processContext = {
          caseId:
            processCaseId,
          permit,
          state: state!
        };
      }

      let courtContext:
        | {
            caseId: string;
            permit:
              CourtAnalysisExecutionPermit;
            state:
              CourtAnalysisState;
          }
        | null = null;

      if (
        previewPlan.id ===
          "COURT_ANALYSIS_V1"
      ) {
        if (
          !options.caseAccessService ||
          !options
            .courtAnalysisWorkflowStore
        ) {
          res.status(503).json({
            error:
              "COURT_ANALYSIS_STATE_SERVICE_UNAVAILABLE"
          });
          return;
        }

        const nonFirmCaseIds =
          new Set(
            sessionAttachments
              .filter(
                (attachment) =>
                  !isFirmScope(attachment.sourceScope)
              )
              .map(
                (attachment) =>
                  attachment.caseId
              )
              .filter(
                (
                  caseId
                ): caseId is string =>
                  Boolean(caseId)
              )
          );
        const courtCaseId =
          knowledge.caseId ??
          (
            nonFirmCaseIds.size === 1
              ? [
                  ...nonFirmCaseIds
                ][0]
              : undefined
          );
        if (!courtCaseId) {
          throw new Error(
            "COURT_ANALYSIS_CASE_REQUIRED"
          );
        }

        const actor =
          responseAuthContext(res);
        options.caseAccessService
          .assertAccess(
            actor,
            courtCaseId,
            "WRITE"
          );
        const caseView =
          options.caseAccessService
            .openCase(
              actor,
              courtCaseId
            );
        const state =
          await options
            .caseAccessService
            .withCaseDataKey(
              actor,
              courtCaseId,
              "WRITE",
              async (
                caseDataKey
              ) => {
                const current =
                  await options
                    .courtAnalysisWorkflowStore!
                    .getCourtAnalysisState({
                      caseId:
                        courtCaseId,
                      caseDataKey,
                      keyVersion:
                        caseView.keyVersion
                    });
                if (current) {
                  return current;
                }
                return await options
                  .courtAnalysisWorkflowStore!
                  .saveCourtAnalysisState({
                    caseId:
                      courtCaseId,
                    caseDataKey,
                    keyVersion:
                      caseView
                        .keyVersion,
                    state:
                      createCourtAnalysisState(
                        courtCaseId
                      )
                  });
              }
            );

        const permit =
          requireCourtAnalysisExecutionPermit(
            state
          );
        request.courtWorkflowContext = {
          stage:
            permit.stage,
          checkpoint:
            permit.checkpoint
        };
        courtContext = {
          caseId:
            courtCaseId,
          permit,
          state
        };
      }

      let chronologyContext:
        | {
            caseId: string;
            permit:
              ChronologyExecutionPermit;
            state:
              ChronologyState;
          }
        | null = null;

      if (
        previewPlan.id ===
          "CHRONOLOGY_V1"
      ) {
        if (
          !options.caseAccessService ||
          !options
            .chronologyWorkflowStore
        ) {
          res.status(503).json({
            error:
              "CHRONOLOGY_STATE_SERVICE_UNAVAILABLE"
          });
          return;
        }

        const nonFirmCaseIds =
          new Set(
            sessionAttachments
              .filter(
                (attachment) =>
                  !isFirmScope(attachment.sourceScope)
              )
              .map(
                (attachment) =>
                  attachment.caseId
              )
              .filter(
                (
                  caseId
                ): caseId is string =>
                  Boolean(caseId)
              )
          );
        const chronologyCaseId =
          knowledge.caseId ??
          (
            nonFirmCaseIds.size === 1
              ? [
                  ...nonFirmCaseIds
                ][0]
              : undefined
          );
        if (!chronologyCaseId) {
          throw new Error(
            "CHRONOLOGY_CASE_REQUIRED"
          );
        }

        const actor =
          responseAuthContext(res);
        options.caseAccessService
          .assertAccess(
            actor,
            chronologyCaseId,
            "WRITE"
          );
        const caseView =
          options.caseAccessService
            .openCase(
              actor,
              chronologyCaseId
            );

        const temporalRequired =
          chronologyTemporalGateRequired([
            request.query,
            ...sessionAttachments.flatMap(
              (attachment) =>
                attachment.chunks.map(
                  (chunk) =>
                    chunk.text
                )
            )
          ]);

        const state =
          await options
            .caseAccessService
            .withCaseDataKey(
              actor,
              chronologyCaseId,
              "WRITE",
              async (
                caseDataKey
              ) => {
                let current =
                  await options
                    .chronologyWorkflowStore!
                    .getChronologyState({
                      caseId:
                        chronologyCaseId,
                      caseDataKey,
                      keyVersion:
                        caseView.keyVersion
                    });

                if (!current) {
                  current =
                    await options
                      .chronologyWorkflowStore!
                      .saveChronologyState({
                        caseId:
                          chronologyCaseId,
                        caseDataKey,
                        keyVersion:
                          caseView
                            .keyVersion,
                        state:
                          createChronologyState(
                            chronologyCaseId
                          )
                      });
                }

                if (
                  temporalRequired &&
                  !current
                    .temporalGateRequired
                ) {
                  const next =
                    requireChronologyTemporalGate(
                      current,
                      true
                    );
                  current =
                    await options
                      .chronologyWorkflowStore!
                      .saveChronologyState({
                        caseId:
                          chronologyCaseId,
                        caseDataKey,
                        keyVersion:
                          caseView
                            .keyVersion,
                        state: next,
                        expectedRevision:
                          current.revision
                      });
                }
                return current;
              }
            );

        const permit =
          requireChronologyExecutionPermit(
            state
          );
        request.chronologyWorkflowContext = {
          stage:
            permit.stage,
          checkpoint:
            permit.checkpoint,
          temporalGateRequired:
            state
              .temporalGateRequired
        };
        chronologyContext = {
          caseId:
            chronologyCaseId,
          permit,
          state
        };
      }

      let contractContext:
        | {
            caseId: string;
            permit:
              ContractExecutionPermit;
            state:
              ContractAnalysisState;
          }
        | null = null;

      if (
        previewPlan.id ===
          "CONTRACT_ANALYSIS_V1"
      ) {
        if (
          !options.caseAccessService ||
          !options
            .contractWorkflowStore
        ) {
          res.status(503).json({
            error:
              "CONTRACT_STATE_SERVICE_UNAVAILABLE"
          });
          return;
        }

        const nonFirmCaseIds =
          new Set(
            sessionAttachments
              .filter(
                (attachment) =>
                  !isFirmScope(attachment.sourceScope)
              )
              .map(
                (attachment) =>
                  attachment.caseId
              )
              .filter(
                (
                  caseId
                ): caseId is string =>
                  Boolean(caseId)
              )
          );
        const contractCaseId =
          knowledge.caseId ??
          (
            nonFirmCaseIds.size === 1
              ? [
                  ...nonFirmCaseIds
                ][0]
              : undefined
          );
        if (!contractCaseId) {
          throw new Error(
            "CONTRACT_CASE_REQUIRED"
          );
        }

        const actor =
          responseAuthContext(res);
        options.caseAccessService
          .assertAccess(
            actor,
            contractCaseId,
            "WRITE"
          );
        const caseView =
          options.caseAccessService
            .openCase(
              actor,
              contractCaseId
            );

        const state =
          await options
            .caseAccessService
            .withCaseDataKey(
              actor,
              contractCaseId,
              "WRITE",
              (
                caseDataKey
              ) =>
                options
                  .contractWorkflowStore!
                  .getContractAnalysisState({
                    caseId:
                      contractCaseId,
                    caseDataKey,
                    keyVersion:
                      caseView
                        .keyVersion
                  })
            );
        if (!state) {
          throw new Error(
            "CONTRACT_STATE_REQUIRED"
          );
        }

        const permit =
          requireContractExecutionPermit(
            state
          );
        request.contractWorkflowContext = {
          mode:
            permit.mode,
          stage:
            permit.stage,
          checkpoint:
            permit.checkpoint
        };
        contractContext = {
          caseId:
            contractCaseId,
          permit,
          state
        };
      }

      let orderedCaseContext:
        | {
            caseId: string;
            permit:
              OrderedCaseExecutionPermit;
            state:
              OrderedCaseWorkflowState;
          }
        | null = null;

      if (
        previewPlan.id ===
          "EVIDENCE_ANALYSIS_V1" ||
        previewPlan.id ===
          "WITNESS_QUESTIONING_V1"
      ) {
        if (
          !options.caseAccessService ||
          !options
            .orderedCaseWorkflowStore
        ) {
          res.status(503).json({
            error:
              "ORDERED_WORKFLOW_STATE_SERVICE_UNAVAILABLE"
          });
          return;
        }

        const workflowId =
          previewPlan.id as
            OrderedCaseWorkflowId;
        const nonFirmCaseIds =
          new Set(
            sessionAttachments
              .filter(
                (attachment) =>
                  !isFirmScope(attachment.sourceScope)
              )
              .map(
                (attachment) =>
                  attachment.caseId
              )
              .filter(
                (
                  caseId
                ): caseId is string =>
                  Boolean(caseId)
              )
          );
        const orderedCaseId =
          knowledge.caseId ??
          (
            nonFirmCaseIds.size === 1
              ? [
                  ...nonFirmCaseIds
                ][0]
              : undefined
          );
        if (!orderedCaseId) {
          throw new Error(
            "ORDERED_WORKFLOW_CASE_REQUIRED"
          );
        }

        const actor =
          responseAuthContext(res);
        options.caseAccessService
          .assertAccess(
            actor,
            orderedCaseId,
            "WRITE"
          );
        const caseView =
          options.caseAccessService
            .openCase(
              actor,
              orderedCaseId
            );

        const state =
          await options
            .caseAccessService
            .withCaseDataKey(
              actor,
              orderedCaseId,
              "WRITE",
              async (
                caseDataKey
              ) => {
                let current =
                  await options
                    .orderedCaseWorkflowStore!
                    .getOrderedCaseWorkflowState({
                      caseId:
                        orderedCaseId,
                      workflowId,
                      caseDataKey,
                      keyVersion:
                        caseView.keyVersion
                    });
                if (!current) {
                  current =
                    await options
                      .orderedCaseWorkflowStore!
                      .saveOrderedCaseWorkflowState({
                        caseId:
                          orderedCaseId,
                        workflowId,
                        caseDataKey,
                        keyVersion:
                          caseView
                            .keyVersion,
                        state:
                          createOrderedCaseWorkflowState(
                            workflowId,
                            orderedCaseId
                          )
                      });
                }
                return current;
              }
            );

        let permit: ReturnType<typeof requireOrderedCaseExecutionPermit>;
        try {
          permit = requireOrderedCaseExecutionPermit(state);
        } catch (error) {
          // The client needs the workflow to offer its reset.
          if (error instanceof Error && error.message.startsWith("ORDERED_WORKFLOW_")) {
            throw new Error(`${error.message.split(":", 1)[0]}:${workflowId}`);
          }
          throw error;
        }
        request
          .orderedCaseWorkflowContext = {
            workflowId,
            checkpoint:
              permit.checkpoint,
            revision:
              permit.revision
          };
        orderedCaseContext = {
          caseId:
            orderedCaseId,
          permit,
          state
        };
      }

      if (
        processContext?.permit.mode ===
          "AUTO" &&
        options.caseAccessService &&
        options.processWorkflowStore
      ) {
        const actor =
          responseAuthContext(res);
        const caseView =
          options.caseAccessService
            .openCase(
              actor,
              processContext.caseId
            );

        const refreshCitations =
          async (
            result:
              SessionExecutionResponse
          ) => {
            if (
              !result.documentCitations ||
              result.documentCitations
                .length === 0
            ) {
              return;
            }
            if (!options.documentService) {
              throw new Error(
                "DOCUMENT_CITATION_SOURCE_UNAVAILABLE"
              );
            }
            const checked =
              await refreshDocumentCitations({
                result,
                documentService:
                  options.documentService,
                caseAccessService:
                  options.caseAccessService!,
                actor
              });
            result.documentCitationFreshness = {
              result: "PASS",
              checked
            };
          };

        const auto =
          await runBoundedProcessAutoSequence<
            SessionExecutionResponse
          >({
            initialState:
              processContext.state,
            prepareState:
              async (expected) =>
                await options
                  .caseAccessService!
                  .withCaseDataKey(
                    actor,
                    processContext!
                      .caseId,
                    "WRITE",
                    async (
                      caseDataKey
                    ) => {
                      const current =
                        await options
                          .processWorkflowStore!
                          .getProcessPleadingState({
                            caseId:
                              processContext!
                                .caseId,
                            caseDataKey,
                            keyVersion:
                              caseView
                                .keyVersion
                          });
                      if (
                        !current ||
                        current.revision !==
                          expected.revision
                      ) {
                        throw new Error(
                          "PROCESS_PLEADING_STATE_CONFLICT"
                        );
                      }

                      let inventory:
                        ProcessEvidenceInventory = {
                          fileCount:
                            null,
                          complete:
                            false,
                          source:
                            "UNAVAILABLE"
                        };

                      if (
                        options
                          .secureCaseUploadStore
                      ) {
                        const uploads =
                          await options
                            .secureCaseUploadStore
                            .listUploads({
                              caseId:
                                processContext!
                                  .caseId,
                              caseDataKey,
                              keyVersion:
                                caseView
                                  .keyVersion
                            });
                        inventory =
                          evidenceInventoryFromUploads(
                            uploads,
                            "ENCRYPTED_CASE_UPLOADS"
                          );
                      } else if (
                        options
                          .caseFileStore
                          ?.listUploads
                      ) {
                        const uploads =
                          await options
                            .caseFileStore
                            .listUploads(
                              processContext!
                                .caseId
                            );
                        inventory =
                          evidenceInventoryFromUploads(
                            uploads,
                            "LEGACY_CASE_UPLOADS"
                          );
                      }

                      const applicability =
                        applyDeterministicProcessApplicability(
                          current,
                          inventory
                        );
                      if (
                        applicability.state
                          .revision ===
                        current.revision
                      ) {
                        return current;
                      }
                      return await options
                        .processWorkflowStore!
                        .saveProcessPleadingState({
                          caseId:
                            processContext!
                              .caseId,
                          caseDataKey,
                          keyVersion:
                            caseView
                              .keyVersion,
                          state:
                            applicability
                              .state,
                          expectedRevision:
                            current.revision
                        });
                    }
                  ),
            execute:
              async (
                permit,
                current
              ) => {
                const nodeRequest:
                  SessionExecutionRequest = {
                    ...request,
                    processWorkflowContext: {
                      stage:
                        permit.stage,
                      checkpoint:
                        permit.checkpoint,
                      mode:
                        permit.mode,
                      register: processCheckpointRegister(current),
                      ...(await pleadingDraftContext(actor, processContext!.caseId, caseView.keyVersion, permit.checkpoint))
                    }
                  };
                const nodeResult = await completePleadingAnswer(
                  nodeRequest,
                  await options
                    .sessionExecutor!
                    .execute(
                      nodeRequest
                    )
                );
                await refreshCitations(
                  nodeResult
                );
                const commit =
                  nodeResult.status ===
                    "DRAFT_PRESENTABLE" &&
                  nodeResult.workflow
                    ?.id ===
                    "PROCESS_PLEADING_V1" &&
                  processStepDone(nodeResult.workflow, permit.checkpoint);
                if (commit) {
                  const draftProblems: string[] = [];
                  pleadingDraftWritten = (await recordPleadingStep(
                    actor,
                    processContext!.caseId,
                    caseView.keyVersion,
                    permit.checkpoint,
                    permit.stage,
                    nodeResult.answer ?? "",
                    draftProblems
                  )) ?? pleadingDraftWritten;
                  if (draftProblems.length) nodeResult.answer = `${nodeResult.answer ?? ""}\n\n${pleadingDraftNotice(permit.checkpoint, draftProblems)}`;
                }
                return {
                  result:
                    nodeResult,
                  commit,
                  waitingForUser: nodeResult.waitingForUser === true,
                  notApplicable: commit ? evaluateCheckpointOutput(permit.checkpoint, nodeResult.answer ?? "").notApplicable : null
                };
              },
            persist:
              async (
                previous,
                next
              ) =>
                await options
                  .caseAccessService!
                  .withCaseDataKey(
                    actor,
                    processContext!
                      .caseId,
                    "WRITE",
                    async (
                      caseDataKey
                    ) => {
                      const current =
                        await options
                          .processWorkflowStore!
                          .getProcessPleadingState({
                            caseId:
                              processContext!
                                .caseId,
                            caseDataKey,
                            keyVersion:
                              caseView
                                .keyVersion
                          });
                      if (
                        !current ||
                        current.revision !==
                          previous.revision
                      ) {
                        throw new Error(
                          "PROCESS_PLEADING_STATE_CONFLICT"
                        );
                      }
                      return await options
                        .processWorkflowStore!
                        .saveProcessPleadingState({
                          caseId:
                            processContext!
                              .caseId,
                          caseDataKey,
                          keyVersion:
                            caseView
                              .keyVersion,
                          state:
                            next,
                          expectedRevision:
                            previous
                              .revision
                        });
                    }
                  )
          });

        const lastSuccessful =
          auto.steps.at(-1)
            ?.result;
        const response =
          auto.blockedResult ??
          auto.waitingResult ??
          lastSuccessful;
        if (!response) {
          throw new Error(
            "PROCESS_PLEADING_AUTO_RESULT_MISSING"
          );
        }

        const successfulAnswers =
          auto.steps
            .filter(
              (step) =>
                typeof step.result
                  .answer ===
                  "string" &&
                step.result.answer
                  .trim()
            )
            .map(
              (step) =>
                [
                  `## ${step.permit.checkpoint}`,
                  step.result.answer!
                    .trim()
                ].join("\n\n")
            );

        // The checkpoint that asked the user closes the answer: its questions are last.
        if (auto.waitingResult?.answer?.trim() && successfulAnswers.length > 0) {
          successfulAnswers.push(`## ${auto.state.pendingCheckpoint ?? "PYTANIA"}\n\n${auto.waitingResult.answer.trim()}`);
        }
        if (
          response.status ===
            "DRAFT_PRESENTABLE" &&
          successfulAnswers.length > 0
        ) {
          response.answer =
            successfulAnswers.join(
              "\n\n---\n\n"
            );
        }

        response.processAuto = {
          maxSteps:
            PROCESS_AUTO_MAX_STEPS,
          stopped:
            auto.stopped,
          limitReached:
            auto.limitReached,
          steps:
            auto.steps.map(
              (step) => ({
                stage:
                  step.permit.stage,
                checkpoint:
                  step.permit
                    .checkpoint,
                revisionAfter:
                  step.revisionAfter,
                status:
                  step.result.status,
                ...(typeof step
                  .result.answer ===
                    "string"
                  ? {
                      answer:
                        step.result
                          .answer
                    }
                  : {})
              })
            )
        };
        if (pleadingReplyNote) response.answer = `${pleadingReplyNote}\n\n${response.answer ?? ""}`.trimEnd();
        response.processWorkflow = {
          caseId:
            processContext.caseId,
          ...(pleadingDraftWritten ? { draftWritten: pleadingDraftWritten } : {}),
          mode:
            auto.state.mode,
          revision:
            auto.state.revision,
          stage:
            auto.state.stage,
          documentStatus:
            auto.state
              .documentStatus,
          pendingCheckpoint:
            auto.state
              .pendingCheckpoint,
          checkpoints: {
            ...auto.state
              .checkpoints
          }
        };

        restoreSessionDocumentAliases(
          response,
          options.documentService
        );
        res.json(response);
        return;
      }

      const result = await completePleadingAnswer(
        request,
        await options
          .sessionExecutor
          .execute(request)
      );

      if (
        result.documentCitations &&
        result.documentCitations.length > 0
      ) {
        if (!options.documentService) {
          throw new Error(
            "DOCUMENT_CITATION_SOURCE_UNAVAILABLE"
          );
        }
        const actor =
          options.caseAccessService
            ? responseAuthContext(res)
            : undefined;
        const checked =
          await refreshDocumentCitations({
            result,
            documentService:
              options.documentService,
            ...(options.caseAccessService
              ? {
                  caseAccessService:
                    options.caseAccessService
                }
              : {}),
            ...(actor
              ? { actor }
              : {})
          });
        result.documentCitationFreshness = {
          result: "PASS",
          checked
        };
      }

      if (
        orderedCaseContext &&
        options.caseAccessService &&
        options
          .orderedCaseWorkflowStore
      ) {
        const actor =
          responseAuthContext(res);
        const caseView =
          options.caseAccessService
            .openCase(
              actor,
              orderedCaseContext.caseId
            );

        let state =
          orderedCaseContext.state;
        if (
          result.status ===
            "DRAFT_PRESENTABLE" &&
          result.finalization ===
            "PASS" &&
          result.audit.result ===
            "PASS" &&
          result.audit.closed ===
            true &&
          result.workflow?.id ===
            orderedCaseContext
              .permit.workflowId &&
          result.workflow.result ===
            "PASS" &&
          // A checkpoint that asked the user stays open until the reply.
          result.waitingForUser !== true &&
          // A step refused during the turn: the audit of the checkpoint cannot be closed
          // over it; the answer is shown and the checkpoint stays open (checkpointHeld).
          blockedAuditSteps(result).length === 0
        ) {
          if (
            !options
              .secureCaseArtifactStore
          ) {
            throw new Error(
              "WORKFLOW_AUDIT_STORE_UNAVAILABLE"
            );
          }

          state =
            await options
              .caseAccessService
              .withCaseDataKey(
                actor,
                orderedCaseContext.caseId,
                "WRITE",
                async (
                  caseDataKey
                ) => {
                  const current =
                    await options
                      .orderedCaseWorkflowStore!
                      .getOrderedCaseWorkflowState({
                        caseId:
                          orderedCaseContext!
                            .caseId,
                        workflowId:
                          orderedCaseContext!
                            .permit
                            .workflowId,
                        caseDataKey,
                        keyVersion:
                          caseView
                            .keyVersion
                      });
                  if (!current) {
                    throw new Error(
                      "ORDERED_WORKFLOW_STATE_CONFLICT"
                    );
                  }

                  const auditArtifact =
                    await persistWorkflowAuditArtifact({
                      store:
                        options
                          .secureCaseArtifactStore!,
                      caseId:
                        orderedCaseContext!
                          .caseId,
                      caseDataKey,
                      keyVersion:
                        caseView
                          .keyVersion,
                      createdByUserId:
                        actor.user
                          .userId,
                      workflowId:
                        orderedCaseContext!
                          .permit
                          .workflowId,
                      checkpoint:
                        orderedCaseContext!
                          .permit
                          .checkpoint,
                      result
                    });

                  try {
                    const next =
                      completeOrderedCaseExecution(
                        current,
                        orderedCaseContext!
                          .permit,
                        [
                          auditArtifact
                            .auditRef
                        ]
                      );
                    return await options
                      .orderedCaseWorkflowStore!
                      .saveOrderedCaseWorkflowState({
                        caseId:
                          orderedCaseContext!
                            .caseId,
                        workflowId:
                          orderedCaseContext!
                            .permit
                            .workflowId,
                        caseDataKey,
                        keyVersion:
                          caseView
                            .keyVersion,
                        state: next,
                        expectedRevision:
                          current.revision
                      });
                  } catch (error) {
                    await options
                      .secureCaseArtifactStore!
                      .deleteArtifact({
                        caseId:
                          orderedCaseContext!
                            .caseId,
                        artifactId:
                          auditArtifact
                            .artifactId,
                        caseDataKey,
                        keyVersion:
                          caseView
                            .keyVersion
                      });
                    throw error;
                  }
                }
              );
        }

        result.orderedCaseWorkflow = {
          workflowId:
            state.workflowId,
          caseId:
            state.caseId,
          revision:
            state.revision,
          status:
            state.status,
          nextCheckpoint:
            nextOrderedCaseCheckpoint(
              state
            ),
          closedCheckpoints: [
            ...state
              .closedCheckpoints
          ]
        };
      }

      if (
        contractContext &&
        options.caseAccessService &&
        options
          .contractWorkflowStore
      ) {
        const actor =
          responseAuthContext(res);
        const caseView =
          options.caseAccessService
            .openCase(
              actor,
              contractContext.caseId
            );

        let state =
          contractContext.state;
        if (
          result.status ===
            "DRAFT_PRESENTABLE" &&
          result.finalization ===
            "PASS" &&
          result.audit.result ===
            "PASS" &&
          result.audit.closed ===
            true &&
          result.workflow?.id ===
            "CONTRACT_ANALYSIS_V1" &&
          result.workflow.result ===
            "PASS" &&
          // A checkpoint that asked the user stays open until the reply.
          result.waitingForUser !== true &&
          // A step refused during the turn: the audit of the checkpoint cannot be closed
          // over it; the answer is shown and the checkpoint stays open (checkpointHeld).
          blockedAuditSteps(result).length === 0
        ) {
          if (
            !options
              .secureCaseArtifactStore
          ) {
            throw new Error(
              "WORKFLOW_AUDIT_STORE_UNAVAILABLE"
            );
          }

          state =
            await options
              .caseAccessService
              .withCaseDataKey(
                actor,
                contractContext.caseId,
                "WRITE",
                async (
                  caseDataKey
                ) => {
                  const current =
                    await options
                      .contractWorkflowStore!
                      .getContractAnalysisState({
                        caseId:
                          contractContext!
                            .caseId,
                        caseDataKey,
                        keyVersion:
                          caseView
                            .keyVersion
                      });
                  if (!current) {
                    throw new Error(
                      "CONTRACT_STATE_CONFLICT"
                    );
                  }

                  const auditArtifact =
                    await persistWorkflowAuditArtifact({
                      store:
                        options
                          .secureCaseArtifactStore!,
                      caseId:
                        contractContext!
                          .caseId,
                      caseDataKey,
                      keyVersion:
                        caseView
                          .keyVersion,
                      createdByUserId:
                        actor.user
                          .userId,
                      workflowId:
                        "CONTRACT_ANALYSIS_V1",
                      checkpoint:
                        contractContext!
                          .permit
                          .checkpoint,
                      result
                    });

                  try {
                    const next =
                      completeContractExecution(
                        current,
                        contractContext!
                          .permit,
                        [
                          auditArtifact
                            .auditRef
                        ]
                      );
                    return await options
                      .contractWorkflowStore!
                      .saveContractAnalysisState({
                        caseId:
                          contractContext!
                            .caseId,
                        caseDataKey,
                        keyVersion:
                          caseView
                            .keyVersion,
                        state: next,
                        expectedRevision:
                          current.revision
                      });
                  } catch (error) {
                    await options
                      .secureCaseArtifactStore!
                      .deleteArtifact({
                        caseId:
                          contractContext!
                            .caseId,
                        artifactId:
                          auditArtifact
                            .artifactId,
                        caseDataKey,
                        keyVersion:
                          caseView
                            .keyVersion
                      });
                    throw error;
                  }
                }
              );
        }

        result.contractWorkflow = {
          caseId:
            contractContext.caseId,
          revision:
            state.revision,
          mode:
            state.mode,
          stage:
            state.stage,
          nextCheckpoint:
            nextContractCheckpoint(
              state
            ),
          closedCheckpoints: [
            ...state
              .closedCheckpoints
          ]
        };
      }

      if (
        chronologyContext &&
        options.caseAccessService &&
        options
          .chronologyWorkflowStore
      ) {
        const actor =
          responseAuthContext(res);
        const caseView =
          options.caseAccessService
            .openCase(
              actor,
              chronologyContext.caseId
            );

        let state =
          chronologyContext.state;
        if (
          result.status ===
            "DRAFT_PRESENTABLE" &&
          result.finalization ===
            "PASS" &&
          result.audit.result ===
            "PASS" &&
          result.audit.closed ===
            true &&
          result.workflow?.id ===
            "CHRONOLOGY_V1" &&
          result.workflow.result ===
            "PASS" &&
          // A checkpoint that asked the user stays open until the reply.
          result.waitingForUser !== true &&
          // A step refused during the turn: the audit of the checkpoint cannot be closed
          // over it; the answer is shown and the checkpoint stays open (checkpointHeld).
          blockedAuditSteps(result).length === 0
        ) {
          if (
            !options
              .secureCaseArtifactStore
          ) {
            throw new Error(
              "WORKFLOW_AUDIT_STORE_UNAVAILABLE"
            );
          }

          state =
            await options
              .caseAccessService
              .withCaseDataKey(
                actor,
                chronologyContext.caseId,
                "WRITE",
                async (
                  caseDataKey
                ) => {
                  const current =
                    await options
                      .chronologyWorkflowStore!
                      .getChronologyState({
                        caseId:
                          chronologyContext!
                            .caseId,
                        caseDataKey,
                        keyVersion:
                          caseView
                            .keyVersion
                      });
                  if (!current) {
                    throw new Error(
                      "CHRONOLOGY_STATE_CONFLICT"
                    );
                  }

                  const auditArtifact =
                    await persistWorkflowAuditArtifact({
                      store:
                        options
                          .secureCaseArtifactStore!,
                      caseId:
                        chronologyContext!
                          .caseId,
                      caseDataKey,
                      keyVersion:
                        caseView
                          .keyVersion,
                      createdByUserId:
                        actor.user
                          .userId,
                      workflowId:
                        "CHRONOLOGY_V1",
                      checkpoint:
                        chronologyContext!
                          .permit
                          .checkpoint,
                      result
                    });

                  try {
                    const next =
                      completeChronologyExecution(
                        current,
                        chronologyContext!
                          .permit,
                        [
                          auditArtifact
                            .auditRef
                        ]
                      );
                    return await options
                      .chronologyWorkflowStore!
                      .saveChronologyState({
                        caseId:
                          chronologyContext!
                            .caseId,
                        caseDataKey,
                        keyVersion:
                          caseView
                            .keyVersion,
                        state: next,
                        expectedRevision:
                          current.revision
                      });
                  } catch (error) {
                    await options
                      .secureCaseArtifactStore!
                      .deleteArtifact({
                        caseId:
                          chronologyContext!
                            .caseId,
                        artifactId:
                          auditArtifact
                            .artifactId,
                        caseDataKey,
                        keyVersion:
                          caseView
                            .keyVersion
                      });
                    throw error;
                  }
                }
              );
        }

        result.chronologyWorkflow = {
          caseId:
            chronologyContext.caseId,
          revision:
            state.revision,
          stage:
            state.stage,
          temporalGateRequired:
            state
              .temporalGateRequired,
          nextCheckpoint:
            nextChronologyCheckpoint(
              state
            ),
          closedCheckpoints: [
            ...state
              .closedCheckpoints
          ]
        };
      }

      if (
        courtContext &&
        options.caseAccessService &&
        options
          .courtAnalysisWorkflowStore
      ) {
        const actor =
          responseAuthContext(res);
        const caseView =
          options.caseAccessService
            .openCase(
              actor,
              courtContext.caseId
            );

        let state =
          courtContext.state;
        if (
          result.status ===
            "DRAFT_PRESENTABLE" &&
          result.finalization ===
            "PASS" &&
          result.audit.result ===
            "PASS" &&
          result.audit.closed ===
            true &&
          result.workflow?.id ===
            "COURT_ANALYSIS_V1" &&
          result.workflow.result ===
            "PASS" &&
          // A checkpoint that asked the user stays open until the reply.
          result.waitingForUser !== true &&
          // A step refused during the turn: the audit of the checkpoint cannot be closed
          // over it; the answer is shown and the checkpoint stays open (checkpointHeld).
          blockedAuditSteps(result).length === 0
        ) {
          if (
            !options
              .secureCaseArtifactStore
          ) {
            throw new Error(
              "WORKFLOW_AUDIT_STORE_UNAVAILABLE"
            );
          }

          state =
            await options
              .caseAccessService
              .withCaseDataKey(
                actor,
                courtContext.caseId,
                "WRITE",
                async (
                  caseDataKey
                ) => {
                  const current =
                    await options
                      .courtAnalysisWorkflowStore!
                      .getCourtAnalysisState({
                        caseId:
                          courtContext!
                            .caseId,
                        caseDataKey,
                        keyVersion:
                          caseView
                            .keyVersion
                      });
                  if (!current) {
                    throw new Error(
                      "COURT_ANALYSIS_STATE_CONFLICT"
                    );
                  }

                  const auditArtifact =
                    await persistWorkflowAuditArtifact({
                      store:
                        options
                          .secureCaseArtifactStore!,
                      caseId:
                        courtContext!
                          .caseId,
                      caseDataKey,
                      keyVersion:
                        caseView
                          .keyVersion,
                      createdByUserId:
                        actor.user
                          .userId,
                      workflowId:
                        "COURT_ANALYSIS_V1",
                      checkpoint:
                        courtContext!
                          .permit
                          .checkpoint,
                      result
                    });

                  try {
                    const next =
                      completeCourtAnalysisExecution(
                        current,
                        courtContext!
                          .permit,
                        [
                          auditArtifact
                            .auditRef
                        ]
                      );
                    return await options
                      .courtAnalysisWorkflowStore!
                      .saveCourtAnalysisState({
                        caseId:
                          courtContext!
                            .caseId,
                        caseDataKey,
                        keyVersion:
                          caseView
                            .keyVersion,
                        state: next,
                        expectedRevision:
                          current.revision
                      });
                  } catch (error) {
                    await options
                      .secureCaseArtifactStore!
                      .deleteArtifact({
                        caseId:
                          courtContext!
                            .caseId,
                        artifactId:
                          auditArtifact
                            .artifactId,
                        caseDataKey,
                        keyVersion:
                          caseView
                            .keyVersion
                      });
                    throw error;
                  }
                }
              );
        }

        result.courtWorkflow = {
          caseId:
            courtContext.caseId,
          revision:
            state.revision,
          stage:
            state.stage,
          nextCheckpoint:
            nextCourtAnalysisCheckpoint(
              state
            ),
          closedCheckpoints: [
            ...state
              .closedCheckpoints
          ]
        };
      }

      if (
        processContext &&
        options.caseAccessService &&
        options.processWorkflowStore
      ) {
        const actor =
          responseAuthContext(res);
        const caseView =
          options.caseAccessService
            .openCase(
              actor,
              processContext.caseId
            );

        let state =
          processContext.state;
        if (
          result.status ===
            "DRAFT_PRESENTABLE" &&
          result.workflow?.id ===
            "PROCESS_PLEADING_V1" &&
          processStepDone(result.workflow, processContext.permit.checkpoint) &&
          // A checkpoint that asked the user stays open until the reply.
          result.waitingForUser !== true
        ) {
          state =
            await options
              .caseAccessService
              .withCaseDataKey(
                actor,
                processContext.caseId,
                "WRITE",
                async (
                  caseDataKey
                ) => {
                  const current =
                    await options
                      .processWorkflowStore!
                      .getProcessPleadingState({
                        caseId:
                          processContext!
                            .caseId,
                        caseDataKey,
                        keyVersion:
                          caseView
                            .keyVersion
                      });
                  if (!current) {
                    throw new Error(
                      "PROCESS_PLEADING_STATE_CONFLICT"
                    );
                  }
                  const next =
                    completeProcessExecution(
                      current,
                      processContext!
                        .permit,
                      evaluateCheckpointOutput(processContext!.permit.checkpoint, result.answer ?? "").notApplicable
                    );
                  return await options
                    .processWorkflowStore!
                    .saveProcessPleadingState({
                      caseId:
                        processContext!
                          .caseId,
                      caseDataKey,
                      keyVersion:
                        caseView
                          .keyVersion,
                      state: next,
                      expectedRevision:
                        current.revision
                    });
                }
              );
        }

        if (
          result.status === "DRAFT_PRESENTABLE" &&
          result.workflow?.id === "PROCESS_PLEADING_V1" &&
          processStepDone(result.workflow, processContext.permit.checkpoint)
        ) {
          const draftProblems: string[] = [];
          pleadingDraftWritten =
            (await recordPleadingStep(
              actor,
              processContext.caseId,
              caseView.keyVersion,
              processContext.permit.checkpoint,
              processContext.permit.stage,
              result.answer ?? "",
              draftProblems
            )) ?? pleadingDraftWritten;
          if (draftProblems.length) result.answer = `${result.answer ?? ""}\n\n${pleadingDraftNotice(processContext.permit.checkpoint, draftProblems)}`;
        }

        if (pleadingReplyNote) result.answer = `${pleadingReplyNote}\n\n${result.answer ?? ""}`.trimEnd();
        result.processWorkflow = {
          caseId:
            processContext.caseId,
          ...(pleadingDraftWritten ? { draftWritten: pleadingDraftWritten } : {}),
          mode: state.mode,
          revision: state.revision,
          stage: state.stage,
          documentStatus:
            state.documentStatus,
          pendingCheckpoint:
            state.pendingCheckpoint,
          checkpoints: {
            ...state.checkpoints
          }
        };
      }

      const restoredFromDocuments = restoreSessionDocumentAliases(
        result,
        options.documentService
      );
      if (appliedTemplate) result.firmTemplateApplied = appliedTemplate;
      // A chronology result is kept as the case's timeline (case memory) for the later work.
      const timelineToKeep =
        knowledge.caseId && options.caseMemoryStore && options.caseAccessService
          ? chronologyFromAnswer({
              answer: result.answer,
              status: result.status,
              ...(result.taskSkill ? { taskSkill: result.taskSkill } : {}),
              reportClosed:
                chronologyContext?.permit.checkpoint === "CHRONOLOGY_REPORT_COMPLETE" &&
                result.chronologyWorkflow?.closedCheckpoints.includes("CHRONOLOGY_REPORT_COMPLETE") === true,
              sessionId: result.sessionId
            })
          : null;
      const overviewToKeep =
        knowledge.caseId && options.caseMemoryStore && options.caseAccessService
          ? overviewFromAnswer({ answer: result.answer, status: result.status, requested: overviewAsked, sessionId: result.sessionId })
          : null;
      // The register of the case's work: documents analysed (pages), the chronology, workflows done.
      const completedWorkflows = [
        result.courtWorkflow?.stage === "COMPLETE" ? "COURT_ANALYSIS_V1" : null,
        result.contractWorkflow?.stage === "COMPLETE" ? "CONTRACT_ANALYSIS_V1" : null,
        result.chronologyWorkflow?.stage === "COMPLETE" ? "CHRONOLOGY_V1" : null,
        result.orderedCaseWorkflow?.status === "COMPLETE" ? result.orderedCaseWorkflow.workflowId : null,
        result.processWorkflow?.documentStatus === "FINAL" ? "PROCESS_PLEADING_V1" : null
      ].filter((id): id is string => Boolean(id));
      // Points left open (to verify, to research) and settled: kept in the case memory with
      // their label and sent with every later message, past the trimmed conversation.
      const announced = result.pipelineNext?.choices?.some((choice) => choice.kind === "CONTINUE")
        ? (result.answer ?? "").split(/⚖️/u)[0]!.replace(/\s+/gu, " ").trim().slice(0, 200)
        : null;
      const issues = result.status === "DRAFT_PRESENTABLE"
        ? turnIssues({ blockedReferences: result.blockedReferences, evidence: result.evidence, announcedStep: announced, answer: result.answer ?? "" })
        : { open: [], resolved: [], gapsListed: false };
      // A fact the user corrected (applyFactCorrectionGate): kept in the register, so later
      // turns of any thread use it although the conversation that said it is trimmed.
      const correction = request.factCorrection && result.status === "DRAFT_PRESENTABLE" ? latestUserMessage(parseSkillSelectionEnvelope(request.query).query).trim() : "";
      const workChanged =
        Boolean(correction) ||
        result.status === "DRAFT_PRESENTABLE" &&
        ((result.documentAnalysis && result.documentCoverage?.length) || timelineToKeep || completedWorkflows.length ||
          issues.open.length ||
          caseWork.some(
            (item) =>
              item.kind === "OPEN_ISSUE" &&
              item.status === "OPEN" &&
              (issues.resolved.includes(item.key.slice("ISSUE:".length)) || (issues.gapsListed && item.key.startsWith("ISSUE:brak:")))
          ));
      if (knowledge.caseId && options.caseMemoryStore && options.caseAccessService && (timelineToKeep || overviewToKeep || workChanged)) {
        try {
          const actor = responseAuthContext(res);
          const caseView = options.caseAccessService.openCase(actor, knowledge.caseId);
          const now = new Date().toISOString();
          await options.caseAccessService.withCaseDataKey(actor, knowledge.caseId, "WRITE", async (caseDataKey) => {
            const key = { caseId: knowledge.caseId!, caseDataKey, keyVersion: caseView.keyVersion };
            const current = await options.caseMemoryStore!.getCaseMemory(key);
            await options.caseMemoryStore!.saveCaseMemory({
              ...key,
              ...(timelineToKeep ? { chronology: timelineToKeep } : {}),
              ...(overviewToKeep ? { overview: overviewToKeep } : {}),
              ...(workChanged
                ? {
                    work: recordCaseWork(current.work ?? caseWork, {
                      now,
                      ...(result.taskSkill ? { skill: result.taskSkill } : {}),
                      ...(result.documentAnalysis ? { documentAnalysis: true } : {}),
                      ...(result.documentCoverage ? { coverage: result.documentCoverage } : {}),
                      chronologySaved: Boolean(timelineToKeep),
                      completedWorkflows,
                      openIssues: issues.open,
                      resolvedIssues: issues.resolved,
                      gapsListed: issues.gapsListed,
                      ...(correction ? { corrections: [correction] } : {})
                    })
                  }
                : {})
            });
          });
          if (timelineToKeep) result.chronologySaved = { updatedAt: timelineToKeep.updatedAt };
        } catch (error) {
          console.error("CASE_MEMORY_WORK_SAVE_FAILED", error instanceof Error ? error.message : String(error));
        }
      }
      // A part of a long letter: checked against the plan and the parts before it, kept in the
      // case memory when it passes; the chat shows "Część k z N" and the next part is asked for.
      // A part the gates blocked (a provision unverified or cited under the wrong act): no text
      // reaches the register, but the part is not lost from the loop - it is asked for again
      // with the citations to correct, as a part that failed its own check.
      if (
        result.status === "BLOCKED" &&
        longDocument &&
        askedLongPart &&
        knowledge.caseId &&
        options.caseMemoryStore &&
        options.caseAccessService
      ) {
        const problems = blockedPartProblems(result.blockedReferences);
        const state: LongDocumentState = { ...longDocument, failed: { k: askedLongPart, problems }, updatedAt: new Date().toISOString() };
        try {
          const actor = responseAuthContext(res);
          const caseView = options.caseAccessService.openCase(actor, knowledge.caseId);
          await options.caseAccessService.withCaseDataKey(actor, knowledge.caseId, "WRITE", (caseDataKey) =>
            options.caseMemoryStore!.saveCaseMemory({ caseId: knowledge.caseId!, caseDataKey, keyVersion: caseView.keyVersion, longDocument: state })
          );
          const n = state.plan.czesci.length;
          result.longDocument = { id: state.id, title: state.plan.tytul, part: askedLongPart, parts: n, ok: false, problems, complete: false, next: askedLongPart };
          const choice = { skill: result.taskSkill ?? result.primarySkill, kind: "CONTINUE" as const, reason: `Popraw część ${askedLongPart} z ${n}: ${problems.slice(0, 2).join("; ")}` };
          result.pipelineNext = { skill: choice.skill, reason: choice.reason, choices: [choice] };
        } catch (error) {
          console.error("CASE_MEMORY_LONG_DOCUMENT_SAVE_FAILED", error instanceof Error ? error.message : String(error));
        }
      }
      // The first letter of a case not yet in court: its addressee found by court_for_address
      // becomes the case's court for the letters after it.
      const letterCourt = result.status === "DRAFT_PRESENTABLE" && result.answer && !caseCourt && result.courtsFound?.length ? addresseeCourt(result.answer) : null;
      if (letterCourt && result.courtsFound!.includes(letterCourt) && knowledge.caseId && options.caseMemoryStore && options.caseAccessService) {
        try {
          const actor = responseAuthContext(res);
          const caseView = options.caseAccessService.openCase(actor, knowledge.caseId);
          await options.caseAccessService.withCaseDataKey(actor, knowledge.caseId, "WRITE", (caseDataKey) =>
            options.caseMemoryStore!.saveCaseMemory({ caseId: knowledge.caseId!, caseDataKey, keyVersion: caseView.keyVersion, court: { nazwa: letterCourt, zrodlo: "PISMO", at: new Date().toISOString() } })
          );
          result.caseCourt = { nazwa: letterCourt, zrodlo: "PISMO" };
        } catch (error) {
          console.error("CASE_COURT_SAVE_FAILED", error instanceof Error ? error.message : String(error));
        }
      } else if (caseCourt) {
        result.caseCourt = { nazwa: caseCourt.nazwa, zrodlo: caseCourt.zrodlo, ...(caseCourt.sygnatura ? { sygnatura: caseCourt.sygnatura } : {}) };
      }
      const writtenPart = result.status === "DRAFT_PRESENTABLE" && result.answer ? parsePart(result.answer) : null;
      if (writtenPart && knowledge.caseId && options.caseMemoryStore && options.caseAccessService) {
        const now = new Date().toISOString();
        const started: LongDocumentState | null =
          writtenPart.k === 1 && writtenPart.plan ? { id: randomUUID(), plan: writtenPart.plan, parts: [], updatedAt: now } : longDocument;
        if (started) {
          const check = checkPart(writtenPart, started.plan, started.parts);
          const { failed: _failed, ...clean } = started;
          const state: LongDocumentState = check.ok
            ? withPart(clean, writtenPart, now)
            : { ...started, failed: { k: writtenPart.k, problems: check.problems }, updatedAt: now };
          try {
            const actor = responseAuthContext(res);
            const caseView = options.caseAccessService.openCase(actor, knowledge.caseId);
            await options.caseAccessService.withCaseDataKey(actor, knowledge.caseId, "WRITE", (caseDataKey) =>
              options.caseMemoryStore!.saveCaseMemory({ caseId: knowledge.caseId!, caseDataKey, keyVersion: caseView.keyVersion, longDocument: state })
            );
            const next = nextPart(state);
            result.answer = presentPart(result.answer!, writtenPart, state.plan.tytul);
            result.longDocument = {
              id: state.id,
              title: state.plan.tytul,
              part: writtenPart.k,
              parts: state.plan.czesci.length,
              ok: check.ok,
              problems: check.problems,
              complete: isComplete(state) && !state.failed,
              next
            };
            // The next part (or the same part again, with its problems), else the one file of
            // all the parts; the file's choice names the document so a reloaded thread keeps it.
            const skill = result.taskSkill ?? result.primarySkill;
            const choice = next
              ? {
                  skill,
                  kind: "CONTINUE" as const,
                  reason: check.ok ? `Część ${next} z ${state.plan.czesci.length}` : `Popraw część ${next} z ${state.plan.czesci.length}: ${check.problems.slice(0, 2).join("; ")}`
                }
              : { skill, kind: "DOCUMENT" as const, reason: `jeden plik z ${state.plan.czesci.length} części`, longDocumentId: state.id };
            result.pipelineNext = {
              skill: choice.skill,
              reason: choice.reason,
              choices: [choice, ...(result.pipelineNext?.choices ?? []).filter((item) => item.kind !== "CONTINUE" && item.kind !== "DOCUMENT")]
            };
          } catch (error) {
            console.error("CASE_MEMORY_LONG_DOCUMENT_SAVE_FAILED", error instanceof Error ? error.message : String(error));
          }
        } else if (writtenPart.planInvalid || writtenPart.k > 1) {
          result.longDocument = {
            id: "",
            title: "",
            part: writtenPart.k,
            parts: writtenPart.n,
            ok: false,
            problems: [writtenPart.planInvalid ? "plan pisma nieczytelny: poproś o pismo jeszcze raz" : "brak planu tego pisma w sprawie: zacznij od części 1"],
            complete: false,
            next: null
          };
        }
      }
      // An answer (a letter, an analysis) kept with its session's trail for its file, made from
      // its text without a model turn. A DEGRADED finalization (references left marked
      // unverified) still makes a draft: the export gate names what was not verified.
      const internalState = result[SESSION_EXECUTION_INTERNAL];
      if (
        knowledge.caseId &&
        options.caseMemoryStore &&
        options.caseAccessService &&
        internalState &&
        result.status === "DRAFT_PRESENTABLE" &&
        result.finalization !== "BLOCKED" &&
        result.audit.result === "PASS" &&
        result.answer &&
        !result.waitingForUser &&
        !result.longDocument &&
        answerDocumentMarkup(result.answer)
      ) {
        try {
          const actor = responseAuthContext(res);
          const caseView = options.caseAccessService.openCase(actor, knowledge.caseId);
          await options.caseAccessService.withCaseDataKey(actor, knowledge.caseId, "WRITE", (caseDataKey) =>
            options.caseMemoryStore!.saveCaseMemory({
              caseId: knowledge.caseId!,
              caseDataKey,
              keyVersion: caseView.keyVersion,
              answerDocument: {
                sessionId: result.sessionId,
                at: new Date().toISOString(),
                text: result.answer!,
                validationContext: answerValidationContext(request, result, internalState)
              }
            })
          );
          result.answerDocument = { sessionId: result.sessionId };
        } catch (error) {
          console.error("CASE_MEMORY_ANSWER_DOCUMENT_SAVE_FAILED", error instanceof Error ? error.message : String(error));
        }
      }
      if (knowledge.caseId && options.caseMemoryStore && options.caseAccessService && !trivialChat) {
        await rememberThreadEvidence({
          store: options.caseMemoryStore,
          caseAccessService: options.caseAccessService,
          actor: responseAuthContext(res),
          caseId: knowledge.caseId,
          previous: threadEvidence,
          result,
          // Real data restored into this answer: never "example data" later.
          realValues: [...(result.restorations ?? []).map((item) => item.text), ...restoredFromDocuments]
        });
      }
      // A workflow step that passed but had a refused step on the way: its checkpoint was
      // not closed (no audit artifact over a BLOCKED event); the user sees why and repeats it.
      const held =
        result.status === "DRAFT_PRESENTABLE" &&
        result.workflow?.result === "PASS" &&
        isStatefulWorkflowAuditId(result.workflow.id) &&
        result.waitingForUser !== true
          ? blockedAuditSteps(result)
          : [];
      if (held.length) result.checkpointHeld = { reason: "BLOCKED_STEP", steps: held };
      res.json(result);
    } catch (error) {
      if (
        sendCaseAccessError(
          res,
          error
        )
      ) {
        return;
      }

      if (error instanceof MissingProviderCredentialError) {
        res.status(503).json({
          error: "PROVIDER_NOT_CONFIGURED",
          provider: error.provider
        });
        return;
      }

      if (
        sendProcessWorkflowError(
          res,
          error
        )
      ) {
        return;
      }

      if (
        sendCourtWorkflowError(
          res,
          error
        )
      ) {
        return;
      }

      if (
        sendChronologyWorkflowError(
          res,
          error
        )
      ) {
        return;
      }

      if (
        sendContractWorkflowError(
          res,
          error
        )
      ) {
        return;
      }

      if (sendOrderedWorkflowError(res, error)) {
        return;
      }

      if (
        error instanceof Error &&
        [
          "DOCUMENT_CITATION_SOURCE_CHANGED",
          "DOCUMENT_CITATION_SOURCE_UNAVAILABLE",
          "DOCUMENT_CITATION_REFRESH_AUTH_REQUIRED"
        ].includes(error.message)
      ) {
        res.status(409).json({
          error: error.message
        });
        return;
      }

      if (error instanceof ContextBudgetError) {
        res.status(422).json({
          error: error.message,
          ...error.details
        });
        return;
      }

      if (error instanceof Error && error.message === "DOCUMENT_NOT_REVIEWED") {
        // Shown to the user: open the document's preview and confirm it first.
        res.status(422).json({ error: "DOCUMENT_NOT_REVIEWED" });
        return;
      }

      if (
        error instanceof Error &&
        [
          "UNKNOWN_LOCAL_DOCUMENT",
          "DOCUMENT_NOT_FINALIZED",
          "INVALID_DOCUMENT_CHUNK_SELECTION",
          "UNKNOWN_DOCUMENT_CHUNK",
          "DOCUMENT_ATTACHMENT_CONTEXT_TOO_LARGE",
          "TOO_MANY_DOCUMENT_ATTACHMENTS"
        ].includes(error.message)
      ) {
        res.status(422).json({
          error:
            "DOCUMENT_ATTACHMENT_RESOLUTION_FAILED"
        });
        return;
      }

      if (sendAccountPolicyError(res, error)) {
        return;
      }

      const localFailureMessage =
        request.model.startsWith(
          "local/"
        )
          ? (
              error instanceof
                ProviderGatewayError &&
              error.causeValue instanceof
                Error
                ? error.causeValue
                    .message
                : error instanceof Error
                  ? error.message
                  : ""
            )
          : "";
      const parsedLocalFailureReason =
        localFailureMessage
          .split(
            ":",
            1
          )[0] ?? "";
      const localFailureReason =
        /^LOCAL_MODEL_[A-Z0-9_]+$/.test(
          parsedLocalFailureReason
        )
          ? parsedLocalFailureReason
          : "LOCAL_MODEL_INFERENCE_FAILED";
      if (
        request.model.startsWith(
          "local/"
        )
      ) {
        res.status(503).json({
          error:
            "LOCAL_MODEL_EXECUTION_FAILED",
          reason:
            localFailureReason,
          ...(localFailureMessage
            ? {
                description:
                  safeDiagnosticText(
                    localFailureMessage
                  )
              }
            : {})
        });
        return;
      }

      if (error instanceof ProviderGatewayError) {
        const rawReason =
          error.causeValue instanceof Error
            ? error.causeValue.message
            : "";
        const parsedReason =
          rawReason.split(
            ":",
            1
          )[0] ?? "";
        res.status(502).json({
          error: "PROVIDER_EXECUTION_FAILED",
          provider: error.provider,
          reason:
            /^[A-Z0-9_]+$/.test(
              parsedReason
            )
              ? parsedReason
              : "PROVIDER_UNCODED_FAILURE",
          ...(rawReason
            ? {
                description:
                  safeDiagnosticText(
                    rawReason
                  )
              }
            : {})
        });
        return;
      }

      if (
        error instanceof Error &&
        error.name ===
          "LexExecutionError"
      ) {
        const target =
          typeof (
            error as Error & {
              target?: unknown;
            }
          ).target === "string"
            ? (
                error as Error & {
                  target: string;
                }
              ).target
            : "UNKNOWN_LEGAL_WORKFLOW_GATE";
        const executionError =
          error as Error & {
            events?: Array<{
              sequence?: number;
              type?: string;
              target?: string;
              status?: string;
              detail?: string;
            }>;
          };
        res.status(422).json({
          error:
            "LEGAL_WORKFLOW_EXECUTION_FAILED",
          reason:
            target,
          stage:
            target,
          description:
            safeDiagnosticText(
              error
            ),
          trace:
            Array.isArray(
              executionError.events
            )
              ? executionError.events
                  .slice(-24)
                  .map((event) => ({
                    sequence:
                      event.sequence,
                    type:
                      event.type,
                    target:
                      event.target,
                    status:
                      event.status,
                    ...(event.detail
                      ? {
                          detail:
                            safeDiagnosticText(
                              event.detail
                            )
                        }
                      : {})
                  }))
              : []
        });
        return;
      }

      // The chat privacy gate is fail-closed: it blocks the turn when the
      // local pseudonymization pipeline cannot run. That is a named,
      // actionable condition, not an unknown server fault, so it must not
      // reach the client as a generic SESSION_EXECUTION_FAILED.
      if (
        error instanceof Error &&
        error.message ===
          "CHAT_PRIVACY_GATE_FAILED"
      ) {
        res.status(503).json({
          error:
            "CHAT_PRIVACY_GATE_FAILED",
          ...privacyGateReason(error)
        });
        return;
      }

      if (
        error instanceof Error &&
        error.message ===
          "WORKFLOW_AUDIT_STORE_UNAVAILABLE"
      ) {
        res.status(503).json({
          error:
            "WORKFLOW_AUDIT_UNAVAILABLE"
        });
        return;
      }

      // Every mapped failure above returns a specific code. Reaching here
      // means an unclassified error, and the client only ever sees
      // SESSION_EXECUTION_FAILED — without this there is no diagnostic
      // anywhere for an operator to work from. Name and message only: no
      // request body, no stack, nothing that could carry a credential.
      console.error(
        "SESSION_EXECUTION_FAILED",
        error instanceof Error
          ? `${error.name}: ${error.message}`
          : String(error)
      );
      res.status(500).json({
        error: "SESSION_EXECUTION_FAILED",
        description:
          safeDiagnosticText(
            error
          )
      });
    }
  });

  app.use((_req, res) => {
    res.status(404).json({
      error: "NOT_FOUND"
    });
  });
  app.use(jsonErrorHandler);

  return app;
}
