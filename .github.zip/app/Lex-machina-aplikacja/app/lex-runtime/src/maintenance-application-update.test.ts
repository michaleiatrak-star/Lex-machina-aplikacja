import fs from "node:fs";
import {
  createHash
} from "node:crypto";
import {
  afterEach,
  beforeEach,
  describe,
  expect,
  it,
  vi
} from "vitest";
import {
  MaintenanceService,
  applicationUpdateStagingRoot
} from "./maintenance-service.js";
import type {
  ApplicationInstallerVerifier
} from "./application-update-verifier.js";
import type {
  UpdateDiscovery
} from "./update-discovery.js";

afterEach(() => {
  fs.rmSync(
    applicationUpdateStagingRoot(),
    {
      recursive: true,
      force: true
    }
  );
});

describe(
  "application update release-to-installer version binding",
  () => {
    let original: PropertyDescriptor;
    beforeEach(() => {
      original = Object.getOwnPropertyDescriptor(process, "platform")!;
      Object.defineProperty(process, "platform", { value: "win32" });
    });
    afterEach(() => Object.defineProperty(process, "platform", original));
    it(
      "persists an explicit unsigned receipt when the temporary policy accepts SHA-256 + ProductVersion",
      async () => {
        const bytes =
          Buffer.from(
            "unsigned-installer-fixture",
            "utf8"
          );
        const digest =
          createHash("sha256")
            .update(bytes)
            .digest("hex");

        const discovery:
          UpdateDiscovery = {
            async check() {
              return {
                currentVersion:
                  "0.1.3",
                status:
                  "AVAILABLE",
                checkedAt:
                  "2026-09-18T10:05:00.000Z",
                latestVersion:
                  "0.1.4",
                installer: {
                  name:
                    "LexMachina-Windows-Online-Installer.exe",
                  url:
                    "https://github.com/michaleiatrak-star/Lex-Machina/releases/download/v0.1.4/LexMachina-Windows-Online-Installer.exe",
                  sha256:
                    digest,
                  bytes:
                    bytes.byteLength
                }
              };
            }
          };

        const fetchImpl =
          vi.fn(
            async () =>
              new Response(
                bytes,
                {
                  status: 200
                }
              )
          ) as unknown as
            typeof fetch;

        const verify =
          vi.fn(
            (
              _path: string,
              expectedVersion?: string
            ) => {
              expect(
                expectedVersion
              ).toBe("0.1.4");
              return {
                verification:
                  "UNSIGNED_ALLOWED" as const,
                subject: null,
                thumbprint: null,
                productVersion:
                  "0.1.4",
                warning:
                  "TEMPORARY_UNSIGNED_UPDATE_ALLOWED" as const
              };
            }
          );

        const installerVerifier:
          ApplicationInstallerVerifier = {
            verify
          };

        const maintenance =
          new MaintenanceService(
            discovery,
            fetchImpl,
            installerVerifier,
            () => false,
            () => {
              throw new Error(
                "UNUSED_SKILL_VERIFIER"
              );
            },
            () => false,
            () => {
              throw new Error(
                "UNUSED_MODEL_PACK_VERIFIER"
              );
            }
          );

        const result =
          await maintenance
            .downloadApplicationUpdate();

        expect(
          result.publisher
        ).toEqual({
          verification:
            "UNSIGNED_ALLOWED",
          subject: null,
          thumbprint: null,
          productVersion:
            "0.1.4",
          warning:
            "TEMPORARY_UNSIGNED_UPDATE_ALLOWED"
        });

        const receipt =
          JSON.parse(
            fs.readFileSync(
              applicationUpdateStagingRoot() +
                "/" +
                result.receiptToken,
              "utf8"
            )
          ) as {
            sha256?: unknown;
            version?: unknown;
            publisher?: {
              verification?: unknown;
              productVersion?: unknown;
              warning?: unknown;
            };
          };

        expect(
          receipt.sha256
        ).toBe(digest);
        expect(
          receipt.version
        ).toBe("0.1.4");
        expect(
          receipt.publisher
            ?.verification
        ).toBe(
          "UNSIGNED_ALLOWED"
        );
        expect(
          receipt.publisher
            ?.productVersion
        ).toBe("0.1.4");
        expect(
          receipt.publisher
            ?.warning
        ).toBe(
          "TEMPORARY_UNSIGNED_UPDATE_ALLOWED"
        );
      }
    );

    it(
      "passes the discovered release version to Authenticode verification and persists the verified ProductVersion",
      async () => {
        const bytes =
          Buffer.from(
            "signed-installer-fixture",
            "utf8"
          );
        const digest =
          createHash("sha256")
            .update(bytes)
            .digest("hex");

        const discovery:
          UpdateDiscovery = {
            async check() {
              return {
                currentVersion:
                  "0.1.3",
                status:
                  "AVAILABLE",
                checkedAt:
                  "2026-09-18T10:00:00.000Z",
                latestVersion:
                  "0.1.4",
                installer: {
                  name:
                    "LexMachina-Windows-Online-Installer.exe",
                  url:
                    "https://github.com/michaleiatrak-star/Lex-Machina/releases/download/v0.1.4/LexMachina-Windows-Online-Installer.exe",
                  sha256:
                    digest,
                  bytes:
                    bytes.byteLength
                }
              };
            }
          };

        const fetchImpl =
          vi.fn(
            async () =>
              new Response(
                bytes,
                {
                  status: 200
                }
              )
          ) as unknown as
            typeof fetch;

        const verify =
          vi.fn(
            (
              _path: string,
              expectedVersion?: string
            ) => {
              expect(
                expectedVersion
              ).toBe("0.1.4");
              return {
                verification:
                  "AUTHENTICODE" as const,
                subject:
                  "CN=Lex Machina Test",
                thumbprint:
                  "A".repeat(40),
                productVersion:
                  "0.1.4"
              };
            }
          );

        const installerVerifier:
          ApplicationInstallerVerifier = {
            verify
          };

        const maintenance =
          new MaintenanceService(
            discovery,
            fetchImpl,
            installerVerifier,
            () => false,
            () => {
              throw new Error(
                "UNUSED_SKILL_VERIFIER"
              );
            },
            () => false,
            () => {
              throw new Error(
                "UNUSED_MODEL_PACK_VERIFIER"
              );
            }
          );

        const result =
          await maintenance
            .downloadApplicationUpdate();

        expect(verify)
          .toHaveBeenCalledTimes(1);
        expect(
          result.version
        ).toBe("0.1.4");
        expect(
          result.publisher
            .productVersion
        ).toBe("0.1.4");

        const receipt =
          JSON.parse(
            fs.readFileSync(
              applicationUpdateStagingRoot() +
                "/" +
                result.receiptToken,
              "utf8"
            )
          ) as {
            version?: unknown;
            publisher?: {
              productVersion?: unknown;
            };
          };

        expect(
          receipt.version
        ).toBe("0.1.4");
        expect(
          receipt.publisher
            ?.productVersion
        ).toBe("0.1.4");
      }
    );

    it(
      "skips the download when no signer is trusted (manual install from the release page)",
      async () => {
        const discovery:
          UpdateDiscovery = {
            async check() {
              return {
                currentVersion: "0.1.25",
                status: "AVAILABLE",
                checkedAt: "2026-10-10T08:00:00.000Z",
                latestVersion: "0.1.26",
                releaseUrl:
                  "https://github.com/michaleiatrak-star/Lex-machina-aplikacja/releases/tag/v0.1.26",
                installer: {
                  name: "Lex-Machina-0.1.26-Online-x64-Setup.exe",
                  url:
                    "https://github.com/michaleiatrak-star/Lex-machina-aplikacja/releases/download/v0.1.26/Lex-Machina-0.1.26-Online-x64-Setup.exe",
                  sha256: "a".repeat(64)
                }
              };
            }
          };
        const fetchImpl =
          vi.fn() as unknown as typeof fetch;
        const verify = vi.fn();
        const maintenance =
          new MaintenanceService(
            discovery,
            fetchImpl,
            { verify, ready: () => false },
            () => false,
            () => {
              throw new Error("UNUSED_SKILL_VERIFIER");
            },
            () => false,
            () => {
              throw new Error("UNUSED_MODEL_PACK_VERIFIER");
            }
          );

        await expect(
          maintenance.downloadApplicationUpdate()
        ).rejects.toThrow(
          "APPLICATION_UPDATE_MANUAL_INSTALL_REQUIRED"
        );
        expect(fetchImpl).not.toHaveBeenCalled();
        expect(verify).not.toHaveBeenCalled();
      }
    );
  }
);

describe("aktualizacja na macOS: zweryfikowany .pkg zamiast instrukcji ręcznej", () => {
  it("pobiera .pkg, sprawdza SHA-256 i zapisuje paragon z nazwą pliku .pkg", async () => {
    const platform = Object.getOwnPropertyDescriptor(process, "platform")!;
    Object.defineProperty(process, "platform", { value: "darwin" });
    try {
      const bytes = Buffer.from("pkg-fixture", "utf8");
      const digest = createHash("sha256").update(bytes).digest("hex");
      const discovery: UpdateDiscovery = {
        async check() {
          return {
            currentVersion: "0.1.46",
            status: "AVAILABLE",
            checkedAt: "2026-10-24T08:00:00.000Z",
            latestVersion: "0.1.47",
            installer: {
              name: "Lex-Machina-0.1.47-macOS-arm64.pkg",
              url: "https://github.com/michaleiatrak-star/Lex-machina-aplikacja/releases/download/v0.1.47/Lex-Machina-0.1.47-macOS-arm64.pkg",
              sha256: digest,
              bytes: bytes.byteLength
            }
          };
        }
      };
      const verify = vi.fn();
      const maintenance = new MaintenanceService(
        discovery,
        vi.fn(async () => new Response(bytes, { status: 200 })) as unknown as typeof fetch,
        { verify, ready: () => false },
        () => false,
        () => {
          throw new Error("UNUSED_SKILL_VERIFIER");
        },
        () => false,
        () => {
          throw new Error("UNUSED_MODEL_PACK_VERIFIER");
        }
      );
      const result = await maintenance.downloadApplicationUpdate();
      expect(result.token).toMatch(/^update_0-1-47_[a-f0-9]{16}\.pkg$/u);
      expect(result.receiptToken).toBe(result.token.replace(/\.pkg$/u, ".json"));
      expect(verify).not.toHaveBeenCalled();
      const receipt = JSON.parse(fs.readFileSync(`${applicationUpdateStagingRoot()}/${result.receiptToken}`, "utf8"));
      expect(receipt).toMatchObject({ installerToken: result.token, sha256: digest, version: "0.1.47" });
      expect(fs.readFileSync(`${applicationUpdateStagingRoot()}/${result.token}`)).toEqual(bytes);
    } finally {
      Object.defineProperty(process, "platform", platform);
    }
  });
});
