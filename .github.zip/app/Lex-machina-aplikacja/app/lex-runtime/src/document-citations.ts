import type {
  SessionDocumentAttachment
} from "./session-executor.js";
import { CASE_MATERIAL_MARKER_TEXT } from "./finalization-gate.js";

export type PublicDocumentCitation = {
  citationId: string;
  marker: string;
  label: string;
  caseId?: string;
  documentId: string;
  chunkIndex: number;
  pageStart: number;
  pageEnd: number;
  contextText: string;
  quote?: string;
  // EXACT: the quote is in the document (whitespace, typography, case and [...] elisions
  // folded); NOT_FOUND: it is not, shown with QUOTE_MISMATCH_MARKER; DIGEST_UNCHECKED: only
  // an extractive digest of the passage was available, so the wording could not be checked.
  quoteFidelity?: "EXACT" | "NOT_FOUND" | "DIGEST_UNCHECKED";
  highlightStart?: number;
  highlightEnd?: number;
};

export type ProcessedDocumentCitations = {
  text: string;
  citations: PublicDocumentCitation[];
  rejectedMarkers: number;
  quoteFindings: {
    // A quote without a marker found verbatim in a case document: linked by the application.
    autoLinked: number;
    // A linked quote whose wording is not in the document.
    mismatched: number;
    // A quote attributed to a pleading or case document, without a marker, found nowhere.
    unsourced: number;
  };
};

export const QUOTE_MISMATCH_MARKER = "⚠️ [CYTAT NIEZGODNY Z DOKUMENTEM]";
export const QUOTE_UNSOURCED_MARKER = "⚠️ [CYTAT NIEODNALEZIONY W AKTACH]";

const MARKER = /\[\[LEXDOC:([^:\]\r\n]{1,180}):(\d{1,7})\]\]/g;
const MAX_QUOTE_SCAN = 4_500;

function quoteBefore(text: string, markerStart: number): string | undefined {
  // "*„…”* [[LEXDOC…]]": emphasis around the quote and a space before the marker.
  const window = text.slice(
    Math.max(0, markerStart - MAX_QUOTE_SCAN),
    markerStart
  ).trimEnd().replace(/[*_]+$/u, "");

  const candidates = [
    /„([^„”]{2,4000})”\s*$/s,
    /“([^“”]{2,4000})”\s*$/s,
    /"([^"\r\n]{2,4000})"\s*$/s,
    /'([^'\r\n]{2,4000})'\s*$/s
  ];
  for (const pattern of candidates) {
    const match = window.match(pattern);
    const quote = match?.[1]?.trim();
    if (quote) return quote;
  }
  return undefined;
}

// Folds only what does not change the wording: whitespace, line-break hyphenation, dashes,
// quotation-mark style and letter case. Never fuzzy matching: a changed word is a mismatch.
function fold(text: string): { text: string; map: number[] } {
  let out = "";
  const map: number[] = [];
  for (let i = 0; i < text.length; i += 1) {
    const ch = text[i]!;
    if (ch === "\u00AD") continue;
    if (/[-‐‑‒–—−]/u.test(ch)) {
      // "praco-\nwnik" is "pracownik"; other dashes are dropped on both sides.
      if (/^.[ \t]*\r?\n/u.test(text.slice(i, i + 6))) {
        while (i + 1 < text.length && /\s/u.test(text[i + 1]!)) i += 1;
      }
      continue;
    }
    let folded: string;
    if (/\s/u.test(ch)) {
      if (out === "" || out.endsWith(" ")) continue;
      folded = " ";
    } else if (/[„“”"«»]/u.test(ch)) folded = "\"";
    else if (/[‚‘’'`]/u.test(ch)) folded = "'";
    else if (ch === "…") folded = "...";
    else {
      const lower = ch.toLowerCase();
      folded = lower.length === 1 ? lower : ch;
    }
    for (const part of folded) {
      out += part;
      map.push(i);
    }
  }
  return { text: out, map };
}

const ELISION = /\s*(?:\[\s*(?:\.{3}|…)\s*\]|\(\s*(?:\.{3}|…)\s*\)|\.{3}|…)\s*/u;

function quoteSegments(quote: string): string[] {
  return quote
    .split(ELISION)
    .map((segment) => fold(segment).text.trim().replace(/^[\s.,;:!?]+|[\s.,;:!?]+$/gu, ""))
    .filter((segment) => segment.length >= 3);
}

// An editorial ending in brackets ("Członk[ów] Zarządu", "poczt[y] tradycyjn[ej]", RD 121/26):
// that word may differ in its ending from the source; its stem and every other word may not.
const ADAPTED_WORD = /(\p{L}*)\[(\p{L}{1,6})\](\p{L}*)/gu;

function locateAdaptedQuote(contextText: string, quote: string): { start: number; end: number } | undefined {
  const words = fold(quote.replace(new RegExp(ELISION.source, "gu"), " ")).text.trim().split(" ").filter(Boolean);
  let adapted = 0;
  const pattern = words.map((word) => {
    ADAPTED_WORD.lastIndex = 0;
    const match = ADAPTED_WORD.exec(word);
    if (!match) return word.replace(/[.*+?^${}()|[\]\\]/gu, "\\$&");
    adapted += 1;
    const stem = match[1]!.slice(0, Math.max(3, match[1]!.length - 2));
    const escape = (part: string) => part.replace(/[.*+?^${}()|[\]\\]/gu, "\\$&");
    return `${escape(word.slice(0, match.index))}${escape(stem)}\\p{L}*${escape(word.slice(match.index + match[0].length))}`;
  });
  // Only an adapted quote, and never one made mostly of adapted words.
  if (adapted === 0 || words.length - adapted < 2) return undefined;
  const source = fold(contextText);
  const found = new RegExp(pattern.join(" "), "u").exec(source.text);
  return found ? { start: source.map[found.index]!, end: source.map[found.index + found[0].length - 1]! + 1 } : undefined;
}

// Every segment of the quote ("a [...] b" is two) in the document, in order.
function locateQuote(
  contextText: string,
  quote: string | undefined
): { start: number; end: number } | undefined {
  if (!quote) return undefined;
  if (/\[\p{L}{1,6}\]/u.test(quote)) {
    const adapted = locateAdaptedQuote(contextText, quote);
    if (adapted) return adapted;
  }
  const segments = quoteSegments(quote);
  if (segments.length === 0) return undefined;
  const source = fold(contextText);
  let from = 0;
  let start = -1;
  let end = -1;
  for (const segment of segments) {
    const at = source.text.indexOf(segment, from);
    if (at < 0) return undefined;
    if (start < 0) start = at;
    end = at + segment.length;
    from = end;
  }
  return { start: source.map[start]!, end: source.map[end - 1]! + 1 };
}

function textContainsQuote(text: string, quote: string): boolean {
  return locateQuote(text, quote) !== undefined;
}

// Where a quote comes from, not whether it is verbatim: a passage put into the sentence's case
// ("o pozwie „spełniającym przesłanki…”" from "od pozwu spełniającego przesłanki…", live C13-039)
// is still that source's text. Each word keeps its stem; only the ending may differ.
function words(text: string): string[] {
  return text.toLocaleLowerCase("pl").match(/[\p{L}\p{N}]+/gu) ?? [];
}

function sameStem(left: string, right: string): boolean {
  if (left === right) return true;
  const shorter = Math.min(left.length, right.length);
  if (shorter < 4 || Math.abs(left.length - right.length) > 3) return false;
  let common = 0;
  while (common < shorter && left[common] === right[common]) common += 1;
  return common >= Math.max(3, Math.max(left.length, right.length) - 3);
}

function textContainsInflectedQuote(text: string, quote: string): boolean {
  if (textContainsQuote(text, quote)) return true;
  return quoteSegments(quote).every((segment) => {
    const wanted = words(segment);
    if (wanted.length < 4) return false;
    const source = words(text);
    for (let at = 0; at + wanted.length <= source.length; at += 1) {
      if (wanted.every((word, index) => sameStem(word, source[at + index]!))) return true;
    }
    return false;
  });
}

type ChunkEntry = {
  attachment: SessionDocumentAttachment;
  chunk: SessionDocumentAttachment["chunks"][number];
};

function findQuoteChunk(
  entries: ChunkEntry[],
  quote: string,
  preferDocumentId?: string
): { entry: ChunkEntry; location: { start: number; end: number } } | undefined {
  const ordered = preferDocumentId
    ? [
        ...entries.filter((entry) => entry.attachment.documentId === preferDocumentId),
        ...entries.filter((entry) => entry.attachment.documentId !== preferDocumentId)
      ]
    : entries;
  for (const entry of ordered) {
    const location = locateQuote(entry.chunk.text, quote);
    if (location) return { entry, location };
  }
  return undefined;
}

// A quote the answer attributes to a pleading, a letter or another case document.
const DOCUMENT_ATTRIBUTION =
  /(?:pozw\p{L}*|pism\p{L}*|apelacj\p{L}*|zażaleni\p{L}*|sprzeciw\p{L}*|skarg\p{L}*|wnios\p{L}*|umow\p{L}*|aneks\p{L}*|zaskarżon\p{L}*|protok\p{L}*|wezwani\p{L}*|notatk\p{L}*|e-?mail\p{L}*|korespondencj\p{L}*|regulamin\p{L}*|dokument\p{L}*|załącznik\p{L}*|przeciwn\p{L}*|powod\p{L}*|powód|pełnomocnik\p{L}*|oskarżon\p{L}*|uczestnik\p{L}*|wierzyciel\p{L}*|dłużni\p{L}*|kontrahent\p{L}*|klient\p{L}*)/giu;
// The wording of a statute or a judgment's thesis: checked by the provision and case-law gates.
const NON_DOCUMENT_SOURCE =
  /(?:\bart\.|§|\bstanowi\p{L}*|\bbrzmi\p{L}*|\bprzepis\p{L}*|\bustaw\p{L}*|\bkodeks\p{L}*|\bDz\.\s?U|\bteza\p{L}*|\bSN\b|\bNSA\b|\bTK\b|\bTSUE\b|\bSąd Najwyższy)/giu;
// Typographic quotes only: straight "…" are JSON strings and code as often as quotations.
const UNMARKED_QUOTE = /„([^„”\r\n]{20,1500})”|“([^“”\r\n]{20,1500})”/gu;

function lastMatchEnd(pattern: RegExp, text: string): number {
  let last = -1;
  pattern.lastIndex = 0;
  let match: RegExpExecArray | null;
  while ((match = pattern.exec(text)) !== null) last = match.index + match[0].length;
  return last;
}

function attributedToDocument(text: string, quoteStart: number): boolean {
  const paragraphStart = Math.max(text.lastIndexOf("\n\n", quoteStart), quoteStart - 300, 0);
  const before = text.slice(paragraphStart, quoteStart);
  const attribution = lastMatchEnd(DOCUMENT_ATTRIBUTION, before);
  if (attribution < 0) return false;
  // "pozwany powołuje art. 6 k.c., który stanowi: „…”": the nearer cue decides.
  return lastMatchEnd(NON_DOCUMENT_SOURCE, before) < attribution;
}

// "VIII W 633/25 ⚠️ [NIEWERYFIKOWANE: z materiałów sprawy]": the signature is in the case's
// documents, so the marker gets the passage that names it, shown and highlighted like a quote
// (RD 121/26: the user saw "z materiałów sprawy" without which document or where).
const SIGNATURE_BEFORE = /((?:sygn\.?\s*(?:akt\s*)?:?\s*)?(?:[A-ZĄĆĘŁŃÓŚŹŻ]{1,8}\s+){1,4}\d+\/\d{2,4})\s*$/u;

function linkCaseMaterialSignatures(text: string, entries: ChunkEntry[]): string {
  if (!entries.length || !text.includes(CASE_MATERIAL_MARKER_TEXT)) return text;
  let output = "";
  let cursor = 0;
  for (let at = text.indexOf(CASE_MATERIAL_MARKER_TEXT); at >= 0; at = text.indexOf(CASE_MATERIAL_MARKER_TEXT, at + 1)) {
    const end = at + CASE_MATERIAL_MARKER_TEXT.length;
    if (/^\s*\[\[LEXDOC:/u.test(text.slice(end, end + 12))) continue;
    const signature = SIGNATURE_BEFORE.exec(text.slice(Math.max(0, at - 60), at))?.[1]?.replace(/^sygn\.?\s*(?:akt\s*)?:?\s*/iu, "");
    if (!signature) continue;
    const pattern = new RegExp(`(?<![\\p{L}\\d])${signature.trim().replace(/[.*+?^${}()|[\]\\]/gu, "\\$&").replace(/\s+/gu, "\\s*")}(?![\\d])`, "iu");
    const found = entries.find((entry) => pattern.test(entry.chunk.text));
    if (!found) continue;
    output += text.slice(cursor, end) + ` [[LEXDOC:${found.attachment.documentId}:${found.chunk.index}]]`;
    cursor = end;
  }
  return output + text.slice(cursor);
}

// Quotes without a marker: linked when found in a case document; flagged when attributed to
// a document yet found neither there nor in the thread or the case law read in this turn.
function linkUnmarkedQuotes(
  text: string,
  entries: ChunkEntry[],
  otherTexts: string[]
): { text: string; autoLinked: number; unsourced: number } {
  // A structured result (the document AST) is not prose: quotes in it are not touched.
  if (/^\s*[{[]/u.test(text)) return { text, autoLinked: 0, unsourced: 0 };
  let output = "";
  let cursor = 0;
  let autoLinked = 0;
  let unsourced = 0;
  UNMARKED_QUOTE.lastIndex = 0;
  let match: RegExpExecArray | null;
  const fences = [...text.matchAll(/^```[^\n]*\n[\s\S]*?^```/gmu)]
    .map((fence) => ({ start: fence.index, end: fence.index + fence[0].length }));
  while ((match = UNMARKED_QUOTE.exec(text)) !== null) {
    const quote = (match[1] ?? match[2] ?? "").trim();
    const end = match.index + match[0].length;
    if (fences.some((fence) => match!.index >= fence.start && match!.index < fence.end)) continue;
    if (/^[*_]*\s*\[\[LEXDOC:/u.test(text.slice(end, end + 16))) continue;
    if (quote.split(/\s+/u).length < 4) continue;
    const found = entries.length ? findQuoteChunk(entries, quote) : undefined;
    if (found) {
      output += text.slice(cursor, end) + `[[LEXDOC:${found.entry.attachment.documentId}:${found.entry.chunk.index}]]`;
      cursor = end;
      autoLinked += 1;
      continue;
    }
    if (!attributedToDocument(text, match.index)) continue;
    // "Czy dostała Pani też decyzję, że „nie podlega Pani ubezpieczeniom”?": a question to the
    // user about a document's wording, not a quote from it (live C12-027). A quote given after
    // a colon ("pozwany napisał: „…”, prawda?") is still presented as the document's text.
    if (/^[^.!\n]*\?/u.test(text.slice(end, end + 200)) && !/:\s*[*_]*$/u.test(text.slice(Math.max(0, match.index - 4), match.index))) continue;
    if (otherTexts.some((other) => textContainsInflectedQuote(other, quote))) continue;
    // A digest shows the passage shortened: the quote may be in the full text.
    if (entries.some((entry) => entry.chunk.representation === "EXTRACTIVE_DIGEST")) continue;
    output += text.slice(cursor, end) + ` ${QUOTE_UNSOURCED_MARKER}`;
    cursor = end;
    unsourced += 1;
  }
  return { text: output + text.slice(cursor), autoLinked, unsourced };
}

export function documentCitationSystemPrompt(
  attachments: SessionDocumentAttachment[]
): string {
  if (attachments.length === 0) return "";
  return [
    "# LOCAL DOCUMENT CITATION PROTOCOL",
    "When you quote or closely rely on an attached local document, cite the exact chunk immediately after the relevant sentence or quotation using this internal marker:",
    "[[LEXDOC:<documentId>:<chunkIndex>]]",
    "Use only documentId and chunkIndex values present in LOCAL_DOCUMENT_CONTEXT.",
    "Never invent a document id, page, chunk, quote, or marker.",
    "For a verbatim quotation, place the marker immediately after the closing quotation mark so the application can validate and highlight the exact passage.",
    "Quote a pleading, a letter or any case document word for word; mark omissions with [...]. A quotation not found in the document is shown to the user as not matching it.",
    "Markers are machine-readable metadata and will be replaced by clickable in-chat citations before presentation."
  ].join("\n");
}

export function processDocumentCitationMarkers(
  modelText: string,
  attachments: SessionDocumentAttachment[],
  options: {
    // Texts a quote may legitimately come from without a case document link: the thread
    // (the user's own words, earlier answers), case law and statute wording read in this turn.
    otherTexts?: string[];
  } = {}
): ProcessedDocumentCitations {
  const chunks = new Map<string, ChunkEntry>();
  for (const attachment of attachments) {
    for (const chunk of attachment.chunks) {
      chunks.set(`${attachment.documentId}:${chunk.index}`, {
        attachment,
        chunk
      });
    }
  }
  const entries = [...chunks.values()];
  const linked = linkUnmarkedQuotes(linkCaseMaterialSignatures(modelText, entries), entries, options.otherTexts ?? []);
  const text = linked.text;
  let mismatched = 0;

  const citations: PublicDocumentCitation[] = [];
  let rejectedMarkers = 0;
  let output = "";
  let cursor = 0;
  let match: RegExpExecArray | null;
  MARKER.lastIndex = 0;

  while ((match = MARKER.exec(text)) !== null) {
    output += text.slice(cursor, match.index);
    const documentId = match[1] ?? "";
    const chunkIndex = Number(match[2]);
    const cited = chunks.get(`${documentId}:${chunkIndex}`);
    if (!cited || !Number.isInteger(chunkIndex)) {
      rejectedMarkers += 1;
      cursor = match.index + match[0].length;
      continue;
    }

    const citationId = `docref_${citations.length + 1}`;
    const marker = `[[LEXDOCREF:${citationId}]]`;
    const quote = quoteBefore(text, match.index);
    let resolved = cited;
    let location = locateQuote(cited.chunk.text, quote);
    if (quote && !location) {
      // Cited the wrong chunk: the link goes where the words actually are.
      const elsewhere = findQuoteChunk(entries, quote, documentId);
      if (elsewhere) {
        resolved = elsewhere.entry;
        location = elsewhere.location;
      }
    }
    // A case-material signature's link highlights the signature itself in the passage.
    const before = text.slice(Math.max(0, match.index - 80), match.index).trimEnd();
    const signature = !quote && before.endsWith(CASE_MATERIAL_MARKER_TEXT)
      ? SIGNATURE_BEFORE.exec(before.slice(0, -CASE_MATERIAL_MARKER_TEXT.length).trimEnd())?.[1]?.replace(/^sygn\.?\s*(?:akt\s*)?:?\s*/iu, "")
      : undefined;
    if (signature && !location) location = locateQuote(resolved.chunk.text, signature);
    const quoteFidelity = !quote
      ? undefined
      : location
        ? "EXACT" as const
        : cited.chunk.representation === "EXTRACTIVE_DIGEST"
          ? "DIGEST_UNCHECKED" as const
          : "NOT_FOUND" as const;
    if (quoteFidelity === "NOT_FOUND") mismatched += 1;
    const pageLabel = resolved.chunk.pageStart === resolved.chunk.pageEnd
      ? `s. ${resolved.chunk.pageStart}`
      : `s. ${resolved.chunk.pageStart}–${resolved.chunk.pageEnd}`;
    const citation: PublicDocumentCitation = {
      citationId,
      marker,
      label: `Dokument ${citations.length + 1}, ${pageLabel}`,
      ...(resolved.attachment.caseId
        ? { caseId: resolved.attachment.caseId }
        : {}),
      documentId: resolved.attachment.documentId,
      chunkIndex: resolved.chunk.index,
      pageStart: resolved.chunk.pageStart,
      pageEnd: resolved.chunk.pageEnd,
      contextText: resolved.chunk.text,
      ...(quote ? { quote } : {}),
      ...(quoteFidelity ? { quoteFidelity } : {}),
      ...(location
        ? {
            highlightStart: location.start,
            highlightEnd: location.end
          }
        : {})
    };
    citations.push(citation);
    output += quoteFidelity === "NOT_FOUND" ? `${marker} ${QUOTE_MISMATCH_MARKER}` : marker;
    cursor = match.index + match[0].length;
  }

  output += text.slice(cursor);
  return {
    text: output,
    citations,
    rejectedMarkers,
    quoteFindings: {
      autoLinked: linked.autoLinked,
      mismatched,
      unsourced: linked.unsourced
    }
  };
}
