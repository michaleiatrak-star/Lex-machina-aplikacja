import { ARTICLE_LEAD, compactActAbbreviations } from "./legal-act-abbreviations.js";

export type DomainLockReport = {
  gate: "G39I_DOMAIN_LOCK";
  result: "PASS" | "BLOCKED";
  criminalDomainLoaded: boolean;
  criminalLegalReferences: string[];
  unsupportedCriminalSignals: string[];
};

export type RateCompletenessReport = {
  gate:
    "G39I_RATE_COMPLETENESS";
  result:
    "PASS" | "BLOCKED";
  triggered: boolean;
  numericRateLines: number;
  unverifiedNumericRateLines: number;
  aggregateClaim: boolean;
  hasExplicitInterval: boolean;
  hasSeriesTable: boolean;
  missing: string[];
};

// Na tekście po compactActAbbreviations: "art. 148 k.k." -> "art. 148 KK".
const CRIMINAL_REFERENCE =
  new RegExp(
    `${ARTICLE_LEAD}\\d+[a-ząćęłńóśźż]*(?:\\s*§\\s*\\d+[a-z]*)?\\s+(?:KK|KPK|KKS|KKW|KW|KPW)\\b`,
    "giu"
  );
const HIGH_RISK_CRIMINAL_SIGNAL =
  /\b(?:zawiadomieni[ae]\s+o\s+(?:możliwości\s+)?popełnieni[ua]\s+przestępstwa|odpowiedzialność\s+karna|kwalifikacja\s+karna)\b/giu;

function unique(
  values: string[]
): string[] {
  return [
    ...new Set(
      values.map(
        (value) =>
          value.trim()
      )
        .filter(Boolean)
    )
  ];
}

export function evaluateDomainLock(args: {
  text: string;
  loadedSkills:
    readonly string[];
}): DomainLockReport {
  const criminalDomainLoaded =
    args.loadedSkills.some(
      (skill) =>
        skill.startsWith(
          "dr-03-"
        )
    );
  const criminalLegalReferences =
    unique(
      [
        ...compactActAbbreviations(
          args.text
        ).matchAll(
          CRIMINAL_REFERENCE
        )
      ].map(
        (match) =>
          match[0] ?? ""
      )
    );
  const unsupportedCriminalSignals =
    unique(
      [
        ...args.text.matchAll(
          HIGH_RISK_CRIMINAL_SIGNAL
        )
      ].map(
        (match) =>
          match[0] ?? ""
      )
    );

  const contamination =
    !criminalDomainLoaded &&
    (
      criminalLegalReferences.length >
        0 ||
      unsupportedCriminalSignals
        .length > 0
    );

  return {
    gate:
      "G39I_DOMAIN_LOCK",
    result:
      contamination
        ? "BLOCKED"
        : "PASS",
    criminalDomainLoaded,
    criminalLegalReferences,
    unsupportedCriminalSignals
  };
}

const RATE_TOPIC =
  /\b(?:odsetk\w*|waloryzac\w*|inflacj\w*|minimaln\w*\s+wynagrodzen\w*|przeciętn\w*\s+wynagrodzen\w*|rekompensat\w*\s+za\s+koszty\s+odzyskiwania\s+należności)\b/iu;
// Granice słowa przez \p{L}: JS-owe \b jest tylko ASCII, więc po "%" i "zł" oraz
// przed "ł" nigdy nie pasowało.
const NUMERIC_RATE =
  /(?:\b\d{1,3}(?:[.,]\d{1,4})?\s*%(?![\p{L}\d])|\b\d{1,3}(?:[ .]\d{3})*(?:[.,]\d{1,2})?\s*(?:zł(?:ot\p{L}*)?|PLN)(?![\p{L}\d]))/iu;
const VERIFIED_OR_GAP =
  /(?:✅\s*\[VER:|⚠️?\s*\[NIEWERYFIKOWANE(?::[^\]\r\n]*)?\]|🟨\s*\[KOTWICA-URZĘDOWA|⬛\s*\[(?:DO UZUPEŁNIENIA|UZUPEŁNIJ))/iu;
const AGGREGATE =
  /(?<![\p{L}\d])(?:łącznie|suma|kwota\s+łączna|razem\s+do\s+zapłaty|należność\s+łącznie)(?![\p{L}\d])/iu;
const EXPLICIT_INTERVAL =
  /\b(?:od\s+\d{1,4}[-./]\d{1,2}[-./]\d{1,4}\s+do\s+\d{1,4}[-./]\d{1,2}[-./]\d{1,4}|przedział\s*[:=-]\s*\d{1,4}[-./]\d{1,2}[-./]\d{1,4}\s*(?:–|-|do)\s*\d{1,4}[-./]\d{1,2}[-./]\d{1,4})\b/iu;
const SERIES_HEADER =
  /\|\s*Od\s*\|\s*Do\s*\|\s*Stawka\s*\|/iu;

export function evaluateRateCompleteness(
  text: string
): RateCompletenessReport {
  const triggered =
    RATE_TOPIC.test(text);
  if (!triggered) {
    return {
      gate:
        "G39I_RATE_COMPLETENESS",
      result: "PASS",
      triggered: false,
      numericRateLines: 0,
      unverifiedNumericRateLines: 0,
      aggregateClaim: false,
      hasExplicitInterval: false,
      hasSeriesTable: false,
      missing: []
    };
  }

  const lines =
    text.split(/\r?\n/u);
  const numericLines =
    lines.filter(
      (line) =>
        RATE_TOPIC.test(line) &&
        NUMERIC_RATE.test(line)
    );
  const unverified =
    numericLines.filter(
      (line) =>
        !VERIFIED_OR_GAP.test(
          line
        )
    );
  const aggregateClaim =
    AGGREGATE.test(text) &&
    (
      NUMERIC_RATE.test(text) ||
      /\b\d+(?:[.,]\d+)?\s*(?:zł(?:ot\p{L}*)?|PLN)(?![\p{L}\d])/iu.test(
        text
      )
    );
  const hasExplicitInterval =
    EXPLICIT_INTERVAL.test(
      text
    );
  const hasSeriesTable =
    SERIES_HEADER.test(text);
  const missing:
    string[] = [];

  if (
    numericLines.length > 0 &&
    unverified.length > 0
  ) {
    missing.push(
      "RATE_LINE_VERIFICATION_MARKER"
    );
  }
  if (
    aggregateClaim &&
    !hasExplicitInterval
  ) {
    missing.push(
      "RATE_INTERVAL"
    );
  }
  if (
    aggregateClaim &&
    !hasSeriesTable
  ) {
    missing.push(
      "RATE_SERIES_TABLE"
    );
  }

  return {
    gate:
      "G39I_RATE_COMPLETENESS",
    result:
      missing.length === 0
        ? "PASS"
        : "BLOCKED",
    triggered,
    numericRateLines:
      numericLines.length,
    unverifiedNumericRateLines:
      unverified.length,
    aggregateClaim,
    hasExplicitInterval,
    hasSeriesTable,
    missing
  };
}
