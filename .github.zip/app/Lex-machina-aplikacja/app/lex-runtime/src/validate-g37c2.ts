import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here =
  path.dirname(
    fileURLToPath(import.meta.url)
  );
const repoRoot =
  path.resolve(
    here,
    "../../.."
  );

function read(relative: string): string {
  return fs.readFileSync(
    path.join(repoRoot, relative),
    "utf8"
  );
}

const trust =
  read(
    "app/lex-desktop/src-tauri/src/trust_boundary.rs"
  );
const webApi =
  read(
    "app/lex-web/src/api.ts"
  );
const runtimeCredentials =
  read(
    "app/lex-runtime/src/providers/credentials.ts"
  );
const desktopLib =
  read(
    "app/lex-desktop/src-tauri/src/lib.rs"
  );
const webApp =
  read(
    "app/lex-web/src/ChatApp.tsx"
  );
const normalizedWebApp =
  webApp.replace(/\s+/g, " ");
const webApiClient =
  read(
    "app/lex-web/src/api.ts"
  );

const checks = {
  osKeyringService:
    trust.includes(
      'const PROVIDER_KEYRING_SERVICE: &str = "LexMachina/ProviderCredential"'
    ) &&
    trust.includes(
      'const ACCOUNT_OAUTH_KEYRING_SERVICE: &str = "LexMachina/AccountOAuthCredential"'
    ) &&
    trust.includes(
      "Entry::new("
    ),
  restoreOnEveryAuthenticatedSession:
    desktopLib.includes(
      ".ensure_managed_identity()"
    ) &&
    // Restored at every managed sign-in; a Keychain error no longer stops the app
    // (macOS, ad-hoc signed updates), it is logged and the key entered again.
    trust.includes(
      "if let Err(error) = self.restore_provider_credentials() {"
    ) &&
    trust.includes(
      "let _ = self.restore_provider_credentials();"
    ),
  restoreDoesNotDropTheStoredCredential:
    trust.includes(
      '"persistence": "OS_KEYRING"'
    ),
  restoreIntoMemoryOnlyRuntime:
    trust.includes(
      '"/api/admin/providers/{provider}/credential"'
    ) &&
    runtimeCredentials.includes(
      "class MemoryOverlayCredentialResolver"
    ),
  claudeOAuthRestoredSeparately:
    trust.includes(
      '"/api/admin/provider-accounts/anthropic/oauth-token"'
    ) &&
    trust.includes(
      "restore_account_oauth_body"
    ) &&
    trust.includes(
      "persist_account_oauth_credential"
    ) &&
    trust.includes(
      "delete_account_oauth_credential"
    ),
  persistOnlyAfterRuntimeSuccess:
    trust.includes(
      "if status.is_success()"
    ) &&
    trust.includes(
      "self.persist_provider_credential("
    ),
  explicitPersistenceOptIn:
    trust.includes(
      'Some("OS_KEYRING") => true'
    ) &&
    trust.includes(
      'Some("PROCESS_MEMORY") | None => false'
    ) &&
    webApiClient.includes(
      '"PROCESS_MEMORY"'
    ) &&
    webApiClient.includes(
      '"OS_KEYRING"'
    ) &&
    normalizedWebApp.includes(
      'isDesktopShell() ? "Zapisz w systemie" : "Użyj w sesji"'
    ) &&
    normalizedWebApp.includes(
      'isDesktopShell() ? "OS_KEYRING" : "PROCESS_MEMORY"'
    ),
  memoryOnlyRemovesStoredCredential:
    trust.includes(
      "if persist"
    ) &&
    trust.includes(
      "self.delete_provider_credential("
    ),
  deleteFromOsKeyring:
    trust.includes(
      "fn delete_provider_credential("
    ) &&
    trust.includes(
      ".delete_credential()"
    ) &&
    trust.includes(
      "Err(KeyringError::NoEntry) => Ok(())"
    ),
  providerAllowlist:
    trust.includes(
      '"openai" | "anthropic" | "xai" | "google"'
    ),
  transientSecretZeroization:
    trust.includes(
      "unsafe_zero_string(&mut api_key);"
    ) &&
    runtimeCredentials.includes(
      "previous?.fill(0);"
    ),
  noBrowserPersistence:
    !webApi.includes(
      "localStorage"
    ) &&
    !webApi.includes(
      "sessionStorage"
    ),
  desktopDoesNotExposeSessionBearer:
    trust.includes(
      "extract_and_strip_session_token"
    ) &&
    trust.includes(
      "session_token: Option<String>"
    )
};

const pass =
  Object.values(checks)
    .every(Boolean);

console.log(
  JSON.stringify(
    {
      gate:
        "G37C2_OS_KEYRING_PROVIDER_CREDENTIALS",
      result:
        pass
          ? "PASS"
          : "BLOCKED",
      checks
    },
    null,
    2
  )
);

if (!pass) {
  process.exitCode = 1;
}
