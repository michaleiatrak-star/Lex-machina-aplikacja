# Dokumentacja techniczna aplikacji

Czekamy na kod Michała. Po jego dodaniu opisz tutaj:

1. Wymagania i uruchamianie lokalne.
2. Konfigurację, integracje oraz przykładowe zmienne bez sekretów.
3. Testy, budowanie instalatora i docelowe systemy operacyjne.
4. Numer wersji testowej i znane ograniczenia.

Dokumentacja ma wynikać z dostarczonego kodu. Nie utrzymujemy wcześniejszych, hipotetycznych specyfikacji jako opisu aktualnej aplikacji.

[Przygotowanie pierwszych testów](../../docs/beta.md).
