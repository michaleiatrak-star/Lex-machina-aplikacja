# Dokumentacja techniczna API

Po ustaleniu zakresu i rozpoczęciu implementacji zapisz tutaj konfigurację, kontrakty API, autoryzację, integrację płatności, testy i wdrożenie. Nie zakładamy dostawcy ani architektury przed podjęciem tych decyzji.

Sekrety usług pozostają po stronie serwera; przykładowa konfiguracja bez sekretów trafia do `.env.example`. Zasady oferty, komunikację i decyzje produktowe zapisujemy w głównym `docs/`.
