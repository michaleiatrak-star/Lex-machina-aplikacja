# Lex Machina — API / backend

Miejsce na przyszły backend, m.in. płatności i integracje. Nie ma jeszcze implementacji; technologia i dostawca płatności pozostają do ustalenia.

Kod trafia bezpośrednio do `api/`, a dokumentacja techniczna do [docs/](docs/README.md). Formularze kontaktowe strony są obecnie obsługiwane przez `web/` i nie stanowią API aplikacji.
