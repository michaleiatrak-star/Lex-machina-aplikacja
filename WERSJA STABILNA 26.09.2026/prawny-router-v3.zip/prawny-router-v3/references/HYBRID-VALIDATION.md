# HYBRID-VALIDATION — stub (sub-referencja)

Pełna logika walidacji hybrydowej znajduje się w bibliotece shared.

**Wczytaj przed użyciem:**
```
view shared/HYBRID-VALIDATION.md
```

Uruchom zgodnie z instrukcją tamtego pliku — wszystkie fazy, format raportu
i sekwencja aktualizacji są tam zdefiniowane.

**Skrót dla tego skilla:**
Po wygenerowaniu pisma → wczytaj plik główny → wykonaj sekwencję walidacji
(raport braków → uzupełnianie → zamknięcie).
