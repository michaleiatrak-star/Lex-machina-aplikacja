# mod-CG-zawody-prawnicze-i-pokrewne.md — Zawody prawnicze i pokrewne — doradcy, rzecznicy patentowi, syndycy, mediatorzy

> ⚠️ PRZEMIANOWANIE PLIKU 2026-07-15 (naprawa F-2): ten plik nazywał się wcześniej
> `mod-ustawa-zawody-medyczne-i-prawnicze.md`, mimo że jego treść dotyczy
> WYŁĄCZNIE zawodów prawniczych pokrewnych (doradcy podatkowi, rzecznicy
> patentowi, syndycy, mediatorzy) — zawody medyczne mają własne, osobne
> dedykowane moduły (mod-ustawa-zawod-lekarza, mod-ustawa-pielegniarka-polozna,
> mod-ustawa-aptekarz-zawod, mod-ustawa-diagnostyka-laboratoryjna,
> mod-ustawa-lekarz-weterynarii-zawod, mod-ustawa-psycholog-zawod) i nigdy nie
> były pokrywane przez ten plik. Nazwa pliku skorygowana na
> `mod-ustawa-zawody-prawnicze-pokrewne.md`, zgodnie z rzeczywistą treścią.

Status: moduł prawa polskiego klasy wzorcowej. Stan metodyczny: 2026-05-28. Źródła prawa muszą być każdorazowo weryfikowane w ELI (RZĄD 1) / Dzienniku Ustaw; LEX/Legalis dopuszczalne pomocniczo przy braku praktycznego dostępu do aktu albo dla komentarza.

> ℹ️ AKTUALIZACJA 2026-06-14/15: dla RZECZNIKÓW PATENTOWYCH, DORADCÓW
> PODATKOWYCH i SYNDYKÓW/DORADCÓW RESTRUKTURYZACYJNYCH istnieją teraz
> DEDYKOWANE moduły z konkretnymi Dz.U., ZASADAMI ABSOLUTNYMI i mapą
> proceduralną właściwą dla tych zawodów:
> - DR-12/`mod-ustawa-rzecznicy-patentowi-zawod` (Dz.U. 2026 poz. 778 t.j.)
> - DR-06/`mod-ustawa-doradcy-podatkowi-zawod` (Dz.U. 2026 poz. 1274 t.j.,
>   obejmuje nowelizację Dz.U. 2025 poz. 1882)
> - DR-02/`mod-ustawa-doradca-restrukturyzacyjny-zawod` (licencja syndyka/
>   nadzorcy/zarządcy — Dz.U. 2022 poz. 1007 + Pr. restrukturyzacyjne
>   2026/533 + Pr. upadłościowe 2025/614)
> Dla tych zawodów PREFERUJ moduły dedykowane.
>
> MEDIATOR: status (mediator "zwykły" vs stały mediator, KRM, obowiązek
> konta w portalu informacyjnym od 1.03.2026) jest opisany w DR-12/
> `mod-KPC-arbitraz-mediacja-ADR` (sekcja "STATUS MEDIATORA") — mediator
> NIE jest zawodem regulowanym z własną ustawą/samorządem, to kwalifikacja
> wg KPC.
>
> Ten moduł generyczny pozostaje jako ogólny szkielet metodologiczny
> (intake/mapa proceduralna/quality gate) jeśli moduł dedykowany nie
> wystarcza, oraz dla innych zawodów pokrewnych nieobjętych powyższymi.

## 1. Akty i źródła do weryfikacji
- Ustawa o doradztwie podatkowym → patrz DR-06/mod-ustawa-doradcy-podatkowi-zawod
- ustawa o rzecznikach patentowych → patrz DR-12/mod-ustawa-rzecznicy-patentowi-zawod
- ustawa o licencji doradcy restrukturyzacyjnego + Prawo restrukturyzacyjne/
  upadłościowe w zakresie statusu syndyka/nadzorcy/zarządcy → patrz
  DR-02/mod-ustawa-doradca-restrukturyzacyjny-zawod
- status mediatora (zwykły/stały, KRM) → patrz DR-12/mod-KPC-arbitraz-
  mediacja-ADR, sekcja "STATUS MEDIATORA"


Nie cytuj literalnego brzmienia przepisu bez aktualnego sprawdzenia źródła. Przed użyciem artykułu ustal:

- akt i Dz.U.,
- status obowiązywania,
- wersję temporalną na dzień zdarzenia,
- wersję na dzień sporządzania pisma,
- przepisy przejściowe,
- właściwy organ i tryb zaskarżenia.

## 2. Zakres spraw
- odpowiedzialność dyscyplinarna
- należyta staranność
- tajemnica zawodowa
- konflikt interesów
- skarga do samorządu
- odszkodowanie za błąd zawodowy

## 3. Intake
Ustal obowiązkowo:

1. kto jest stroną / uczestnikiem / funkcjonariuszem / organem,
2. jaki akt, czynność albo zaniechanie jest kwestionowane,
3. data czynności, doręczenia, powzięcia wiadomości i termin do reakcji,
4. organ pierwszej instancji i organ odwoławczy,
5. czy sprawa jest administracyjna, cywilna, karna, dyscyplinarna, służbowa albo mieszana,
6. czy istnieje dokument urzędowy: decyzja, postanowienie, zarządzenie, protokół, notatka, polecenie, uchwała,
7. czy zachodzi ryzyko prekluzji, przedawnienia, bezczynności albo bezskuteczności środka.

## 4. Mapa proceduralna
Stosuj ścieżkę:

`zdarzenie/czynność → kwalifikacja prawna → właściwość organu → środek zwykły → środek nadzwyczajny → kontrola sądowa → wykonanie rozstrzygnięcia → odpowiedzialność odszkodowawcza/dyscyplinarna`

W sprawach publicznoprawnych zawsze rozważ równolegle:

- środek w toku sprawy,
- skargę na bezczynność/przewlekłość,
- wniosek o wstrzymanie wykonania,
- zabezpieczenie dowodów,
- odpowiedzialność funkcjonariusza/organu,
- dostęp do akt i informacji publicznej,
- ochronę danych osobowych i informacji niejawnych.

## 5. Warunki skuteczności
Sprawdź:

- termin,
- właściwość organu/sądu,
- legitymację,
- interes prawny albo faktyczny,
- podpis,
- pełnomocnictwo,
- opłatę,
- odpisy,
- załączniki,
- dowód doręczenia,
- wskazanie żądania,
- wskazanie zarzutów,
- relację dowód → fakt → norma.

## 6. Matryca dowodowa
Dla każdego faktu zbuduj tabelę:

| Fakt | Dowód | Źródło | Siła | Luka | Ryzyko |
|---|---|---|---|---|---|

Typowe dowody:

- decyzje, postanowienia, protokoły, notatki, zarządzenia,
- korespondencja z organem,
- nagrania, zdjęcia, logi, metadane,
- zeznania świadków,
- dokumentacja medyczna/techniczna/księgowa,
- opinie biegłych,
- akty prawa miejscowego,
- wydruki z BIP, rejestrów, systemów publicznych.

## 7. Zarzuty typowe
Rozważ co najmniej:

- naruszenie właściwości,
- naruszenie prawa do udziału w sprawie,
- brak podstawy prawnej,
- błędna wykładnia przepisu,
- dowolna ocena dowodów,
- brak uzasadnienia,
- nieproporcjonalność,
- nierówne traktowanie,
- naruszenie zaufania do organu,
- naruszenie terminów,
- brak rozpoznania istoty sprawy,
- pominięcie dowodu,
- wadliwe pouczenie.

## 8. Kontrargumenty organu / strony przeciwnej
Przewiduj:

- formalny brak legitymacji,
- spóźnienie środka,
- brak interesu prawnego,
- domniemanie prawidłowości dokumentu urzędowego,
- uznaniowość organu,
- tajemnicę ustawowo chronioną,
- bezpieczeństwo publiczne,
- brak szkody albo związku przyczynowego,
- nieadekwatność środka.

## 9. Strategia
Priorytety:

1. zabezpiecz termin i dowód doręczenia,
2. uzyskaj akta i pełną podstawę rozstrzygnięcia,
3. oddziel zarzuty formalne od materialnych,
4. wskaż fakty decydujące, nie wszystkie fakty,
5. buduj żądanie główne i ewentualne,
6. przygotuj wariant: organ → sąd administracyjny/cywilny/karny/dyscyplinarny,
7. oceń, czy korzystniejsze jest uchylenie, zmiana, stwierdzenie nieważności, wznowienie, odszkodowanie lub skarga.

## 10. Orzecznictwo
Nie wpisuj fikcyjnych sygnatur. Szukaj tylko realnych orzeczeń w:

- SN / NSA / TK,
- CBOSA,
- Portalu Orzeczeń Sądów Powszechnych,
- orzeczeniach sądów dyscyplinarnych, jeżeli publicznie dostępne,
- LEX/Legalis pomocniczo.

Każde orzeczenie oceniaj według: aktualność, hierarchia sądu, analogiczność stanu faktycznego, linia dominująca/odmienna.

## 11. Ryzyka
Oceń:

- ryzyko zwrotu/odrzucenia,
- ryzyko spóźnienia,
- ryzyko braku legitymacji,
- ryzyko niewykazania faktu,
- ryzyko niedopuszczalności dowodu,
- ryzyko uznania organu,
- ryzyko kosztowe,
- ryzyko retorsji służbowej/dyscyplinarnej,
- ryzyko równoległych postępowań.

## 12. Quality gate
Przed odpowiedzią lub pismem zastosuj:

- `shared/POLISH-LAW-FINAL-COMPLETENESS-GATE.md`,
- `shared/ISAP-AUDIT-PROTOCOL.md`,
- `shared/TEMPORAL-LAW-CHECK.md`,
- `shared/LEGAL-QUALITY-GATE.md`,
- `shared/RISK-ASSESSMENT.md`, jeżeli istnieje,
- `shared/FORMAL-CHECK.md`, jeżeli powstaje pismo.
