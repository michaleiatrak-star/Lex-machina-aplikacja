# mod-ustawa-zarzadzanie-kryzysowe

**Status:** moduł klasy kancelaryjnej — poziom DR-03
**Źródło weryfikacji:** Ustawa o zarządzaniu kryzysowym — **Dz.U. 2026 poz. 574 t.j.** ✅ [VER] RZĄD 1 2026-09-10c (F-148a) | Ustawa o ochronie ludności i obronie cywilnej — weryfikuj aktualny t.j. w ELI (RZĄD 1)
**Data weryfikacji online:** 2026-06-05
**Zasada:** Każde brzmienie przepisu przed powołaniem → isap.sejm.gov.pl

---

## 1. CORE

### Zakres
Zarządzanie kryzysowe na szczeblu gminnym, powiatowym i wojewódzkim: centrum zarządzania kryzysowego, plany zarządzania kryzysowego, stany nadzwyczajne, obrona cywilna (od 01.01.2025 nowe przepisy), ewakuacja, świadczenia na rzecz obrony (rekwizycja).

### Akty

| Akt | Dz.U. |
|---|---|
| Ustawa o zarządzaniu kryzysowym | **Dz.U. 2026 poz. 574 t.j.** ✅ [VER] RZĄD 1 2026-09-10c — obwieszczenie Marszałka Sejmu z 21.04.2026. ⛔ KROK 2C: jedna nowelizacja po tekście jednolitym — ustawa z 29.05.2026 (Dz.U. 2026 poz. 815), więc tekst jednolity NIE oddaje stanu bieżącego. ⛔ **BŁĄD SKORYGOWANY:** dotychczasowy `Dz.U. 2024 poz. 1194` to obwieszczenie o tekście jednolitym ustawy o **dozorze technicznym** — inny akt (klasa F-149/3) |
| Ustawa o ochronie ludności i obronie cywilnej | weryfikuj aktualny t.j. w ELI (RZĄD 1) (ustawa z 2022 r.) |

---

## 2. PROCEDURA — SZCZEBEL JST

### Kompetencje wójta/burmistrza/prezydenta

```
□ Kierowanie działaniami w zakresie zarządzania kryzysowego na terenie gminy
□ Wydawanie poleceń kierownikom gminnych jednostek organizacyjnych
□ Może wnioskować o pomoc wojska i policji do Wojewody
□ Centrum Zarządzania Kryzysowego gminy (przy dużych gminach)
□ Gminny Plan Zarządzania Kryzysowego: aktualizowany co 2 lata
```

### Świadczenia na rzecz obrony

```
Obowiązki osób fizycznych i podmiotów:
  → Świadczenia osobiste i rzeczowe na potrzeby obrony (rekwizycja)
  → Decyzja wójta / burmistrza / starosty / Wojewody
  → Odszkodowanie za rekwizycję: weryfikuj przepisy w ELI (RZĄD 1)
  → Zaskarżenie: KPA → SKO → WSA
```

---

## 3. QUALITY GATE / OUTPUT

**Quality gate:** Ustawa o zarządzaniu kryzysowym — aktualny t.j. (Dz.U. 2026 poz. 574) zweryfikowany, wraz z nowelizacją Dz.U. 2026 poz. 815 po tekście jednolitym? Nowa ustawa o ochronie ludności — aktualny t.j. w ISAP?

**Output:** Kwalifikacja sytuacji → właściwy szczebel → kompetencje organu → środki → rekomendacja.

**Powiązania:** `mod-JST-ustroj-samorzad-gminny-powiatowy-wojewodztwa` | `dr-13` (służby, bezpieczeństwo) | `pisma-procesowe-v3`

**Źródła:** https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20241194
