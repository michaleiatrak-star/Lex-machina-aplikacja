# Wykroczenia — Szczegółowy Framework

> ⚠️ **WERYFIKACJA ONLINE OBOWIĄZKOWA** — weryfikuj przepisy i taryfikator
> w isap.sejm.gov.pl przed każdą analizą.

## TERMIN 7 DNI NA SPRZECIW — ABSOLUTNY PRIORYTET
Sprzeciw od wyroku nakazowego: **7 dni od doręczenia** — termin ZAWITY (art. 94 § 1 KPW w zw. z art. 506 § 1 KPK — art. 94 sam terminu nie podaje, odsyła do KPK). ✅ [VER] RZĄD 1 2026-09-16 — KPW `Dz.U. 2025 poz. 860`, KPK `Dz.U. 2026 poz. 490`.
Sprawdź JAKO PIERWSZE w każdej sprawie nakazowej.

## SCHEMAT POSTĘPOWANIA
```
Zdarzenie
  ↓ [MANDAT: przyjąć / odmówić na miejscu]
  Odmowa → Czynności wyjaśniające → Wniosek o ukaranie do SR
  ↓
  [Tryb nakazowy: wyrok bez rozprawy — doręczany pocztą]
    ↓ [7 DNI od DORĘCZENIA] SPRZECIW → Sprawa przechodzi do trybu zwykłego
  [Tryb zwykły: rozprawa]
    ↓ [7 dni od ogłoszenia — wniosek o uzasadnienie]
    ↓ [7 dni od doręczenia wyroku z uzasad.] APELACJA → Sąd Okręgowy
```

## MANDAT KARNY — PRZYJĄĆ CZY ODMÓWIĆ?
**Odmów gdy:** jesteś niewinny, fakty sporne, zarzut nie wyczerpuje znamion,
upłynął termin przedawnienia, kwota rażąco zawyżona.

**Przyjmij gdy:** jesteś winny, sprawa sądowa to strata czasu, szybkie zakończenie jest priorytetem.

### Kary mandatowe — rozróżnienie (ważne!)
```
MANDAT (policja / ITD / straż): max 2.500 zł
RECYDYWA (ten sam typ wykroczenia w ciągu 24 m-cy): max 5.000 zł
SĄD (art. 24 §1 KW): grzywna do 30.000 zł
⚠️ "Max kara" w tabeli = kara sądowa. Mandat policyjny to max 2.500/5.000 zł.
```

### Uchylenie prawomocnego mandatu (art. 101 KPSW)
```
Termin: 7 dni od uprawomocnienia się mandatu (ZAWITY) — wniosek ukaranego
        lub z urzędu / na wniosek organu który nałożył (bez terminu)

Podstawy uchylenia (§ 1 i §1a):
  §1:   Grzywna nałożona za czyn NIE będący wykroczeniem
        Nałożona na osobę, która popełniła czyn przed ukończeniem 17 lat
        Gdy ustawa stanowi, że sprawca nie popełnia wykroczenia (art. 15–17 KW)
  §1a:  Grzywna nałożona wbrew zakazom z art. 96 §2 KPSW
        (np. gdy należy orzec środek karny, zbieg z przestępstwem)
  §1a:  Grzywna wyższa niż dopuszczalna — uchylenie w CZĘŚCI przekraczającej
  §1b:  Gdy po uprawomocnieniu ujawnią się fakty/dowody wskazujące, że
        ukarany nie popełnił czynu (nadzwyczajne środki)

⚠️ Uchylenie NIE jest środkiem odwoławczym — sąd bada tylko podstawę formalno-
   prawną wystawienia, nie winę ukaranego.
```

## GRANICA WYKROCZENIE / PRZESTĘPSTWO — KRYTYCZNE
```
Kradzież (i przywłaszczenie):
  Wartość ≤ 800 zł → art. 119 KW (WYKROCZENIE) — obowiązuje od 01.10.2023
  Wartość > 800 zł → art. 278 KK (PRZESTĘPSTWO)
  ⚠️ Kumulacja wykroczeń (czyn ciągły art. 12 §2 KK):
     suma wartości kilku kradzieży < 800 zł każda może przekroczyć próg
     → kwalifikacja jako przestępstwo

Alkohol za kierownicą:
  0,2–0,5‰ we krwi lub 0,1–0,25 mg/l w wydychanym pow. → art. 87 KW (WYKROCZENIE)
  > 0,5‰ we krwi lub > 0,25 mg/l w wydychanym pow. → art. 178a KK (PRZESTĘPSTWO)

Inne granice (art. 124 KW):
  Zniszczenie mienia ≤ 800 zł → KW; > 800 zł → art. 288 KK
  Kradzież leśna (art. 120 KW): ≤ 800 zł → KW; > 800 zł → KK
```

## TYPOWE WYKROCZENIA DROGOWE — TARYFIKATOR (stan: wrzesień 2022, aktualny w 2026)
| Art. | Czyn | Mandat policyjny | Kara sądowa max |
|---|---|---|---|
| 86 §1 | Kolizja (niezachowanie ostrożności) | 500–1.500 zł | 30.000 zł |
| 87 §1 | Jazda po alkoholu (0,2–0,5‰) | 2.500 zł | 30.000 zł + zakaz |
| 92a §1 | Przekroczenie prędkości do 10 km/h | 100 zł | 5.000 zł |
| 92a §1 | Przekroczenie o 11–20 km/h | 200–300 zł | 5.000 zł |
| 92a §1 | Przekroczenie o 21–30 km/h | 300–400 zł | 5.000 zł |
| 92a §2 | Przekroczenie o 31–40 km/h | 800 zł (1.600 recyd.) | 30.000 zł |
| 92a §2 | Przekroczenie o 41–50 km/h | 1.000 zł (2.000 recyd.) | 30.000 zł |
| 92a §2 | Przekroczenie o > 50 km/h | 1.500–2.500 zł (do 5.000) | 30.000 zł |
| 94 §1 | Jazda bez uprawnień | 1.500 zł | 30.000 zł |
| 96 §3 | Nieujawnienie kierowcy | 2.500 zł | 30.000 zł |

*Mandaty w recydywie (ten sam typ w ciągu 24 m-cy): podwojona kwota, max 5.000 zł.*
*Taryfikator rozporządzeniowy — weryfikuj aktualne stawki w obowiązującym rozporządzeniu.*
*Korekta AUDYT-2026-10-04c: art. 92a § 2 KW obejmuje przekroczenie o PONAD 30 km/h (grzywna nie niższa niż 800 zł, do 30 000 zł z art. 24 § 1a); przekroczenie do 30 km/h = art. 92a § 1, górna granica 5 000 zł (art. 24 § 1 — § 1a wymienia wyłącznie § 2). ✅ [VER: ELI RZĄD 1 — DU/2025/734 (t.j. KW) text.pdf + DU/2025/1872 text.pdf (art. 1; wejście w życie art. 9: 30 dni od ogłoszenia 29.12.2025 → 29.01.2026, ELI entryIntoForce 2026-01-29); odczyt 2026-10-04]*

## 5 LINII OBRONY NA ROZPRAWIE
```
1. Brak znamion wykroczenia (czy czyn wyczerpuje opis przepisu?)
2. Okoliczności wyłączające winę: wyższa konieczność (art. 16 KW),
   niepoczytalność (art. 17 KW), błąd co do faktu (art. 7 KW)
3. Znikomość szkodliwości społecznej (art. 1 §1 KW) → nagana lub umorzenie
4. Przedawnienie karalności (1 rok od czynu bez wszczęcia; 2 lata łącznie)
5. Okoliczności łagodzące: naprawienie szkody, dobra opinia, trudna sytuacja
   + błędy proceduralne (np. brak uprzedzenia o prawie odmowy mandatu)
```

## MANDAT A POWAGA RZECZY OSĄDZONEJ — WAŻNE ORZECZNICTWO
```
Uchwała SN I KZP 7/25 z 19.03.2026 (sn.pl):
  "Prawomocne ukaranie mandatem karnym za wykroczenie stoi na przeszkodzie
   objęciu czynu ukaranego w tym trybie odmianą czynu ciągłego z art. 12 §2 KK."
  → Przyjęcie mandatu = res iudicata → nie można potem ścigać za to samo
    zdarzenie jako element przestępstwa ciągłego
  Kontekst: dotyczy wykroczeń kumulujących się do progu przestępstwa
  ⚠️ Uzasadnienie w przygotowaniu — weryfikuj URL w sn.pl przed powołaniem

Postanowienie SN IV KK 145/24 z 10.09.2024 (sn.pl):
  Wcześniejsza podstawa: prawomocne zakończenie postępowania wykroczeniowego
  (w tym mandatem) kreuje stan powagi rzeczy osądzonej (ne bis in idem)
```

## PRZEDAWNIENIE I ZATARCIE
```
Przedawnienie karalności:  1 rok od czynu
                           2 lata gdy wszczęto postępowanie w terminie
Przedawnienie wykonania:   3 lata od uprawomocnienia orzeczenia / mandatu
Zatarcie ukarania:         2 lata od wykonania kary / grzywny / środka
                           → po zatarciu: ukaranie = niebyłe w KRK
```

## KALKULATOR TERMINÓW
| Czynność | Termin |
|---|---|
| Odmowa mandatu | W chwili wręczenia — na miejscu |
| Uchylenie prawomocnego mandatu | **7 dni** od uprawomocnienia (ZAWITY) |
| Sprzeciw od wyroku nakazowego | **7 dni** od doręczenia (ZAWITY) |
| Wniosek o uzasadnienie wyroku SR | **7 dni** od ogłoszenia |
| Apelacja od wyroku SR | **7 dni** od doręczenia z uzasadnieniem |

## FAZA 0 — INTAKE
```
□ Mandat karny (przyjęty/nieprzyjęty) czy wyrok nakazowy (pocztą)?
□ Wyrok nakazowy: 7 dni na sprzeciw od doręczenia — SPRAWDŹ NATYCHMIAST
□ Data doręczenia / uprawomocnienia? Termin na sprzeciw / uchylenie upłynął?
□ Jaka kwota / jaki czyn? → czy wyczerpuje znamiona wykroczenia?
□ Czy wartość mienia przekracza 800 zł? → może być przestępstwo KK
□ Czy alkohol > 0,5‰? → art. 178a KK (przestępstwo), nie wykroczenie
□ Czy termin przedawnienia nie upłynął? (1 rok od czynu)
□ Czy to recydywa w rozumieniu taryfikatora (ten sam typ w 24 m-cy)?
□ Czy mandat naruszał art. 96 §2 KPSW? → uchylenie obligatoryjne
```

## PREDYKCJA WYNIKU — SZABLON
```
Szanse na wygraną: [0–100%]
IN PLUS: brak znamion, przedawnienie, błędy proceduralne (np. brak pouczenia
         o prawie odmowy), brak świadków, sprzeczność zeznań funkcjonariuszy
IN MINUS: nagranie, radar, dwóch policjantów, przyznanie się, upływ terminu
BENCHMARKING: → wywołaj orzeczenia-sadowe-v2
  Uchwała SN I KZP 7/25 z 19.03.2026 i postanowienie IV KK 145/24 — powaga mandatu
  (⚠️ weryfikuj URL w sn.pl przed każdym powołaniem)
REKOMENDACJA: □ Sprzeciw od wyroku nakazowego  □ Rozprawa  □ Przyjąć mandat
```

## ŁĄCZ Z
| Sytuacja | Skill |
|---|---|
| Sprzeciw od wyroku nakazowego | `pisma-proste-v2` |
| Analiza akt wykroczeniowych | `analiza-sadowa-v6` |
| Obrona na rozprawie (pytania do funkcjonariusza) | moduł [K] `przesluchanie-swiadkow-v2-min90` |
| Orzecznictwo SN — wykroczenia | `orzeczenia-sadowe-v2` |
| Granica z przestępstwem → | `dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-KPK-framework-karne.md` + `dr-03-prawo-karne-wykroczenia-egzekucja/modules/mod-KK-kwalifikator-karnomaterialny.md` |
| Prawo jazdy, punkty karne, cofnięcie/zatrzymanie pj | `mod-PRD-prawo-jazdy-punkty-karne` |

---

## NOWE WYKROCZENIA DROGOWE 2026 — UZUPEŁNIENIE

> Ustawa z 04.12.2025 r. (Dz.U. 2025 poz. 1872) — wejście w życie 29.01.2026 (cz. 30.03.2026)
> Weryfikuj: ELI (RZĄD 1) → KW ze zm. Dz.U. 2025 poz. 1872

```
ART. 86c KW (NOWY — od 29.01.2026) — CELOWY DRIFT / POŚLIZG:
  → "Celowe wprowadzenie pojazdu w poślizg lub utrata styczności choćby jednego koła
    z nawierzchnią na drodze publicznej, w strefie ruchu lub zamieszkania"
  → Kara: grzywna nie niższa niż 1 500 zł (§ 1); gdy następstwem jest zagrożenie
    bezpieczeństwa w ruchu drogowym — nie niższa niż 2 500 zł (§ 2); górna granica
    30 000 zł (art. 24 § 1a — od 29.01.2026). ✅ [VER: ELI RZĄD 1 — DU/2025/734 (t.j. KW) text.pdf + DU/2025/1872 text.pdf (art. 1; wejście w życie art. 9: 30 dni od ogłoszenia 29.12.2025 → 29.01.2026, ELI entryIntoForce 2026-01-29); odczyt 2026-10-04]
  → Od 30.03.2026: ZATRZYMANIE PJ na 3 miesiące (administracyjne — niezależnie od wypadku)
  ⚠️ KLUCZOWY ELEMENT ZNAMION: CELOWOŚĆ — niezamierzony poślizg ≠ wykroczenie z art. 86c

ORGANIZOWANIE SPOTKAŃ MOTORYZACYJNYCH BEZ ZGŁOSZENIA:
  → ≥10 pojazdów = obowiązek zgłoszenia organowi gminy
  → Art. 52aa KW (od 29.01.2026): organizator / przewodniczący spotkania bez wymaganego
    zawiadomienia (art. 65ja PRD) — kara ograniczenia wolności albo grzywny NIE NIŻSZEJ
    niż 2 000 zł (§ 1); umyślny uczestnik — grzywna (§ 2); nie-kierujący uczestnik
    nielegalnego wyścigu i widz — ta sama kara (§ 3–4). Poprzedni zapis „grzywna do
    2 000 zł (organizator i uczestnicy)” był błędny. ✅ [VER: ELI RZĄD 1 — DU/2025/734 (t.j. KW) text.pdf + DU/2025/1872 text.pdf (art. 1; wejście w życie art. 9: 30 dni od ogłoszenia 29.12.2025 → 29.01.2026, ELI entryIntoForce 2026-01-29); odczyt 2026-10-04]

TARYFIKATOR MANDATÓW — AKTUALIZACJA:
  → Rozporządzenie Dz.U. 2026 poz. 724 (MSWiA 29.05.2026) — weryfikuj aktualne stawki
  → web_search: "taryfikator mandatów drogowych 2026 maksymalne kwoty rozporządzenie"

NOWE PRZESTĘPSTWA KK (NIE wykroczenia — odesłanie):
  → Brawurowa jazda, nielegalne wyścigi, przepadek pojazdu → mod-PRD + mod-KK-KPK-framework-karne
```

---
*KW (Dz.U. 2025 poz. 734 t.j. ze zm. Dz.U. 2025 poz. 1872) + KPSW (Dz.U. 2025 poz. 860 t.j.)*
*KPK stosowany posiłkowo (Dz.U. 2026 poz. 490 t.j.)*
*Uchwała SN I KZP 7/25 z 19.03.2026 — sn.pl (weryfikuj URL)*
*Postanowienie SN IV KK 145/24 z 10.09.2024 — sn.pl*
*Taryfikator mandatów + punktów karnych: rozp. Dz.U. 2026 poz. 724 — weryfikuj ISAP*
*Nowe wykroczenia drogowe: Dz.U. 2025 poz. 1872 (art. 86c KW drift, zloty) — weryfikuj ISAP*
