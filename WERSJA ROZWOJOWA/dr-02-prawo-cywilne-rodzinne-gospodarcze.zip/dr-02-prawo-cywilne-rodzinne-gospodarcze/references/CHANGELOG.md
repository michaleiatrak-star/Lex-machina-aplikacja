# CHANGELOG — dr-02-prawo-cywilne-rodzinne-gospodarcze

- 3.63 (2026-10-05l, AUDYT-2026-10-05l): Linie „Hasła spraw” w mod-KRO-rodzinne, mod-ustawa-prawa-konsumenta, mod-PrUpad-upadlosc-restrukturyzacja, mod-KSH-organy-spolki-zoo (dobór modułu przez aplikację). Treść prawna bez zmian.

- 3.62 (2026-10-04n, AUDYT-2026-10-04n): Historia zmian SKILL.md i modułów przeniesiona z plików roboczych do `references/HISTORIA-ZMIAN-PLIKOW.md` (plik historyczny, niewczytywany przez model). Treść robocza bez zmian.

- 3.61 (2026-10-03b, AUDYT-2026-10-03b, F-223): `SKILL.md` odtworzony z `main` sprzed 3.60 (wydanie 3.60 zbudowano z kopii zainstalowanej w claude.ai — host zdjął wcięcie listy `dependencies.requires` i usunął komentarz YAML z 2026-09-27e). Treść 3.60 (F-218, `mod-KC-ubezpieczenia`) bez zmian; jedyna różnica `SKILL.md` względem 3.59 to `version:`.
- 3.60 (2026-10-03, AUDYT-2026-10-03, F-218): mod-KC-ubezpieczenia — STRATEGIA pkt 5: usunięty jednolity 3-letni termin „z art. 819 KC” dla pozwu poszkodowanego (sprzeczny z tabelą TERMIN PRZEDAWNIENIA tego samego modułu) i błędny moment biegu („zakończenie postępowania likwidacyjnego”). Nowe brzmienie: umowa własna → art. 819 § 1; poszkodowany → ubezpieczyciel OC → art. 819 § 3 (delikt: art. 442¹ § 1–3; kontrakt: art. 118); bieg na nowo od otrzymania na piśmie oświadczenia ubezpieczyciela (art. 819 § 4). Adnotacja korekty w nagłówku modułu. ✅ [VER: api.sejm.gov.pl ELI DU/2026/795, 2026-10-03; zero nowelizacji po t.j.]. Wykryte przy audycie cudzego tekstu (kategoria [11] routera), nie testem automatycznym.
- 3.59 (2026-09-27e, AUDYT-2026-09-27e): claude.ai po dodaniu marketplace instalował wyłącznie 4 z 32 pluginów (shared, prawny-router-v3, analizator-dowodow-v3, przesluchanie-swiadkow-v2-min90); jedyna cecha wspólna tych 4, nieobecna w żadnym z 28 pozostałych, to klucz `dependencies` we frontmatterze SKILL.md. Dodano go (`requires: [shared]` — zgodnie ze stanem faktycznym) oraz jawny manifest pluginu (name, description = description z SKILL.md, author, repository, license) — host nie musi niczego wnioskować z SKILL.md. `version` w manifeście = `version:` z SKILL.md (pilnuje T38 w audyt-systemu-v4) — host rozpoznaje aktualizację po podbiciu wersji. Treść skilla bez zmian.
- 3.58 (2026-09-23, AUDYT-2026-09-23c): SKILL.md: „Źródło podstawowe” — LEX/Legalis → ArsLege gdy aktu nie da się pobrać z RZĘDU 1 (awaria serwera, timeout, blokada); korekta użytkownika do warunku E-3.
- 3.57 (2026-09-23, AUDYT-2026-09-23b): kanon E-1…E-5 (`shared/HIERARCHIA-ZRODEL.md` 1.10): instrukcje weryfikacji „w ISAP” / „isap.sejm.gov.pl →” zamienione na „w ELI (RZĄD 1)” (26 plików); ISAP pozostaje adresem dla człowieka; wpisy historyczne („zweryfikowano w ISAP …”) bez zmian.
- 3.56 (2026-09-16, F-189): mod-KC-spadki-dlugi-umowy-transgraniczne — ważność odpisu EPS: 6 miesięcy z datą ważności w odpisie, wyjątkowo okres dłuższy, potem przedłużenie albo nowy odpis (art. 70 ust. 1–3 rozp. 650/2012) — RZĄD 1 przez Cellar; usunięte oznaczenie „niezweryfikowane”.
- 3.55 (2026-09-16, F-189): F-135 (RZĄD 1 — KRO 2026/236, KPC 2026/468): kro-rodzinne/czesc-07 — ⛔ kalkulator: zaprzeczenie ojcostwa (matka, dziecko) — ROK (nie 6 miesięcy / 3 lata); powrót do nazwiska — rok, przed USC (nie 3 miesiące, nie tryb sądowy); art. 60 § 3 — „nie został uznany za winnego”, przedłużenie; dopisane art. 73 § 1 i 172; mediacja — sprzeciw w tygodniu (art. 183⁸ § 2), art. 183⁹ § 2, 183¹⁰ § 1; zmiana imienia/nazwiska — termin z art. 35 § 3 KPA, opłata 37 zł potwierdzona; mod-KRO-zawarcie-malzenstwa — art. 8 § 3 KRO (5 dni bez dni ustawowo wolnych, obowiązek duchownego, nadanie polecone).
- 3.54 (2026-09-16, F-189): F-135 (RZĄD 1 — KPC 2026/468): mod-KC-spadki — nowa sekcja 2a „Terminy postępowania spadkowego (KPC)” (wezwanie spadkobierców, zmiana stwierdzenia nabycia, odwrócony kredyt hipoteczny, prekluzja działu); zachowek — art. 1007 § 1–4; mod-KC-spadki-dlugi-umowy-transgraniczne — ważność odpisów EPS oznaczona jako niezweryfikowana w RZĘDZIE 1.
- 3.53 (2026-09-16, F-189): F-135 (RZĄD 1 — KC 2026/795): mod-KC-ubezpieczenia — art. 819 § 1, § 3, § 4 i 442¹ § 1–3 (⛔ szkoda na osobie; ⛔ wezwanie do zapłaty NIE przerywa biegu — art. 123); mod-KC-cywilne-zobowiazania-odpowiedzialnosc — § 3 w tabeli deliktu; mod-KC-spadki-zachowek-dzial-rozrzadzenia — art. 1007 § 1–4 (punkty startowe).
- 3.52 (2026-09-16, F-189): mod-ustawa-deweloperska — akt pierwotny `2021/1177` jako aktualna podstawa → t.j. `2026/880` (3 miejsca; RZĄD 1; T27 ZASTĄPIONY_TJ).
- 3.51 (2026-09-16, F-189): ODTWORZENIE utraconych wydań 3.48–3.50 (F-189), RZĄD 1 — KRO (Dz.U. 2026 poz. 236): terminy zaprzeczenia ojcostwa (art. 63–65, 69 § 1, 70 § 1, 70¹, 86) i bezskuteczności uznania (art. 78–81¹); ⛔ NOWE: art. 61¹³–61¹⁵ — macierzyństwo: ROK, nie 6 miesięcy/3 lata (poprzednio „potwierdzone RZĄD 2B”). PrUp (Dz.U. 2026 poz. 913): adresat zgłoszenia — syndyk przez system teleinformatyczny (art. 236 ust. 1), skutek spóźnienia — ryczałt 15% wskaźnika GUS (art. 235 ust. 1), domniemanie i 24 miesiące ≠ termin. PrRestr art. 91 podniesiony do RZĘDU 1 (Dz.U. 2026 poz. 533). KSH (Dz.U. 2024 poz. 18): cztery reżimy zaskarżania uchwał (art. 251, 252 § 3–4, 424, 425).
- 3.50 — LUKA JAWNA: wydanie AUDYT-2026-09-12m nieobecne na dysku — odtworzone w 3.51
- 3.49 — LUKA JAWNA: wydanie AUDYT-2026-09-12l nieobecne na dysku — odtworzone w 3.51
- 3.48 — LUKA JAWNA: wydanie AUDYT-2026-09-12k nieobecne na dysku — odtworzone w 3.51
- 3.47 (2026-09-10v, O-11): czesc-04-alimenty: koszty zastepstwa w sprawie o alimenty to stawka minimalna 240 zl NIEZALEZNIE OD WPS (par. 4 ust. 1 pkt 9 obu taks) - tabela od WPS nie ma tu zastosowania, policzenie z niej zawyza koszty blisko czterokrotnie
- 3.46 (2026-09-10u, O-11): kro-rodzinne/czesc-04-alimenty: WYSOKOSC alimentow oparta na ODCZYCIE TRESCI art. 135 KRO (t.j. Dz.U. 2026 poz. 236) - dwie przeslanki z par. 1, osobiste starania z par. 2 jako forma wykonania obowiazku, zakaz odliczania swiadczen z par. 3. Przeslanki art. 128-140 przepisane z tresci, nie z pamieci. Dopisane zwolnienie z art. 96 ust. 1 pkt 2 KSCU i WPS z art. 22 KPC
- 3.45 (2026-09-10o, F-181): ustawa o Krajowym Rejestrze Zadluzonych 2021/1909 na 2025/1584 (RZAD 1, zero nowelizacji po t.j.)
- 3.44 (2026-08-26): F-86 — dodano `modules/mod-PrUpad-likwidacja-miedzynarodowe-szczegolne.md` obejmujący mapę art. 316–334, 378–417 i 418–425s Prawa upadłościowego; zaktualizowano MAPA-AKTOW, MAPA-POKRYCIA i routing centralny. Granica od art. 426 jawnie oznaczona jako nieopracowana. Liczba plików skilla 78 → 79.
  *(Wpis WTÓRNY, odtworzony 2026-08-31 z `audyt-systemu-v4/references/AUDIT-JOURNAL.md`, sesja AUDYT-2026-08-26c, sekcja „Zamknięte flagi” → F-86, oraz AUDYT-2026-08-27 pkt 1 i 4. Przy rozbieżności rozstrzyga dziennik. Powód odtworzenia: flaga F-140, wykryta testem T12.)*

- 3.43 (2026-08-27): dodano trzy moduły zamykające luki zerowe KSH, KPC oraz PrUp/PrRestr; zsynchronizowano MAPA-AKTOW, MAPA-POKRYCIA i centralny routing.

- 3.42 — F-108 P3/13 i P3/34: wydzielono Prawo spółdzielcze i ustawę o spółdzielniach mieszkaniowych do odrębnych modułów opartych na RZĄD 1 ELI. (2026-08-27)

- 3.41 — F-108/51: dodano dedykowany moduł Prawa przedsiębiorców, poziom B, ze świeżą metryką i zmianami z RZĄD 1 ELI. (2026-08-27)

- 3.40 — F-108 P1: dodano odrębny moduł ustawy o ubezpieczeniach obowiązkowych/UFG/PBUK oraz moduł ustawy o fundacji rodzinnej; rozdzielono metrykę Dz.U. 2026 poz. 783 od KC. (2026-08-27)

- 3.39 — F-108/46: operacyjny rdzeń transakcji handlowych, sześć półroczy, rekompensata i jawna mapa luk; KC/UZNK odsyłają do jednego modułu. (2026-08-27)

- 3.38 (2026-08-26): zarejestrowano istniejące moduły art. 162 KPC oraz
  kaucji najmu; dodano moduł F-86 dla art. 316–334, 378–417 i 418–425s
  Prawa upadłościowego; poprawiono metrykę ustawy o timeshare i
  zsynchronizowano licznik modułów.
- 3.37 (2026-08-26): poprawiono i zsynchronizowano metryki tekstów jednolitych
  w modułach cywilnych, rodzinnych, konsumenckich, nieruchomościowych,
  upadłościowych i korporacyjnych.
