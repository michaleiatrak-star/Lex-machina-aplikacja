# mod-KP-prawo-pracy

**Status:** moduł klasy kancelaryjnej — poziom DR-03
**Źródło weryfikacji:** KP — Dz.U. 2026 poz. 1245 t.j. ✅ [VER] RZĄD 1 2026-10-09 (ELI, obwieszczenie odczytane) (obejmuje m.in. 2025/807 jawność wynagrodzeń, 2025/1423 reforma stażu, 2026/25; ⛔ także 2026/1046 — w życie 5.11.2026)
**Data weryfikacji online:** 2026-06-05
**Zasada:** Każde brzmienie przepisu przed powołaniem → isap.sejm.gov.pl | LEX/Legalis wyłącznie pomocniczo

---

## ⚡ ALERTY LEGISLACYJNE — CZYTAJ PRZED ANALIZĄ

| Zmiana | Status | Podstawa |
|---|---|---|
| **Reforma stażu pracy** (wliczanie zlecenia, JDG, służb mundurowych) | **Sektor publiczny: od 01.01.2026 | Sektor prywatny: od ~01.04.2026** — weryfikuj datę wejścia w życie | Dz.U. 2025 poz. 1423 — art. 30², 302¹ KP |
| **Jawność wynagrodzeń** (art. 183ca KP — nowy) | **OBOWIĄZUJE** — pracodawca musi ujawnić widełki wynagrodzenia w ogłoszeniu o pracę | Dz.U. 2025 poz. 807 |
| Minimalne wynagrodzenie 2026 | **4 806 zł brutto/mies. od 01.01.2026 | stawka godz.: 31,40 zł** | Dz.U. 2025 poz. 1242 |
| ⚡ **Regulamin pracy/wynagradzania — próg 20→50 pracowników** + forma "papierowa lub elektroniczna" dla wielu czynności KP + procedura uzgadniania ZFŚS bez ZZ | **OBOWIĄZUJE od 26/27.01.2026** (sprawdź dokładną datę) — bez przepisów przejściowych. Szczegóły i checklist redakcyjna → `analizator-umow-v1/references/mod-J21-rodo-archiwizacja-regulaminy.md` (J21.4-J21.5) | Dz.U. 2026 poz. 25 — art. 104, 77² KP |
| Projekt zniesienia umów cywilnoprawnych w stosunku pracy | Status: projekt — weryfikuj ELI (RZĄD 1) | — |

---

## 1. CORE

### Zakres modułu
Nawiązanie i rozwiązanie stosunku pracy, wypowiedzenie (wymogi formalne, przyczyna, termin), zwolnienie dyscyplinarne (art. 52 KP), ochrona szczególna (ciąża, wiek przedemerytalny, L4, działacze ZZ), roszczenia pracownika (przywrócenie / odszkodowanie), nadgodziny, urlopy, czas pracy, odpowiedzialność materialna, wypadki przy pracy, reforma stażu pracy.

### Akty i źródła kontrolne

| Akt | Dz.U. | Uwaga |
|---|---|---|
| Kodeks pracy (KP) | Dz.U. 2026 poz. 1245 t.j. ze zm. | Weryfikuj wszystkie nowelizacje w ISAP |
| Ustawa o minimalnym wynagrodzeniu | Dz.U. 2024 poz. 1773 t.j. | Kwota co roku z rozporządzenia RM |
| Rozp. RM w sprawie wys. min. wynagrodzenia | Dz.U. 2025 poz. 1242 (2026 r.) | Weryfikuj przez web_search co rok |

---

## 2. INTAKE

```
□ Data doręczenia wypowiedzenia / dyscyplinarki → OBLICZ 21 DNI NATYCHMIAST
□ Rodzaj umowy: na czas nieokreślony / określony / próbny / na zastępstwo
□ Tryb: wypowiedzenie (art. 45) / dyscyplinarka (art. 52) / porozumienie / art. 55 §1¹ KP
□ Ochrona szczególna: ciąża / wiek przedemerytalny / L4 / działacz ZZ / urlop rodzicielski
□ Staż pracy (po reformie 2025/2026 — uwzględnij zlecenia i JDG!)
□ Czy pracodawca ≥ 20 pracowników? → obowiązek wskazania przyczyny i konsultacji ZZ
□ Zabezpieczenie dowodów — lista poniżej
```

---

## 3. PROCEDURA

### TERMIN 21 DNI — ABSOLUTNY PRIORYTET

```
✅ [VER] RZĄD 1 2026-09-12n, ponownie 2026-09-16 (F-189) — `Dz.U. 2025 poz. 277`.
KROK 2C (odczyt treści 2026-09-16): `Dz.U. 2026 poz. 1046` (w życie 5.11.2026) zmienia w KP
art. 18³ᵃ, 18³ᵈ, 18³ᵉ (+ nowe 18³ᶠ–18³ᵍ), 94, 94³ (+ nowy 94³ᵃ), 104¹; w KPC art. 47, 461
(+ nowy 477⁶ᵃ) — NIE dotyka art. 52, 109, 112, 264, 265, 291.

TERMINY PRACOWNIKA:
Odwołanie od wypowiedzenia:     21 dni od doręczenia pisma wypowiadającego (art. 264 § 1)
Przywrócenie / odszkodowanie
  po rozwiązaniu bez wypowiedzenia
  LUB po WYGAŚNIĘCIU umowy:     21 dni od doręczenia zawiadomienia o rozwiązaniu
                                ALBO od dnia wygaśnięcia umowy (art. 264 § 2)
                                ⛔ przy wygaśnięciu nie ma pisma — termin biegnie od zdarzenia
Żądanie nawiązania umowy:       21 dni od doręczenia zawiadomienia o ODMOWIE przyjęcia
                                do pracy (art. 264 § 3)
Przywrócenie terminu:           7 dni od ustania przyczyny uchybienia; okoliczności
                                trzeba UPRAWDOPODOBNIĆ (art. 265 § 2)
Sprzeciw od kary porządkowej:   7 dni od zawiadomienia o ukaraniu (art. 112 § 1 zd. 1)
  ⭐ MILCZĄCA ZGODA: nieodrzucenie sprzeciwu w 14 dni od wniesienia =
     UWZGLĘDNIENIE sprzeciwu (art. 112 § 1 zd. 3)
  Sąd pracy: 14 dni od zawiadomienia o odrzuceniu — TYLKO po sprzeciwie (art. 112 § 2)
⚠️ TERMIN ZAWITY — nawet bezprawne zwolnienie staje się skuteczne po upływie!
⚠️ Pracodawca często manewruje negocjacjami → pilnuj terminu niezależnie od rozmów

GRANICE DLA PRACODAWCY (⛔ to NIE terminy pracownika — ich upływ to ZARZUT OBRONY):
art. 52 § 2:  dyscyplinarka nie później niż MIESIĄC od uzyskania wiadomości
              o okoliczności — po upływie wadliwa niezależnie od zasadności przyczyny
art. 109 § 1: kara porządkowa — nie po 2 TYGODNIACH od powzięcia wiadomości
              i nie po 3 MIESIĄCACH od naruszenia
art. 109 § 3: gdy pracownik nieobecny i nie może być wysłuchany — bieg 2 tygodni
              nie rozpoczyna się, a rozpoczęty ulega zawieszeniu do stawienia się

PRZEDAWNIENIE (art. 291):
§ 1: 3 lata od wymagalności
§ 2: roszczenie PRACODAWCY o szkodę — rok od powzięcia wiadomości, max 3 lata
     od wyrządzenia; § 3: szkoda UMYŚLNA — przepisy KC
§ 4: terminów nie można skracać ani przedłużać czynnością prawną
§ 5: roszczenie stwierdzone prawomocnym orzeczeniem lub ugodą — 10 lat
```

### Wypowiedzenie — wymogi formalne (art. 30 KP)

```
Przy umowie na czas NIEOKREŚLONY pracodawca MUSI:
  □ Forma pisemna
  □ Konkretna, prawdziwa i rzeczywista przyczyna
    (ogólnikowa lub pozorna → wadliwość = skuteczne odwołanie)
  □ Pouczenie o prawie odwołania w 21 dniach do sądu pracy
  □ Konsultacja ze ZZ (art. 38 KP) gdy ZOZ istnieje

Przy umowie na czas OKREŚLONY:
  □ Forma pisemna
  □ Przyczyna — NIE jest wymagana (art. 30 §4 in fine KP)
    ⚠️ Wyjątek: gdy pracodawca podaje przyczynę → musi być prawdziwa
```

### Okresy wypowiedzenia (art. 36 KP — weryfikuj w ELI (RZĄD 1) po reformie stażu)

| Staż u danego pracodawcy | Okres |
|---|---|
| < 6 miesięcy | 2 tygodnie |
| ≥ 6 miesięcy do < 3 lat | 1 miesiąc |
| ≥ 3 lata | 3 miesiące |

> ⚠️ Po reformie stażu (Dz.U. 2025 poz. 1423) — do stażu wlicza się teraz m.in. zlecenia i JDG. Oblicz staż zgodnie z nowym art. 30² KP.

### Dyscyplinarka (art. 52 KP) — kiedy obalić

```
□ Przekroczenie terminu 1 miesiąca od powzięcia wiadomości przez pracodawcę (art. 52 §2 KP)
  ⚠️ Termin biegnie od wiedzy osoby uprawnionej do rozwiązania umowy
□ Brak kwalifikowanej winy (ciężkie naruszenie obowiązków pracowniczych):
  → Zwykłe niedbalstwo ≠ ciężkie naruszenie
  → Jednorazowe uchybienie przy dobrej historii zatrudnienia
□ Brak konsultacji z ZOZ (art. 52 §3 KP gdy ZOZ istnieje)
□ Nieproporcjonalność — pierwsze naruszenie, brak wcześniejszych ostrzeżeń
□ Brak formy pisemnej
```

### Ochrona szczególna

| Chroniony | Podstawa | Zakres ochrony |
|---|---|---|
| Ciąża | art. 177 KP | Zakaz wypowiedzenia i rozwiązania od momentu zajścia w ciążę |
| Wiek przedemerytalny | art. 39 KP | 4 lata przed uzyskaniem prawa do emerytury |
| Zwolnienie lekarskie (L4) | art. 41 KP | Zakaz w trakcie zwolnienia (do limitów z art. 53 KP) |
| Działacz ZZ | art. 32 ustawy o ZZ | Zakaz bez zgody zarządu ZOZ |
| Urlop macierzyński / rodzicielski | art. 177, 186⁸ KP | Zakaz przez cały urlop — ⚠️ TO JEST tylko aspekt OCHRONNY; pełna treść urlopów (długości, warunki) ✅ NAPRAWIONA 2026-08-13 (F-27): patrz `mod-KP-dzial-VIII-rodzicielstwo.md` |

### Roszczenia pracownika (art. 45 KP)

```
ODSZKODOWANIE (art. 47¹ KP):
  Min.: wynagrodzenie za 2 tygodnie
        (nie mniej niż za okres wypowiedzenia)
  Max.: wynagrodzenie za 3 miesiące
  ⚠️ Dolna granica: 2 TYGODNIE — nie miesiące

PRZYWRÓCENIE DO PRACY + wynagrodzenie za czas procesu (art. 47 KP):
  Standardowo: nie więcej niż 3 miesiące, nie mniej niż 1 miesiąc
  Pracownik chroniony (ciąża, wiek przedemeryt., działacz ZZ):
    → wynagrodzenie za CAŁY czas pozostawania bez pracy — BRAK LIMITU
```

---

## 4. REFORMA STAŻU PRACY (Dz.U. 2025 poz. 1423 — art. 30², 302¹ KP)

```
SEKTOR PUBLICZNY: od 01.01.2026
SEKTOR PRYWATNY: od pierwszego dnia miesiąca po 6 miesiącach od ogłoszenia
  → orientacyjnie ok. 01.04.2026 — WERYFIKUJ aktualną datę w ELI (RZĄD 1)

DO STAŻU WLICZA SIĘ OD TEJ DATY:
  □ Okresy pracy na umowach zlecenia i o świadczenie usług
  □ Okresy prowadzenia jednoosobowej działalności gospodarczej
  □ Służba: Policja, ABW, Straż Graniczna, Służba Więzienna, PSP, wojsko (art. 30²)
  □ Okresy pracy za granicą (udokumentowane)
  □ DZIAŁAJĄ WSTECZ — wcześniejsze okresy też się wliczają po udokumentowaniu

TERMIN NA DOKUMENTACJĘ: 24 miesiące od wejścia ustawy w życie
  → Zaświadczenie z ZUS (nowa procedura elektroniczna: zus.pl)

WPŁYW NA ROSZCZENIA:
  ⚠️ Wymiar urlopu — szybsze osiągnięcie 10 lat → 26 dni
  ⚠️ Okresy wypowiedzenia (art. 36 KP) — mogą być dłuższe niż dotąd
  ⚠️ Odprawy (ustawa o zwolnieniach grupowych) — mogą wzrosnąć
  ⚠️ Dodatki stażowe w sektorze publicznym — automatycznie przeliczane
```

---

## 5. KALKULATOR ROSZCZEŃ FINANSOWYCH

```
NADGODZINY (art. 151¹ KP — weryfikuj w ELI (RZĄD 1)):
  +50%: pn–pt, w porze dziennej
  +100%: pora nocna, niedziele, święta, dobowy odpoczynek

URLOP — ekwiwalent za niewykorzystany:
  Wynagrodzenie z 3 m-cy / liczba dni roboczych w kwartale × liczba dni urlopu
  ⚠️ Oblicz dokładnie — pracodawcy często zaniżają

ODPRAWA (ustawa o zwolnieniach grupowych — weryfikuj **Dz.U. 2026 poz. 1195 t.j.** ✅ [VER] RZĄD 1 2026-09-10r (poprzednio 2025 poz. 570 — wygaśnięcie aktu)):
  Do 2 lat stażu:   1 miesiąc
  2–8 lat stażu:    2 miesiące
  > 8 lat stażu:    3 miesiące
  Max: 15-krotność minimalnego wynagrodzenia
  ⚠️ Minimalne wynagrodzenie 2026: 4 806 zł → max odprawa: 72 090 zł

MINIMALNE WYNAGRODZENIE 2026: 4 806 zł brutto | stawka godzinowa: 31,40 zł
  ⚠️ Weryfikuj co rok: web_search: "minimalne wynagrodzenie 2026 rozporządzenie RM"
```

---

## 6. WŁAŚCIWOŚĆ SĄDU

| Wartość sporu | Sąd |
|---|---|
| Do 75 000 zł | Sąd Rejonowy (wydział pracy) |
| Powyżej 75 000 zł | Sąd Okręgowy |

Właściwość przemienna (wybór pracownika): siedziba pracodawcy / zakład pracy / miejsce zamieszkania pracownika.
Opłata: pracownik zwolniony od kosztów do 75 000 zł.
> ⚠️ Weryfikuj art. 461 KPC w ELI (RZĄD 1).

---

## 7. ZABEZPIECZENIE DOWODÓW — CHECKLISTA NATYCHMIASTOWA

```
Wykonaj przed opuszczeniem stanowiska pracy:
  □ Kopie e-maili dot. wyników i poleceń (wyślij na prywatny adres)
  □ Screenshoty harmonogramów, zadań, komunikatów służbowych
  □ Historia logowań / dane z systemów (dowód nadgodzin)
  □ Zaświadczenie Rp-7 o zarobkach — żądaj na piśmie od razu
  □ Karta urlopowa — kopia salda urlopu
  □ Nagrania własnych rozmów z przełożonym (LEGALNE w Polsce)
  □ Lista świadków: imiona, nazwiska, kontakty
  □ Kopie umów o pracę, aneksów, regulaminów
  □ Dokumentacja szkoleń i certyfikatów
```

---

## 8. DOWODY

| Teza | Dowód | Źródło | Siła | Luka | Działanie |
|---|---|---|---|---|---|
| Ogólnikowość przyczyny | Treść pisma wypowiedzenia | pracodawca | wysoka | brak pisma | żądaj formy pisemnej |
| Ochrona ciążowa | Zaświadczenie lekarskie | lekarz | wysoka | data zaświadczenia | powiedz pracodawcy w trakcie |
| Przekroczenie terminu dyscyplinarki | Data pisma vs data wiedzy pracodawcy | korespondencja / zeznania | wysoka | sporna data wiedzy | zeznania świadków |
| Brak konsultacji ZZ | Brak pisma do ZOZ / brak odpowiedzi | dokumenty HR | wysoka | ustna konsultacja | żądaj potwierdzenia na piśmie |
| Nadgodziny | Listy obecności, maile, logi systemów | systemy IT | średnia | brak rejestracji | żądaj ewidencji czasu pracy |
| Wyższe wynagrodzenie niż umowa | Paski płacowe, przelewy bankowe | bank | wysoka | wypłaty gotówkowe | świadkowie |

---

## 9. STRATEGIA

### Perspektywa pracownika

1. Oblicz termin 21 dni — to absolutny priorytet.
2. Nie podpisuj porozumienia bez konsultacji z prawnikiem — porozumienie = brak odwołania + karencja zasiłku.
3. Oceń czy warto żądać przywrócenia czy odszkodowania (szczególnie przy ochronie szczególnej).
4. Zgromadź dowody PRZED opuszczeniem miejsca pracy.
5. Po reformie stażu: sprawdź czy nowe wliczenie zlecenia/JDG wydłuża staż → wyższe roszczenia.

### Perspektywa pracodawcy

1. Konkretna przyczyna — ogólnikowa to ryzyko wadliwości.
2. Zachowaj termin 1 miesiąca na dyscyplinarkę od powzięcia wiedzy.
3. Skonsultuj ZOZ jeśli istnieje — brak konsultacji = wadliwość.
4. Udokumentuj podstawę dyscyplinarki zanim wręczysz pismo.
5. Przy zwolnieniu grupowym — zachowaj procedurę (konsultacja, PIP, PUP, 30 dni).

### Kontrargumenty / ryzyka

| Ryzyko | Opis | Działanie zaradcze |
|---|---|---|
| Utrata terminu 21 dni | Termin zawity — brak przywrócenia | Priorytet absolutny — złóż odwołanie niezwłocznie |
| Podpisanie porozumienia | Brak odwołania, karencja zasiłku | Nie podpisuj bez analizy prawnej |
| Brak dowodów | Niemożność wykazania roszczeń | Zabezpieczaj dowody natychmiast |
| Kwalifikacja prawna stosunku pracy | B2B zakwalifikowany jako pracowniczy | Analiza cech stosunku pracy (art. 22 KP); dla umowy ramowej zlecenia z systemem oferta–przyjęcie poszczególnych zleceń → `analizator-umow-v1/references/b2b-podwykonawcze.md` sekcja G.1D (dodane 2026-09-27, F-205) |

---

## 10. ORZECZNICTWO

Nie twórz fikcyjnych sygnatur. Źródła: sn.pl, orzeczenia.ms.gov.pl.

```
web_search: "ogólnikowa przyczyna wypowiedzenia wadliwość SN prawo pracy 2025 2026"
web_search: "dyscyplinarka termin 1 miesiąc wiedza pracodawcy art 52 §2 KP SN"
web_search: "ochrona ciążowa art 177 KP przywrócenie wynagrodzenie SN"
web_search: "reforma stażu pracy 2025 zlecenie JDG art 30(2) KP orzecznictwo"
```

---

## 11. QUALITY GATE

- [ ] Termin 21 dni obliczony i sprawdzony?
- [ ] Rodzaj umowy i tryb rozwiązania ustalony?
- [ ] Ochrona szczególna sprawdzona?
- [ ] Staż po reformie (poz. 1423) obliczony?
- [ ] Minimalne wynagrodzenie 2026 zweryfikowane (4 806 zł)?
- [ ] Każda przesłanka ma przypisany dowód?
- [ ] Właściwość sądu (SR/SO) ustalona?

---

## 12. OUTPUT

1. Stan faktyczny; 2. Kwalifikacja trybu rozwiązania; 3. Stan prawny (Dz.U. z ISAP); 4. Termin 21 dni (data graniczna); 5. Ochrona szczególna (tak/nie/wątpliwa); 6. Matryca dowodowa; 7. Kalkulator roszczeń (odszkodowanie / przywrócenie / nadgodziny / odprawa / ekwiwalent); 8. Analiza ryzyk; 9. Strategia; 10. Predykcja wyniku (IN PLUS / IN MINUS); 11. Rekomendacja (sąd / ugoda / negocjacje); 12. Kontrola ISAP/temporalności.

---

## PREDYKCJA WYNIKU — SZABLON

```
Szanse na wygraną: [0–100%]
IN PLUS: terminowe odwołanie, ochrona szczególna, brak uzasadnienia / ogólnikowe
IN MINUS: porozumienie podpisane, brak dowodów, termin przekroczony
BENCHMARKING: → wywołaj orzeczenia-sadowe-v2
  (NIGDY nie cytuj sygnatur z pamięci — ZAWSZE weryfikuj online)
REKOMENDACJA: □ Sąd — odwołanie  □ Ugoda / negocjacje  □ PIP
```

---

## POWIĄZANIA

| Sytuacja | Skill / Moduł |
|---|---|
| Mobbing / dyskryminacja | `dr-04-prawo-pracy-zus-swiadczenia/modules/mod-KP-mobbing-dyskryminacja.md` |
| Zwolnienia grupowe | `mod-ustawa-zwolnienia-grupowe` |
| Inspekcja pracy | `mod-ustawa-PIP-inspekcja-pracy` |
| ZUS (składki, zasiłki) | `mod-SUS-ZUS-ubezpieczenia-spoleczne` |
| Pismo: pozew / odwołanie | `pisma-procesowe-v3` |
| Orzecznictwo SN pracy | `orzeczenia-sadowe-v2` |
| Redakcja/audyt: regulamin pracy/wynagradzania (⚡ próg 50 pracowników od Dz.U. 2026/25), ZFŚS, monitoringu, RODO wewnętrzne | `analizator-umow-v1` → `mod-J21-rodo-archiwizacja-regulaminy.md` (J21) |

---

## ŹRÓDŁA ONLINE

- KP: https://isap.sejm.gov.pl/isap.nsf/DocDetails.xsp?id=WDU20250000277
- ISAP: https://isap.sejm.gov.pl
- SN: https://www.sn.pl
- Orzeczenia sądów pracy: https://orzeczenia.ms.gov.pl


## ANEKSY — WYDZIELONE 2026-06-12 (dawne ANEKS A/B/C)

Trzy aneksy tematyczne wydzielone do samodzielnych modułów — lazy loading:
ten moduł (rozwiązanie umowy o pracę) NIE wymaga ładowania treści o mobbingu,
wypadkach przy pracy czy pracy zdalnej, jeśli sprawa ich nie dotyczy.

- **Mobbing, dyskryminacja, molestowanie** (kwalifikacja różnicująca,
  strategia procesowa, projekt nowelizacji UD183/RM 17.02.2026):
  → `view dr-04-prawo-pracy-zus-swiadczenia/modules/mod-KP-mobbing-dyskryminacja.md`
  → definicja i linia SN: `shared/definicje/DEF-PRACA.md`

- **Wypadek przy pracy i choroba zawodowa** (intake, świadczenia ZUS,
  terminy, ścieżka sporna):
  → `view dr-04-prawo-pracy-zus-swiadczenia/modules/mod-wypadek-przy-pracy-choroba-zawodowa.md`
  → definicja (4 elementy): `shared/definicje/DEF-PRACA.md` (H.1.4)

- **Praca zdalna** (art. 67⁵-67²⁴ KP — obowiązki, BHP, praca okazjonalna):
  → `view dr-04-prawo-pracy-zus-swiadczenia/modules/mod-KP-praca-zdalna.md`
  → wykładnia MRiPS: `shared/ORKA-BAS-VIII-X-KADENCJA.md` BAS-W03

⚠️ KRZYŻOWE PRZYPADKI: mobbing/wypadek/praca zdalna MOGĄ być przyczyną
rozwiązania umowy z winy pracodawcy (art. 55 §1¹ KP) — wtedy załaduj
ten moduł (rdzeń) RAZEM z odpowiednim aneksem.
