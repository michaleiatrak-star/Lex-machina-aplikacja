# CHANGELOG — dr-05-prawo-administracyjne-sadowoadministracyjne

- 3.34 (2026-10-09g, AUDYT-2026-10-09g): ⛔ mod-ustawa-zaskarzanie-decyzji-wlasnosci: nowelizacja KPA art. 156 §2 to ustawa z 11.08.2021, Dz.U. 2021 poz. 1491 (było „z 09.06.2021, Dz.U. 2021 poz. 1706” — rozp. MKiŚ). ELI 2026-10-09.

- 3.33 (2026-10-09, AUDYT-2026-10-09): cudzoziemcy: świadczenia rodzinne — t.j. Dz.U. 2026 poz. 1240 (ELI 2026-10-09).

- 3.32 (2026-10-05l, AUDYT-2026-10-05l): Linie „Hasła spraw” w mod-ustawa-cudzoziemcy i mod-KPA-tryby-nadzwyczajne-i-strategia. Treść prawna bez zmian.

- 3.31 (2026-09-27e, AUDYT-2026-09-27e): claude.ai po dodaniu marketplace instalował wyłącznie 4 z 32 pluginów (shared, prawny-router-v3, analizator-dowodow-v3, przesluchanie-swiadkow-v2-min90); jedyna cecha wspólna tych 4, nieobecna w żadnym z 28 pozostałych, to klucz `dependencies` we frontmatterze SKILL.md. Dodano go (`requires: [shared]` — zgodnie ze stanem faktycznym) oraz jawny manifest pluginu (name, description = description z SKILL.md, author, repository, license) — host nie musi niczego wnioskować z SKILL.md. `version` w manifeście = `version:` z SKILL.md (pilnuje T38 w audyt-systemu-v4) — host rozpoznaje aktualizację po podbiciu wersji. Treść skilla bez zmian.
- 3.30 (2026-09-23, AUDYT-2026-09-23c): SKILL.md: „Źródło podstawowe” — LEX/Legalis → ArsLege gdy aktu nie da się pobrać z RZĘDU 1 (awaria serwera, timeout, blokada); korekta użytkownika do warunku E-3.
- 3.29 (2026-09-23, AUDYT-2026-09-23b): kanon E-1…E-5 (`shared/HIERARCHIA-ZRODEL.md` 1.10): instrukcje weryfikacji „w ISAP” / „isap.sejm.gov.pl →” zamienione na „w ELI (RZĄD 1)” (13 plików); ISAP pozostaje adresem dla człowieka; wpisy historyczne („zweryfikowano w ISAP …”) bez zmian.
- 3.28 (2026-09-16, F-189): F-135 (RZĄD 1 — KPA 2025/1691, PPSA 2026/143): mod-ustawa-zaskarzanie-decyzji-wlasnosci — art. 156 § 2 (10 lat) i 158 § 3 (30 lat) rozdzielone; ⛔ art. 160 KPA uchylony → art. 417¹ § 2 KC; mod-KPA — organ przekazuje skargę w 30 dni (nie 15), autokontrola z art. 54 § 3; mod-ustawa-cudzoziemcy — termin skargi z art. 53 § 1 (nie 54 § 1); mod-PPSA-terminy — art. 259 § 1 w zakresie art. 258 § 2 pkt 6–8, RZĄD 1 zamiast źródła wtórnego, wniosek o art. 53 § 3 oznaczony jako interpretacja.
- 3.27 (2026-09-16, F-189): ODTWORZENIE utraconego wydania 3.26 (F-189), RZĄD 1 (UPEA Dz.U. 2026 poz. 268; KROK 2C poz. 516 i 739 — tylko art. 3a i sprzedaż): CRIT — termin zarzutu „7 dni od TW” nie istnieje, terminy końcowe art. 33 § 5; katalog zamknięty art. 33 § 2 (6 podstaw); „zbyt uciążliwy środek” → skarga art. 54 § 1 pkt 2; skarga na czynność 7 dni od doręczenia odpisu dokumentu (art. 54 § 3, nie „14 dni od czynności”); art. 15 § 1–2; kwota wolna — art. 54 ust. 1 Prawa bankowego (Dz.U. 2026 poz. 38).
- 3.26 — LUKA JAWNA: wydanie AUDYT-2026-09-12h nieobecne na dysku — odtworzone w 3.27
- 3.25 (2026-09-12g): mod-UDIP-dostep-informacji-publicznej - mapa proceduralna opisywala art. 52 par. 3 PPSA jako droge "gdy podmiot bez wyzszego organu". Odczyt tresci (Dz.U. 2026 poz. 143) wykazal, ze przepis pozwala wniesc skarge BEZ uprzedniego wniosku o ponowne rozpatrzenie ZAWSZE, gdy taki wniosek przysluguje - z wyjatkiem decyzji ministra ds. zagranicznych w sprawach z ustawy o cudzoziemcach i decyzji konsula. Dopisane: art. 52 par. 4 PPSA jest UCHYLONY, a "wezwanie do usuniecia naruszenia prawa" zniknelo z procedury w 2017 r.
- 3.24 (2026-09-10o, F-181): nieprawdziwa adnotacja o braku nowszego tekstu jednolitego przy ustawie o kontroli w administracji rzadowej skorygowana: aktualny t.j. Dz.U. 2026 poz. 158 (RZAD 1)
- 3.23 (2026-08-27): dodano moduł uzupełniający pozostałe działy PPSA i zsynchronizowano MAPA-AKTOW, MAPA-POKRYCIA i routing.

- 3.22 (2026-08-27): F-108/45 — wydzielono ustawę o wojewodzie i administracji rządowej w województwie do dedykowanego modułu B+ (RZĄD 1 ELI).

- 3.21 (2026-08-26): poprawiono metryki KPA/PPSA i aktów ustrojowych oraz
  precyzyjnie odwzorowano zmianę PPSA z Dz.U. 2026 poz. 846.
