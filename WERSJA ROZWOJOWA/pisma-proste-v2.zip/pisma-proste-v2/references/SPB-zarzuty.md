# SPB — Zarzuty od Nakazu Zapłaty

*Ładuj gdy: nakaz zapłaty wydany w postępowaniu nakazowym (nie upominawczym).
Termin zawity: **miesiąc** od doręczenia nakazu na terytorium UE, w tym w Polsce
(art. 480² § 2 pkt 3 KPC); poza UE — 3 miesiące (pkt 4).
Opłata: **3/4 opłaty od pozwu**; gdy nakaz wydano przeciwko konsumentowi —
od pozwanego konsumenta **nie więcej niż 750 zł** (art. 19 ust. 4 KSCU).*
✅ [VER] RZĄD 1 2026-09-16 — KPC `Dz.U. 2026 poz. 468`, KSCU `Dz.U. 2025 poz. 1228`.

---

## PODSTAWA PRAWNA

- **art. 493 § 1 KPC** — zarzuty od nakazu zapłaty (przepis mówi, ŻE przysługują; terminu NIE zawiera)
- **art. 480² § 2 pkt 3 KPC** — termin: miesiąc od doręczenia na terytorium UE
- **art. 480³ KPC** — tryb: do sądu, który wydał nakaz
- **art. 19 ust. 4 KSCU** — opłata od zarzutów = 3/4 opłaty; od konsumenta max 750 zł (KSCU dzieli się na ustępy, nie paragrafy)
- **art. 492 §1 KPC** — nakaz zapłaty w postępowaniu nakazowym ma rygor natychmiastowej wykonalności

> ⚠ Weryfikuj przepisy na ELI (RZĄD 1) przed użyciem.

---

## RÓŻNICA MIĘDZY SPA A SPB

| Cecha | Sprzeciw (SPA) | Zarzuty (SPB) |
|---|---|---|
| Tryb | Upominawczy / EPU | **Nakazowy** |
| Termin | **2 tygodnie** (kraj) / miesiąc (UE poza krajem) | ⛔ **MIESIĄC** przy doręczeniu na terytorium UE, w tym w Polsce / 3 miesiące poza UE |
| Opłata | brak | **3/4 wpisu** |
| Podstawa terminu | **art. 480² § 2 pkt 1–2 KPC** | **art. 480² § 2 pkt 3–4 KPC** |
| Podstawa dopuszczalności | art. 505 § 1 KPC (⛔ art. 503 UCHYLONY) | art. 493 § 1 KPC (nie zawiera terminu) |
| Skutek | Nakaz traci moc | Nakaz **nie traci** mocy — sprawa toczy się dalej |
| Rygor | Brak | Nakaz nakazowy = tytuł wykonawczy od razu |

> ⚠ Zarzuty NIE wstrzymują wykonalności nakazu nakazowego — rozważ wniosek
> o zawieszenie rygoru natychmiastowej wykonalności (art. 492 §3 KPC).

---

## DANE WYMAGANE (z M2-intake.md)

```
□ Imię i nazwisko / firma pozwanego (wnoszącego zarzuty)
□ Adres pozwanego + PESEL lub NIP
□ Nazwa sądu i wydział
□ Sygnatura nakazu zapłaty
□ Data doręczenia nakazu (wyznacza termin 7-dniowy)
□ Kwota z nakazu (należność + odsetki + koszty)
□ Dokument będący podstawą nakazu (weksel, czek, uznane roszczenie?)
□ Zarzuty merytoryczne lub formalne
□ Dane powoda
```

---

## KALKULACJA OPŁATY

```
WPS (wartość przedmiotu sporu) = kwota z nakazu
Opłata podstawowa wg art. 27 KSCU:
  do 500 zł    →  30 zł
  do 1 500 zł  → 100 zł
  do 4 000 zł  → 200 zł
  do 7 500 zł  → 400 zł
  do 15 000 zł → 500 zł
  do 20 000 zł → 750 zł
  > 20 000 zł  → 5% WPS, max 100 000 zł (⚠️ POPRAWKA 2026-07-27: było błędnie "200 000 zł", obniżone reformą z 25.07.2025)

Opłata od zarzutów = 3/4 × opłata podstawowa
Weryfikuj w aktualnej wersji KSCU na ELI (RZĄD 1).
```

---

## SZABLON PISMA

```
[Miejscowość], dnia [DD miesiąc RRRR] r.

[Imię i nazwisko / Nazwa firmy Pozwanego]
[Adres]
[PESEL: XXXXXXXXXXX / NIP: XXX-XXX-XX-XX]

                        [Nazwa Sądu]
                        [Wydział]
                        [Adres sądu]

Sygn. akt: [sygnatura nakazu]

            ZARZUTY OD NAKAZU ZAPŁATY

Działając w imieniu własnym, wnoszę zarzuty od nakazu zapłaty
wydanego przez [Sąd] w postępowaniu nakazowym w dniu [data nakazu]
w sprawie sygn. akt [sygnatura], doręczonego w dniu [data doręczenia].

                        WNOSZĘ O:

1. Uchylenie nakazu zapłaty w całości / w części [wskazać zakres].
2. Oddalenie powództwa w całości / w części.
3. [Opcjonalnie]: Uchylenie rygoru natychmiastowej wykonalności nakazu
   do czasu prawomocnego rozstrzygnięcia sprawy (art. 492 §3 KPC).
4. Zasądzenie od powoda na rzecz pozwanego kosztów postępowania
   według norm przepisanych.

                       UZASADNIENIE

[ZARZUTY FORMALNE — jeśli dotyczy]
[np. nakaz wydany na podstawie nieautentycznego lub niepełnego dokumentu,
brak wymaganych dokumentów z art. 485 KPC, niewłaściwość sądu]

[ZARZUTY MERYTORYCZNE]
[Opis: dlaczego roszczenie nie jest zasadne — spełnienie zobowiązania,
potrącenie (art. 498 KC), nieważność dokumentu, przedawnienie,
brak podstawy prawnej, zapłata częściowa, etc.]

[OCENA PRAWNA]
[Przepis uzasadniający zarzut — zweryfikowany online.]

[KONKLUZJA]
W świetle powyższego wnoszę jak na wstępie.

Opłata sądowa od zarzutów w kwocie [X] zł uiszczona
— dowód uiszczenia w załączniku nr [Y].

Załączniki:
1. Dowód uiszczenia opłaty sądowej w kwocie [X] zł.
2. Odpis zarzutów dla powoda.
3. [inne dokumenty]

                        [Miejscowość], dnia [data]
                        ___________________________
                        [Imię i nazwisko / podpis]
```

---

## UWAGI SZCZEGÓLNE

- Nakaz nakazowy ma **rygor natychmiastowej wykonalności** z chwilą wydania —
  powód może wszcząć egzekucję zanim sprawa się skończy. Rozważ wniosek z art. 492 §3 KPC.
- W zarzutach od weksla → wskaż zarzuty wekslowe (wypełnienie niezgodne z porozumieniem,
  zarzut ze stosunku podstawowego — art. 10 prawa wekslowego).
- Zarzuty muszą być **kompletne** — późniejsze rozszerzenie jest ograniczone (art. 495 §3 KPC).

---

## ESKALACJA DO pisma-procesowe-v3

Eskaluj gdy:
- konieczna analiza prawa wekslowego lub czekowego w zakresie wykraczającym poza
  proste zarzuty ze stosunku podstawowego,
- potrzeba wielu orzeczeń SN lub analiza linii orzeczniczej,
- sprawa ma wątek wzajemny.
